﻿using System;

// Token: 0x0200003F RID: 63
internal static class 353B51DA
{
	// Token: 0x060002E3 RID: 739 RVA: 0x001C1430 File Offset: 0x001BF230
	internal static void 28DD3762(uint[] 0400232B)
	{
		int i = 0;
		uint num = 0U;
		while (i < 0400232B.Length)
		{
			num = ~0400232B[i] + 1U;
			0400232B[i] = num;
			if (num != 0U)
			{
				i++;
				break;
			}
			i++;
		}
		if (num != 0U)
		{
			while (i < 0400232B.Length)
			{
				0400232B[i] = ~0400232B[i];
				i++;
			}
			return;
		}
		0400232B = 353B51DA.429A684B(0400232B, 0400232B.Length + 1);
		0400232B[0400232B.Length - 1] = 1U;
	}

	// Token: 0x060002E4 RID: 740 RVA: 0x001C1490 File Offset: 0x001BF290
	private static uint[] 429A684B(uint[] 09447161, int 7A3E2ABB)
	{
		if (09447161.Length == 7A3E2ABB)
		{
			return 09447161;
		}
		uint[] array = new uint[7A3E2ABB];
		int num = Math.Min(09447161.Length, 7A3E2ABB);
		for (int i = 0; i < num; i++)
		{
			array[i] = 09447161[i];
		}
		return array;
	}

	// Token: 0x060002E5 RID: 741 RVA: 0x001C14CC File Offset: 0x001BF2CC
	internal static void 1E1A513A<T>(ref T 4BF6545D, ref T 2A560091)
	{
		T t = 4BF6545D;
		4BF6545D = 2A560091;
		2A560091 = t;
	}

	// Token: 0x060002E6 RID: 742 RVA: 0x001C14F3 File Offset: 0x001BF2F3
	internal static ulong 1EA114CC(uint 445C78B8, uint 22D93B8C)
	{
		return (ulong)445C78B8 << 32 | (ulong)22D93B8C;
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x001C14FD File Offset: 0x001BF2FD
	internal static uint 1F176203(ulong 26221A83)
	{
		return (uint)26221A83;
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x001C1501 File Offset: 0x001BF301
	internal static uint 3B4D32F1(ulong 6A645761)
	{
		return (uint)(6A645761 >> 32);
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x001C1508 File Offset: 0x001BF308
	private static uint 446A5E04(uint 0F7A6B33, uint 086B2A4B)
	{
		return (0F7A6B33 << 7 | 0F7A6B33 >> 25) ^ 086B2A4B;
	}

	// Token: 0x060002EA RID: 746 RVA: 0x001C1514 File Offset: 0x001BF314
	internal static int 419A765A(int 780654F5, int 0B3562FD)
	{
		return (int)353B51DA.446A5E04((uint)780654F5, (uint)0B3562FD);
	}

	// Token: 0x060002EB RID: 747 RVA: 0x001C1520 File Offset: 0x001BF320
	internal static int 27811C05(uint 06F80841)
	{
		if (06F80841 == 0U)
		{
			return 32;
		}
		int num = 0;
		if ((06F80841 & 4294901760U) == 0U)
		{
			num += 16;
			06F80841 <<= 16;
		}
		if ((06F80841 & 4278190080U) == 0U)
		{
			num += 8;
			06F80841 <<= 8;
		}
		if ((06F80841 & 4026531840U) == 0U)
		{
			num += 4;
			06F80841 <<= 4;
		}
		if ((06F80841 & 3221225472U) == 0U)
		{
			num += 2;
			06F80841 <<= 2;
		}
		if ((06F80841 & 2147483648U) == 0U)
		{
			num++;
		}
		return num;
	}

	// Token: 0x04000182 RID: 386
	private const int 2F2822DC = 32;
}
