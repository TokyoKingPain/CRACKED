﻿using System;

// Token: 0x0200002F RID: 47
public class 51E33AD3
{
	// Token: 0x06000205 RID: 517 RVA: 0x002FC264 File Offset: 0x002F9E64
	public 51E33AD3()
	{
		this.09D122D5 = 999776346U;
	}

	// Token: 0x06000206 RID: 518 RVA: 0x002FC278 File Offset: 0x002F9E78
	public uint 73DC7C62(uint 5A5C6280)
	{
		uint num = 5A5C6280 ^ this.09D122D5;
		this.09D122D5 = (00542DE3.5403126C(this.09D122D5, 7) ^ num);
		return num;
	}

	// Token: 0x04000129 RID: 297
	private uint 09D122D5;
}
