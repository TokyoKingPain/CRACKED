﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x0200000B RID: 11
internal class eliteBorderLabel : ThemeControl154
{
	// Token: 0x0600011F RID: 287 RVA: 0x00005690 File Offset: 0x00003A90
	public eliteBorderLabel()
	{
		base.SetColor("DownGradient1", 42, 42, 42);
		base.SetColor("DownGradient2", 42, 42, 42);
		base.SetColor("Text", 254, 254, 254);
		base.SetColor("Border1", 35, 35, 35);
		base.SetColor("Border2", 42, 42, 42);
	}

	// Token: 0x06000120 RID: 288 RVA: 0x00005704 File Offset: 0x00003B04
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("DownGradient1");
		this.C2 = base.GetColor("DownGradient2");
		this.B1 = new SolidBrush(base.GetColor("Text"));
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x06000121 RID: 289 RVA: 0x00005778 File Offset: 0x00003B78
	protected override void PaintHook()
	{
		base.DrawGradient(this.C1, this.C2, base.ClientRectangle, 90f);
		base.DrawText(this.B1, HorizontalAlignment.Center, 0, 0);
		base.DrawBorders(this.P1, 1);
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x0400007B RID: 123
	private Color C1;

	// Token: 0x0400007C RID: 124
	private Color C2;

	// Token: 0x0400007D RID: 125
	private SolidBrush B1;

	// Token: 0x0400007E RID: 126
	private Pen P1;

	// Token: 0x0400007F RID: 127
	private Pen P2;
}
