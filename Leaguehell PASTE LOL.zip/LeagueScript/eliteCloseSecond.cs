﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000010 RID: 16
internal class eliteCloseSecond : ThemeControl154
{
	// Token: 0x06000130 RID: 304 RVA: 0x0000613C File Offset: 0x0000453C
	public eliteCloseSecond()
	{
		base.SetColor("DownGradient1", 210, 15, 13);
		base.SetColor("DownGradient2", 243, 97, 24);
		base.SetColor("NoneGradient1", 50, 50, 50);
		base.SetColor("NoneGradient2", 42, 42, 42);
		base.SetColor("ClickedGradient1", 247, 127, 30);
		base.SetColor("ClickedGradient2", 210, 15, 13);
		base.SetColor("Text", 254, 254, 254);
		base.SetColor("Border1", 35, 35, 35);
		base.SetColor("Border2", 42, 42, 42);
	}

	// Token: 0x06000131 RID: 305 RVA: 0x00006200 File Offset: 0x00004600
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("DownGradient1");
		this.C2 = base.GetColor("DownGradient2");
		this.C3 = base.GetColor("NoneGradient1");
		this.C4 = base.GetColor("NoneGradient2");
		this.C5 = base.GetColor("ClickedGradient1");
		this.C6 = base.GetColor("ClickedGradient2");
		this.B1 = new SolidBrush(base.GetColor("Text"));
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x06000132 RID: 306 RVA: 0x000062B8 File Offset: 0x000046B8
	protected override void PaintHook()
	{
		if (this.State == MouseState.Over)
		{
			base.DrawGradient(this.C1, this.C2, base.ClientRectangle, 90f);
			this.Text = "x";
		}
		else if (this.State == MouseState.Down)
		{
			base.DrawGradient(this.C6, this.C5, base.ClientRectangle, 90f);
			this.Text = "x";
		}
		else
		{
			base.DrawGradient(this.C3, this.C4, base.ClientRectangle, 90f);
		}
		base.DrawText(this.B1, HorizontalAlignment.Center, 0, 0);
		base.DrawBorders(this.P1, 1);
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x040000A5 RID: 165
	private Color C1;

	// Token: 0x040000A6 RID: 166
	private Color C2;

	// Token: 0x040000A7 RID: 167
	private Color C3;

	// Token: 0x040000A8 RID: 168
	private Color C4;

	// Token: 0x040000A9 RID: 169
	private Color C5;

	// Token: 0x040000AA RID: 170
	private Color C6;

	// Token: 0x040000AB RID: 171
	private SolidBrush B1;

	// Token: 0x040000AC RID: 172
	private Pen P1;

	// Token: 0x040000AD RID: 173
	private Pen P2;
}
