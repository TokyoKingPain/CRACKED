﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x0200000D RID: 13
internal class eliteHideSecond : ThemeControl154
{
	// Token: 0x06000127 RID: 295 RVA: 0x00005A48 File Offset: 0x00003E48
	public eliteHideSecond()
	{
		base.SetColor("DownGradient1", 140, 138, 27);
		base.SetColor("DownGradient2", 180, 196, 114);
		base.SetColor("NoneGradient1", 50, 50, 50);
		base.SetColor("NoneGradient2", 42, 42, 42);
		base.SetColor("ClickedGradient1", 204, 201, 35);
		base.SetColor("ClickedGradient2", 140, 138, 27);
		base.SetColor("Text", 254, 254, 254);
		base.SetColor("Border1", 35, 35, 35);
		base.SetColor("Border2", 42, 42, 42);
	}

	// Token: 0x06000128 RID: 296 RVA: 0x00005B18 File Offset: 0x00003F18
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("DownGradient1");
		this.C2 = base.GetColor("DownGradient2");
		this.C3 = base.GetColor("NoneGradient1");
		this.C4 = base.GetColor("NoneGradient2");
		this.C5 = base.GetColor("ClickedGradient1");
		this.C6 = base.GetColor("ClickedGradient2");
		this.B1 = new SolidBrush(base.GetColor("Text"));
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x06000129 RID: 297 RVA: 0x00005BD0 File Offset: 0x00003FD0
	protected override void PaintHook()
	{
		if (this.State == MouseState.Over)
		{
			base.DrawGradient(this.C1, this.C2, base.ClientRectangle, 90f);
			this.Text = "_";
		}
		else if (this.State == MouseState.Down)
		{
			base.DrawGradient(this.C6, this.C5, base.ClientRectangle, 90f);
			this.Text = "_";
			Application.OpenForms[1].WindowState = FormWindowState.Minimized;
		}
		else
		{
			base.DrawGradient(this.C3, this.C4, base.ClientRectangle, 90f);
		}
		base.DrawText(this.B1, HorizontalAlignment.Center, 0, 0);
		base.DrawBorders(this.P1, 1);
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x0400008A RID: 138
	private Color C1;

	// Token: 0x0400008B RID: 139
	private Color C2;

	// Token: 0x0400008C RID: 140
	private Color C3;

	// Token: 0x0400008D RID: 141
	private Color C4;

	// Token: 0x0400008E RID: 142
	private Color C5;

	// Token: 0x0400008F RID: 143
	private Color C6;

	// Token: 0x04000090 RID: 144
	private SolidBrush B1;

	// Token: 0x04000091 RID: 145
	private Pen P1;

	// Token: 0x04000092 RID: 146
	private Pen P2;
}
