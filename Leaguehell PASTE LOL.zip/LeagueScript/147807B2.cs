﻿using System;

// Token: 0x02000040 RID: 64
internal abstract class 147807B2
{
	// Token: 0x060002EC RID: 748 RVA: 0x0030AC4C File Offset: 0x0030884C
	public static uint 0B47086B(uint 5A462615)
	{
		5A462615 -= 2U;
		if (5A462615 < 4U)
		{
			return 5A462615;
		}
		return 3U;
	}

	// Token: 0x04000183 RID: 387
	public const uint 66F93E06 = 12U;

	// Token: 0x04000184 RID: 388
	public const int 17A02AC0 = 6;

	// Token: 0x04000185 RID: 389
	private const int 1D0C60D4 = 2;

	// Token: 0x04000186 RID: 390
	public const uint 2C661025 = 4U;

	// Token: 0x04000187 RID: 391
	public const uint 2FF953F7 = 2U;

	// Token: 0x04000188 RID: 392
	public const int 6F7C10A6 = 4;

	// Token: 0x04000189 RID: 393
	public const uint 736A5405 = 4U;

	// Token: 0x0400018A RID: 394
	public const uint 447075AB = 14U;

	// Token: 0x0400018B RID: 395
	public const uint 6EF95EBC = 128U;

	// Token: 0x0400018C RID: 396
	public const int 345C5CF2 = 4;

	// Token: 0x0400018D RID: 397
	public const uint 5E3B42F1 = 16U;

	// Token: 0x0400018E RID: 398
	public const int 0E0E6827 = 3;

	// Token: 0x0400018F RID: 399
	public const int 71FD6CCA = 3;

	// Token: 0x04000190 RID: 400
	public const int 51670AB5 = 8;

	// Token: 0x04000191 RID: 401
	public const uint 36CD422D = 8U;

	// Token: 0x04000192 RID: 402
	public const uint 6A0169DB = 8U;

	// Token: 0x02000075 RID: 117
	public struct 0FF55DB6
	{
		// Token: 0x0600049E RID: 1182 RVA: 0x00310800 File Offset: 0x0030E400
		public void 374763C8()
		{
			this.69D2529A = 0U;
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x0031080C File Offset: 0x0030E40C
		public void 6D9E313C()
		{
			if (this.69D2529A < 4U)
			{
				this.69D2529A = 0U;
				return;
			}
			if (this.69D2529A < 10U)
			{
				this.69D2529A -= 3U;
				return;
			}
			this.69D2529A -= 6U;
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x0031084C File Offset: 0x0030E44C
		public void 556E2469()
		{
			this.69D2529A = ((this.69D2529A < 7U) ? 7U : 10U);
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x00310868 File Offset: 0x0030E468
		public void 2AB50C47()
		{
			this.69D2529A = ((this.69D2529A < 7U) ? 8U : 11U);
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x00310884 File Offset: 0x0030E484
		public void 5F9D3D29()
		{
			this.69D2529A = ((this.69D2529A < 7U) ? 9U : 11U);
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x003108A4 File Offset: 0x0030E4A4
		public bool 1ED2481F()
		{
			return this.69D2529A < 7U;
		}

		// Token: 0x04000212 RID: 530
		public uint 69D2529A;
	}
}
