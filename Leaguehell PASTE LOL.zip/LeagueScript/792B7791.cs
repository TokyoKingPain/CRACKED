﻿using System;

// Token: 0x02000043 RID: 67
internal struct 792B7791
{
	// Token: 0x060002F9 RID: 761 RVA: 0x0030B458 File Offset: 0x00309058
	public void 2A5E052D()
	{
		this.39532462 = 1024U;
	}

	// Token: 0x060002FA RID: 762 RVA: 0x0030B468 File Offset: 0x00309068
	public uint 638962C8(3EA83B76 22034997)
	{
		uint num = (22034997.4550755C >> 11) * this.39532462;
		if (22034997.77710334 < num)
		{
			22034997.4550755C = num;
			this.39532462 += 2048U - this.39532462 >> 5;
			if (22034997.4550755C < 16777216U)
			{
				22034997.77710334 = (22034997.77710334 << 8 | (uint)((byte)22034997.0FD9684F.ReadByte()));
				22034997.4550755C <<= 8;
			}
			return 0U;
		}
		22034997.4550755C -= num;
		22034997.77710334 -= num;
		this.39532462 -= this.39532462 >> 5;
		if (22034997.4550755C < 16777216U)
		{
			22034997.77710334 = (22034997.77710334 << 8 | (uint)((byte)22034997.0FD9684F.ReadByte()));
			22034997.4550755C <<= 8;
		}
		return 1U;
	}

	// Token: 0x040001AA RID: 426
	private const int 0E800A89 = 11;

	// Token: 0x040001AB RID: 427
	private const uint 7D115CC5 = 2048U;

	// Token: 0x040001AC RID: 428
	private const int 163324FD = 5;

	// Token: 0x040001AD RID: 429
	private uint 39532462;
}
