﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x0200000C RID: 12
internal class eliteHide : ThemeControl154
{
	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000122 RID: 290 RVA: 0x000057D6 File Offset: 0x00003BD6
	// (set) Token: 0x06000123 RID: 291 RVA: 0x000057DE File Offset: 0x00003BDE
	public FormWindowState WindowState { get; set; }

	// Token: 0x06000124 RID: 292 RVA: 0x000057E8 File Offset: 0x00003BE8
	public eliteHide()
	{
		base.SetColor("DownGradient1", 140, 138, 27);
		base.SetColor("DownGradient2", 180, 196, 114);
		base.SetColor("NoneGradient1", 50, 50, 50);
		base.SetColor("NoneGradient2", 42, 42, 42);
		base.SetColor("ClickedGradient1", 204, 201, 35);
		base.SetColor("ClickedGradient2", 140, 138, 27);
		base.SetColor("Text", 254, 254, 254);
		base.SetColor("Border1", 35, 35, 35);
		base.SetColor("Border2", 42, 42, 42);
	}

	// Token: 0x06000125 RID: 293 RVA: 0x000058B8 File Offset: 0x00003CB8
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("DownGradient1");
		this.C2 = base.GetColor("DownGradient2");
		this.C3 = base.GetColor("NoneGradient1");
		this.C4 = base.GetColor("NoneGradient2");
		this.C5 = base.GetColor("ClickedGradient1");
		this.C6 = base.GetColor("ClickedGradient2");
		this.B1 = new SolidBrush(base.GetColor("Text"));
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x06000126 RID: 294 RVA: 0x00005970 File Offset: 0x00003D70
	protected override void PaintHook()
	{
		if (this.State == MouseState.Over)
		{
			base.DrawGradient(this.C1, this.C2, base.ClientRectangle, 90f);
			this.Text = "_";
		}
		else if (this.State == MouseState.Down)
		{
			base.DrawGradient(this.C6, this.C5, base.ClientRectangle, 90f);
			this.Text = "_";
			Application.OpenForms[0].WindowState = FormWindowState.Minimized;
		}
		else
		{
			base.DrawGradient(this.C3, this.C4, base.ClientRectangle, 90f);
		}
		base.DrawText(this.B1, HorizontalAlignment.Center, 0, 0);
		base.DrawBorders(this.P1, 1);
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x04000081 RID: 129
	private Color C1;

	// Token: 0x04000082 RID: 130
	private Color C2;

	// Token: 0x04000083 RID: 131
	private Color C3;

	// Token: 0x04000084 RID: 132
	private Color C4;

	// Token: 0x04000085 RID: 133
	private Color C5;

	// Token: 0x04000086 RID: 134
	private Color C6;

	// Token: 0x04000087 RID: 135
	private SolidBrush B1;

	// Token: 0x04000088 RID: 136
	private Pen P1;

	// Token: 0x04000089 RID: 137
	private Pen P2;
}
