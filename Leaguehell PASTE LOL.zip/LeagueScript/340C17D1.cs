﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200002D RID: 45
public class 340C17D1
{
	// Token: 0x060001FC RID: 508 RVA: 0x001E0664 File Offset: 0x001DE464
	public 340C17D1(byte[] 26AE309D)
	{
		for (;;)
		{
			IL_00:
			uint num = 1638948795U;
			base..ctor();
			for (;;)
			{
				IL_0D:
				num = 1878928420U << (int)num;
				uint num2 = num + 3758096388U;
				num %= 380437913U;
				uint num3 = num2;
				for (;;)
				{
					IL_30:
					int num4 = (int)(num ^ 156432997U);
					num = 2071229698U + num;
					uint[] array = new uint[num4];
					for (;;)
					{
						num = (1045827642U ^ num);
						uint[] array2 = new uint[num + 1164869837U];
						num = (33709831U & num);
						this.50CF2F84 = array2;
						for (;;)
						{
							IL_70:
							uint num5 = num + 4261388548U;
							num *= 1628851390U;
							uint num6 = num5;
							if (num >> 26 == 0U)
							{
								goto IL_00;
							}
							uint[] array3 = array;
							num ^= 964391122U;
							int num7 = (int)(num - 3703970023U);
							num -= 1948412356U;
							array3[num7] = num + 2539409628U;
							if (543762784U == num)
							{
								goto IL_0D;
							}
							for (;;)
							{
								num = (1449808861U | num);
								if (num / 96756592U == 0U)
								{
									goto IL_00;
								}
								uint num8 = num6;
								uint num9 = num - 2129395710U;
								num = 865799032U + num;
								if (num8 == num9)
								{
									break;
								}
								num = 1990401363U;
								if ((num & 1844393290U) == 0U)
								{
									goto IL_0D;
								}
								uint[] array4 = array;
								int num10 = (int)(num6 / num3);
								uint[] array5 = array;
								uint num11 = num6;
								num += 1682442062U;
								uint num12 = num3;
								num = 1946838474U >> (int)num;
								int num13 = num11 / num12;
								num &= 2141982701U;
								object obj = array5[num13];
								int num14 = num - 973341405U;
								num *= 1877344575U;
								object obj2 = obj << num14;
								num /= 880564340U;
								byte b = 26AE309D[(int)num6];
								num = 1462259946U - num;
								array4[num10] = obj2 + b;
								if ((221409814U ^ num) == 0U)
								{
									goto IL_0D;
								}
								uint num15 = num6;
								uint num16 = num - 1462259945U;
								num = (1455561737U ^ num);
								uint num17 = num15 - num16;
								num = (652024516U & num);
								num6 = num17;
								num += 1742448228U;
							}
							if (num < 1208839419U)
							{
								break;
							}
							uint[] array6 = this.50CF2F84;
							int num18 = (int)(num + 1299772555U);
							uint num19 = num ^ 3592895904U;
							num |= 761886200U;
							array6[num18] = num19;
							uint num20 = num + 1074823172U;
							num = 1796803833U / num;
							num6 = num20;
							for (;;)
							{
								num /= 1996312782U;
								uint num21 = num6;
								uint num22 = num - 4294967264U;
								num = 1747591740U + num;
								if (num21 >= num22)
								{
									break;
								}
								num = 1429106013U;
								uint[] array7 = this.50CF2F84;
								int num23 = (int)num6;
								num = (505350889U | num);
								num *= 564549841U;
								uint[] array8 = this.50CF2F84;
								num *= 460145835U;
								object obj3 = array8[(int)(num6 - (num ^ 3512944942U))];
								uint num24 = num ^ 3598469594U;
								num = 980304926U / num;
								object obj4 = obj3 + num24;
								num <<= 26;
								array7[num23] = obj4;
								num -= 1093167889U;
								uint num25 = num6;
								num -= 1317231997U;
								uint num26 = num25 + (num + 2410399887U);
								num += 79038816U;
								num6 = num26;
								num += 2331361070U;
							}
							uint num27 = num + 2547375556U;
							num = 1012427876U / num;
							num ^= 1618507884U;
							uint num28 = num27;
							uint num29 = num27;
							num *= 261305997U;
							num6 = num27;
							num ^= 2007782850U;
							uint num30 = num27;
							uint num31 = num27;
							if ((num ^ 298542176U) != 0U)
							{
								while (1130778681U <= num)
								{
									if (num28 >= num - 1919503966U)
									{
										goto Block_12;
									}
									num = 1968389208U;
									if (num == 1266038629U)
									{
										goto IL_70;
									}
									uint[] array9 = this.50CF2F84;
									int num32 = (int)num6;
									num &= 1979148693U;
									num = 209666622U % num;
									uint[] array10 = this.50CF2F84;
									num %= 1363569710U;
									int num33 = (int)num6;
									num = (1714710573U & num);
									uint 05A63C = array10[num33] + num31 + num30;
									num *= 472477260U;
									int 519910D = (int)(num ^ 3391223059U);
									num = (338775033U | num);
									uint num34 = 00542DE3.5403126C(05A63C, 519910D);
									num = 2103540726U + num;
									num = 171189579U - num;
									uint num35 = num34;
									num = 1145928082U >> (int)num;
									array9[num32] = num34;
									num -= 116540794U;
									num31 = num35;
									num = 1117326857U + num;
									uint[] array11 = array;
									num = (772680878U & num);
									int num36 = (int)num29;
									uint[] array12 = array;
									num = 663373894U + num;
									uint num37 = array12[(int)num29];
									num = (1709391446U | num);
									uint num38 = num31;
									num = 357711550U - num;
									uint 05A63C2 = num37 + num38 + num30;
									num = (757666241U ^ num);
									int num39 = (int)num31;
									num += 1868306623U;
									int 519910D2 = num39 + (int)num30;
									num /= 431846667U;
									uint num40 = 00542DE3.5403126C(05A63C2, 519910D2);
									num %= 1114640584U;
									num = (1535857845U | num);
									num35 = num40;
									num |= 720572828U;
									array11[num36] = num40;
									num <<= 31;
									if (num % 1917126735U == 0U)
									{
										goto IL_30;
									}
									uint num41 = num35;
									num = 1669028283U + num;
									num30 = num41;
									num = (1407990807U ^ num);
									uint num42 = num28;
									num = 1822973432U % num;
									uint num43 = num + 2471993865U;
									num = 2007852000U * num;
									uint num44 = num42 + num43;
									num ^= 2143174665U;
									num28 = num44;
									num <<= 29;
									uint num45 = num6;
									uint num46 = num - 536870911U;
									num |= 435976087U;
									uint num47 = (num45 + num46) % (num ^ 972847031U);
									num = 1462178650U * num;
									num6 = num47;
									uint num48 = num29;
									uint num49 = num - 2829271061U;
									num = 1410749228U << (int)num;
									uint num50 = num48 + num49;
									num = 2123659563U << (int)num;
									num29 = num50 % (num ^ 2123659561U);
									num += 4090811795U;
								}
								goto IL_00;
							}
							goto IL_00;
						}
					}
					Block_12:
					if (num >> 31 == 0U)
					{
						return;
					}
				}
			}
		}
	}

	// Token: 0x060001FD RID: 509 RVA: 0x001E0B7C File Offset: 0x001DE97C
	private void 22F42B67(ref 340C17D1.422B2B8A 36DE439E)
	{
		uint num = 532808710U;
		if (592592505 << (int)num == 0)
		{
			goto IL_42;
		}
		uint num2;
		do
		{
			IL_18:
			uint 0D635DC = 36DE439E.0D635DC7;
			num = 1185368266U / num;
			num2 = 0D635DC + this.50CF2F84[(int)(num ^ 2U)];
		}
		while (num % 565586809U == 0U);
		IL_42:
		num = (1583556312U ^ num);
		uint 5AC = 36DE439E.5AC06818;
		num = 947682240U >> (int)num;
		num = 1532038070U + num;
		uint[] array = this.50CF2F84;
		num ^= 99420190U;
		int num3 = (int)(num + 2705587239U);
		num *= 1375478383U;
		uint num4 = array[num3];
		num >>= 19;
		uint num5 = 5AC + num4;
		num = 157305355U - num;
		uint num6 = num5;
		uint num7 = num + 4137668618U;
		for (;;)
		{
			while (num <= 1940547749U)
			{
				uint num8 = num7;
				num = 1548104675U * num;
				uint num9 = num ^ 1533197578U;
				num += 1625823513U;
				if (num8 > num9)
				{
					goto Block_2;
				}
				uint num10 = num2;
				num = 1926459631U;
				uint 05A63C = num10 ^ num6;
				num &= 649934171U;
				int 519910D = (int)num6;
				num = (1136222387U ^ num);
				uint num11 = 00542DE3.5403126C(05A63C, 519910D);
				num /= 1012469507U;
				uint[] array2 = this.50CF2F84;
				num = 1012168530U / num;
				int num12 = (int)((num - 1012168528U) * num7);
				num = 275012746U % num;
				num2 = num11 + array2[num12];
				uint num13 = num6;
				uint num14 = num2;
				num %= 1957325424U;
				uint 05A63C2 = num13 ^ num14;
				num <<= 10;
				uint num15 = 00542DE3.5403126C(05A63C2, (int)num2);
				num <<= 5;
				uint[] array3 = this.50CF2F84;
				num = 1577021971U >> (int)num;
				int num16 = (int)((num ^ 1577021969U) * num7);
				num &= 176046965U;
				uint num17 = array3[num16 + (int)(num + 4152475120U)];
				num = (1108352027U ^ num);
				num6 = num15 + num17;
				uint num18 = num7 + (num ^ 1248747019U);
				num |= 1102406346U;
				num7 = num18;
				num ^= 1117737277U;
			}
		}
		Block_2:
		num = 909800481U + num;
		num = (80248284U & num);
		uint 0D635DC2 = num2;
		num = 2036298332U + num;
		36DE439E.0D635DC7 = 0D635DC2;
		num ^= 328476011U;
		uint 5AC2 = num6;
		num ^= 1584418419U;
		36DE439E.5AC06818 = 5AC2;
		if (num * 779704091U != 0U)
		{
			return;
		}
		goto IL_18;
	}

	// Token: 0x060001FE RID: 510 RVA: 0x001E0D54 File Offset: 0x001DEB54
	private void 6CEB4E76(ref 340C17D1.422B2B8A 5BC54147)
	{
		uint num;
		uint num3;
		for (;;)
		{
			uint 5AC = 5BC54147.5AC06818;
			num = 238836132U;
			uint num2 = 5AC;
			for (;;)
			{
				IL_0D:
				num &= 1358392613U;
				num3 = 5BC54147.0D635DC7;
				num = 97670144U / num;
				uint num4 = num ^ 19U;
				num /= 280649619U;
				uint num5 = num4;
				while (num <= 1971215339U)
				{
					uint num6 = num5;
					uint num7 = num - 0U;
					num |= 265961581U;
					if (num6 <= num7)
					{
						num *= 1606251309U;
						uint num8 = num2;
						num = 18031834U + num;
						num = (460336556U | num);
						uint[] array = this.50CF2F84;
						num /= 1109550305U;
						uint 5AC2 = num8 - array[(int)(num ^ 2U)];
						num *= 1800828940U;
						5BC54147.5AC06818 = 5AC2;
						if (num != 213455402U)
						{
							goto Block_4;
						}
						goto IL_0D;
					}
					else
					{
						uint num9 = num2;
						num = 1486822027U;
						num %= 113718726U;
						uint[] array2 = this.50CF2F84;
						int num10 = (int)(num + 4286488709U);
						int num11 = (int)num5;
						num = 1675639214U + num;
						int num12 = num10 * num11 + (int)(num ^ 1684117802U);
						num = 1244414827U % num;
						uint num13 = array2[num12];
						num ^= 1757494490U;
						uint num14 = 00542DE3.4D4A6110(num9 - num13, (int)num3);
						num = 31327676U * num;
						uint num15 = num3;
						num = 10883313U << (int)num;
						uint num16 = num14 ^ num15;
						num |= 2052603020U;
						num2 = num16;
						if (num << 17 == 0U)
						{
							break;
						}
						uint num17 = num3;
						num = 642874680U >> (int)num;
						num = (1665876850U | num);
						uint[] array3 = this.50CF2F84;
						int num18 = (int)(num ^ 1665886069U);
						num -= 1512910900U;
						int num19 = num18 * (int)num5;
						num |= 979135890U;
						uint num20 = array3[num19];
						num &= 220952684U;
						uint 14F747BC = num17 - num20;
						num = 1913390596U - num;
						int 23F25BF = (int)num2;
						num = 1242521512U - num;
						uint num21 = 00542DE3.4D4A6110(14F747BC, 23F25BF);
						uint num22 = num2;
						num = 121519572U + num;
						uint num23 = num21 ^ num22;
						num = 2080859299U - num;
						num3 = num23;
						num ^= 223231551U;
						if (1919050434U > num)
						{
							goto IL_0D;
						}
						uint num24 = num5;
						num = 2025415676U % num;
						uint num25 = num24 - (num - 2025415675U);
						num = 1806203123U << (int)num;
						num5 = num25;
						num += 3489660928U;
					}
				}
				break;
			}
		}
		Block_4:
		num %= 620907863U;
		uint num26 = num3;
		num = (1612934579U | num);
		num <<= 7;
		uint[] array4 = this.50CF2F84;
		num %= 1388327688U;
		uint num27 = array4[(int)(num ^ 1056951416U)];
		num = (1474958003U | num);
		uint 0D635DC = num26 - num27;
		num = 2083790574U * num;
		5BC54147.0D635DC7 = 0D635DC;
	}

	// Token: 0x060001FF RID: 511 RVA: 0x001E0F60 File Offset: 0x001DED60
	public byte[] 53823386(byte[] 0B4F703F)
	{
		uint num = 122773283U;
		int num2 = 0B4F703F.Length;
		num = 575999193U % num;
		byte[] array = new byte[num2];
		do
		{
			num = 266552773U >> (int)num;
			byte[] 09177FC = array;
			num = 301169085U % num;
			this.18FD78DB(0B4F703F, 09177FC);
		}
		while (num > 1576102017U);
		return array;
	}

	// Token: 0x06000200 RID: 512 RVA: 0x001E0FB0 File Offset: 0x001DEDB0
	public byte[] 41725B77(byte[] 20433BEB)
	{
		uint num = 447945357U;
		if (901066540U < num)
		{
			goto IL_38;
		}
		IL_11:
		int num2 = 20433BEB.Length;
		num = 1866948390U >> (int)num;
		byte[] array = new byte[num2];
		num = (142702795U ^ num);
		byte[] array2 = array;
		num = (1678337057U ^ num);
		IL_38:
		num = (1891918497U & num);
		num = 1125651869U - num;
		byte[] 07873C = array2;
		num += 529407477U;
		this.1E5F732C(20433BEB, 07873C);
		num = 357846179U % num;
		if (num <= 683352880U)
		{
			return array2;
		}
		goto IL_11;
	}

	// Token: 0x06000201 RID: 513 RVA: 0x001E102C File Offset: 0x001DEE2C
	public void 18FD78DB(byte[] 4D4A75D9, byte[] 09177FC9)
	{
		uint num = 230237245U;
		do
		{
			IL_06:
			num = (2041591648U ^ num);
			340C17D1.422B2B8A 422B2B8A = default(340C17D1.422B2B8A);
			for (;;)
			{
				num = 1889954687U - num;
				int num2 = (int)(num ^ 4238170146U);
				if (473070066U / num != 0U)
				{
					goto IL_06;
				}
				for (;;)
				{
					num /= 875783003U;
					if (num >= 29718986U)
					{
						break;
					}
					int num3 = num2;
					num ^= 1826629630U;
					num -= 1828279720U;
					int num4 = 4D4A75D9.Length;
					num = 361761372U * num;
					int num5 = num4;
					num |= 237045286U;
					if (num3 >= num5)
					{
						goto Block_6;
					}
					do
					{
						num = 4981270U;
						422B2B8A.46E35627 = BitConverter.ToUInt64(4D4A75D9, num2);
						num <<= 2;
					}
					while (965888625U <= num);
					num = 962681326U * num;
					num = 226579405U - num;
					this.22F42B67(ref 422B2B8A);
					num %= 1456427144U;
					if (458817651U * num == 0U)
					{
						goto IL_06;
					}
					ref 340C17D1.422B2B8A ptr = 422B2B8A;
					num = 878126441U << (int)num;
					ulong 46E = ptr.46E35627;
					num = 147600900U + num;
					Array bytes = BitConverter.GetBytes(46E);
					num = 1217093383U - num;
					num = 1579511611U + num;
					bytes.CopyTo(09177FC9, num2);
					num = (848768982U ^ num);
					if (1995127612U % num == 0U)
					{
						goto IL_06;
					}
					int num6 = num2;
					int num7 = (int)(num - 3260266464U);
					num = (670052900U | num);
					int num8 = num6 + num7;
					num /= 714356509U;
					num2 = num8;
					num ^= 4238170151U;
				}
			}
			Block_6:;
		}
		while (183116561U >= num);
	}

	// Token: 0x06000202 RID: 514 RVA: 0x001E1178 File Offset: 0x001DEF78
	public void 1E5F732C(byte[] 44E00AC5, byte[] 07873C20)
	{
		uint num = 1364472980U;
		340C17D1.422B2B8A 422B2B8A = default(340C17D1.422B2B8A);
		for (;;)
		{
			IL_0E:
			int num2 = (int)(num + 2930494316U);
			num <<= 20;
			int num3 = num2;
			for (;;)
			{
				int num4 = num3;
				num ^= 1062824332U;
				num |= 1663177245U;
				int num5 = 44E00AC5.Length;
				num = (1071082749U ^ num);
				int num6 = num5;
				num *= 1801869539U;
				if (num4 >= num6)
				{
					return;
				}
				num = 1904958756U;
				int startIndex = num3;
				num = (563172674U | num);
				422B2B8A.46E35627 = BitConverter.ToUInt64(44E00AC5, startIndex);
				do
				{
					num |= 1236223319U;
					num += 1228827691U;
					this.6CEB4E76(ref 422B2B8A);
					num |= 1364268826U;
					if (num <= 1939944308U)
					{
						goto IL_0E;
					}
					Array bytes = BitConverter.GetBytes(422B2B8A.46E35627);
					num ^= 1417226511U;
					num = 426449151U + num;
					int index = num3;
					num += 221785008U;
					bytes.CopyTo(07873C20, index);
				}
				while (67333755U > num);
				int num7 = num3;
				num <<= 13;
				int num8 = num7 + (int)(num - 124551160U);
				num %= 1936876719U;
				num3 = num8;
				num ^= 1311539200U;
			}
		}
	}

	// Token: 0x04000121 RID: 289
	private const int 1B244F5D = 15;

	// Token: 0x04000122 RID: 290
	private const int 27D24444 = 8;

	// Token: 0x04000123 RID: 291
	private const int 2DEB62B3 = 2;

	// Token: 0x04000124 RID: 292
	private const int 231469F1 = 32;

	// Token: 0x04000125 RID: 293
	private readonly uint[] 50CF2F84;

	// Token: 0x04000126 RID: 294
	private const uint 486951DF = 4207804417U;

	// Token: 0x04000127 RID: 295
	private const uint 1F7A0567 = 4207804418U;

	// Token: 0x02000047 RID: 71
	[StructLayout(LayoutKind.Explicit)]
	private struct 422B2B8A
	{
		// Token: 0x040001B9 RID: 441
		[FieldOffset(0)]
		public ulong 46E35627;

		// Token: 0x040001BA RID: 442
		[FieldOffset(0)]
		public uint 0D635DC7;

		// Token: 0x040001BB RID: 443
		[FieldOffset(4)]
		public uint 5AC06818;
	}
}
