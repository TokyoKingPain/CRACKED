﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000035 RID: 53
public static class 429B6BE0
{
	// Token: 0x0600021E RID: 542 RVA: 0x001BAA44 File Offset: 0x001B8844
	public static int[] 53960F13(int 6D2D27D9)
	{
		IntPtr intPtr = IntPtr.Zero;
		int[] result;
		try
		{
			byte[] array = (IntPtr.Size == 4) ? 429B6BE0.24D7630A : 429B6BE0.145D5A50;
			intPtr = 02211CF7.62532A9E(IntPtr.Zero, new UIntPtr((uint)array.Length), (02211CF7.63233398)12288U, 02211CF7.36962D8D.456F09C0);
			Marshal.Copy(array, 0, intPtr, array.Length);
			429B6BE0.073418A8 073418A = (429B6BE0.073418A8)Marshal.GetDelegateForFunctionPointer(intPtr, typeof(429B6BE0.073418A8));
			GCHandle a = default(GCHandle);
			int[] array2 = new int[4];
			try
			{
				a = GCHandle.Alloc(array2, GCHandleType.Pinned);
				073418A(6D2D27D9, array2);
			}
			finally
			{
				if (a != default(GCHandle))
				{
					a.Free();
				}
			}
			result = array2;
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				02211CF7.4DCC4CC3(intPtr, 0U, 32768U);
			}
		}
		return result;
	}

	// Token: 0x0400014A RID: 330
	private static readonly byte[] 24D7630A = new byte[]
	{
		85,
		139,
		236,
		83,
		87,
		139,
		69,
		8,
		15,
		162,
		139,
		125,
		12,
		137,
		7,
		137,
		95,
		4,
		137,
		79,
		8,
		137,
		87,
		12,
		95,
		91,
		139,
		229,
		93,
		195
	};

	// Token: 0x0400014B RID: 331
	private static readonly byte[] 145D5A50 = new byte[]
	{
		83,
		73,
		137,
		208,
		137,
		200,
		15,
		162,
		65,
		137,
		64,
		0,
		65,
		137,
		88,
		4,
		65,
		137,
		72,
		8,
		65,
		137,
		80,
		12,
		91,
		195
	};

	// Token: 0x02000048 RID: 72
	// (Invoke) Token: 0x06000309 RID: 777
	private delegate void 073418A8(int 22BE2D41, int[] 0CD702E7);
}
