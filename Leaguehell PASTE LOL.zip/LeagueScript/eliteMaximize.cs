﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

// Token: 0x02000011 RID: 17
internal class eliteMaximize : ThemeControl154
{
	// Token: 0x17000031 RID: 49
	// (get) Token: 0x06000133 RID: 307 RVA: 0x0000637C File Offset: 0x0000477C
	// (set) Token: 0x06000134 RID: 308 RVA: 0x00006384 File Offset: 0x00004784
	public FormWindowState WindowState { get; set; }

	// Token: 0x06000135 RID: 309 RVA: 0x00006390 File Offset: 0x00004790
	public eliteMaximize()
	{
		base.SetColor("DownGradient1", 140, 138, 27);
		base.SetColor("DownGradient2", 180, 196, 114);
		base.SetColor("NoneGradient1", 50, 50, 50);
		base.SetColor("NoneGradient2", 42, 42, 42);
		base.SetColor("ClickedGradient1", 204, 201, 35);
		base.SetColor("ClickedGradient2", 140, 138, 27);
		base.SetColor("Text", 254, 254, 254);
		base.SetColor("Border1", 35, 35, 35);
		base.SetColor("Border2", 42, 42, 42);
	}

	// Token: 0x06000136 RID: 310 RVA: 0x00006460 File Offset: 0x00004860
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("DownGradient1");
		this.C2 = base.GetColor("DownGradient2");
		this.C3 = base.GetColor("NoneGradient1");
		this.C4 = base.GetColor("NoneGradient2");
		this.C5 = base.GetColor("ClickedGradient1");
		this.C6 = base.GetColor("ClickedGradient2");
		this.B1 = new SolidBrush(base.GetColor("Text"));
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x06000137 RID: 311 RVA: 0x00006518 File Offset: 0x00004918
	protected override void PaintHook()
	{
		if (this.State == MouseState.Over)
		{
			base.DrawGradient(this.C1, this.C2, base.ClientRectangle, 90f);
			if (Application.OpenForms[0].WindowState == FormWindowState.Normal)
			{
				this.Text = "+";
			}
			else if (Application.OpenForms[0].WindowState == FormWindowState.Maximized)
			{
				this.Text = "-\u007f\u007f";
			}
		}
		else if (this.State == MouseState.Down)
		{
			base.DrawGradient(this.C6, this.C5, base.ClientRectangle, 90f);
			if (Application.OpenForms[0].WindowState == FormWindowState.Normal)
			{
				this.Text = "+";
				Thread.Sleep(100);
				Application.OpenForms[0].WindowState = FormWindowState.Maximized;
				this.Text = "-";
			}
			else if (Application.OpenForms[0].WindowState == FormWindowState.Maximized)
			{
				this.Text = "-";
				Thread.Sleep(100);
				Application.OpenForms[0].WindowState = FormWindowState.Normal;
				this.Text = "+";
			}
		}
		else
		{
			base.DrawGradient(this.C3, this.C4, base.ClientRectangle, 90f);
		}
		base.DrawText(this.B1, HorizontalAlignment.Center, 0, 0);
		base.DrawBorders(this.P1, 1);
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x040000AF RID: 175
	private Color C1;

	// Token: 0x040000B0 RID: 176
	private Color C2;

	// Token: 0x040000B1 RID: 177
	private Color C3;

	// Token: 0x040000B2 RID: 178
	private Color C4;

	// Token: 0x040000B3 RID: 179
	private Color C5;

	// Token: 0x040000B4 RID: 180
	private Color C6;

	// Token: 0x040000B5 RID: 181
	private SolidBrush B1;

	// Token: 0x040000B6 RID: 182
	private Pen P1;

	// Token: 0x040000B7 RID: 183
	private Pen P2;
}
