﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x0200000E RID: 14
internal class eliteQuestion : ThemeControl154
{
	// Token: 0x0600012A RID: 298 RVA: 0x00005CA8 File Offset: 0x000040A8
	public eliteQuestion()
	{
		base.SetColor("DownGradient1", 140, 138, 27);
		base.SetColor("DownGradient2", 180, 196, 114);
		base.SetColor("NoneGradient1", 50, 50, 50);
		base.SetColor("NoneGradient2", 42, 42, 42);
		base.SetColor("ClickedGradient1", 204, 201, 35);
		base.SetColor("ClickedGradient2", 140, 138, 27);
		base.SetColor("Text", 254, 254, 254);
		base.SetColor("Border1", 35, 35, 35);
		base.SetColor("Border2", 42, 42, 42);
	}

	// Token: 0x0600012B RID: 299 RVA: 0x00005D78 File Offset: 0x00004178
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("DownGradient1");
		this.C2 = base.GetColor("DownGradient2");
		this.C3 = base.GetColor("NoneGradient1");
		this.C4 = base.GetColor("NoneGradient2");
		this.C5 = base.GetColor("ClickedGradient1");
		this.C6 = base.GetColor("ClickedGradient2");
		this.B1 = new SolidBrush(base.GetColor("Text"));
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x0600012C RID: 300 RVA: 0x00005E30 File Offset: 0x00004230
	protected override void PaintHook()
	{
		if (this.State == MouseState.Over)
		{
			base.DrawGradient(this.C1, this.C2, base.ClientRectangle, 90f);
			this.Text = "?";
		}
		else if (this.State == MouseState.Down)
		{
			base.DrawGradient(this.C6, this.C5, base.ClientRectangle, 90f);
			this.Text = "?";
		}
		else
		{
			base.DrawGradient(this.C3, this.C4, base.ClientRectangle, 90f);
		}
		base.DrawText(this.B1, HorizontalAlignment.Center, 0, 0);
		base.DrawBorders(this.P1, 1);
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x04000093 RID: 147
	private Color C1;

	// Token: 0x04000094 RID: 148
	private Color C2;

	// Token: 0x04000095 RID: 149
	private Color C3;

	// Token: 0x04000096 RID: 150
	private Color C4;

	// Token: 0x04000097 RID: 151
	private Color C5;

	// Token: 0x04000098 RID: 152
	private Color C6;

	// Token: 0x04000099 RID: 153
	private SolidBrush B1;

	// Token: 0x0400009A RID: 154
	private Pen P1;

	// Token: 0x0400009B RID: 155
	private Pen P2;
}
