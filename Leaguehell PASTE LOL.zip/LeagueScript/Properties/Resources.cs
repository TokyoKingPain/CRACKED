﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace LeagueScript.Properties
{
	// Token: 0x02000016 RID: 22
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x0600014C RID: 332 RVA: 0x00006C49 File Offset: 0x00005049
		internal Resources()
		{
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x0600014D RID: 333 RVA: 0x00006C51 File Offset: 0x00005051
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = new ResourceManager("LeagueScript.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x0600014E RID: 334 RVA: 0x00006C7D File Offset: 0x0000507D
		// (set) Token: 0x0600014F RID: 335 RVA: 0x00006C84 File Offset: 0x00005084
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000150 RID: 336 RVA: 0x00006C8C File Offset: 0x0000508C
		internal static Bitmap lhbot
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("lhbot", Resources.resourceCulture);
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000151 RID: 337 RVA: 0x00006CA7 File Offset: 0x000050A7
		internal static Bitmap lhbotw
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("lhbotw", Resources.resourceCulture);
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000152 RID: 338 RVA: 0x00006CC2 File Offset: 0x000050C2
		internal static Bitmap lhoverlay
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("lhoverlay", Resources.resourceCulture);
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000153 RID: 339 RVA: 0x00006CDD File Offset: 0x000050DD
		internal static Bitmap lhoverlay1
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("lhoverlay1", Resources.resourceCulture);
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000154 RID: 340 RVA: 0x00006CF8 File Offset: 0x000050F8
		internal static Bitmap ot
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("ot", Resources.resourceCulture);
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000155 RID: 341 RVA: 0x00006D13 File Offset: 0x00005113
		internal static Bitmap spray
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("spray", Resources.resourceCulture);
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000156 RID: 342 RVA: 0x00006D2E File Offset: 0x0000512E
		internal static Bitmap valobot
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("valobot", Resources.resourceCulture);
			}
		}

		// Token: 0x040000C8 RID: 200
		private static ResourceManager resourceMan;

		// Token: 0x040000C9 RID: 201
		private static CultureInfo resourceCulture;
	}
}
