﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace LeagueScript.Properties
{
	// Token: 0x02000017 RID: 23
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.8.1.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000157 RID: 343 RVA: 0x00006D49 File Offset: 0x00005149
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x040000CA RID: 202
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
