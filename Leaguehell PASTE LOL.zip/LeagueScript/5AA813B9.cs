﻿using System;

// Token: 0x02000036 RID: 54
public static class 5AA813B9
{
	// Token: 0x06000220 RID: 544 RVA: 0x002FC368 File Offset: 0x002F9F68
	public static bool 650334E1()
	{
		return (bool)new 467F5DB3().37F432DB(null, 3001602);
	}

	// Token: 0x06000221 RID: 545 RVA: 0x002FC38C File Offset: 0x002F9F8C
	public static bool 0E89287E()
	{
		return (bool)new 467F5DB3().37F432DB(null, 1977802);
	}

	// Token: 0x06000222 RID: 546 RVA: 0x002FC3B0 File Offset: 0x002F9FB0
	public static uint 1DC70CA4()
	{
		return (uint)new 467F5DB3().37F432DB(null, 1975807);
	}

	// Token: 0x06000223 RID: 547 RVA: 0x002FC3D4 File Offset: 0x002F9FD4
	public static uint 4B57470D()
	{
		return (uint)new 467F5DB3().37F432DB(null, 1975260);
	}

	// Token: 0x06000224 RID: 548 RVA: 0x002FC3F8 File Offset: 0x002F9FF8
	public static uint 5F6B1B00()
	{
		return (uint)new 467F5DB3().37F432DB(null, 3117309);
	}

	// Token: 0x06000225 RID: 549 RVA: 0x002FC41C File Offset: 0x002FA01C
	public static uint 24A2334B()
	{
		return (uint)new 467F5DB3().37F432DB(null, 3000641);
	}

	// Token: 0x06000226 RID: 550 RVA: 0x002FC440 File Offset: 0x002FA040
	public static uint 22936922()
	{
		return (uint)new 467F5DB3().37F432DB(null, 1976923);
	}

	// Token: 0x06000227 RID: 551 RVA: 0x002FC464 File Offset: 0x002FA064
	public static uint 65B716E0()
	{
		return (uint)new 467F5DB3().37F432DB(null, 3002003);
	}

	// Token: 0x06000228 RID: 552 RVA: 0x002FC488 File Offset: 0x002FA088
	// Note: this type is marked as 'beforefieldinit'.
	static 5AA813B9()
	{
		new 467F5DB3().37F432DB(null, 3002040);
	}

	// Token: 0x0400014C RID: 332
	private static uint[] 589C76AD;
}
