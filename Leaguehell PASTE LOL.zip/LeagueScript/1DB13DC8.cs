﻿using System;
using System.Net.Security;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

// Token: 0x02000038 RID: 56
public class 1DB13DC8
{
	// Token: 0x0600022B RID: 555 RVA: 0x001E1B34 File Offset: 0x001DF934
	public 1DB13DC8(long 6AC52CEA)
	{
		object[] 560004FE = new object[]
		{
			this,
			6AC52CEA
		};
		new 467F5DB3().37F432DB(560004FE, 47606);
	}

	// Token: 0x0600022C RID: 556 RVA: 0x001E1B6C File Offset: 0x001DF96C
	public 1DB13DC8(byte[] 7EA17338)
	{
		object[] 560004FE = new object[]
		{
			this,
			7EA17338
		};
		new 467F5DB3().37F432DB(560004FE, 47951);
	}

	// Token: 0x04000152 RID: 338
	private readonly byte[] 01AE5545;

	// Token: 0x04000153 RID: 339
	private byte[] 528853DA;

	// Token: 0x04000154 RID: 340
	private readonly object 010050EE;

	// Token: 0x04000155 RID: 341
	private 6CF10C53 5AF40F9C;

	// Token: 0x04000156 RID: 342
	private long 78E968E4;

	// Token: 0x04000157 RID: 343
	private readonly int 103F037F;

	// Token: 0x04000158 RID: 344
	private int 40380F4F;

	// Token: 0x04000159 RID: 345
	private uint 78374925;

	// Token: 0x0200004A RID: 74
	public class 4B140067
	{
		// Token: 0x0600030C RID: 780 RVA: 0x001C20EC File Offset: 0x001BFEEC
		protected bool 5C0A33FE(byte[] 739955CB)
		{
			int num = BitConverter.ToInt32(739955CB, 32);
			if (num == 0)
			{
				return false;
			}
			int index = BitConverter.ToInt32(739955CB, 28);
			this.67AE5F48 = Encoding.UTF8.GetString(739955CB, index, num);
			if (this.67AE5F48[this.67AE5F48.Length - 1] != '/')
			{
				this.67AE5F48 += "/";
			}
			return true;
		}

		// Token: 0x0600030D RID: 781 RVA: 0x001C2156 File Offset: 0x001BFF56
		protected void 12790F2E()
		{
			this.67AE5F48 = Convert.ToBase64String(Encoding.UTF8.GetBytes(this.67AE5F48));
		}

		// Token: 0x0600030E RID: 782 RVA: 0x001C2173 File Offset: 0x001BFF73
		protected void 2F113214(string 5E465854, string 0D9E2994)
		{
			this.52F73CB7(5E465854, false);
			this.52F73CB7(0D9E2994, true);
		}

		// Token: 0x0600030F RID: 783 RVA: 0x001C2188 File Offset: 0x001BFF88
		private void 52F73CB7(string 6FA5274A, bool 1BBD016A)
		{
			if (1BBD016A)
			{
				StringBuilder stringBuilder = new StringBuilder(this.67AE5F48);
				foreach (char c in 6FA5274A)
				{
					if (c != '+')
					{
						if (c != '/')
						{
							if (c != '=')
							{
								stringBuilder.Append(c);
							}
							else
							{
								stringBuilder.Append("%3D");
							}
						}
						else
						{
							stringBuilder.Append("%2F");
						}
					}
					else
					{
						stringBuilder.Append("%2B");
					}
				}
				this.67AE5F48 = stringBuilder.ToString();
				return;
			}
			this.67AE5F48 += 6FA5274A;
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x06000310 RID: 784 RVA: 0x001C2334 File Offset: 0x001C0134
		// (set) Token: 0x06000311 RID: 785 RVA: 0x001C233C File Offset: 0x001C013C
		public string 67AE5F48
		{
			[CompilerGenerated]
			get
			{
				return this.398B671E;
			}
			[CompilerGenerated]
			private set
			{
				this.398B671E = value;
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000312 RID: 786 RVA: 0x001C2345 File Offset: 0x001C0145
		// (set) Token: 0x06000313 RID: 787 RVA: 0x001C234D File Offset: 0x001C014D
		public string 18351070
		{
			get
			{
				return this.482D6ADC;
			}
			private set
			{
				this.482D6ADC = value;
			}
		}

		// Token: 0x06000315 RID: 789 RVA: 0x0030B874 File Offset: 0x00309474
		public unsafe static object 79162FEC(void* 5EB256B7)
		{
			uint num = 1569997594U;
			RuntimeTypeHandle handle = typeof(void*).TypeHandle;
			num <<= 17;
			Type typeFromHandle = Type.GetTypeFromHandle(handle);
			num /= 1918437854U;
			return Pointer.Box(5EB256B7, typeFromHandle);
		}

		// Token: 0x06000316 RID: 790 RVA: 0x0030B8A8 File Offset: 0x003094A8
		public unsafe static void* 4B966AC2(object 5A9E14B6)
		{
			uint num = 561000304U;
			num = 1207837978U % num;
			return Pointer.Unbox(5A9E14B6);
		}

		// Token: 0x040001C1 RID: 449
		private string 398B671E;

		// Token: 0x040001C2 RID: 450
		private string 482D6ADC;

		// Token: 0x0200007A RID: 122
		[Serializable]
		private sealed class 39C83D52
		{
			// Token: 0x060004B0 RID: 1200 RVA: 0x002FC330 File Offset: 0x002F9F30
			internal bool 2F532CA0(object 1F3E1A86, X509Certificate 37385DAD, X509Chain 3C1D1511, SslPolicyErrors 30592347)
			{
				uint num = 366420344U;
				return (num ^ 366420345U) != 0U;
			}

			// Token: 0x0400021E RID: 542
			public static readonly 1DB13DC8.4B140067.39C83D52 16A148D5 = new 1DB13DC8.4B140067.39C83D52();

			// Token: 0x0400021F RID: 543
			public static RemoteCertificateValidationCallback 7B617E74;
		}
	}

	// Token: 0x0200004B RID: 75
	public class 782F634D : 1DB13DC8.4B140067
	{
		// Token: 0x040001C3 RID: 451
		private string 027B2560;
	}

	// Token: 0x0200004C RID: 76
	public class 5BCD0A67 : 1DB13DC8.4B140067
	{
	}
}
