﻿using System;
using System.Diagnostics;

// Token: 0x0200003D RID: 61
[Serializable]
internal struct 20307533
{
	// Token: 0x060002B1 RID: 689 RVA: 0x001C0188 File Offset: 0x001BDF88
	[Conditional("DEBUG")]
	private void 2BC51AF3()
	{
		if (this.2397465A != null)
		{
			20307533.126E587A(this.2397465A);
		}
	}

	// Token: 0x17000059 RID: 89
	// (get) Token: 0x060002B2 RID: 690 RVA: 0x001C01A0 File Offset: 0x001BDFA0
	private static 20307533 60ED7FAE
	{
		get
		{
			return 20307533.21645C96;
		}
	}

	// Token: 0x1700005A RID: 90
	// (get) Token: 0x060002B3 RID: 691 RVA: 0x001C01A7 File Offset: 0x001BDFA7
	private bool 3F3D7CD0
	{
		get
		{
			if (this.2397465A != null)
			{
				return (this.2397465A[0] & 1U) == 0U;
			}
			return (this.7A2B2F4D & 1) == 0;
		}
	}

	// Token: 0x1700005B RID: 91
	// (get) Token: 0x060002B4 RID: 692 RVA: 0x001C01CA File Offset: 0x001BDFCA
	private int 20476E7D
	{
		get
		{
			return (this.7A2B2F4D >> 31) - (-this.7A2B2F4D >> 31);
		}
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x001C01E0 File Offset: 0x001BDFE0
	public bool BAE9AF70(object 7950250D)
	{
		return 7950250D is 20307533 && this.Equals((20307533)7950250D);
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x001C0204 File Offset: 0x001BE004
	public int 548F5EE2()
	{
		if (this.2397465A == null)
		{
			return this.7A2B2F4D;
		}
		int num = this.7A2B2F4D;
		int num2 = 20307533.126E587A(this.2397465A);
		while (--num2 >= 0)
		{
			num = 353B51DA.419A765A(num, (int)this.2397465A[num2]);
		}
		return num;
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x001C0250 File Offset: 0x001BE050
	private int 2F2329C8(20307533 2B4A2CE6)
	{
		if ((this.7A2B2F4D ^ 2B4A2CE6.7A2B2F4D) < 0)
		{
			if (this.7A2B2F4D >= 0)
			{
				return 1;
			}
			return -1;
		}
		else if (this.2397465A == null)
		{
			if (2B4A2CE6.2397465A != null)
			{
				return -2B4A2CE6.7A2B2F4D;
			}
			if (this.7A2B2F4D < 2B4A2CE6.7A2B2F4D)
			{
				return -1;
			}
			if (this.7A2B2F4D <= 2B4A2CE6.7A2B2F4D)
			{
				return 0;
			}
			return 1;
		}
		else
		{
			int num;
			int num2;
			if (2B4A2CE6.2397465A == null || (num = 20307533.126E587A(this.2397465A)) > (num2 = 20307533.126E587A(2B4A2CE6.2397465A)))
			{
				return this.7A2B2F4D;
			}
			if (num < num2)
			{
				return -this.7A2B2F4D;
			}
			int num3 = 20307533.306B6273(this.2397465A, 2B4A2CE6.2397465A, num);
			if (num3 == 0)
			{
				return 0;
			}
			if (this.2397465A[num3 - 1] >= 2B4A2CE6.2397465A[num3 - 1])
			{
				return this.7A2B2F4D;
			}
			return -this.7A2B2F4D;
		}
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x001C0328 File Offset: 0x001BE128
	internal byte[] 26E027B5()
	{
		if (this.2397465A == null && this.7A2B2F4D == 0)
		{
			return new byte[1];
		}
		uint[] array;
		byte b;
		if (this.2397465A == null)
		{
			array = new uint[]
			{
				(uint)this.7A2B2F4D
			};
			b = ((this.7A2B2F4D < 0) ? byte.MaxValue : 0);
		}
		else if (this.7A2B2F4D == -1)
		{
			array = (uint[])this.2397465A.Clone();
			353B51DA.28DD3762(array);
			b = byte.MaxValue;
		}
		else
		{
			array = this.2397465A;
			b = 0;
		}
		byte[] array2 = new byte[checked(4 * array.Length)];
		int num = 0;
		foreach (uint num2 in array)
		{
			for (int j = 0; j < 4; j++)
			{
				array2[num++] = (byte)(num2 & 255U);
				num2 >>= 8;
			}
		}
		if ((array2[array2.Length - 1] & 128) == (b & 128))
		{
			return array2;
		}
		byte[] array4 = new byte[array2.Length + 1];
		Array.Copy(array2, array4, array2.Length);
		array4[array4.Length - 1] = b;
		return array4;
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x001C0435 File Offset: 0x001BE235
	private 20307533(int 190B37E3)
	{
		if (190B37E3 == -2147483648)
		{
			this = 20307533.6F1751FD;
			return;
		}
		this.7A2B2F4D = 190B37E3;
		this.2397465A = null;
	}

	// Token: 0x060002BA RID: 698 RVA: 0x001C045C File Offset: 0x001BE25C
	internal 20307533(byte[] 4EF216B2)
	{
		if (4EF216B2 == null)
		{
			throw new ArgumentNullException("value");
		}
		int num = 4EF216B2.Length;
		bool flag = num > 0 && (4EF216B2[num - 1] & 128) == 128;
		while (num > 0 && 4EF216B2[num - 1] == 0)
		{
			num--;
		}
		if (num == 0)
		{
			this.7A2B2F4D = 0;
			this.2397465A = null;
			return;
		}
		if (num <= 4)
		{
			if (flag)
			{
				this.7A2B2F4D = -1;
			}
			else
			{
				this.7A2B2F4D = 0;
			}
			for (int i = num - 1; i >= 0; i--)
			{
				this.7A2B2F4D <<= 8;
				this.7A2B2F4D |= (int)4EF216B2[i];
			}
			this.2397465A = null;
			if (this.7A2B2F4D < 0 && !flag)
			{
				this.2397465A = new uint[1];
				this.2397465A[0] = (uint)this.7A2B2F4D;
				this.7A2B2F4D = 1;
			}
			if (this.7A2B2F4D == -2147483648)
			{
				this = 20307533.6F1751FD;
				return;
			}
		}
		else
		{
			int num2 = num % 4;
			int num3 = num / 4 + ((num2 == 0) ? 0 : 1);
			bool flag2 = true;
			uint[] array = new uint[num3];
			int j = 3;
			int k;
			for (k = 0; k < num3 - ((num2 == 0) ? 0 : 1); k++)
			{
				for (int l = 0; l < 4; l++)
				{
					if (4EF216B2[j] != 0)
					{
						flag2 = false;
					}
					array[k] <<= 8;
					array[k] |= (uint)4EF216B2[j];
					j--;
				}
				j += 8;
			}
			if (num2 != 0)
			{
				if (flag)
				{
					array[num3 - 1] = uint.MaxValue;
				}
				for (j = num - 1; j >= num - num2; j--)
				{
					if (4EF216B2[j] != 0)
					{
						flag2 = false;
					}
					array[k] <<= 8;
					array[k] |= (uint)4EF216B2[j];
				}
			}
			if (flag2)
			{
				this = 20307533.39BF1539;
				return;
			}
			if (flag)
			{
				353B51DA.28DD3762(array);
				int num4 = array.Length;
				while (num4 > 0 && array[num4 - 1] == 0U)
				{
					num4--;
				}
				if (num4 == 1 && array[0] > 0U)
				{
					if (array[0] == 1U)
					{
						this = 20307533.0C5922FF;
						return;
					}
					if (array[0] == 2147483648U)
					{
						this = 20307533.6F1751FD;
						return;
					}
					this.7A2B2F4D = (int)(uint.MaxValue * array[0]);
					this.2397465A = null;
					return;
				}
				else
				{
					if (num4 != array.Length)
					{
						this.7A2B2F4D = -1;
						this.2397465A = new uint[num4];
						Array.Copy(array, this.2397465A, num4);
						return;
					}
					this.7A2B2F4D = -1;
					this.2397465A = array;
					return;
				}
			}
			else
			{
				this.7A2B2F4D = 1;
				this.2397465A = array;
			}
		}
	}

	// Token: 0x060002BB RID: 699 RVA: 0x001C06E3 File Offset: 0x001BE4E3
	internal 20307533(int 21997F9F, uint[] 39CF5D23)
	{
		this.7A2B2F4D = 21997F9F;
		this.2397465A = 39CF5D23;
	}

	// Token: 0x060002BC RID: 700 RVA: 0x001C06F3 File Offset: 0x001BE4F3
	private static void 3F4D62F2(ref 032546EE 516C1DF6, ref 032546EE 2F977AAA, ref 032546EE 287B0517, ref 032546EE 4388381B)
	{
		353B51DA.1E1A513A<032546EE>(ref 516C1DF6, ref 4388381B);
		516C1DF6.2F9B5C6D(ref 4388381B, ref 2F977AAA);
		516C1DF6.184D7F43(ref 287B0517);
	}

	// Token: 0x060002BD RID: 701 RVA: 0x001C070B File Offset: 0x001BE50B
	private static void 4EAC05B0(ref 032546EE 04A03283, ref 032546EE 77F15E18, ref 032546EE 5D3F0C1F)
	{
		353B51DA.1E1A513A<032546EE>(ref 04A03283, ref 5D3F0C1F);
		04A03283.2F9B5C6D(ref 5D3F0C1F, ref 5D3F0C1F);
		04A03283.184D7F43(ref 77F15E18);
	}

	// Token: 0x060002BE RID: 702 RVA: 0x001C0723 File Offset: 0x001BE523
	private static void 377D0D3D(uint 76F31ACD, ref 032546EE 62291387, ref 032546EE 48896FDF, ref 032546EE 01C063A6, ref 032546EE 29C63C9E)
	{
		while (76F31ACD != 0U)
		{
			if ((76F31ACD & 1U) == 1U)
			{
				20307533.3F4D62F2(ref 62291387, ref 48896FDF, ref 01C063A6, ref 29C63C9E);
			}
			if (76F31ACD == 1U)
			{
				break;
			}
			20307533.4EAC05B0(ref 48896FDF, ref 01C063A6, ref 29C63C9E);
			76F31ACD >>= 1;
		}
	}

	// Token: 0x060002BF RID: 703 RVA: 0x001C074C File Offset: 0x001BE54C
	private static void 3B770F8A(uint 1A5B2C84, ref 032546EE 695E3882, ref 032546EE 5AEC215E, ref 032546EE 6D6871D5, ref 032546EE 16E00CFC)
	{
		for (int i = 0; i < 32; i++)
		{
			if ((1A5B2C84 & 1U) == 1U)
			{
				20307533.3F4D62F2(ref 695E3882, ref 5AEC215E, ref 6D6871D5, ref 16E00CFC);
			}
			20307533.4EAC05B0(ref 5AEC215E, ref 6D6871D5, ref 16E00CFC);
			1A5B2C84 >>= 1;
		}
	}

	// Token: 0x060002C0 RID: 704 RVA: 0x001C0784 File Offset: 0x001BE584
	internal static 20307533 6F7711EF(20307533 466224AD, 20307533 1146003F, 20307533 73767E1D)
	{
		if (1146003F.20476E7D < 0)
		{
			throw new ArgumentOutOfRangeException("exponent", "ArgumentOutOfRange must be non negative");
		}
		int num = 1;
		int num2 = 1;
		int num3 = 1;
		bool flag = 1146003F.3F3D7CD0;
		032546EE 032546EE = new 032546EE(20307533.60ED7FAE, ref num);
		032546EE 032546EE2 = new 032546EE(466224AD, ref num2);
		032546EE 032546EE3 = new 032546EE(73767E1D, ref num3);
		032546EE 032546EE4 = new 032546EE(032546EE2.2E3A65C2);
		032546EE.184D7F43(ref 032546EE3);
		if (1146003F.2397465A == null)
		{
			20307533.377D0D3D((uint)1146003F.7A2B2F4D, ref 032546EE, ref 032546EE2, ref 032546EE3, ref 032546EE4);
		}
		else
		{
			int num4 = 20307533.126E587A(1146003F.2397465A);
			for (int i = 0; i < num4 - 1; i++)
			{
				20307533.3B770F8A(1146003F.2397465A[i], ref 032546EE, ref 032546EE2, ref 032546EE3, ref 032546EE4);
			}
			20307533.377D0D3D(1146003F.2397465A[num4 - 1], ref 032546EE, ref 032546EE2, ref 032546EE3, ref 032546EE4);
		}
		return 032546EE.6B396A2D((466224AD.7A2B2F4D > 0) ? 1 : (flag ? 1 : -1));
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x001C0877 File Offset: 0x001BE677
	public static bool 1FBC22E7(20307533 03344EFA, 20307533 3BFB1FAC)
	{
		return 03344EFA.2F2329C8(3BFB1FAC) < 0;
	}

	// Token: 0x060002C2 RID: 706 RVA: 0x001C0884 File Offset: 0x001BE684
	public static bool 2F2536DC(20307533 61664F02, 20307533 423F7706)
	{
		return 61664F02.2F2329C8(423F7706) <= 0;
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x001C0894 File Offset: 0x001BE694
	public static bool 11540843(20307533 25290D89, 20307533 33843DF2)
	{
		return 25290D89.2F2329C8(33843DF2) > 0;
	}

	// Token: 0x060002C4 RID: 708 RVA: 0x001C08A1 File Offset: 0x001BE6A1
	public static bool 3EDC7D91(20307533 1C776EA7, 20307533 39483684)
	{
		return 1C776EA7.2F2329C8(39483684) >= 0;
	}

	// Token: 0x060002C5 RID: 709 RVA: 0x001C08B1 File Offset: 0x001BE6B1
	public static bool 3BE26BCE(20307533 05646B3A, 20307533 0FCA7794)
	{
		return 05646B3A.Equals(0FCA7794);
	}

	// Token: 0x060002C6 RID: 710 RVA: 0x001C08C6 File Offset: 0x001BE6C6
	public static bool 4CE102D3(20307533 78B960F0, 20307533 65C95D6F)
	{
		return !78B960F0.Equals(65C95D6F);
	}

	// Token: 0x060002C7 RID: 711 RVA: 0x001C08E0 File Offset: 0x001BE6E0
	private static int 126E587A(uint[] 67DE28A2)
	{
		int num = 67DE28A2.Length;
		if (67DE28A2[num - 1] != 0U)
		{
			return num;
		}
		return num - 1;
	}

	// Token: 0x1700005C RID: 92
	// (get) Token: 0x060002C8 RID: 712 RVA: 0x001C08FD File Offset: 0x001BE6FD
	internal int 327A1157
	{
		get
		{
			return this.7A2B2F4D;
		}
	}

	// Token: 0x1700005D RID: 93
	// (get) Token: 0x060002C9 RID: 713 RVA: 0x001C0905 File Offset: 0x001BE705
	internal uint[] 102F2D90
	{
		get
		{
			return this.2397465A;
		}
	}

	// Token: 0x060002CA RID: 714 RVA: 0x001C0910 File Offset: 0x001BE710
	private static int 306B6273(uint[] 698F72CB, uint[] 31FD66E4, int 272E6601)
	{
		int num = 272E6601;
		while (--num >= 0)
		{
			if (698F72CB[num] != 31FD66E4[num])
			{
				return num + 1;
			}
		}
		return 0;
	}

	// Token: 0x04000175 RID: 373
	private const uint 14644ADA = 2147483648U;

	// Token: 0x04000176 RID: 374
	private const int 1C0A5E76 = 32;

	// Token: 0x04000177 RID: 375
	private readonly int 7A2B2F4D;

	// Token: 0x04000178 RID: 376
	private readonly uint[] 2397465A;

	// Token: 0x04000179 RID: 377
	private static readonly 20307533 6F1751FD = new 20307533(-1, new uint[]
	{
		2147483648U
	});

	// Token: 0x0400017A RID: 378
	private static readonly 20307533 21645C96 = new 20307533(1);

	// Token: 0x0400017B RID: 379
	private static readonly 20307533 39BF1539 = new 20307533(0);

	// Token: 0x0400017C RID: 380
	private static readonly 20307533 0C5922FF = new 20307533(-1);
}
