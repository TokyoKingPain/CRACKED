﻿using System;
using System.IO;

// Token: 0x02000041 RID: 65
public class 44BD2378
{
	// Token: 0x060002EE RID: 750 RVA: 0x0030AC60 File Offset: 0x00308860
	public 44BD2378()
	{
		this.457D0E71 = uint.MaxValue;
		int num = 0;
		while ((long)num < 4L)
		{
			this.41BE7632[num] = new 6C703443(6);
			num++;
		}
	}

	// Token: 0x060002EF RID: 751 RVA: 0x0030AD58 File Offset: 0x00308958
	private void 7D140302(uint 38431ECA)
	{
		if (this.457D0E71 != 38431ECA)
		{
			this.457D0E71 = 38431ECA;
			this.187E2FC6 = Math.Max(this.457D0E71, 1U);
			uint 23DB4A0E = Math.Max(this.187E2FC6, 4096U);
			this.32640D56.5ECD3A65(23DB4A0E);
		}
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x0030ADA8 File Offset: 0x003089A8
	private void 1C636473(int 67D41188, int 55E114A4)
	{
		if (67D41188 > 8)
		{
			throw new ArgumentException("lp > 8");
		}
		if (55E114A4 > 8)
		{
			throw new ArgumentException("lc > 8");
		}
		this.6EC5233F.6310695D(67D41188, 55E114A4);
	}

	// Token: 0x060002F1 RID: 753 RVA: 0x0030ADDC File Offset: 0x003089DC
	private void 4E9B0C4E(int 046602B5)
	{
		if (046602B5 > 4)
		{
			throw new ArgumentException("pb > Base.KNumPosStatesBitsMax");
		}
		uint num = 1U << 046602B5;
		this.2A50095B.0AF32D9B(num);
		this.62B77AD8.0AF32D9B(num);
		this.5D150165 = num - 1U;
	}

	// Token: 0x060002F2 RID: 754 RVA: 0x0030AE24 File Offset: 0x00308A24
	private void 55245183(Stream 69F46CDE, Stream 5CA07C8D)
	{
		this.45443E5C.4DB9499E(69F46CDE);
		this.32640D56.79167C46(5CA07C8D, false);
		for (uint num = 0U; num < 12U; num += 1U)
		{
			for (uint num2 = 0U; num2 <= this.5D150165; num2 += 1U)
			{
				uint num3 = (num << 4) + num2;
				this.3EE14E98[(int)num3].2A5E052D();
				this.325D1AB0[(int)num3].2A5E052D();
			}
			this.2D8E6091[(int)num].2A5E052D();
			this.29477598[(int)num].2A5E052D();
			this.7A3C58B7[(int)num].2A5E052D();
			this.3C830618[(int)num].2A5E052D();
		}
		this.6EC5233F.3E2E2742();
		for (uint num = 0U; num < 4U; num += 1U)
		{
			this.41BE7632[(int)num].09C01B9D();
		}
		for (uint num = 0U; num < 114U; num += 1U)
		{
			this.3EF2498D[(int)num].2A5E052D();
		}
		this.2A50095B.7A952003();
		this.62B77AD8.7A952003();
		this.75995E8E.09C01B9D();
	}

	// Token: 0x060002F3 RID: 755 RVA: 0x0030AF54 File Offset: 0x00308B54
	public void 01B24373(Stream 051750B5, Stream 239B195A, long 7DBE0CDC)
	{
		this.55245183(051750B5, 239B195A);
		147807B2.0FF55DB6 0FF55DB = default(147807B2.0FF55DB6);
		0FF55DB.374763C8();
		uint num = 0U;
		uint num2 = 0U;
		uint num3 = 0U;
		uint num4 = 0U;
		ulong num5 = 0UL;
		if (num5 < (ulong)7DBE0CDC)
		{
			if (this.3EE14E98[(int)((int)0FF55DB.69D2529A << 4)].638962C8(this.45443E5C) != 0U)
			{
				throw new InvalidDataException("IsMatchDecoders");
			}
			0FF55DB.6D9E313C();
			byte 33960F = this.6EC5233F.0C9F6D3C(this.45443E5C, 0U, 0);
			this.32640D56.79266A07(33960F);
			num5 += 1UL;
		}
		while (num5 < (ulong)7DBE0CDC)
		{
			uint num6 = (uint)num5 & this.5D150165;
			if (this.3EE14E98[(int)((0FF55DB.69D2529A << 4) + num6)].638962C8(this.45443E5C) == 0U)
			{
				byte b = this.32640D56.2B4A6AFD(0U);
				byte 33960F2;
				if (!0FF55DB.1ED2481F())
				{
					33960F2 = this.6EC5233F.1FC56E3C(this.45443E5C, (uint)num5, b, this.32640D56.2B4A6AFD(num));
				}
				else
				{
					33960F2 = this.6EC5233F.0C9F6D3C(this.45443E5C, (uint)num5, b);
				}
				this.32640D56.79266A07(33960F2);
				0FF55DB.6D9E313C();
				num5 += 1UL;
			}
			else
			{
				uint num8;
				if (this.2D8E6091[(int)0FF55DB.69D2529A].638962C8(this.45443E5C) == 1U)
				{
					if (this.29477598[(int)0FF55DB.69D2529A].638962C8(this.45443E5C) == 0U)
					{
						if (this.325D1AB0[(int)((0FF55DB.69D2529A << 4) + num6)].638962C8(this.45443E5C) == 0U)
						{
							0FF55DB.5F9D3D29();
							this.32640D56.79266A07(this.32640D56.2B4A6AFD(num));
							num5 += 1UL;
							continue;
						}
					}
					else
					{
						uint num7;
						if (this.7A3C58B7[(int)0FF55DB.69D2529A].638962C8(this.45443E5C) == 0U)
						{
							num7 = num2;
						}
						else
						{
							if (this.3C830618[(int)0FF55DB.69D2529A].638962C8(this.45443E5C) == 0U)
							{
								num7 = num3;
							}
							else
							{
								num7 = num4;
								num4 = num3;
							}
							num3 = num2;
						}
						num2 = num;
						num = num7;
					}
					num8 = this.62B77AD8.49130687(this.45443E5C, num6) + 2U;
					0FF55DB.2AB50C47();
				}
				else
				{
					num4 = num3;
					num3 = num2;
					num2 = num;
					num8 = 2U + this.2A50095B.49130687(this.45443E5C, num6);
					0FF55DB.556E2469();
					uint num9 = this.41BE7632[(int)147807B2.0B47086B(num8)].237E3620(this.45443E5C);
					if (num9 >= 4U)
					{
						int num10 = (int)((num9 >> 1) - 1U);
						num = (2U | (num9 & 1U)) << num10;
						if (num9 < 14U)
						{
							num += 6C703443.56167BF2(this.3EF2498D, num - num9 - 1U, this.45443E5C, num10);
						}
						else
						{
							num += this.45443E5C.782E7457(num10 - 4) << 4;
							num += this.75995E8E.1759207D(this.45443E5C);
						}
					}
					else
					{
						num = num9;
					}
				}
				if ((ulong)num >= (ulong)this.32640D56.21913397 + num5 || num >= this.187E2FC6)
				{
					if (num != 4294967295U)
					{
						throw new InvalidDataException("rep0");
					}
					break;
				}
				else
				{
					this.32640D56.6F6A718C(num, num8);
					num5 += (ulong)num8;
				}
			}
		}
		this.32640D56.4CDA6C69();
		this.32640D56.59DA5CE6();
		this.45443E5C.17D619A9();
	}

	// Token: 0x060002F4 RID: 756 RVA: 0x0030B2E8 File Offset: 0x00308EE8
	public void 00B31520(byte[] 43106C79)
	{
		if (43106C79.Length < 5)
		{
			throw new ArgumentException("properties.Length < 5");
		}
		int 55E114A = (int)(43106C79[0] % 9);
		byte b = 43106C79[0] / 9;
		int 67D = (int)(b % 5);
		int num = (int)(b / 5);
		if (num > 4)
		{
			throw new ArgumentException("pb > Base.kNumPosStatesBitsMax");
		}
		uint num2 = 0U;
		for (int i = 0; i < 4; i++)
		{
			num2 += (uint)((uint)43106C79[1 + i] << i * 8);
		}
		this.7D140302(num2);
		this.1C636473(67D, 55E114A);
		this.4E9B0C4E(num);
	}

	// Token: 0x04000193 RID: 403
	private uint 681C39CC = 1U;

	// Token: 0x04000194 RID: 404
	private readonly 60D7271D 32640D56 = new 60D7271D();

	// Token: 0x04000195 RID: 405
	private readonly 3EA83B76 45443E5C = new 3EA83B76();

	// Token: 0x04000196 RID: 406
	private readonly 792B7791[] 3EE14E98 = new 792B7791[192];

	// Token: 0x04000197 RID: 407
	private readonly 792B7791[] 2D8E6091 = new 792B7791[12];

	// Token: 0x04000198 RID: 408
	private readonly 792B7791[] 29477598 = new 792B7791[12];

	// Token: 0x04000199 RID: 409
	private readonly 792B7791[] 7A3C58B7 = new 792B7791[12];

	// Token: 0x0400019A RID: 410
	private readonly 792B7791[] 3C830618 = new 792B7791[12];

	// Token: 0x0400019B RID: 411
	private readonly 792B7791[] 325D1AB0 = new 792B7791[192];

	// Token: 0x0400019C RID: 412
	private readonly 6C703443[] 41BE7632 = new 6C703443[4];

	// Token: 0x0400019D RID: 413
	private readonly 792B7791[] 3EF2498D = new 792B7791[114];

	// Token: 0x0400019E RID: 414
	private 6C703443 75995E8E = new 6C703443(4);

	// Token: 0x0400019F RID: 415
	private readonly 44BD2378.7A8A380F 2A50095B = new 44BD2378.7A8A380F();

	// Token: 0x040001A0 RID: 416
	private readonly 44BD2378.7A8A380F 62B77AD8 = new 44BD2378.7A8A380F();

	// Token: 0x040001A1 RID: 417
	private readonly 44BD2378.44BF2D15 6EC5233F = new 44BD2378.44BF2D15();

	// Token: 0x040001A2 RID: 418
	private uint 457D0E71;

	// Token: 0x040001A3 RID: 419
	private uint 187E2FC6;

	// Token: 0x040001A4 RID: 420
	private uint 5D150165;

	// Token: 0x02000076 RID: 118
	private class 7A8A380F
	{
		// Token: 0x060004A4 RID: 1188 RVA: 0x003108B0 File Offset: 0x0030E4B0
		public void 0AF32D9B(uint 56307956)
		{
			for (uint num = this.200B7116; num < 56307956; num += 1U)
			{
				this.0631530D[(int)num] = new 6C703443(3);
				this.3DBF5102[(int)num] = new 6C703443(3);
			}
			this.200B7116 = 56307956;
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x00310900 File Offset: 0x0030E500
		public void 7A952003()
		{
			this.22C259FF.2A5E052D();
			for (uint num = 0U; num < this.200B7116; num += 1U)
			{
				this.0631530D[(int)num].09C01B9D();
				this.3DBF5102[(int)num].09C01B9D();
			}
			this.76BA1168.2A5E052D();
			this.07A31335.09C01B9D();
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x00310968 File Offset: 0x0030E568
		public uint 49130687(3EA83B76 1AF210AC, uint 6CC179E5)
		{
			if (this.22C259FF.638962C8(1AF210AC) == 0U)
			{
				return this.0631530D[(int)6CC179E5].237E3620(1AF210AC);
			}
			uint num = 8U;
			if (this.76BA1168.638962C8(1AF210AC) == 0U)
			{
				num += this.3DBF5102[(int)6CC179E5].237E3620(1AF210AC);
			}
			else
			{
				num += 8U;
				num += this.07A31335.237E3620(1AF210AC);
			}
			return num;
		}

		// Token: 0x04000213 RID: 531
		private 792B7791 22C259FF;

		// Token: 0x04000214 RID: 532
		private 792B7791 76BA1168;

		// Token: 0x04000215 RID: 533
		private readonly 6C703443[] 0631530D = new 6C703443[16];

		// Token: 0x04000216 RID: 534
		private readonly 6C703443[] 3DBF5102 = new 6C703443[16];

		// Token: 0x04000217 RID: 535
		private 6C703443 07A31335 = new 6C703443(8);

		// Token: 0x04000218 RID: 536
		private uint 200B7116;
	}

	// Token: 0x02000077 RID: 119
	private class 44BF2D15
	{
		// Token: 0x060004A8 RID: 1192 RVA: 0x00310A0C File Offset: 0x0030E60C
		public void 6310695D(int 670F4CA1, int 75BE4F1E)
		{
			if (this.5DFB5ED9 != null && this.3FA43F43 == 75BE4F1E && this.35D51F81 == 670F4CA1)
			{
				return;
			}
			this.35D51F81 = 670F4CA1;
			this.31492ABA = (1U << 670F4CA1) - 1U;
			this.3FA43F43 = 75BE4F1E;
			uint num = 1U << this.3FA43F43 + this.35D51F81;
			this.5DFB5ED9 = new 44BD2378.44BF2D15.02837633[num];
			for (uint num2 = 0U; num2 < num; num2 += 1U)
			{
				this.5DFB5ED9[(int)num2].647922D0();
			}
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x00310A9C File Offset: 0x0030E69C
		public void 3E2E2742()
		{
			uint num = 1U << this.3FA43F43 + this.35D51F81;
			for (uint num2 = 0U; num2 < num; num2 += 1U)
			{
				this.5DFB5ED9[(int)num2].5CBF5EC7();
			}
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x00310AE0 File Offset: 0x0030E6E0
		private uint 195D4F35(uint 5E4752A0, byte 750720AB)
		{
			return ((5E4752A0 & this.31492ABA) << this.3FA43F43) + (uint)(750720AB >> 8 - this.3FA43F43);
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x00310B04 File Offset: 0x0030E704
		public byte 0C9F6D3C(3EA83B76 71A61DB1, uint 2C8E372D, byte 61207783)
		{
			return this.5DFB5ED9[(int)this.195D4F35(2C8E372D, 61207783)].5D2558E0(71A61DB1);
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x00310B20 File Offset: 0x0030E720
		public byte 1FC56E3C(3EA83B76 629015F8, uint 60874B36, byte 02023742, byte 10094BCB)
		{
			return this.5DFB5ED9[(int)this.195D4F35(60874B36, 02023742)].349B5A52(629015F8, 10094BCB);
		}

		// Token: 0x04000219 RID: 537
		private uint 77300635 = 1U;

		// Token: 0x0400021A RID: 538
		private 44BD2378.44BF2D15.02837633[] 5DFB5ED9;

		// Token: 0x0400021B RID: 539
		private int 3FA43F43;

		// Token: 0x0400021C RID: 540
		private int 35D51F81;

		// Token: 0x0400021D RID: 541
		private uint 31492ABA;

		// Token: 0x0200007B RID: 123
		private struct 02837633
		{
			// Token: 0x060004B1 RID: 1201 RVA: 0x00310B50 File Offset: 0x0030E750
			public void 647922D0()
			{
				this.687C3FAB = new 792B7791[768];
			}

			// Token: 0x060004B2 RID: 1202 RVA: 0x00310B64 File Offset: 0x0030E764
			public void 5CBF5EC7()
			{
				for (int i = 0; i < 768; i++)
				{
					this.687C3FAB[i].2A5E052D();
				}
			}

			// Token: 0x060004B3 RID: 1203 RVA: 0x00310B98 File Offset: 0x0030E798
			public byte 5D2558E0(3EA83B76 0D685AA4)
			{
				uint num = 1U;
				do
				{
					num = (num << 1 | this.687C3FAB[(int)num].638962C8(0D685AA4));
				}
				while (num < 256U);
				return (byte)num;
			}

			// Token: 0x060004B4 RID: 1204 RVA: 0x00310BCC File Offset: 0x0030E7CC
			public byte 349B5A52(3EA83B76 05E537F7, byte 002F5E6B)
			{
				uint num = 1U;
				for (;;)
				{
					uint num2 = (uint)(002F5E6B >> 7 & 1);
					002F5E6B = (byte)(002F5E6B << 1);
					uint num3 = this.687C3FAB[(int)((1U + num2 << 8) + num)].638962C8(05E537F7);
					num = (num << 1 | num3);
					if (num2 != num3)
					{
						break;
					}
					if (num >= 256U)
					{
						goto IL_6B;
					}
				}
				while (num < 256U)
				{
					num = (num << 1 | this.687C3FAB[(int)num].638962C8(05E537F7));
				}
				IL_6B:
				return (byte)num;
			}

			// Token: 0x04000220 RID: 544
			private 792B7791[] 687C3FAB;
		}
	}
}
