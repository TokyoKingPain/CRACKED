﻿using System;
using System.Drawing;

// Token: 0x02000006 RID: 6
internal struct Bloom
{
	// Token: 0x1700002C RID: 44
	// (get) Token: 0x06000108 RID: 264 RVA: 0x0000503A File Offset: 0x0000343A
	public string Name
	{
		get
		{
			return this._Name;
		}
	}

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x06000109 RID: 265 RVA: 0x00005042 File Offset: 0x00003442
	// (set) Token: 0x0600010A RID: 266 RVA: 0x0000504A File Offset: 0x0000344A
	public Color Value
	{
		get
		{
			return this._Value;
		}
		set
		{
			this._Value = value;
		}
	}

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x0600010B RID: 267 RVA: 0x00005054 File Offset: 0x00003454
	// (set) Token: 0x0600010C RID: 268 RVA: 0x000050B8 File Offset: 0x000034B8
	public string ValueHex
	{
		get
		{
			return "#" + this._Value.R.ToString("X2", null) + this._Value.G.ToString("X2", null) + this._Value.B.ToString("X2", null);
		}
		set
		{
			try
			{
				this._Value = ColorTranslator.FromHtml(value);
			}
			catch
			{
			}
		}
	}

	// Token: 0x0600010D RID: 269 RVA: 0x000050E8 File Offset: 0x000034E8
	public Bloom(string name, Color value)
	{
		this._Name = name;
		this._Value = value;
	}

	// Token: 0x04000063 RID: 99
	public string _Name;

	// Token: 0x04000064 RID: 100
	private Color _Value;
}
