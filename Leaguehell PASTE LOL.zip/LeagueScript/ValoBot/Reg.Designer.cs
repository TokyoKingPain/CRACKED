﻿namespace ValoBot
{
	// Token: 0x0200001A RID: 26
	public partial class Reg : global::System.Windows.Forms.Form
	{
		// Token: 0x06000181 RID: 385 RVA: 0x00008088 File Offset: 0x00006488
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000182 RID: 386 RVA: 0x000080A8 File Offset: 0x000064A8
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ValoBot.Reg));
			this.textBox4 = new global::System.Windows.Forms.TextBox();
			this.textBox3 = new global::System.Windows.Forms.TextBox();
			this.textBox2 = new global::System.Windows.Forms.TextBox();
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.eliteButton1 = new global::eliteButton();
			this.eliteButton4 = new global::eliteButton();
			this.eliteLabel5 = new global::eliteLabel();
			this.eliteLabel4 = new global::eliteLabel();
			this.eliteLabel3 = new global::eliteLabel();
			this.eliteLabel2 = new global::eliteLabel();
			this.eliteLabel1 = new global::eliteLabel();
			this.eliteButton3 = new global::eliteButton();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.textBox4.Location = new global::System.Drawing.Point(101, 144);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new global::System.Drawing.Size(172, 20);
			this.textBox4.TabIndex = 27;
			this.textBox3.Location = new global::System.Drawing.Point(101, 118);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new global::System.Drawing.Size(172, 20);
			this.textBox3.TabIndex = 26;
			this.textBox2.Location = new global::System.Drawing.Point(101, 92);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new global::System.Drawing.Size(172, 20);
			this.textBox2.TabIndex = 25;
			this.textBox1.Location = new global::System.Drawing.Point(101, 66);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new global::System.Drawing.Size(172, 20);
			this.textBox1.TabIndex = 24;
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(11, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(60, 48);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 35;
			this.pictureBox1.TabStop = false;
			this.eliteButton1.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton1.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton1.Image = null;
			this.eliteButton1.Location = new global::System.Drawing.Point(12, 233);
			this.eliteButton1.Name = "eliteButton1";
			this.eliteButton1.NoRounding = false;
			this.eliteButton1.Size = new global::System.Drawing.Size(262, 23);
			this.eliteButton1.TabIndex = 38;
			this.eliteButton1.Text = "EXIT";
			this.eliteButton1.Transparent = false;
			this.eliteButton1.Click += new global::System.EventHandler(this.eliteButton1_Click_1);
			this.eliteButton4.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton4.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton4.Image = null;
			this.eliteButton4.Location = new global::System.Drawing.Point(12, 173);
			this.eliteButton4.Name = "eliteButton4";
			this.eliteButton4.NoRounding = false;
			this.eliteButton4.Size = new global::System.Drawing.Size(128, 54);
			this.eliteButton4.TabIndex = 37;
			this.eliteButton4.Text = "REGISTER";
			this.eliteButton4.Transparent = false;
			this.eliteButton4.Click += new global::System.EventHandler(this.eliteButton4_Click);
			this.eliteLabel5.Customization = "/v7+/yoqKv8=";
			this.eliteLabel5.Font = new global::System.Drawing.Font("ZeF RAVE", 24f, global::System.Drawing.FontStyle.Italic, global::System.Drawing.GraphicsUnit.Point, 0);
			this.eliteLabel5.Image = null;
			this.eliteLabel5.Location = new global::System.Drawing.Point(82, 12);
			this.eliteLabel5.Name = "eliteLabel5";
			this.eliteLabel5.NoRounding = false;
			this.eliteLabel5.Size = new global::System.Drawing.Size(191, 48);
			this.eliteLabel5.TabIndex = 36;
			this.eliteLabel5.Text = "ValoEXP";
			this.eliteLabel5.Transparent = false;
			this.eliteLabel4.Customization = "/v7+/yoqKv8=";
			this.eliteLabel4.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteLabel4.Image = null;
			this.eliteLabel4.Location = new global::System.Drawing.Point(10, 144);
			this.eliteLabel4.Name = "eliteLabel4";
			this.eliteLabel4.NoRounding = false;
			this.eliteLabel4.Size = new global::System.Drawing.Size(75, 23);
			this.eliteLabel4.TabIndex = 34;
			this.eliteLabel4.Text = "License Key:";
			this.eliteLabel4.Transparent = false;
			this.eliteLabel3.Customization = "/v7+/yoqKv8=";
			this.eliteLabel3.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteLabel3.Image = null;
			this.eliteLabel3.Location = new global::System.Drawing.Point(10, 118);
			this.eliteLabel3.Name = "eliteLabel3";
			this.eliteLabel3.NoRounding = false;
			this.eliteLabel3.Size = new global::System.Drawing.Size(75, 23);
			this.eliteLabel3.TabIndex = 33;
			this.eliteLabel3.Text = "Email:";
			this.eliteLabel3.Transparent = false;
			this.eliteLabel2.Customization = "/v7+/yoqKv8=";
			this.eliteLabel2.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteLabel2.Image = null;
			this.eliteLabel2.Location = new global::System.Drawing.Point(10, 92);
			this.eliteLabel2.Name = "eliteLabel2";
			this.eliteLabel2.NoRounding = false;
			this.eliteLabel2.Size = new global::System.Drawing.Size(75, 23);
			this.eliteLabel2.TabIndex = 32;
			this.eliteLabel2.Text = "Password:";
			this.eliteLabel2.Transparent = false;
			this.eliteLabel1.Customization = "/v7+/yoqKv8=";
			this.eliteLabel1.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteLabel1.Image = null;
			this.eliteLabel1.Location = new global::System.Drawing.Point(10, 66);
			this.eliteLabel1.Name = "eliteLabel1";
			this.eliteLabel1.NoRounding = false;
			this.eliteLabel1.Size = new global::System.Drawing.Size(75, 23);
			this.eliteLabel1.TabIndex = 31;
			this.eliteLabel1.Text = "Login:";
			this.eliteLabel1.Transparent = false;
			this.eliteButton3.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton3.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton3.Image = null;
			this.eliteButton3.Location = new global::System.Drawing.Point(146, 173);
			this.eliteButton3.Name = "eliteButton3";
			this.eliteButton3.NoRounding = false;
			this.eliteButton3.Size = new global::System.Drawing.Size(128, 54);
			this.eliteButton3.TabIndex = 28;
			this.eliteButton3.Text = "LOGIN";
			this.eliteButton3.Transparent = false;
			this.eliteButton3.Click += new global::System.EventHandler(this.eliteButton3_Click_1);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(42, 42, 42);
			base.ClientSize = new global::System.Drawing.Size(288, 266);
			base.Controls.Add(this.eliteButton1);
			base.Controls.Add(this.eliteButton4);
			base.Controls.Add(this.eliteLabel5);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.eliteLabel4);
			base.Controls.Add(this.eliteLabel3);
			base.Controls.Add(this.eliteLabel2);
			base.Controls.Add(this.eliteLabel1);
			base.Controls.Add(this.eliteButton3);
			base.Controls.Add(this.textBox4);
			base.Controls.Add(this.textBox3);
			base.Controls.Add(this.textBox2);
			base.Controls.Add(this.textBox1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "Reg";
			this.Text = "Register Area";
			base.TransparencyKey = global::System.Drawing.Color.Purple;
			base.Load += new global::System.EventHandler(this.Reg_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040000DE RID: 222
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040000DF RID: 223
		private global::eliteLabel eliteLabel4;

		// Token: 0x040000E0 RID: 224
		private global::eliteLabel eliteLabel3;

		// Token: 0x040000E1 RID: 225
		private global::eliteLabel eliteLabel2;

		// Token: 0x040000E2 RID: 226
		private global::eliteLabel eliteLabel1;

		// Token: 0x040000E3 RID: 227
		private global::eliteButton eliteButton3;

		// Token: 0x040000E4 RID: 228
		private global::System.Windows.Forms.TextBox textBox4;

		// Token: 0x040000E5 RID: 229
		private global::System.Windows.Forms.TextBox textBox3;

		// Token: 0x040000E6 RID: 230
		private global::System.Windows.Forms.TextBox textBox2;

		// Token: 0x040000E7 RID: 231
		private global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x040000E8 RID: 232
		private global::eliteLabel eliteLabel5;

		// Token: 0x040000E9 RID: 233
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x040000EA RID: 234
		private global::eliteButton eliteButton4;

		// Token: 0x040000EB RID: 235
		private global::eliteButton eliteButton1;
	}
}
