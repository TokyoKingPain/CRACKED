﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using LHSharp;

namespace ValoBot
{
	// Token: 0x0200001A RID: 26
	public partial class Reg : Form
	{
		// Token: 0x0600017B RID: 379 RVA: 0x00007FB5 File Offset: 0x000063B5
		public Reg()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600017C RID: 380 RVA: 0x00007FC4 File Offset: 0x000063C4
		private void eliteButton1_Click(object sender, EventArgs e)
		{
			if (API.Register(this.textBox1.Text, this.textBox2.Text, this.textBox3.Text, this.textBox4.Text))
			{
				MessageBox.Show("Register has been successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}

		// Token: 0x0600017D RID: 381 RVA: 0x00008018 File Offset: 0x00006418
		private void eliteButton4_Click(object sender, EventArgs e)
		{
			if (API.Register(this.textBox1.Text, this.textBox2.Text, this.textBox3.Text, this.textBox4.Text))
			{
				MessageBox.Show("Register has been successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}

		// Token: 0x0600017E RID: 382 RVA: 0x0000806B File Offset: 0x0000646B
		private void eliteButton3_Click_1(object sender, EventArgs e)
		{
			base.Hide();
			new Form2().ShowDialog();
		}

		// Token: 0x0600017F RID: 383 RVA: 0x0000807E File Offset: 0x0000647E
		private void eliteButton1_Click_1(object sender, EventArgs e)
		{
			base.Close();
		}

		// Token: 0x06000180 RID: 384 RVA: 0x00008086 File Offset: 0x00006486
		private void Reg_Load(object sender, EventArgs e)
		{
		}
	}
}
