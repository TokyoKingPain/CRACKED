﻿namespace ValoBot
{
	// Token: 0x02000019 RID: 25
	public partial class Form2 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000179 RID: 377 RVA: 0x0000788B File Offset: 0x00005C8B
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600017A RID: 378 RVA: 0x000078AC File Offset: 0x00005CAC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ValoBot.Form2));
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.textBox2 = new global::System.Windows.Forms.TextBox();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.eliteButton1 = new global::eliteButton();
			this.eliteLabel3 = new global::eliteLabel();
			this.eliteButton2 = new global::eliteButton();
			this.eliteButton3 = new global::eliteButton();
			this.eliteLabel2 = new global::eliteLabel();
			this.eliteLabel1 = new global::eliteLabel();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.textBox1.Location = new global::System.Drawing.Point(83, 76);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new global::System.Drawing.Size(191, 20);
			this.textBox1.TabIndex = 6;
			this.textBox2.Location = new global::System.Drawing.Point(83, 102);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new global::System.Drawing.Size(191, 20);
			this.textBox2.TabIndex = 13;
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(11, 2);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(60, 58);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.eliteButton1.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton1.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton1.Image = null;
			this.eliteButton1.Location = new global::System.Drawing.Point(12, 194);
			this.eliteButton1.Name = "eliteButton1";
			this.eliteButton1.NoRounding = false;
			this.eliteButton1.Size = new global::System.Drawing.Size(262, 23);
			this.eliteButton1.TabIndex = 17;
			this.eliteButton1.Text = "EXIT";
			this.eliteButton1.Transparent = false;
			this.eliteButton1.Click += new global::System.EventHandler(this.eliteButton1_Click_1);
			this.eliteLabel3.Customization = "/v7+/yoqKv8=";
			this.eliteLabel3.Font = new global::System.Drawing.Font("ZeF RAVE", 18f, global::System.Drawing.FontStyle.Italic);
			this.eliteLabel3.Image = null;
			this.eliteLabel3.Location = new global::System.Drawing.Point(83, 12);
			this.eliteLabel3.Name = "eliteLabel3";
			this.eliteLabel3.NoRounding = false;
			this.eliteLabel3.Size = new global::System.Drawing.Size(191, 48);
			this.eliteLabel3.TabIndex = 16;
			this.eliteLabel3.Text = "LeagueScript";
			this.eliteLabel3.Transparent = false;
			this.eliteButton2.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton2.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton2.Image = null;
			this.eliteButton2.Location = new global::System.Drawing.Point(146, 134);
			this.eliteButton2.Name = "eliteButton2";
			this.eliteButton2.NoRounding = false;
			this.eliteButton2.Size = new global::System.Drawing.Size(128, 54);
			this.eliteButton2.TabIndex = 15;
			this.eliteButton2.Text = "REGISTER";
			this.eliteButton2.Transparent = false;
			this.eliteButton2.Click += new global::System.EventHandler(this.eliteButton2_Click_1);
			this.eliteButton3.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton3.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton3.Image = null;
			this.eliteButton3.Location = new global::System.Drawing.Point(12, 134);
			this.eliteButton3.Name = "eliteButton3";
			this.eliteButton3.NoRounding = false;
			this.eliteButton3.Size = new global::System.Drawing.Size(128, 54);
			this.eliteButton3.TabIndex = 14;
			this.eliteButton3.Text = "LOGIN";
			this.eliteButton3.Transparent = false;
			this.eliteButton3.Click += new global::System.EventHandler(this.eliteButton3_Click_1);
			this.eliteLabel2.Customization = "/v7+/yoqKv8=";
			this.eliteLabel2.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteLabel2.Image = null;
			this.eliteLabel2.Location = new global::System.Drawing.Point(11, 105);
			this.eliteLabel2.Name = "eliteLabel2";
			this.eliteLabel2.NoRounding = false;
			this.eliteLabel2.Size = new global::System.Drawing.Size(61, 23);
			this.eliteLabel2.TabIndex = 12;
			this.eliteLabel2.Text = "Password:";
			this.eliteLabel2.Transparent = false;
			this.eliteLabel1.Customization = "/v7+/yoqKv8=";
			this.eliteLabel1.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteLabel1.Image = null;
			this.eliteLabel1.Location = new global::System.Drawing.Point(20, 76);
			this.eliteLabel1.Name = "eliteLabel1";
			this.eliteLabel1.NoRounding = false;
			this.eliteLabel1.Size = new global::System.Drawing.Size(45, 23);
			this.eliteLabel1.TabIndex = 11;
			this.eliteLabel1.Text = "Login:";
			this.eliteLabel1.Transparent = false;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(42, 42, 42);
			base.ClientSize = new global::System.Drawing.Size(289, 227);
			base.Controls.Add(this.eliteButton1);
			base.Controls.Add(this.eliteLabel3);
			base.Controls.Add(this.eliteButton2);
			base.Controls.Add(this.eliteButton3);
			base.Controls.Add(this.textBox2);
			base.Controls.Add(this.eliteLabel2);
			base.Controls.Add(this.eliteLabel1);
			base.Controls.Add(this.textBox1);
			base.Controls.Add(this.pictureBox1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "Form2";
			this.Text = "Form2";
			base.TransparencyKey = global::System.Drawing.Color.Purple;
			base.Load += new global::System.EventHandler(this.Form2_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040000D4 RID: 212
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040000D5 RID: 213
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x040000D6 RID: 214
		private global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x040000D7 RID: 215
		private global::eliteLabel eliteLabel1;

		// Token: 0x040000D8 RID: 216
		private global::eliteLabel eliteLabel2;

		// Token: 0x040000D9 RID: 217
		private global::System.Windows.Forms.TextBox textBox2;

		// Token: 0x040000DA RID: 218
		private global::eliteButton eliteButton3;

		// Token: 0x040000DB RID: 219
		private global::eliteButton eliteButton2;

		// Token: 0x040000DC RID: 220
		private global::eliteLabel eliteLabel3;

		// Token: 0x040000DD RID: 221
		private global::eliteButton eliteButton1;
	}
}
