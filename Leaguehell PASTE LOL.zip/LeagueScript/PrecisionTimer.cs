﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000007 RID: 7
internal class PrecisionTimer : IDisposable
{
	// Token: 0x1700002F RID: 47
	// (get) Token: 0x0600010E RID: 270 RVA: 0x000050F8 File Offset: 0x000034F8
	public bool Enabled
	{
		get
		{
			return this._Enabled;
		}
	}

	// Token: 0x0600010F RID: 271
	[DllImport("kernel32.dll")]
	private static extern bool CreateTimerQueueTimer(ref IntPtr handle, IntPtr queue, PrecisionTimer.TimerDelegate callback, IntPtr state, uint dueTime, uint period, uint flags);

	// Token: 0x06000110 RID: 272
	[DllImport("kernel32.dll")]
	private static extern bool DeleteTimerQueueTimer(IntPtr queue, IntPtr handle, IntPtr callback);

	// Token: 0x06000111 RID: 273 RVA: 0x00005100 File Offset: 0x00003500
	public void Create(uint dueTime, uint period, PrecisionTimer.TimerDelegate callback)
	{
		if (this._Enabled)
		{
			return;
		}
		this.TimerCallback = callback;
		bool flag = PrecisionTimer.CreateTimerQueueTimer(ref this.Handle, IntPtr.Zero, this.TimerCallback, IntPtr.Zero, dueTime, period, 0U);
		if (!flag)
		{
			this.ThrowNewException("CreateTimerQueueTimer");
		}
		this._Enabled = flag;
	}

	// Token: 0x06000112 RID: 274 RVA: 0x00005154 File Offset: 0x00003554
	public void Delete()
	{
		if (!this._Enabled)
		{
			return;
		}
		bool flag = PrecisionTimer.DeleteTimerQueueTimer(IntPtr.Zero, this.Handle, IntPtr.Zero);
		if (!flag && Marshal.GetLastWin32Error() != 997)
		{
			this.ThrowNewException("DeleteTimerQueueTimer");
		}
		this._Enabled = !flag;
	}

	// Token: 0x06000113 RID: 275 RVA: 0x000051A4 File Offset: 0x000035A4
	private void ThrowNewException(string name)
	{
		throw new Exception(string.Format("{0} failed. Win32Error: {1}", name, Marshal.GetLastWin32Error()));
	}

	// Token: 0x06000114 RID: 276 RVA: 0x000051C0 File Offset: 0x000035C0
	public void Dispose()
	{
		this.Delete();
	}

	// Token: 0x04000065 RID: 101
	private bool _Enabled;

	// Token: 0x04000066 RID: 102
	private IntPtr Handle;

	// Token: 0x04000067 RID: 103
	private PrecisionTimer.TimerDelegate TimerCallback;

	// Token: 0x02000026 RID: 38
	// (Invoke) Token: 0x060001E4 RID: 484
	public delegate void TimerDelegate(IntPtr r1, bool r2);
}
