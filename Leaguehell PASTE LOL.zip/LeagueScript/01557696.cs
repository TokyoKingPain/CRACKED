﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200002E RID: 46
public class 01557696
{
	// Token: 0x06000203 RID: 515 RVA: 0x002FC19C File Offset: 0x002F9D9C
	public 01557696()
	{
		if (01557696.110D424D == null)
		{
			01557696.110D424D = new uint[256];
			for (int i = 0; i < 256; i++)
			{
				uint num = (uint)i;
				for (int j = 0; j < 8; j++)
				{
					if ((num & 1U) == 1U)
					{
						num = (num >> 1 ^ 3988292384U);
					}
					else
					{
						num >>= 1;
					}
				}
				01557696.110D424D[i] = num;
			}
		}
	}

	// Token: 0x06000204 RID: 516 RVA: 0x002FC218 File Offset: 0x002F9E18
	public uint 4521524A(IntPtr 75644D84, uint 5D4E101F)
	{
		uint num = 0U;
		int num2 = 0;
		while ((long)num2 < (long)((ulong)5D4E101F))
		{
			num = (01557696.110D424D[(int)(((uint)Marshal.ReadByte(new IntPtr(75644D84.ToInt64() + (long)num2)) ^ num) & 255U)] ^ num >> 8);
			num2++;
		}
		return ~num;
	}

	// Token: 0x04000128 RID: 296
	private static uint[] 110D424D;
}
