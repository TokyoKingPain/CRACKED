﻿using System;
using System.ComponentModel;
using System.Drawing;

// Token: 0x02000014 RID: 20
[DefaultEvent("CheckedChanged")]
internal class eliteCheckBox : ThemeControl154
{
	// Token: 0x06000140 RID: 320 RVA: 0x000068D4 File Offset: 0x00004CD4
	public eliteCheckBox()
	{
		base.Transparent = true;
		this.BackColor = Color.Transparent;
		base.SetColor("Background", 249, 249, 249);
		base.SetColor("ClickedGradient1", 204, 201, 35);
		base.SetColor("ClickedGradient2", 140, 138, 27);
		base.SetColor("Border1", 235, 235, 235);
		base.SetColor("Border2", 249, 249, 249);
	}

	// Token: 0x06000141 RID: 321 RVA: 0x00006978 File Offset: 0x00004D78
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("Background");
		this.C2 = base.GetColor("ClickedGradient1");
		this.C3 = base.GetColor("ClickedGradient2");
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x06000142 RID: 322 RVA: 0x000069E4 File Offset: 0x00004DE4
	protected override void PaintHook()
	{
		this.G.Clear(this.BackColor);
		if (this._Checked)
		{
			base.DrawGradient(this.C1, this.C1, base.ClientRectangle, 90f);
			base.DrawGradient(this.C2, this.C3, 3, 3, base.Width - 6, base.Height - 6, 90f);
			base.DrawBorders(this.P1, 1);
			base.Height = base.Width;
			base.DrawBorders(this.P2);
			base.DrawCorners(this.BackColor);
			return;
		}
		base.DrawGradient(this.C1, this.C1, base.ClientRectangle, 90f);
		base.DrawBorders(this.P1, 1);
		base.Height = base.Width;
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x06000143 RID: 323 RVA: 0x00006AD0 File Offset: 0x00004ED0
	// (set) Token: 0x06000144 RID: 324 RVA: 0x00006AD8 File Offset: 0x00004ED8
	private bool _Checked { get; set; }

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x06000145 RID: 325 RVA: 0x00006AE1 File Offset: 0x00004EE1
	// (set) Token: 0x06000146 RID: 326 RVA: 0x00006AE9 File Offset: 0x00004EE9
	public bool Checked
	{
		get
		{
			return this._Checked;
		}
		set
		{
			this._Checked = value;
		}
	}

	// Token: 0x06000147 RID: 327 RVA: 0x00006AF2 File Offset: 0x00004EF2
	protected override void OnClick(EventArgs e)
	{
		this._Checked = !this._Checked;
		if (this.CheckedChanged != null)
		{
			this.CheckedChanged(this);
		}
		base.OnClick(e);
	}

	// Token: 0x14000001 RID: 1
	// (add) Token: 0x06000148 RID: 328 RVA: 0x00006B20 File Offset: 0x00004F20
	// (remove) Token: 0x06000149 RID: 329 RVA: 0x00006B58 File Offset: 0x00004F58
	public event eliteCheckBox.CheckedChangedEventHandler CheckedChanged;

	// Token: 0x040000C0 RID: 192
	private Color C1;

	// Token: 0x040000C1 RID: 193
	private Color C2;

	// Token: 0x040000C2 RID: 194
	private Color C3;

	// Token: 0x040000C3 RID: 195
	private Pen P1;

	// Token: 0x040000C4 RID: 196
	private Pen P2;

	// Token: 0x02000027 RID: 39
	// (Invoke) Token: 0x060001E8 RID: 488
	public delegate void CheckedChangedEventHandler(object sender);
}
