﻿using System;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x0200003C RID: 60
internal static class 02211CF7
{
	// Token: 0x060002A1 RID: 673
	[DllImport("kernel32", CharSet = CharSet.Auto, EntryPoint = "CreateFile", SetLastError = true)]
	public static extern IntPtr 0ED5194C(string 39B7147A, int 7F7E2BB9, int 01A548B5, IntPtr 4EF8480B, int 1EB264CA, int 454418C1, IntPtr 57F963F9);

	// Token: 0x060002A2 RID: 674
	[DllImport("kernel32", CharSet = CharSet.Auto, EntryPoint = "CreateFileMapping", SetLastError = true)]
	public static extern IntPtr 24276583(IntPtr 3EF65D37, IntPtr 303A3B8A, 02211CF7.36962D8D 237F4923, int 0E247207, int 6F98756A, string 39D436A8);

	// Token: 0x060002A3 RID: 675
	[DllImport("kernel32", EntryPoint = "FlushViewOfFile", SetLastError = true)]
	public static extern bool 19957B23(IntPtr 3EE45338, int 53990D0F);

	// Token: 0x060002A4 RID: 676
	[DllImport("kernel32", EntryPoint = "MapViewOfFile", SetLastError = true)]
	public static extern IntPtr 6A9A777F(IntPtr 18D0554F, 02211CF7.5C1B0CC2 27FA6135, int 04BF439F, int 04FA17A5, IntPtr 29646D17);

	// Token: 0x060002A5 RID: 677
	[DllImport("kernel32", CharSet = CharSet.Auto, EntryPoint = "OpenFileMapping", SetLastError = true)]
	public static extern IntPtr 37E416A9(int 749A6DE8, bool 7B6E2BBC, string 00A03F40);

	// Token: 0x060002A6 RID: 678
	[DllImport("kernel32", EntryPoint = "UnmapViewOfFile", SetLastError = true)]
	public static extern bool 5AEA6B29(IntPtr 3F6B6EF8);

	// Token: 0x060002A7 RID: 679
	[DllImport("kernel32", EntryPoint = "CloseHandle", SetLastError = true)]
	public static extern bool 675B6026(IntPtr 63970199);

	// Token: 0x060002A8 RID: 680
	[DllImport("kernel32", EntryPoint = "GetFileSize", SetLastError = true)]
	public static extern uint 110F4228(IntPtr 62E64034, IntPtr 4B170EBC);

	// Token: 0x060002A9 RID: 681
	[DllImport("kernel32", EntryPoint = "VirtualAlloc", SetLastError = true)]
	public static extern IntPtr 62532A9E(IntPtr 70D375A9, UIntPtr 0F460DC6, 02211CF7.63233398 252E0772, 02211CF7.36962D8D 039F10D8);

	// Token: 0x060002AA RID: 682
	[DllImport("kernel32", EntryPoint = "VirtualFree")]
	public static extern bool 4DCC4CC3(IntPtr 63DE3AE6, uint 44F23B11, uint 16DF1826);

	// Token: 0x060002AB RID: 683
	[DllImport("kernel32", EntryPoint = "VirtualProtect", SetLastError = true)]
	public static extern bool 404A56A5(IntPtr 28AC02B9, UIntPtr 37A05DF2, 02211CF7.36962D8D 315963BF, out 02211CF7.36962D8D 07AA67C1);

	// Token: 0x060002AC RID: 684
	[DllImport("kernel32", EntryPoint = "GetVolumeInformation")]
	public static extern bool 3A356F51(string 2C671666, StringBuilder 3C833A10, uint 5D2D1E3B, ref uint 22D228FA, ref uint 592C454A, ref uint 7CC34D09, StringBuilder 79945791, uint 1FAD3A4C);

	// Token: 0x060002AD RID: 685
	[DllImport("kernel32", EntryPoint = "IsDebuggerPresent")]
	public static extern bool 75886373();

	// Token: 0x060002AE RID: 686
	[DllImport("kernel32", EntryPoint = "CheckRemoteDebuggerPresent")]
	public static extern bool 046F5BF0();

	// Token: 0x060002AF RID: 687
	[DllImport("ntdll", EntryPoint = "NtQueryInformationProcess")]
	public static extern int 7601163B(IntPtr 060A32B5, int 14F32DA9, byte[] 7CA87DF4, uint 42282475, out uint 1B451E5B);

	// Token: 0x0400016D RID: 365
	public const int 5C761242 = -2147483648;

	// Token: 0x0400016E RID: 366
	public const int 0DF73B39 = 3;

	// Token: 0x0400016F RID: 367
	public const int 2B4028F8 = 128;

	// Token: 0x04000170 RID: 368
	public const int 66D766D3 = 1;

	// Token: 0x04000171 RID: 369
	public const int 5E066728 = 2;

	// Token: 0x04000172 RID: 370
	public static readonly IntPtr 43043F59 = new IntPtr(-1);

	// Token: 0x04000173 RID: 371
	public static readonly IntPtr 7989609C = IntPtr.Zero;

	// Token: 0x04000174 RID: 372
	public static readonly IntPtr 40EB1C19 = new IntPtr(-1);

	// Token: 0x0200006E RID: 110
	public enum 63233398 : uint
	{
		// Token: 0x040001EE RID: 494
		42404B69 = 4096U,
		// Token: 0x040001EF RID: 495
		4570048B = 8192U
	}

	// Token: 0x0200006F RID: 111
	public enum 36962D8D : uint
	{
		// Token: 0x040001F1 RID: 497
		23056074 = 1U,
		// Token: 0x040001F2 RID: 498
		30BE51CA,
		// Token: 0x040001F3 RID: 499
		75D77D50 = 4U,
		// Token: 0x040001F4 RID: 500
		30780CF2 = 8U,
		// Token: 0x040001F5 RID: 501
		5DA2216D = 16U,
		// Token: 0x040001F6 RID: 502
		3BEB6483 = 32U,
		// Token: 0x040001F7 RID: 503
		456F09C0 = 64U,
		// Token: 0x040001F8 RID: 504
		62011A50 = 256U
	}

	// Token: 0x02000070 RID: 112
	public enum 5C1B0CC2 : uint
	{
		// Token: 0x040001FA RID: 506
		2AFE667F = 1U,
		// Token: 0x040001FB RID: 507
		3C01721E,
		// Token: 0x040001FC RID: 508
		7FCB0AE9 = 4U,
		// Token: 0x040001FD RID: 509
		408C005C = 31U
	}

	// Token: 0x02000071 RID: 113
	public enum 2DB77273 : uint
	{
		// Token: 0x040001FF RID: 511
		69DE14DB = 536870912U,
		// Token: 0x04000200 RID: 512
		5AB85852 = 1073741824U,
		// Token: 0x04000201 RID: 513
		46E20647 = 2147483648U
	}

	// Token: 0x02000072 RID: 114
	public enum 234A055A
	{
		// Token: 0x04000203 RID: 515
		3F335871 = 1,
		// Token: 0x04000204 RID: 516
		225932EB,
		// Token: 0x04000205 RID: 517
		68C7392B = 4,
		// Token: 0x04000206 RID: 518
		38055995 = 8,
		// Token: 0x04000207 RID: 519
		0FFA7B3D = 16,
		// Token: 0x04000208 RID: 520
		2F0B1010 = 32,
		// Token: 0x04000209 RID: 521
		20241D32 = 512,
		// Token: 0x0400020A RID: 522
		0A181362 = 256,
		// Token: 0x0400020B RID: 523
		53015F60 = 768,
		// Token: 0x0400020C RID: 524
		7F7C1AAD = 131097,
		// Token: 0x0400020D RID: 525
		34FC471B = 131078,
		// Token: 0x0400020E RID: 526
		3F8B1404 = 131097,
		// Token: 0x0400020F RID: 527
		3EAD6228 = 983103
	}

	// Token: 0x02000073 RID: 115
	internal static class 7A43237D
	{
		// Token: 0x04000210 RID: 528
		public static UIntPtr 27A05E74 = new UIntPtr(2147483650U);

		// Token: 0x04000211 RID: 529
		public static UIntPtr 682F1887 = new UIntPtr(2147483649U);
	}

	// Token: 0x02000074 RID: 116
	public static class 56584A06
	{
		// Token: 0x06000496 RID: 1174
		[DllImport("advapi32", EntryPoint = "RegOpenKeyEx")]
		private static extern uint 5A8A4D7E(UIntPtr 122D1364, string 7A7E21A0, uint 00D56796, int 5FA50634, out UIntPtr 6B426319);

		// Token: 0x06000497 RID: 1175
		[DllImport("advapi32", EntryPoint = "RegCloseKey")]
		private static extern uint 11930F33(UIntPtr 330257AA);

		// Token: 0x06000498 RID: 1176
		[DllImport("advapi32", EntryPoint = "RegQueryValueEx")]
		private static extern int 16A8257D(UIntPtr 3C7725EE, string 3162492C, int 5E4C28A2, ref uint 0EEE24D0, StringBuilder 7ECC7C23, ref uint 07AD2A0F);

		// Token: 0x06000499 RID: 1177
		[DllImport("advapi32", EntryPoint = "RegQueryInfoKey")]
		private static extern uint 56D00111(UIntPtr 44DB3BD2, StringBuilder 594A3078, ref uint 381C65D9, IntPtr 0A1862A5, IntPtr 60110DBF, IntPtr 2153256F, IntPtr 5E841D3A, IntPtr 34A97F5E, IntPtr 09261744, IntPtr 6EF81463, IntPtr 46771170, out long 745A09CA);

		// Token: 0x0600049A RID: 1178 RVA: 0x001C3FCA File Offset: 0x001C1DCA
		public static string 00921C74(UIntPtr 31E5577F, string 475F666A, string 4B386D2E)
		{
			return 02211CF7.56584A06.72D85F81(31E5577F, 475F666A, 02211CF7.234A055A.0A181362, 4B386D2E);
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x001C3FD9 File Offset: 0x001C1DD9
		public static bool 7A0F0C2E(UIntPtr 1399431F, string 352D6253, ref DateTime 015E5F7A)
		{
			return 02211CF7.56584A06.58F11D7A(1399431F, 352D6253, 02211CF7.234A055A.0A181362, ref 015E5F7A);
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x001C3FE8 File Offset: 0x001C1DE8
		public static bool 58F11D7A(UIntPtr 47612D28, string 76C96EB6, 02211CF7.234A055A 77717EE7, ref DateTime 6A0230EE)
		{
			UIntPtr zero = UIntPtr.Zero;
			bool result;
			try
			{
				uint num = 02211CF7.56584A06.5A8A4D7E(47612D28, 76C96EB6, 0U, (int)(02211CF7.234A055A.3F335871 | 77717EE7), out zero);
				if (num != 0U)
				{
					result = false;
				}
				else
				{
					uint num2 = 0U;
					long fileTime;
					num = 02211CF7.56584A06.56D00111(zero, null, ref num2, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, out fileTime);
					if (num != 0U)
					{
						result = false;
					}
					else
					{
						6A0230EE = DateTime.FromFileTime(fileTime);
						result = true;
					}
				}
			}
			finally
			{
				if (UIntPtr.Zero != zero)
				{
					02211CF7.56584A06.11930F33(zero);
				}
			}
			return result;
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x001C4088 File Offset: 0x001C1E88
		public static string 72D85F81(UIntPtr 5D604697, string 28BF2C8E, 02211CF7.234A055A 57395625, string 390B1C08)
		{
			UIntPtr zero = UIntPtr.Zero;
			string result;
			try
			{
				uint num = 02211CF7.56584A06.5A8A4D7E(5D604697, 28BF2C8E, 0U, (int)(02211CF7.234A055A.3F335871 | 57395625), out zero);
				if (num != 0U)
				{
					result = null;
				}
				else
				{
					uint num2 = 0U;
					uint capacity = 1024U;
					StringBuilder stringBuilder = new StringBuilder((int)capacity);
					02211CF7.56584A06.16A8257D(zero, 390B1C08, 0, ref num2, stringBuilder, ref capacity);
					result = stringBuilder.ToString();
				}
			}
			finally
			{
				if (UIntPtr.Zero != zero)
				{
					02211CF7.56584A06.11930F33(zero);
				}
			}
			return result;
		}
	}
}
