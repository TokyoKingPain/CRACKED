﻿using System;

// Token: 0x02000044 RID: 68
internal struct 6C703443
{
	// Token: 0x060002FB RID: 763 RVA: 0x0030B55C File Offset: 0x0030915C
	public 6C703443(int 49552B74)
	{
		this.56C53F70 = 49552B74;
		this.2CAD16A8 = new 792B7791[1 << 49552B74];
	}

	// Token: 0x060002FC RID: 764 RVA: 0x0030B578 File Offset: 0x00309178
	public void 09C01B9D()
	{
		uint num = 1U;
		while ((ulong)num < (ulong)(1L << (this.56C53F70 & 31)))
		{
			this.2CAD16A8[(int)num].2A5E052D();
			num += 1U;
		}
	}

	// Token: 0x060002FD RID: 765 RVA: 0x0030B5B4 File Offset: 0x003091B4
	public uint 237E3620(3EA83B76 50AF3EE6)
	{
		uint num = 1U;
		for (int i = this.56C53F70; i > 0; i--)
		{
			num = (num << 1) + this.2CAD16A8[(int)num].638962C8(50AF3EE6);
		}
		return num - (1U << this.56C53F70);
	}

	// Token: 0x060002FE RID: 766 RVA: 0x0030B600 File Offset: 0x00309200
	public uint 1759207D(3EA83B76 587C2538)
	{
		uint num = 1U;
		uint num2 = 0U;
		for (int i = 0; i < this.56C53F70; i++)
		{
			uint num3 = this.2CAD16A8[(int)num].638962C8(587C2538);
			num <<= 1;
			num += num3;
			num2 |= num3 << i;
		}
		return num2;
	}

	// Token: 0x060002FF RID: 767 RVA: 0x0030B650 File Offset: 0x00309250
	public static uint 56167BF2(792B7791[] 5FFF446B, uint 31D14ECE, 3EA83B76 68BE26E7, int 6C736FE7)
	{
		uint num = 1U;
		uint num2 = 0U;
		for (int i = 0; i < 6C736FE7; i++)
		{
			uint num3 = 5FFF446B[(int)(31D14ECE + num)].638962C8(68BE26E7);
			num <<= 1;
			num += num3;
			num2 |= num3 << i;
		}
		return num2;
	}

	// Token: 0x040001AE RID: 430
	private readonly 792B7791[] 2CAD16A8;

	// Token: 0x040001AF RID: 431
	private readonly int 56C53F70;
}
