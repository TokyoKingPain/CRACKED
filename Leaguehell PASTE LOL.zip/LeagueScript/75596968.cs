﻿using System;
using System.Collections.Generic;

// Token: 0x02000037 RID: 55
public class 75596968
{
	// Token: 0x06000229 RID: 553 RVA: 0x001E1AD4 File Offset: 0x001DF8D4
	public 75596968()
	{
		object[] 560004FE = new object[]
		{
			this
		};
		new 467F5DB3().37F432DB(560004FE, 55329);
	}

	// Token: 0x0600022A RID: 554 RVA: 0x001E1B04 File Offset: 0x001DF904
	public override string ToString()
	{
		object[] 560004FE = new object[]
		{
			this
		};
		return new 467F5DB3().37F432DB(560004FE, 44691);
	}

	// Token: 0x0400014D RID: 333
	private const int 709F3032 = 8;

	// Token: 0x0400014E RID: 334
	private const int 5F6115CF = 24;

	// Token: 0x0400014F RID: 335
	private const uint 3D8A607A = 3U;

	// Token: 0x04000150 RID: 336
	private readonly int 77B70686;

	// Token: 0x04000151 RID: 337
	private readonly List<uint> 1E7203D3;

	// Token: 0x02000049 RID: 73
	private enum 6E245700
	{
		// Token: 0x040001BD RID: 445
		4CC87844,
		// Token: 0x040001BE RID: 446
		7D0438D8,
		// Token: 0x040001BF RID: 447
		48132F6F,
		// Token: 0x040001C0 RID: 448
		629E53FC
	}
}
