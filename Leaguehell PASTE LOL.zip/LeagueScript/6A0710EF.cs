﻿using System;
using System.Collections.Generic;

// Token: 0x0200003A RID: 58
public class 6A0710EF
{
	// Token: 0x0600022D RID: 557 RVA: 0x001E1BA0 File Offset: 0x001DF9A0
	public 6A0710EF(long 615C0E66)
	{
		object[] 560004FE = new object[]
		{
			this,
			615C0E66
		};
		new 467F5DB3().37F432DB(560004FE, 54088);
	}

	// Token: 0x0400015A RID: 346
	private readonly long 688A7006;

	// Token: 0x0400015B RID: 347
	private readonly 340C17D1 2ACA0E05;

	// Token: 0x0400015C RID: 348
	private readonly Dictionary<uint, string> 542C72E0;

	// Token: 0x0400015D RID: 349
	private readonly uint 41401CDC;
}
