﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000008 RID: 8
internal class eliteSimple : ThemeContainer154
{
	// Token: 0x06000116 RID: 278 RVA: 0x000051D0 File Offset: 0x000035D0
	public eliteSimple()
	{
		this.BackColor = Color.FromArgb(42, 42, 42);
		base.TransparencyKey = Color.Purple;
		base.SetColor("Background", 42, 42, 42);
		base.SetColor("DarkGradient", 32, 32, 32);
		base.SetColor("BackgroundGradient", 42, 42, 42);
		base.SetColor("Line1", 42, 42, 42);
		base.SetColor("Line2", 28, 28, 28);
		base.SetColor("Text", 254, 254, 254);
		base.SetColor("Border1", 43, 43, 43);
		base.SetColor("Border2", 25, 25, 25);
	}

	// Token: 0x06000117 RID: 279 RVA: 0x00005290 File Offset: 0x00003690
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("Background");
		this.C2 = base.GetColor("DarkGradient");
		this.C3 = base.GetColor("BackgroundGradient");
		this.P1 = new Pen(base.GetColor("Line1"));
		this.P2 = new Pen(base.GetColor("Line2"));
		this.P3 = new Pen(base.GetColor("Border1"));
		this.P4 = new Pen(base.GetColor("Border2"));
		this.B1 = new SolidBrush(base.GetColor("Text"));
		this.BackColor = this.C1;
	}

	// Token: 0x06000118 RID: 280 RVA: 0x0000534C File Offset: 0x0000374C
	protected override void PaintHook()
	{
		this.G.Clear(this.C1);
		base.DrawGradient(this.C3, this.C2, 0, 0, base.Width, 25);
		this.G.DrawLine(this.P1, 0, 25, base.Width, 25);
		this.G.DrawLine(this.P2, 0, 25, base.Width, 25);
		base.DrawText(this.B1, HorizontalAlignment.Left, 5, 0);
		base.DrawBorders(this.P3, 1);
		base.DrawBorders(this.P4);
		base.DrawCorners(base.TransparencyKey);
	}

	// Token: 0x04000068 RID: 104
	private Color C1;

	// Token: 0x04000069 RID: 105
	private Color C2;

	// Token: 0x0400006A RID: 106
	private Color C3;

	// Token: 0x0400006B RID: 107
	private Pen P1;

	// Token: 0x0400006C RID: 108
	private Pen P2;

	// Token: 0x0400006D RID: 109
	private Pen P3;

	// Token: 0x0400006E RID: 110
	private Pen P4;

	// Token: 0x0400006F RID: 111
	private SolidBrush B1;
}
