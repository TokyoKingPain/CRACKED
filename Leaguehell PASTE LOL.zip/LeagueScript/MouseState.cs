﻿using System;

// Token: 0x02000005 RID: 5
internal enum MouseState : byte
{
	// Token: 0x0400005F RID: 95
	None,
	// Token: 0x04000060 RID: 96
	Over,
	// Token: 0x04000061 RID: 97
	Down,
	// Token: 0x04000062 RID: 98
	Block
}
