﻿using System;

// Token: 0x02000032 RID: 50
public class 2D1E061A
{
	// Token: 0x0600020B RID: 523 RVA: 0x001BA460 File Offset: 0x001B8260
	public 2D1E061A()
	{
		this.60791B15 = 6CF10C53.Invalid;
		this.6FF36540 = DateTime.MaxValue;
		this.3CA3484B = DateTime.MaxValue;
		this.08CD1206 = 0;
		this.769366F4 = new byte[0];
		this.61097504 = "";
		this.71FD5108 = "";
	}

	// Token: 0x04000134 RID: 308
	public 6CF10C53 60791B15;

	// Token: 0x04000135 RID: 309
	public string 61097504;

	// Token: 0x04000136 RID: 310
	public string 71FD5108;

	// Token: 0x04000137 RID: 311
	public DateTime 6FF36540;

	// Token: 0x04000138 RID: 312
	public DateTime 3CA3484B;

	// Token: 0x04000139 RID: 313
	public int 08CD1206;

	// Token: 0x0400013A RID: 314
	public byte[] 769366F4;
}
