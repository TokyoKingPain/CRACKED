﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Threading;

// Token: 0x0200003B RID: 59
public class 467F5DB3
{
	// Token: 0x0600022E RID: 558 RVA: 0x002FC4A8 File Offset: 0x002FA0A8
	public 467F5DB3()
	{
		uint num = 1549145630U;
		for (;;)
		{
			IL_06:
			num = 1633291897U * num;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary = new Dictionary<uint, 467F5DB3.37CE4668>();
			num = (878656385U & num);
			this.4E7C192F = dictionary;
			if (num + 907222082U == 0U)
			{
				goto IL_AA;
			}
			for (;;)
			{
				IL_2D:
				RuntimeTypeHandle handle = typeof(467F5DB3).TypeHandle;
				num %= 899241468U;
				this.25F821A5 = Type.GetTypeFromHandle(handle).Module;
				num = 660015786U + num;
				if (num != 876887955U)
				{
					goto IL_5D;
				}
			}
			do
			{
				IL_AA:
				this.69866088 = new List<467F5DB3.74D46A00>();
				if (1338909020U + num == 0U)
				{
					goto IL_2D;
				}
				for (;;)
				{
					IL_C1:
					Stack<467F5DB3.74D46A00> stack = new Stack<467F5DB3.74D46A00>();
					num = (1157237948U ^ num);
					this.7E2027B1 = stack;
					num = 1069446377U - num;
					if ((1682058712U & num) == 0U)
					{
						goto IL_2D;
					}
					Stack<int> stack2 = new Stack<int>();
					num *= 600210969U;
					this.456178D7 = stack2;
					for (;;)
					{
						List<IntPtr> list = new List<IntPtr>();
						num = 594688658U / num;
						this.11A91B03 = list;
						num = 279476060U * num;
						if ((num ^ 1861633353U) == 0U)
						{
							goto IL_2D;
						}
						num |= 589176706U;
						base..ctor();
						if (num * 563488872U == 0U)
						{
							goto IL_06;
						}
						num = (1669082942U | num);
						Module m = this.25F821A5;
						num = 413740448U >> (int)num;
						IntPtr hinstance = Marshal.GetHINSTANCE(m);
						num -= 422587752U;
						IntPtr intPtr = hinstance;
						this.4E7216B9 = intPtr.ToInt64();
						num = 1177366383U >> (int)num;
						this.4E7C192F[num + 4294967226U] = new 467F5DB3.37CE4668(this.38FE35C9);
						num = 1263735625U + num;
						if ((819661915U ^ num) == 0U)
						{
							goto IL_06;
						}
						for (;;)
						{
							Dictionary<uint, 467F5DB3.37CE4668> dictionary2 = this.4E7C192F;
							num = (1199463787U | num);
							uint key = num - 1333747694U;
							num %= 451623818U;
							dictionary2[key] = new 467F5DB3.37CE4668(this.1EA46AB1);
							num = 1895849963U >> (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary3 = this.4E7C192F;
							num = (361458712U & num);
							uint key2 = num ^ 10U;
							num = 1595612971U * num;
							467F5DB3.37CE4668 value = new 467F5DB3.37CE4668(this.2B30605D);
							num = 1282486040U + num;
							dictionary3[key2] = value;
							num = 23402377U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary4 = this.4E7C192F;
							uint key3 = num - 394854397U;
							num = (1187911855U ^ num);
							dictionary4[key3] = new 467F5DB3.37CE4668(this.4B3477AF);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary5 = this.4E7C192F;
							num |= 209275452U;
							uint key4 = num + 2726339909U;
							IntPtr 678546D = ldftn(26A23C05);
							num = (175261368U & num);
							467F5DB3.37CE4668 value2 = new 467F5DB3.37CE4668(this, 678546D);
							num *= 1419475037U;
							dictionary5[key4] = value2;
							num *= 387390762U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary6 = this.4E7C192F;
							num = 93327771U << (int)num;
							uint key5 = num + 3999596549U;
							num = 1666725074U - num;
							num = 447237288U + num;
							467F5DB3.37CE4668 value3 = new 467F5DB3.37CE4668(this.6D7B3921);
							num = 1449217244U + num;
							dictionary6[key5] = value3;
							if (num < 1213793169U)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary7 = this.4E7C192F;
							uint key6 = num ^ 3267808848U;
							num <<= 1;
							IntPtr 678546D2 = ldftn(30711BF0);
							num -= 1461657929U;
							dictionary7[key6] = new 467F5DB3.37CE4668(this, 678546D2);
							num *= 1786781413U;
							if (num == 1843427788U)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary8 = this.4E7C192F;
							uint key7 = num - 717879688U;
							num = (2146650658U ^ num);
							num >>= 25;
							IntPtr 678546D3 = ldftn(7A5A024A);
							num %= 1271077588U;
							467F5DB3.37CE4668 value4 = new 467F5DB3.37CE4668(this, 678546D3);
							num >>= 23;
							dictionary8[key7] = value4;
							if (2085823466U <= num)
							{
								goto IL_06;
							}
							num = 1867200244U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary9 = this.4E7C192F;
							num += 1093862840U;
							uint key8 = num - 2961063076U;
							IntPtr 678546D4 = ldftn(3A121000);
							num = 1090857112U - num;
							467F5DB3.37CE4668 value5 = new 467F5DB3.37CE4668(this, 678546D4);
							num *= 2109102305U;
							dictionary9[key8] = value5;
							num = 1544505178U * num;
							if (num - 1799504732U == 0U)
							{
								goto IL_83;
							}
							num *= 511320074U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary10 = this.4E7C192F;
							uint key9 = num ^ 4282706873U;
							num &= 510876453U;
							num <<= 12;
							IntPtr 678546D5 = ldftn(7F3C140C);
							num = 923339119U - num;
							dictionary10[key9] = new 467F5DB3.37CE4668(this, 678546D5);
							num = (1125057930U ^ num);
							if (397564140U >= num)
							{
								goto IL_06;
							}
							num = (49419495U | num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary11 = this.4E7C192F;
							num >>= 16;
							uint key10 = num ^ 29680U;
							num = 2133082871U << (int)num;
							467F5DB3.37CE4668 value6 = new 467F5DB3.37CE4668(this.0B982BF4);
							num ^= 2108032881U;
							dictionary11[key10] = value6;
							if (num <= 74388868U)
							{
								goto IL_06;
							}
							num = 1539129115U % num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary12 = this.4E7C192F;
							uint key11 = num ^ 1539129104U;
							num &= 90855616U;
							IntPtr 678546D6 = ldftn(23123A83);
							num = 1899568869U / num;
							dictionary12[key11] = new 467F5DB3.37CE4668(this, 678546D6);
							if ((1059349618U ^ num) == 0U)
							{
								goto IL_06;
							}
							num = 355278748U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary13 = this.4E7C192F;
							num = 903622143U - num;
							dictionary13[num ^ 548343310U] = new 467F5DB3.37CE4668(this.5CB53BAA);
							num /= 1427784391U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary14 = this.4E7C192F;
							num = 2082759491U + num;
							uint key12 = num ^ 2082759502U;
							IntPtr 678546D7 = ldftn(6F4478F8);
							num >>= 28;
							dictionary14[key12] = new 467F5DB3.37CE4668(this, 678546D7);
							num &= 2106871386U;
							num += 1502490876U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary15 = this.4E7C192F;
							num = 703616107U % num;
							uint key13 = num - 703616093U;
							num ^= 779165696U;
							num -= 741178089U;
							467F5DB3.37CE4668 value7 = new 467F5DB3.37CE4668(this.31FC0148);
							num <<= 7;
							dictionary15[key13] = value7;
							num %= 1393518575U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary16 = this.4E7C192F;
							uint key14 = num - 64876819U;
							num ^= 748754184U;
							IntPtr 678546D8 = ldftn(626604EE);
							num = (728448654U ^ num);
							467F5DB3.37CE4668 value8 = new 467F5DB3.37CE4668(this, 678546D8);
							num ^= 2081514947U;
							dictionary16[key14] = value8;
							if (1822259763U > num)
							{
								goto IL_06;
							}
							num = (1386042998U | num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary17 = this.4E7C192F;
							uint key15 = num ^ 2057305959U;
							num |= 1301167709U;
							IntPtr 678546D9 = ldftn(1A586B3E);
							num = 608837631U + num;
							467F5DB3.37CE4668 value9 = new 467F5DB3.37CE4668(this, 678546D9);
							num = 1000103027U - num;
							dictionary17[key15] = value9;
							num = 914316106U << (int)num;
							num = (1432386491U ^ num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary18 = this.4E7C192F;
							uint key16 = num ^ 1008761770U;
							num = (963129389U | num);
							dictionary18[key16] = new 467F5DB3.37CE4668(this.6B8C598E);
							num -= 452755119U;
							num = 54097748U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary19 = this.4E7C192F;
							num = 1271166308U << (int)num;
							uint key17 = num ^ 3158791762U;
							467F5DB3.37CE4668 value10 = new 467F5DB3.37CE4668(this.7BE36DE0);
							num -= 1298753695U;
							dictionary19[key17] = value10;
							num &= 514480215U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary20 = this.4E7C192F;
							num *= 2020425247U;
							uint key18 = num ^ 3831363084U;
							num <<= 1;
							dictionary20[key18] = new 467F5DB3.37CE4668(this.5D2B58DB);
							num |= 722602693U;
							if (num << 28 == 0U)
							{
								goto IL_06;
							}
							num %= 150895834U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary21 = this.4E7C192F;
							num -= 1994668514U;
							uint key19 = num ^ 2331969261U;
							num |= 28975389U;
							dictionary21[key19] = new 467F5DB3.37CE4668(this.647078C3);
							this.4E7C192F[num ^ 2348754920U] = new 467F5DB3.37CE4668(this.41B07E9D);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary22 = this.4E7C192F;
							uint key20 = num + 1946212377U;
							num |= 589834510U;
							num %= 48717492U;
							IntPtr 678546D10 = ldftn(679465DE);
							num = 902369638U << (int)num;
							467F5DB3.37CE4668 value11 = new 467F5DB3.37CE4668(this, 678546D10);
							num &= 1444564666U;
							dictionary22[key20] = value11;
							num |= 712863567U;
							if (1564804204U + num == 0U)
							{
								goto IL_2D;
							}
							this.4E7C192F[num ^ 779972456U] = new 467F5DB3.37CE4668(this.4F9D077C);
							num |= 736904331U;
							if (num > 1641556469U)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary23 = this.4E7C192F;
							uint key21 = num ^ 805138407U;
							num &= 1749573232U;
							467F5DB3.37CE4668 value12 = new 467F5DB3.37CE4668(this.16951CC1);
							num |= 2052478666U;
							dictionary23[key21] = value12;
							num = 1884816319U + num;
							if (1082077946U >= num)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary24 = this.4E7C192F;
							uint key22 = num - 3937821344U;
							num = 1298536152U - num;
							num %= 423381879U;
							IntPtr 678546D11 = ldftn(02E20289);
							num = 2087155851U - num;
							dictionary24[key22] = new 467F5DB3.37CE4668(this, 678546D11);
							num ^= 1033719456U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary25 = this.4E7C192F;
							num /= 280102921U;
							uint key23 = num ^ 31U;
							num = 1041110131U * num;
							467F5DB3.37CE4668 value13 = new 467F5DB3.37CE4668(this.24564138);
							num = 1279075095U % num;
							dictionary25[key23] = value13;
							num ^= 2132621963U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary26 = this.4E7C192F;
							num = 442970824U >> (int)num;
							uint key24 = num ^ 855U;
							num = 575864863U >> (int)num;
							IntPtr 678546D12 = ldftn(468F47CF);
							num *= 1569919880U;
							dictionary26[key24] = new 467F5DB3.37CE4668(this, 678546D12);
							if (num + 428816367U == 0U)
							{
								goto IL_5D;
							}
							num = 1913661422U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary27 = this.4E7C192F;
							uint key25 = num + 2381305902U;
							num = (1517109935U | num);
							467F5DB3.37CE4668 value14 = new 467F5DB3.37CE4668(this.59C158B0);
							num = 1110050656U - num;
							dictionary27[key25] = value14;
							num = 1614245720U >> (int)num;
							if (492379064U % num == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary28 = this.4E7C192F;
							uint key26 = num + 4294955010U;
							num = 1271992421U * num;
							IntPtr 678546D13 = ldftn(408276BF);
							num = 470755346U / num;
							467F5DB3.37CE4668 value15 = new 467F5DB3.37CE4668(this, 678546D13);
							num *= 1872641139U;
							dictionary28[key26] = value15;
							num = 1756659250U - num;
							num %= 1290414342U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary29 = this.4E7C192F;
							num *= 162353446U;
							uint key27 = num ^ 1068994710U;
							num &= 756752124U;
							IntPtr 678546D14 = ldftn(7F851614);
							num = 183251424U / num;
							467F5DB3.37CE4668 value16 = new 467F5DB3.37CE4668(this, 678546D14);
							num = (124139661U ^ num);
							dictionary29[key27] = value16;
							if (num + 852058786U == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary30 = this.4E7C192F;
							num = (427622925U & num);
							uint key28 = num + 4271636498U;
							num >>= 22;
							IntPtr 678546D15 = ldftn(110A0B3C);
							num *= 1348870010U;
							dictionary30[key28] = new 467F5DB3.37CE4668(this, 678546D15);
							num *= 1065831467U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary31 = this.4E7C192F;
							num |= 1809132326U;
							uint key29 = num ^ 2080354134U;
							num = (1516699724U ^ num);
							467F5DB3.37CE4668 value17 = new 467F5DB3.37CE4668(this.2C861DAF);
							num &= 429734810U;
							dictionary31[key29] = value17;
							num = 1696217734U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary32 = this.4E7C192F;
							num = (785848529U ^ num);
							uint key30 = num ^ 920066288U;
							num ^= 1040923665U;
							IntPtr 678546D16 = ldftn(69DE3561);
							num = 336543423U / num;
							dictionary32[key30] = new 467F5DB3.37CE4668(this, 678546D16);
							if ((1008479160U ^ num) == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary33 = this.4E7C192F;
							uint key31 = num ^ 32U;
							num /= 886454738U;
							dictionary33[key31] = new 467F5DB3.37CE4668(this.7F9B0F86);
							num = 889534803U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary34 = this.4E7C192F;
							uint key32 = num - 889534768U;
							num -= 1373637250U;
							dictionary34[key32] = new 467F5DB3.37CE4668(this.3D5D5A63);
							if ((num ^ 639660034U) == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary35 = this.4E7C192F;
							num *= 413102166U;
							uint key33 = num + 3241661934U;
							467F5DB3.37CE4668 value18 = new 467F5DB3.37CE4668(this.50404ACC);
							num /= 383984601U;
							dictionary35[key33] = value18;
							num = 580663674U % num;
							if (264535446U == num)
							{
								goto IL_06;
							}
							num *= 652962495U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary36 = this.4E7C192F;
							uint key34 = num - 4294967259U;
							num %= 1401846869U;
							IntPtr 678546D17 = ldftn(55261814);
							num = 2042772381U - num;
							dictionary36[key34] = new 467F5DB3.37CE4668(this, 678546D17);
							num = 303503850U * num;
							if (num * 1631209927U == 0U)
							{
								goto IL_06;
							}
							num = (1390553006U & num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary37 = this.4E7C192F;
							uint key35 = num + 4288544164U;
							num >>= 21;
							IntPtr 678546D18 = ldftn(58080A16);
							num <<= 7;
							467F5DB3.37CE4668 value19 = new 467F5DB3.37CE4668(this, 678546D18);
							num >>= 14;
							dictionary37[key35] = value19;
							this.4E7C192F[num ^ 39U] = new 467F5DB3.37CE4668(this.513A23AF);
							num = 238816918U - num;
							if (num == 1714894772U)
							{
								goto IL_06;
							}
							num = 228609168U >> (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary38 = this.4E7C192F;
							num = 1250182060U << (int)num;
							uint key36 = num - 3942645720U;
							num = 724187171U % num;
							IntPtr 678546D19 = ldftn(7FA87F62);
							num = (1206201111U & num);
							467F5DB3.37CE4668 value20 = new 467F5DB3.37CE4668(this, 678546D19);
							num = 1453398460U / num;
							dictionary38[key36] = value20;
							num -= 127670229U;
							if (num <= 1353398377U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary39 = this.4E7C192F;
							uint key37 = num - 4167297053U;
							num = 2090024474U * num;
							dictionary39[key37] = new 467F5DB3.37CE4668(this.55087A3D);
							if ((num ^ 1649754642U) == 0U)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary40 = this.4E7C192F;
							num <<= 10;
							uint key38 = num ^ 1647079466U;
							IntPtr 678546D20 = ldftn(5B954D41);
							num -= 366432469U;
							467F5DB3.37CE4668 value21 = new 467F5DB3.37CE4668(this, 678546D20);
							num = 865086220U * num;
							dictionary40[key38] = value21;
							num ^= 1800096367U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary41 = this.4E7C192F;
							num &= 1002723109U;
							uint key39 = num + 3992959754U;
							num = 3765294U / num;
							IntPtr 678546D21 = ldftn(7DFA6A70);
							num %= 1577800673U;
							467F5DB3.37CE4668 value22 = new 467F5DB3.37CE4668(this, 678546D21);
							num = 1629363910U >> (int)num;
							dictionary41[key39] = value22;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary42 = this.4E7C192F;
							num = (886191449U ^ num);
							uint key40 = num ^ 1439443891U;
							num = 619072038U % num;
							IntPtr 678546D22 = ldftn(29262CE3);
							num %= 642515126U;
							467F5DB3.37CE4668 value23 = new 467F5DB3.37CE4668(this, 678546D22);
							num %= 865630794U;
							dictionary42[key40] = value23;
							if (1450971174U < num)
							{
								goto IL_06;
							}
							num = 299201946U / num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary43 = this.4E7C192F;
							uint key41 = num + 45U;
							num <<= 16;
							467F5DB3.37CE4668 value24 = new 467F5DB3.37CE4668(this.239304DE);
							num = 1963529524U << (int)num;
							dictionary43[key41] = value24;
							num <<= 21;
							num <<= 17;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary44 = this.4E7C192F;
							num = 1369977232U - num;
							uint key42 = num + 2924990110U;
							num /= 54220792U;
							IntPtr 678546D23 = ldftn(022B2B36);
							num %= 788404637U;
							467F5DB3.37CE4668 value25 = new 467F5DB3.37CE4668(this, 678546D23);
							num = 788203656U % num;
							dictionary44[key42] = value25;
							if (num == 1371109273U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary45 = this.4E7C192F;
							uint key43 = num + 41U;
							IntPtr 678546D24 = ldftn(756316D4);
							num = 2099521308U >> (int)num;
							dictionary45[key43] = new 467F5DB3.37CE4668(this, 678546D24);
							num /= 1197278361U;
							if (num >= 224881429U)
							{
								goto IL_2D;
							}
							num = 459365971U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary46 = this.4E7C192F;
							uint key44 = num + 3835601373U;
							num = 754453921U % num;
							IntPtr 678546D25 = ldftn(373E71EE);
							num = 1481604732U / num;
							467F5DB3.37CE4668 value26 = new 467F5DB3.37CE4668(this, 678546D25);
							num %= 2053468544U;
							dictionary46[key44] = value26;
							num %= 1558662177U;
							this.4E7C192F[num + 44U] = new 467F5DB3.37CE4668(this.151023C3);
							if (911150167U < num)
							{
								goto IL_06;
							}
							num = 767056914U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary47 = this.4E7C192F;
							uint key45 = num ^ 3835284584U;
							num <<= 11;
							num |= 232785883U;
							IntPtr 678546D26 = ldftn(724F534D);
							num = 1509838901U % num;
							467F5DB3.37CE4668 value27 = new 467F5DB3.37CE4668(this, 678546D26);
							num *= 1525907275U;
							dictionary47[key45] = value27;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary48 = this.4E7C192F;
							num = (1832350174U ^ num);
							uint key46 = num - 648919846U;
							num = 5132208U % num;
							467F5DB3.37CE4668 value28 = new 467F5DB3.37CE4668(this.29A31B2A);
							num = (1870799047U & num);
							dictionary48[key46] = value28;
							num = 2043611389U / num;
							if (num > 1400772829U)
							{
								goto IL_5D;
							}
							num %= 589583939U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary49 = this.4E7C192F;
							num *= 1138193233U;
							uint key47 = num ^ 3167766636U;
							num %= 869733491U;
							dictionary49[key47] = new 467F5DB3.37CE4668(this.5D2121D4);
							num <<= 22;
							if (num <= 1833521396U)
							{
								goto IL_5D;
							}
							num &= 1529754132U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary50 = this.4E7C192F;
							num %= 1383823978U;
							uint key48 = num + 3841982517U;
							num = (1556305349U & num);
							num |= 525213898U;
							dictionary50[key48] = new 467F5DB3.37CE4668(this.4920583E);
							num = (1509825435U ^ num);
							if (1246119884U == num)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary51 = this.4E7C192F;
							uint key49 = num ^ 1185954663U;
							num = 466384346U % num;
							IntPtr 678546D27 = ldftn(37EF1767);
							num %= 1365651264U;
							dictionary51[key49] = new 467F5DB3.37CE4668(this, 678546D27);
							num = 411521285U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary52 = this.4E7C192F;
							num *= 374034412U;
							uint key50 = num ^ 2230265507U;
							num &= 1597854328U;
							467F5DB3.37CE4668 value29 = new 467F5DB3.37CE4668(this.76493535);
							num /= 961551148U;
							dictionary52[key50] = value29;
							num |= 1185247219U;
							if (1714046060U < num)
							{
								goto IL_AA;
							}
							num = 766059958U % num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary53 = this.4E7C192F;
							num += 515927438U;
							uint key51 = num ^ 1281987452U;
							num = 756556372U * num;
							num -= 1546206757U;
							dictionary53[key51] = new 467F5DB3.37CE4668(this.229B29C5);
							num &= 966608044U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary54 = this.4E7C192F;
							num &= 2111250226U;
							uint key52 = num + 3355442201U;
							num = 1861511875U / num;
							IntPtr 678546D28 = ldftn(3F3659CB);
							num %= 337082987U;
							467F5DB3.37CE4668 value30 = new 467F5DB3.37CE4668(this, 678546D28);
							num = (46739932U ^ num);
							dictionary54[key52] = value30;
							if (1382315084U < num)
							{
								goto IL_06;
							}
							num = (524039062U ^ num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary55 = this.4E7C192F;
							num = 1506345160U >> (int)num;
							uint key53 = num ^ 735514U;
							num = 1650012310U << (int)num;
							IntPtr 678546D29 = ldftn(22076BE7);
							num = 692520662U << (int)num;
							467F5DB3.37CE4668 value31 = new 467F5DB3.37CE4668(this, 678546D29);
							num = 782115065U >> (int)num;
							dictionary55[key53] = value31;
							num = (861560307U | num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary56 = this.4E7C192F;
							uint key54 = num ^ 1071545792U;
							num |= 1221461749U;
							IntPtr 678546D30 = ldftn(438B5959);
							num %= 2140346687U;
							dictionary56[key54] = new 467F5DB3.37CE4668(this, 678546D30);
							num -= 535639571U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary57 = this.4E7C192F;
							uint key55 = num - 3764269169U;
							num = 2053046327U % num;
							num &= 1658194909U;
							IntPtr 678546D31 = ldftn(17843B06);
							num = (748302703U | num);
							467F5DB3.37CE4668 value32 = new 467F5DB3.37CE4668(this, 678546D31);
							num = (1711742552U | num);
							dictionary57[key55] = value32;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary58 = this.4E7C192F;
							num = 1217676240U + num;
							uint key56 = num - 3077800722U;
							num += 1580009169U;
							num = (1654087698U ^ num);
							IntPtr 678546D32 = ldftn(292E3E9D);
							num >>= 30;
							467F5DB3.37CE4668 value33 = new 467F5DB3.37CE4668(this, 678546D32);
							num = (688939972U & num);
							dictionary58[key56] = value33;
							num <<= 23;
							num = 52919661U - num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary59 = this.4E7C192F;
							num *= 109120224U;
							uint key57 = num + 4036951774U;
							IntPtr 678546D33 = ldftn(5DC53681);
							num /= 838350657U;
							467F5DB3.37CE4668 value34 = new 467F5DB3.37CE4668(this, 678546D33);
							num %= 989218350U;
							dictionary59[key57] = value34;
							num = (877148849U | num);
							if (528438034U + num == 0U)
							{
								goto IL_AA;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary60 = this.4E7C192F;
							num = 1009657077U * num;
							uint key58 = num - 959385382U;
							num = 1752892730U % num;
							dictionary60[key58] = new 467F5DB3.37CE4668(this.192C77AD);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary61 = this.4E7C192F;
							num = 368064667U * num;
							uint key59 = num ^ 829714359U;
							num /= 813570482U;
							num <<= 17;
							IntPtr 678546D34 = ldftn(20BE7653);
							num *= 467274779U;
							467F5DB3.37CE4668 value35 = new 467F5DB3.37CE4668(this, 678546D34);
							num = 1996832600U / num;
							dictionary61[key59] = value35;
							num = 191654195U % num;
							if (470758331U == num)
							{
								goto IL_AA;
							}
							num %= 1351615413U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary62 = this.4E7C192F;
							num >>= 8;
							uint key60 = num - 4294967231U;
							num ^= 1372398559U;
							467F5DB3.37CE4668 value36 = new 467F5DB3.37CE4668(this.13BD01F0);
							num /= 479079704U;
							dictionary62[key60] = value36;
							num ^= 1376785216U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary63 = this.4E7C192F;
							uint key61 = num + 2918182144U;
							num = (2124968897U | num);
							IntPtr 678546D35 = ldftn(141E7CA7);
							num = 1008079671U >> (int)num;
							467F5DB3.37CE4668 value37 = new 467F5DB3.37CE4668(this, 678546D35);
							num = 1534614668U / num;
							dictionary63[key61] = value37;
							if (num + 938174456U == 0U)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary64 = this.4E7C192F;
							uint key62 = num ^ 79U;
							num = (1229602200U & num);
							num = (1233135485U ^ num);
							dictionary64[key62] = new 467F5DB3.37CE4668(this.5AA0115D);
							if (969290388U + num == 0U)
							{
								goto IL_06;
							}
							num = 1888440602U / num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary65 = this.4E7C192F;
							uint key63 = num + 67U;
							467F5DB3.37CE4668 value38 = new 467F5DB3.37CE4668(this.07164ABD);
							num %= 266107033U;
							dictionary65[key63] = value38;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary66 = this.4E7C192F;
							num = 2052852388U - num;
							uint key64 = num ^ 2052852454U;
							num = (1775594687U | num);
							dictionary66[key64] = new 467F5DB3.37CE4668(this.238B145E);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary67 = this.4E7C192F;
							uint key65 = num + 2216857991U;
							num -= 255533699U;
							num = 640308414U / num;
							IntPtr 678546D36 = ldftn(2CD26CDA);
							num += 1685199744U;
							467F5DB3.37CE4668 value39 = new 467F5DB3.37CE4668(this, 678546D36);
							num = 1858017611U % num;
							dictionary67[key65] = value39;
							num &= 1160588868U;
							num = 1070465717U % num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary68 = this.4E7C192F;
							num = (1529487756U ^ num);
							uint key66 = num - 1528829618U;
							num &= 1421550299U;
							num <<= 22;
							IntPtr 678546D37 = ldftn(316B556C);
							num = (2015649241U | num);
							467F5DB3.37CE4668 value40 = new 467F5DB3.37CE4668(this, 678546D37);
							num = 1110861791U - num;
							dictionary68[key66] = value40;
							if (num >= 1842234129U)
							{
								goto IL_83;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary69 = this.4E7C192F;
							num = 359022899U * num;
							dictionary69[num ^ 1405584762U] = new 467F5DB3.37CE4668(this.17A41624);
							num = 101722364U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary70 = this.4E7C192F;
							num = 641551146U << (int)num;
							uint key67 = num ^ 704643145U;
							num ^= 1896353877U;
							IntPtr 678546D38 = ldftn(19584976);
							num = 619461051U * num;
							467F5DB3.37CE4668 value41 = new 467F5DB3.37CE4668(this, 678546D38);
							num = (1971993558U ^ num);
							dictionary70[key67] = value41;
							num = 358286368U * num;
							if (898499908U > num)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary71 = this.4E7C192F;
							uint key68 = num ^ 2319064170U;
							num = 992765224U / num;
							num |= 436537555U;
							dictionary71[key68] = new 467F5DB3.37CE4668(this.120B316B);
							num += 1105938791U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary72 = this.4E7C192F;
							num = 1255565166U >> (int)num;
							uint key69 = num + 57U;
							467F5DB3.37CE4668 value42 = new 467F5DB3.37CE4668(this.0E732E49);
							num *= 342375758U;
							dictionary72[key69] = value42;
							num -= 1796945686U;
							if (1681991674U % num == 0U)
							{
								goto IL_2D;
							}
							num = 207190130U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary73 = this.4E7C192F;
							num -= 1244685583U;
							uint key70 = num - 3425548069U;
							num ^= 1169898036U;
							num *= 1167732351U;
							IntPtr 678546D39 = ldftn(6740321F);
							num *= 1215520897U;
							467F5DB3.37CE4668 value43 = new 467F5DB3.37CE4668(this, 678546D39);
							num = 1802380098U << (int)num;
							dictionary73[key70] = value43;
							num <<= 27;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary74 = this.4E7C192F;
							num = 1642332488U + num;
							uint key71 = num - 1642332411U;
							num /= 1172193210U;
							num &= 817061071U;
							467F5DB3.37CE4668 value44 = new 467F5DB3.37CE4668(this.6740321F);
							num += 1499147097U;
							dictionary74[key71] = value44;
							if (num + 1601899869U == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary75 = this.4E7C192F;
							num += 345922530U;
							uint key72 = num - 1845069550U;
							467F5DB3.37CE4668 value45 = new 467F5DB3.37CE4668(this.55087A3D);
							num = (722759271U | num);
							dictionary75[key72] = value45;
							num = 2017413350U + num;
							if (216738717U >= num)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary76 = this.4E7C192F;
							num <<= 14;
							uint key73 = num ^ 1310277711U;
							num = 1152478349U / num;
							IntPtr 678546D40 = ldftn(756316D4);
							num ^= 1295584285U;
							467F5DB3.37CE4668 value46 = new 467F5DB3.37CE4668(this, 678546D40);
							num = (903968698U & num);
							dictionary76[key73] = value46;
							num %= 1573669873U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary77 = this.4E7C192F;
							num = 1173441827U << (int)num;
							uint key74 = num + 3707764816U;
							num = 1310657104U / num;
							467F5DB3.37CE4668 value47 = new 467F5DB3.37CE4668(this.26A23C05);
							num -= 1243545803U;
							dictionary77[key74] = value47;
							num = 1841192101U >> (int)num;
							num = 916345167U / num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary78 = this.4E7C192F;
							num += 1167740093U;
							uint key75 = num ^ 1171924236U;
							num &= 1260724326U;
							IntPtr 678546D41 = ldftn(7A5A024A);
							num <<= 28;
							467F5DB3.37CE4668 value48 = new 467F5DB3.37CE4668(this, 678546D41);
							num = 1922172418U << (int)num;
							dictionary78[key75] = value48;
							num = 1381106380U * num;
							if (num + 1346579555U == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary79 = this.4E7C192F;
							uint key76 = num ^ 17616330U;
							467F5DB3.37CE4668 value49 = new 467F5DB3.37CE4668(this.373E71EE);
							num += 2114930983U;
							dictionary79[key76] = value49;
							num |= 1595549335U;
							if (num - 1928690753U == 0U)
							{
								goto IL_2D;
							}
							num = 1048664237U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary80 = this.4E7C192F;
							uint key77 = num - 2147483565U;
							num = 73563927U / num;
							IntPtr 678546D42 = ldftn(16951CC1);
							num = 197418713U * num;
							467F5DB3.37CE4668 value50 = new 467F5DB3.37CE4668(this, 678546D42);
							num = 692930857U - num;
							dictionary80[key77] = value50;
							num = (1179519128U | num);
							if ((1653297843U ^ num) == 0U)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary81 = this.4E7C192F;
							uint key78 = num + 2427500187U;
							IntPtr 678546D43 = ldftn(151023C3);
							num = 474484121U >> (int)num;
							dictionary81[key78] = new 467F5DB3.37CE4668(this, 678546D43);
							num = 962944811U % num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary82 = this.4E7C192F;
							num %= 1406021472U;
							uint key79 = num ^ 86U;
							num = 193217432U + num;
							num = 481428702U % num;
							dictionary82[key79] = new 467F5DB3.37CE4668(this.58080A16);
							num %= 1843341347U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary83 = this.4E7C192F;
							uint key80 = num + 4199973550U;
							num += 1152985954U;
							IntPtr 678546D44 = ldftn(022B2B36);
							num %= 975130186U;
							dictionary83[key80] = new 467F5DB3.37CE4668(this, 678546D44);
							num = 310648439U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary84 = this.4E7C192F;
							uint key81 = num + 3984318944U;
							num <<= 0;
							num = (1139892803U ^ num);
							467F5DB3.37CE4668 value51 = new 467F5DB3.37CE4668(this.292E3E9D);
							num *= 1907110603U;
							dictionary84[key81] = value51;
							num &= 980695457U;
							if (430009356U >= num)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary85 = this.4E7C192F;
							num = (1201437231U & num);
							uint key82 = num ^ 1056888U;
							num = 829629497U % num;
							IntPtr 678546D45 = ldftn(7BE36DE0);
							num = (1057913750U & num);
							dictionary85[key82] = new 467F5DB3.37CE4668(this, 678546D45);
							if (1717768504U + num == 0U)
							{
								goto IL_AA;
							}
							num = 1204308467U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary86 = this.4E7C192F;
							uint key83 = num + 3920173865U;
							num = 1950818917U << (int)num;
							num = (1691764507U | num);
							dictionary86[key83] = new 467F5DB3.37CE4668(this.756316D4);
							num |= 1690782258U;
							if (num << 22 == 0U)
							{
								goto IL_2D;
							}
							num = 835546468U - num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary87 = this.4E7C192F;
							uint key84 = num ^ 3403030131U;
							num = (701629550U | num);
							dictionary87[key84] = new 467F5DB3.37CE4668(this.756316D4);
							num *= 742982496U;
							num = 216336129U >> (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary88 = this.4E7C192F;
							num %= 252725691U;
							uint key85 = num + 4078631258U;
							num |= 466233473U;
							dictionary88[key85] = new 467F5DB3.37CE4668(this.22076BE7);
							if (1280717803U < num)
							{
								goto IL_2D;
							}
							num = 1259083809U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary89 = this.4E7C192F;
							uint key86 = num - 2404726597U;
							num = 51784384U + num;
							num -= 734359294U;
							dictionary89[key86] = new 467F5DB3.37CE4668(this.468F47CF);
							num = 360858442U - num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary90 = this.4E7C192F;
							uint key87 = num ^ 2933673914U;
							num += 1239034326U;
							467F5DB3.37CE4668 value52 = new 467F5DB3.37CE4668(this.756316D4);
							num *= 1745027417U;
							dictionary90[key87] = value52;
							num = 1481077599U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary91 = this.4E7C192F;
							uint key88 = num ^ 3144188746U;
							num = 151203006U * num;
							IntPtr 678546D46 = ldftn(468F47CF);
							num = 1002461847U / num;
							dictionary91[key88] = new 467F5DB3.37CE4668(this, 678546D46);
							if (num >> 13 != 0U)
							{
								goto IL_2D;
							}
							num %= 853573144U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary92 = this.4E7C192F;
							num = (1424780177U ^ num);
							uint key89 = num ^ 1424780238U;
							num = (1493519654U & num);
							467F5DB3.37CE4668 value53 = new 467F5DB3.37CE4668(this.756316D4);
							num /= 339487024U;
							dictionary92[key89] = value53;
							num %= 1669734970U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary93 = this.4E7C192F;
							uint key90 = num ^ 99U;
							num = 1001273915U + num;
							IntPtr 678546D47 = ldftn(151023C3);
							num %= 1618042889U;
							467F5DB3.37CE4668 value54 = new 467F5DB3.37CE4668(this, 678546D47);
							num = 738746842U % num;
							dictionary93[key90] = value54;
							if (num << 24 == 0U)
							{
								goto IL_83;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary94 = this.4E7C192F;
							uint key91 = num ^ 738746811U;
							num = 1514362977U - num;
							dictionary94[key91] = new 467F5DB3.37CE4668(this.26A23C05);
							num = 992165142U + num;
							if (132847989U == num)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary95 = this.4E7C192F;
							uint key92 = num + 2527186117U;
							num = (1620062052U | num);
							dictionary95[key92] = new 467F5DB3.37CE4668(this.110A0B3C);
							if (num <= 181736605U)
							{
								goto IL_06;
							}
							num = 1361792149U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary96 = this.4E7C192F;
							uint key93 = num - 3137965103U;
							num = (1527585890U & num);
							467F5DB3.37CE4668 value55 = new 467F5DB3.37CE4668(this.373E71EE);
							num |= 1170876296U;
							dictionary96[key93] = value55;
							num *= 878599156U;
							if (num >> 27 != 0U)
							{
								goto IL_06;
							}
							num *= 680289227U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary97 = this.4E7C192F;
							num = 2135628114U + num;
							uint key94 = num + 3390448698U;
							num -= 1269848591U;
							467F5DB3.37CE4668 value56 = new 467F5DB3.37CE4668(this.41B07E9D);
							num = (1533874512U | num);
							dictionary97[key94] = value56;
							num = (553613931U & num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary98 = this.4E7C192F;
							uint key95 = num - 545067494U;
							num -= 1091513521U;
							467F5DB3.37CE4668 value57 = new 467F5DB3.37CE4668(this.26A23C05);
							num = (1089405277U | num);
							dictionary98[key95] = value57;
							if (num << 14 == 0U)
							{
								goto IL_5D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary99 = this.4E7C192F;
							uint key96 = num ^ 3757041081U;
							IntPtr 678546D48 = ldftn(6F4478F8);
							num %= 2145523906U;
							dictionary99[key96] = new 467F5DB3.37CE4668(this, 678546D48);
							num >>= 2;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary100 = this.4E7C192F;
							uint key97 = num + 3892088096U;
							num |= 577641079U;
							num = (2129362797U | num);
							dictionary100[key97] = new 467F5DB3.37CE4668(this.3A121000);
							num >>= 8;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary101 = this.4E7C192F;
							uint key98 = num + 4286648553U;
							num %= 892758752U;
							dictionary101[key98] = new 467F5DB3.37CE4668(this.7F9B0F86);
							if ((num ^ 1493258679U) == 0U)
							{
								goto IL_5D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary102 = this.4E7C192F;
							num = 1581912367U - num;
							uint key99 = num - 1573593415U;
							num *= 1291651829U;
							467F5DB3.37CE4668 value58 = new 467F5DB3.37CE4668(this.7F851614);
							num = 1014908579U % num;
							dictionary102[key99] = value58;
							if (995434705U == num)
							{
								goto IL_2D;
							}
							num = 2140107764U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary103 = this.4E7C192F;
							num %= 819661352U;
							uint key100 = num + 3598935115U;
							num = (840640596U & num);
							num = 205278260U + num;
							IntPtr 678546D49 = ldftn(151023C3);
							num &= 2128355175U;
							467F5DB3.37CE4668 value59 = new 467F5DB3.37CE4668(this, 678546D49);
							num = 1154558450U % num;
							dictionary103[key100] = value59;
							num ^= 681710780U;
							if (825898019 << (int)num == 0)
							{
								goto IL_83;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary104 = this.4E7C192F;
							num = 1889957359U - num;
							uint key101 = num - 1070036086U;
							num |= 127604417U;
							IntPtr 678546D50 = ldftn(316B556C);
							num = (2141785718U & num);
							dictionary104[key101] = new 467F5DB3.37CE4668(this, 678546D50);
							num = 1672037445U - num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary105 = this.4E7C192F;
							uint key102 = num ^ 606092681U;
							IntPtr 678546D51 = ldftn(50404ACC);
							num = (2113424455U & num);
							467F5DB3.37CE4668 value60 = new 467F5DB3.37CE4668(this, 678546D51);
							num >>= 15;
							dictionary105[key102] = value60;
							num -= 1566588711U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary106 = this.4E7C192F;
							num = 442399525U << (int)num;
							uint key103 = num ^ 1241514093U;
							num = 1945852175U / num;
							dictionary106[key103] = new 467F5DB3.37CE4668(this.7F851614);
							num -= 194334644U;
							if (1688289206U == num)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary107 = this.4E7C192F;
							num = (1192233735U ^ num);
							uint key104 = num ^ 3011164964U;
							467F5DB3.37CE4668 value61 = new 467F5DB3.37CE4668(this.5D2B58DB);
							num = 913444377U >> (int)num;
							dictionary107[key104] = value61;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary108 = this.4E7C192F;
							uint key105 = num ^ 892140U;
							num *= 198457044U;
							dictionary108[key105] = new 467F5DB3.37CE4668(this.22076BE7);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary109 = this.4E7C192F;
							num = 199958348U * num;
							dictionary109[num ^ 1626575008U] = new 467F5DB3.37CE4668(this.316B556C);
							if (num < 1574983867U)
							{
								goto IL_83;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary110 = this.4E7C192F;
							num /= 425609778U;
							uint key106 = num ^ 114U;
							num = 1164733657U % num;
							IntPtr 678546D52 = ldftn(239304DE);
							num = 1729234639U >> (int)num;
							dictionary110[key106] = new 467F5DB3.37CE4668(this, 678546D52);
							num *= 955657310U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary111 = this.4E7C192F;
							num -= 1845524496U;
							uint key107 = num - 3621682000U;
							num = 1561074625U >> (int)num;
							IntPtr 678546D53 = ldftn(22076BE7);
							num -= 1351968643U;
							467F5DB3.37CE4668 value62 = new 467F5DB3.37CE4668(this, 678546D53);
							num |= 676807160U;
							dictionary111[key107] = value62;
							if ((num ^ 517753475U) == 0U)
							{
								goto IL_83;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary112 = this.4E7C192F;
							uint key108 = num - 4009746314U;
							num = 486165318U >> (int)num;
							IntPtr 678546D54 = ldftn(110A0B3C);
							num <<= 15;
							dictionary112[key108] = new 467F5DB3.37CE4668(this, 678546D54);
							num = 361521888U >> (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary113 = this.4E7C192F;
							num /= 962219686U;
							uint key109 = num ^ 116U;
							num = 1825725473U >> (int)num;
							num = 1721238422U - num;
							467F5DB3.37CE4668 value63 = new 467F5DB3.37CE4668(this.20BE7653);
							num %= 778460076U;
							dictionary113[key109] = value63;
							num = 622998354U % num;
							if (1179260201U == num)
							{
								goto IL_06;
							}
							num = 1289641807U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary114 = this.4E7C192F;
							uint key110 = num ^ 1289641786U;
							num = 623865247U - num;
							num *= 30163531U;
							IntPtr 678546D55 = ldftn(292E3E9D);
							num %= 577964154U;
							467F5DB3.37CE4668 value64 = new 467F5DB3.37CE4668(this, 678546D55);
							num /= 589723306U;
							dictionary114[key110] = value64;
							num >>= 13;
							num &= 1598518601U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary115 = this.4E7C192F;
							num /= 1086945400U;
							uint key111 = num ^ 118U;
							num = (934370698U | num);
							IntPtr 678546D56 = ldftn(58080A16);
							num = (2098795923U ^ num);
							dictionary115[key111] = new 467F5DB3.37CE4668(this, 678546D56);
							if (1850631311U + num == 0U)
							{
								goto IL_5D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary116 = this.4E7C192F;
							uint key112 = num ^ 1252542574U;
							IntPtr 678546D57 = ldftn(76493535);
							num = 1095328289U - num;
							dictionary116[key112] = new 467F5DB3.37CE4668(this, 678546D57);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary117 = this.4E7C192F;
							num *= 31662097U;
							uint key113 = num ^ 2701900528U;
							IntPtr 678546D58 = ldftn(5DC53681);
							num = (1483438233U ^ num);
							467F5DB3.37CE4668 value65 = new 467F5DB3.37CE4668(this, 678546D58);
							num = 1843791724U - num;
							dictionary117[key113] = value65;
							if (1205010723U >= num)
							{
								goto IL_06;
							}
							num = 44263483U - num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary118 = this.4E7C192F;
							uint key114 = num ^ 2384339609U;
							num = 1895060160U % num;
							467F5DB3.37CE4668 value66 = new 467F5DB3.37CE4668(this.22076BE7);
							num = (1735098029U ^ num);
							dictionary118[key114] = value66;
							num = 871529747U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary119 = this.4E7C192F;
							num = 13466594U << (int)num;
							uint key115 = num - 13466472U;
							num = 1480285065U << (int)num;
							num = (1131152248U & num);
							dictionary119[key115] = new 467F5DB3.37CE4668(this.5CB53BAA);
							num = 1460731914U - num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary120 = this.4E7C192F;
							uint key116 = num ^ 379911569U;
							IntPtr 678546D59 = ldftn(0B982BF4);
							num = 1432625798U << (int)num;
							467F5DB3.37CE4668 value67 = new 467F5DB3.37CE4668(this, 678546D59);
							num /= 67118546U;
							dictionary120[key116] = value67;
							num /= 327496087U;
							if ((num ^ 1316567079U) == 0U)
							{
								goto IL_C1;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary121 = this.4E7C192F;
							num = 503983292U - num;
							uint key117 = num - 503983168U;
							num = 2102073286U - num;
							IntPtr 678546D60 = ldftn(316B556C);
							num = 2120513081U >> (int)num;
							467F5DB3.37CE4668 value68 = new 467F5DB3.37CE4668(this, 678546D60);
							num += 1809396278U;
							dictionary121[key117] = value68;
							num >>= 30;
							if (num >> 18 != 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary122 = this.4E7C192F;
							num = 1894188253U % num;
							uint key118 = num - 4294967171U;
							num = (1571036258U ^ num);
							num = 793134991U - num;
							467F5DB3.37CE4668 value69 = new 467F5DB3.37CE4668(this.022B2B36);
							num -= 1040001674U;
							dictionary122[key118] = value69;
							num = 1187987855U - num;
							if (636823099U * num == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary123 = this.4E7C192F;
							num >>= 17;
							uint key119 = num ^ 23019U;
							467F5DB3.37CE4668 value70 = new 467F5DB3.37CE4668(this.26A23C05);
							num ^= 66533374U;
							dictionary123[key119] = value70;
							num <<= 5;
							if (num - 2090808044U == 0U)
							{
								goto IL_5D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary124 = this.4E7C192F;
							uint key120 = num ^ 2129513759U;
							IntPtr 678546D61 = ldftn(756316D4);
							num -= 1784764695U;
							dictionary124[key120] = new 467F5DB3.37CE4668(this, 678546D61);
							if (248990202 << (int)num == 0)
							{
								goto IL_AA;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary125 = this.4E7C192F;
							uint key121 = num + 3950218295U;
							num = 589841773U + num;
							dictionary125[key121] = new 467F5DB3.37CE4668(this.373E71EE);
							num = (649465050U ^ num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary126 = this.4E7C192F;
							num = 1578176132U * num;
							uint key122 = num + 1619168465U;
							num += 1737056891U;
							dictionary126[key122] = new 467F5DB3.37CE4668(this.2CD26CDA);
							num = 592400312U - num;
							num = 1501052896U - num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary127 = this.4E7C192F;
							num = 1025257387U * num;
							uint key123 = num + 3818474001U;
							467F5DB3.37CE4668 value71 = new 467F5DB3.37CE4668(this.7F851614);
							num >>= 26;
							dictionary127[key123] = value71;
							num = 1830569758U % num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary128 = this.4E7C192F;
							num = 2084336067U % num;
							uint key124 = num ^ 131U;
							num ^= 1224163495U;
							num &= 1612063155U;
							dictionary128[key124] = new 467F5DB3.37CE4668(this.7DFA6A70);
							this.4E7C192F[num + 3219783649U] = new 467F5DB3.37CE4668(this.5D2B58DB);
							num <<= 15;
							num = (131466892U & num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary129 = this.4E7C192F;
							uint key125 = num + 4289724549U;
							num = (618933278U & num);
							num = 819601412U >> (int)num;
							467F5DB3.37CE4668 value72 = new 467F5DB3.37CE4668(this.22076BE7);
							num >>= 27;
							dictionary129[key125] = value72;
							num -= 1274630088U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary130 = this.4E7C192F;
							uint key126 = num ^ 3020337336U;
							num = 1774006780U / num;
							IntPtr 678546D62 = ldftn(7A5A024A);
							num = (835742874U ^ num);
							dictionary130[key126] = new 467F5DB3.37CE4668(this, 678546D62);
							num = 482687046U / num;
							if (num > 191308485U)
							{
								goto IL_5D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary131 = this.4E7C192F;
							num = 262686635U - num;
							uint key127 = num - 262686500U;
							num = 1670801332U << (int)num;
							IntPtr 678546D63 = ldftn(6D7B3921);
							num = 2094215032U % num;
							467F5DB3.37CE4668 value73 = new 467F5DB3.37CE4668(this, 678546D63);
							num |= 253627599U;
							dictionary131[key127] = value73;
							if (num * 396057700U == 0U)
							{
								goto IL_AA;
							}
							num = 2106091873U / num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary132 = this.4E7C192F;
							uint key128 = num + 136U;
							num = (625568413U ^ num);
							dictionary132[key128] = new 467F5DB3.37CE4668(this.4B3477AF);
							num /= 1266706773U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary133 = this.4E7C192F;
							num = 1939353863U >> (int)num;
							uint key129 = num - 1939353726U;
							num = 972051260U - num;
							IntPtr 678546D64 = ldftn(19584976);
							num *= 1795307982U;
							467F5DB3.37CE4668 value74 = new 467F5DB3.37CE4668(this, 678546D64);
							num /= 714220637U;
							dictionary133[key129] = value74;
							num = 1670729351U << (int)num;
							num = 2119388148U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary134 = this.4E7C192F;
							uint key130 = num ^ 4093640842U;
							num /= 1257390634U;
							467F5DB3.37CE4668 value75 = new 467F5DB3.37CE4668(this.7BE36DE0);
							num = 2095792676U * num;
							dictionary134[key130] = value75;
							num /= 1067152690U;
							if (327110598U < num)
							{
								goto IL_06;
							}
							num = 1315905664U >> (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary135 = this.4E7C192F;
							num = 982919150U % num;
							uint key131 = num ^ 324966181U;
							num ^= 1045237553U;
							num >>= 6;
							dictionary135[key131] = new 467F5DB3.37CE4668(this.0B982BF4);
							if (820010156U < num)
							{
								goto IL_AA;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary136 = this.4E7C192F;
							num = 1528979999U / num;
							uint key132 = num + 11U;
							num = (1793535155U ^ num);
							IntPtr 678546D65 = ldftn(239304DE);
							num = 1202415367U >> (int)num;
							dictionary136[key132] = new 467F5DB3.37CE4668(this, 678546D65);
							num /= 407849631U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary137 = this.4E7C192F;
							num /= 163802549U;
							uint key133 = num ^ 141U;
							num |= 1536182510U;
							dictionary137[key133] = new 467F5DB3.37CE4668(this.5D2121D4);
							num = (1387806636U & num);
							if ((682513901U ^ num) == 0U)
							{
								goto IL_06;
							}
							num = 1930956085U >> (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary138 = this.4E7C192F;
							num += 86905406U;
							uint key134 = num - 87376688U;
							num = 1347967201U >> (int)num;
							IntPtr 678546D66 = ldftn(7FA87F62);
							num = (785738327U & num);
							467F5DB3.37CE4668 value76 = new 467F5DB3.37CE4668(this, 678546D66);
							num %= 2144095828U;
							dictionary138[key134] = value76;
							num ^= 1062094873U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary139 = this.4E7C192F;
							num -= 1831408694U;
							dictionary139[num ^ 3525653357U] = new 467F5DB3.37CE4668(this.316B556C);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary140 = this.4E7C192F;
							uint key135 = num ^ 3525653362U;
							num = (1375482145U & num);
							467F5DB3.37CE4668 value77 = new 467F5DB3.37CE4668(this.756316D4);
							num = 1307333093U / num;
							dictionary140[key135] = value77;
							if (num > 158662795U)
							{
								goto IL_5D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary141 = this.4E7C192F;
							uint key136 = num ^ 145U;
							num /= 1377706439U;
							dictionary141[key136] = new 467F5DB3.37CE4668(this.292E3E9D);
							if (num == 1440251272U)
							{
								goto IL_5D;
							}
							num <<= 8;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary142 = this.4E7C192F;
							uint key137 = num ^ 146U;
							num = 1267096242U + num;
							num += 688747593U;
							467F5DB3.37CE4668 value78 = new 467F5DB3.37CE4668(this.58080A16);
							num = 1540447329U >> (int)num;
							dictionary142[key137] = value78;
							num *= 962802480U;
							num = 1662020052U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary143 = this.4E7C192F;
							uint key138 = num ^ 3029850579U;
							num = 302398088U >> (int)num;
							dictionary143[key138] = new 467F5DB3.37CE4668(this.19584976);
							num = 1490770137U * num;
							if (965093396U >> (int)num == 0U)
							{
								goto IL_06;
							}
							num ^= 837969884U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary144 = this.4E7C192F;
							uint key139 = num ^ 206322176U;
							num = 833299647U / num;
							num ^= 775622742U;
							dictionary144[key139] = new 467F5DB3.37CE4668(this.55087A3D);
							if (num * 1867194980U == 0U)
							{
								goto IL_06;
							}
							num = (1561724414U ^ num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary145 = this.4E7C192F;
							uint key140 = num - 1932334359U;
							num = 1049830787U - num;
							IntPtr 678546D67 = ldftn(7A5A024A);
							num %= 1321818939U;
							467F5DB3.37CE4668 value79 = new 467F5DB3.37CE4668(this, 678546D67);
							num = (438779729U & num);
							dictionary145[key140] = value79;
							if (1664883354U % num == 0U)
							{
								goto IL_5D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary146 = this.4E7C192F;
							num <<= 26;
							uint key141 = num + 4227858582U;
							num = 1331240178U >> (int)num;
							num = 33567314U * num;
							IntPtr 678546D68 = ldftn(151023C3);
							num >>= 9;
							dictionary146[key141] = new 467F5DB3.37CE4668(this, 678546D68);
							num = 292172870U + num;
							num = 678591169U >> (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary147 = this.4E7C192F;
							num %= 639718652U;
							uint key142 = num - 662535U;
							num <<= 26;
							467F5DB3.37CE4668 value80 = new 467F5DB3.37CE4668(this.151023C3);
							num = 378874314U + num;
							dictionary147[key142] = value80;
							num = 2042843486U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary148 = this.4E7C192F;
							num |= 1114255407U;
							uint key143 = num - 3690885527U;
							num |= 316544851U;
							dictionary148[key143] = new 467F5DB3.37CE4668(this.5D2B58DB);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary149 = this.4E7C192F;
							uint key144 = num ^ 3690887142U;
							467F5DB3.37CE4668 value81 = new 467F5DB3.37CE4668(this.4F9D077C);
							num <<= 27;
							dictionary149[key144] = value81;
							if (2126135658U >= num)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary150 = this.4E7C192F;
							uint key145 = num ^ 4160749722U;
							num = 1908633549U << (int)num;
							467F5DB3.37CE4668 value82 = new 467F5DB3.37CE4668(this.5D2B58DB);
							num -= 1700474260U;
							dictionary150[key145] = value82;
							if (106774310U == num)
							{
								goto IL_83;
							}
							num = (749404559U | num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary151 = this.4E7C192F;
							uint key146 = num ^ 753615652U;
							IntPtr 678546D69 = ldftn(50404ACC);
							num = (1237991613U & num);
							dictionary151[key146] = new 467F5DB3.37CE4668(this, 678546D69);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary152 = this.4E7C192F;
							num = 458305155U % num;
							uint key147 = num ^ 15887568U;
							IntPtr 678546D70 = ldftn(5CB53BAA);
							num %= 101152617U;
							467F5DB3.37CE4668 value83 = new 467F5DB3.37CE4668(this, 678546D70);
							num |= 1141246128U;
							dictionary152[key147] = value83;
							num >>= 7;
							num /= 1674405020U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary153 = this.4E7C192F;
							num /= 1435914304U;
							uint key148 = num - 4294967139U;
							IntPtr 678546D71 = ldftn(5CB53BAA);
							num = (2034764354U & num);
							dictionary153[key148] = new 467F5DB3.37CE4668(this, 678546D71);
							if (num - 1553602504U == 0U)
							{
								goto IL_06;
							}
							num = 734740545U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary154 = this.4E7C192F;
							num = (1689346955U | num);
							uint key149 = num ^ 1689346837U;
							num %= 1540635859U;
							num <<= 20;
							IntPtr 678546D72 = ldftn(7F9B0F86);
							num = 515909004U << (int)num;
							dictionary154[key149] = new 467F5DB3.37CE4668(this, 678546D72);
							if ((num ^ 1360987370U) == 0U)
							{
								goto IL_06;
							}
							num = 533728051U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary155 = this.4E7C192F;
							uint key150 = num + 677085627U;
							num = (1093028132U | num);
							IntPtr 678546D73 = ldftn(76493535);
							num = (1653621380U & num);
							467F5DB3.37CE4668 value84 = new 467F5DB3.37CE4668(this, 678546D73);
							num = 751323566U + num;
							dictionary155[key150] = value84;
							if ((1311665976U ^ num) == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary156 = this.4E7C192F;
							uint key151 = num + 2427941998U;
							IntPtr 678546D74 = ldftn(022B2B36);
							num ^= 1215516546U;
							dictionary156[key151] = new 467F5DB3.37CE4668(this, 678546D74);
							num = (1780355885U ^ num);
							num |= 621029572U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary157 = this.4E7C192F;
							num <<= 2;
							dictionary157[num + 1265114413U] = new 467F5DB3.37CE4668(this.0B982BF4);
							if (1368554374U > num)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary158 = this.4E7C192F;
							uint key152 = num ^ 3029853142U;
							num %= 1655252798U;
							467F5DB3.37CE4668 value85 = new 467F5DB3.37CE4668(this.756316D4);
							num <<= 13;
							dictionary158[key152] = value85;
							num *= 733170749U;
							if (num <= 226302139U)
							{
								goto IL_2D;
							}
							num = 431577269U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary159 = this.4E7C192F;
							num |= 1353016004U;
							uint key153 = num ^ 4190102119U;
							num -= 120681457U;
							num = 1800939735U >> (int)num;
							467F5DB3.37CE4668 value86 = new 467F5DB3.37CE4668(this.239304DE);
							num = 1685394108U / num;
							dictionary159[key153] = value86;
							num ^= 423459124U;
							if (num == 1822700388U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary160 = this.4E7C192F;
							num = 1077167322U % num;
							uint key154 = num + 4064266012U;
							num = (237052468U & num);
							467F5DB3.37CE4668 value87 = new 467F5DB3.37CE4668(this.0B982BF4);
							num = 1372476968U % num;
							dictionary160[key154] = value87;
							num = 406269737U >> (int)num;
							if (1119964802U == num)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary161 = this.4E7C192F;
							num >>= 31;
							uint key155 = num + 165U;
							num <<= 19;
							IntPtr 678546D75 = ldftn(0B982BF4);
							num += 1804027094U;
							dictionary161[key155] = new 467F5DB3.37CE4668(this, 678546D75);
							num ^= 817773690U;
							num = 1598055344U << (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary162 = this.4E7C192F;
							num = (578168169U ^ num);
							dictionary162[num + 3685931837U] = new 467F5DB3.37CE4668(this.26A23C05);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary163 = this.4E7C192F;
							num ^= 1691887965U;
							uint key156 = num - 1083509645U;
							IntPtr 678546D76 = ldftn(0B982BF4);
							num = (2025540747U & num);
							467F5DB3.37CE4668 value88 = new 467F5DB3.37CE4668(this, 678546D76);
							num |= 1646664703U;
							dictionary163[key156] = value88;
							num ^= 1198000661U;
							if (num > 1838424590U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary164 = this.4E7C192F;
							uint key157 = num ^ 635376962U;
							num |= 945565203U;
							dictionary164[key157] = new 467F5DB3.37CE4668(this.07164ABD);
							num ^= 731517530U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary165 = this.4E7C192F;
							num = 874389504U % num;
							uint key158 = num ^ 127124503U;
							IntPtr 678546D77 = ldftn(20BE7653);
							num = 908614113U >> (int)num;
							dictionary165[key158] = new 467F5DB3.37CE4668(this, 678546D77);
							num = 626538622U - num;
							num = 1924358310U - num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary166 = this.4E7C192F;
							num -= 1341405236U;
							uint key159 = num ^ 4251381598U;
							num |= 1121390190U;
							num %= 1292832445U;
							IntPtr 678546D78 = ldftn(316B556C);
							num = (952261423U ^ num);
							467F5DB3.37CE4668 value89 = new 467F5DB3.37CE4668(this, 678546D78);
							num &= 889861877U;
							dictionary166[key159] = value89;
							if (num > 1893728488U)
							{
								goto IL_5D;
							}
							num = 2131121527U >> (int)num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary167 = this.4E7C192F;
							num = 1181368237U / num;
							uint key160 = num - 4294967125U;
							num = (1792102337U & num);
							IntPtr 678546D79 = ldftn(151023C3);
							num >>= 30;
							dictionary167[key160] = new 467F5DB3.37CE4668(this, 678546D79);
							num = 359276336U + num;
							if ((num & 1668113573U) == 0U)
							{
								goto IL_C1;
							}
							num = 455434441U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary168 = this.4E7C192F;
							uint key161 = num - 814710605U;
							num <<= 2;
							467F5DB3.37CE4668 value90 = new 467F5DB3.37CE4668(this.679465DE);
							num <<= 22;
							dictionary168[key161] = value90;
							num &= 352930381U;
							if (296243867U + num == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary169 = this.4E7C192F;
							num = (1697785940U & num);
							dictionary169[num + 4278190253U] = new 467F5DB3.37CE4668(this.229B29C5);
							num = 155932257U * num;
							if ((172522847U ^ num) == 0U)
							{
								goto IL_06;
							}
							this.4E7C192F[num - 1627389778U] = new 467F5DB3.37CE4668(this.2CD26CDA);
							if (num <= 894909418U)
							{
								goto IL_83;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary170 = this.4E7C192F;
							uint key162 = num ^ 1627390127U;
							num %= 1986612835U;
							IntPtr 678546D80 = ldftn(5D2B58DB);
							num *= 434911733U;
							467F5DB3.37CE4668 value91 = new 467F5DB3.37CE4668(this, 678546D80);
							num = 812128197U << (int)num;
							dictionary170[key162] = value91;
							num = 948072169U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary171 = this.4E7C192F;
							num = 646798916U >> (int)num;
							uint key163 = num ^ 79066U;
							IntPtr 678546D81 = ldftn(38FE35C9);
							num &= 902706862U;
							dictionary171[key163] = new 467F5DB3.37CE4668(this, 678546D81);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary172 = this.4E7C192F;
							uint key164 = num ^ 13467U;
							num = 1165772144U - num;
							IntPtr 678546D82 = ldftn(7F3C140C);
							num = 1328882299U - num;
							dictionary172[key164] = new 467F5DB3.37CE4668(this, 678546D82);
							num += 751979915U;
							if (118062081U > num)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary173 = this.4E7C192F;
							uint key165 = num + 3379864050U;
							num |= 1218064914U;
							467F5DB3.37CE4668 value92 = new 467F5DB3.37CE4668(this.58080A16);
							num = (440869626U ^ num);
							dictionary173[key165] = value92;
							num &= 1209796810U;
							if (38737362U * num == 0U)
							{
								goto IL_06;
							}
							num -= 432808612U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary174 = this.4E7C192F;
							num |= 1057054607U;
							uint key166 = num - 1062207292U;
							467F5DB3.37CE4668 value93 = new 467F5DB3.37CE4668(this.151023C3);
							num = 1287980512U >> (int)num;
							dictionary174[key166] = value93;
							num |= 297864065U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary175 = this.4E7C192F;
							num = 2072182857U << (int)num;
							uint key167 = num + 3892164788U;
							num <<= 0;
							dictionary175[key167] = new 467F5DB3.37CE4668(this.22076BE7);
							if ((num ^ 21982773U) == 0U)
							{
								goto IL_06;
							}
							num = (1453725535U & num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary176 = this.4E7C192F;
							num >>= 14;
							uint key168 = num ^ 16573U;
							num += 797137932U;
							467F5DB3.37CE4668 value94 = new 467F5DB3.37CE4668(this.7BE36DE0);
							num <<= 26;
							dictionary176[key168] = value94;
							if ((num ^ 1678846117U) == 0U)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary177 = this.4E7C192F;
							num = 1453285449U % num;
							uint key169 = num ^ 111108351U;
							IntPtr 678546D83 = ldftn(292E3E9D);
							num >>= 9;
							dictionary177[key169] = new 467F5DB3.37CE4668(this, 678546D83);
							num ^= 652115876U;
							if (1919314319U - num == 0U)
							{
								goto IL_2D;
							}
							num /= 597372418U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary178 = this.4E7C192F;
							num = (217716994U & num);
							uint key170 = num ^ 183U;
							num = 1378506867U + num;
							num /= 800352566U;
							IntPtr 678546D84 = ldftn(19584976);
							num /= 1718176608U;
							dictionary178[key170] = new 467F5DB3.37CE4668(this, 678546D84);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary179 = this.4E7C192F;
							num = 1597665255U + num;
							uint key171 = num + 2697302225U;
							num += 1771504501U;
							num = 800284442U * num;
							IntPtr 678546D85 = ldftn(23123A83);
							num = 891699343U >> (int)num;
							dictionary179[key171] = new 467F5DB3.37CE4668(this, 678546D85);
							num = 164896045U / num;
							if (830955381U == num)
							{
								goto IL_5D;
							}
							num |= 1479290262U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary180 = this.4E7C192F;
							num /= 844647296U;
							uint key172 = num ^ 184U;
							num %= 901343982U;
							num = 2069592892U * num;
							dictionary180[key172] = new 467F5DB3.37CE4668(this.229B29C5);
							if (772501161U - num == 0U)
							{
								goto IL_5D;
							}
							num = 1135826412U - num;
							this.4E7C192F[num ^ 3361200650U] = new 467F5DB3.37CE4668(this.316B556C);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary181 = this.4E7C192F;
							num >>= 0;
							uint key173 = num + 933766667U;
							num >>= 29;
							num = 2057585898U >> (int)num;
							IntPtr 678546D86 = ldftn(7A5A024A);
							num = (324746782U & num);
							dictionary181[key173] = new 467F5DB3.37CE4668(this, 678546D86);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary182 = this.4E7C192F;
							num -= 1516773182U;
							uint key174 = num + 1495142376U;
							num -= 1674800590U;
							num /= 1613987829U;
							IntPtr 678546D87 = ldftn(6D7B3921);
							num *= 843336186U;
							dictionary182[key174] = new 467F5DB3.37CE4668(this, 678546D87);
							num = (414213432U ^ num);
							if (num >= 2016351779U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary183 = this.4E7C192F;
							num = 575886706U / num;
							uint key175 = num + 188U;
							num = 532173016U + num;
							IntPtr 678546D88 = ldftn(24564138);
							num = 839209976U << (int)num;
							dictionary183[key175] = new 467F5DB3.37CE4668(this, 678546D88);
							num = 706437773U << (int)num;
							num /= 1188102678U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary184 = this.4E7C192F;
							num %= 1187654892U;
							uint key176 = num ^ 190U;
							num = (1538420357U | num);
							IntPtr 678546D89 = ldftn(76493535);
							num = 735126973U + num;
							dictionary184[key176] = new 467F5DB3.37CE4668(this, 678546D89);
							if (2139177367U * num == 0U)
							{
								goto IL_5D;
							}
							num %= 1562582220U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary185 = this.4E7C192F;
							num = (786178302U | num);
							uint key177 = num - 788297535U;
							num = 1619876745U % num;
							num &= 1093168665U;
							IntPtr 678546D90 = ldftn(30711BF0);
							num = 323235694U >> (int)num;
							dictionary185[key177] = new 467F5DB3.37CE4668(this, 678546D90);
							num -= 347352642U;
							if (1077562043U > num)
							{
								break;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary186 = this.4E7C192F;
							uint key178 = num ^ 3948245781U;
							num -= 989090845U;
							num += 1855722069U;
							467F5DB3.37CE4668 value95 = new 467F5DB3.37CE4668(this.151023C3);
							num = 508103543U * num;
							dictionary186[key178] = value95;
							num += 788408453U;
							if (num > 1647525063U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary187 = this.4E7C192F;
							num %= 765933720U;
							uint key179 = num ^ 367313465U;
							num = 1356152120U << (int)num;
							num = (985753854U | num);
							IntPtr 678546D91 = ldftn(5D2B58DB);
							num %= 488900933U;
							467F5DB3.37CE4668 value96 = new 467F5DB3.37CE4668(this, 678546D91);
							num ^= 897079325U;
							dictionary187[key179] = value96;
							num -= 1826779894U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary188 = this.4E7C192F;
							num &= 867396377U;
							uint key180 = num ^ 1182675U;
							num = 1314276026U + num;
							467F5DB3.37CE4668 value97 = new 467F5DB3.37CE4668(this.5CB53BAA);
							num -= 1028547877U;
							dictionary188[key180] = value97;
							num = 1162028994U + num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary189 = this.4E7C192F;
							num /= 723272463U;
							uint key181 = num ^ 193U;
							num = 317607600U << (int)num;
							num -= 1814369349U;
							IntPtr 678546D92 = ldftn(7DFA6A70);
							num /= 1278553585U;
							dictionary189[key181] = new 467F5DB3.37CE4668(this, 678546D92);
							num = 1040996144U - num;
							num = (1715095217U | num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary190 = this.4E7C192F;
							uint key182 = num ^ 2118014843U;
							num = 2047217829U / num;
							num = 944141842U >> (int)num;
							IntPtr 678546D93 = ldftn(7DFA6A70);
							num &= 666837848U;
							467F5DB3.37CE4668 value98 = new 467F5DB3.37CE4668(this, 678546D93);
							num = 1499757596U << (int)num;
							dictionary190[key182] = value98;
							num = (84836183U | num);
							if (590893219U * num == 0U)
							{
								goto IL_83;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary191 = this.4E7C192F;
							num /= 345930111U;
							uint key183 = num + 191U;
							num = 1909205036U / num;
							IntPtr 678546D94 = ldftn(6D7B3921);
							num = 406070644U % num;
							467F5DB3.37CE4668 value99 = new 467F5DB3.37CE4668(this, 678546D94);
							num >>= 8;
							dictionary191[key183] = value99;
							if (num == 582897881U)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary192 = this.4E7C192F;
							uint key184 = num ^ 343055U;
							IntPtr 678546D95 = ldftn(76493535);
							num = 747052194U << (int)num;
							467F5DB3.37CE4668 value100 = new 467F5DB3.37CE4668(this, 678546D95);
							num = 1780689686U >> (int)num;
							dictionary192[key184] = value100;
							num = (715284347U ^ num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary193 = this.4E7C192F;
							uint key185 = num + 3212741722U;
							IntPtr 678546D96 = ldftn(316B556C);
							num <<= 7;
							467F5DB3.37CE4668 value101 = new 467F5DB3.37CE4668(this, 678546D96);
							num = (1533223670U | num);
							dictionary193[key185] = value101;
							num = 136806335U % num;
							if (1336047449U < num)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary194 = this.4E7C192F;
							uint key186 = num + 4158161161U;
							num = (1248269788U & num);
							IntPtr 678546D97 = ldftn(7F851614);
							num ^= 2138714823U;
							dictionary194[key186] = new 467F5DB3.37CE4668(this, 678546D97);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary195 = this.4E7C192F;
							uint key187 = num ^ 2002593682U;
							IntPtr 678546D98 = ldftn(316B556C);
							num = 2055088812U * num;
							467F5DB3.37CE4668 value102 = new 467F5DB3.37CE4668(this, 678546D98);
							num = 131365128U << (int)num;
							dictionary195[key187] = value102;
							num = (558908949U | num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary196 = this.4E7C192F;
							num %= 1821001732U;
							uint key188 = num - 281906631U;
							num = 1832673449U * num;
							num = 444144739U + num;
							IntPtr 678546D99 = ldftn(19584976);
							num *= 1180109163U;
							dictionary196[key188] = new 467F5DB3.37CE4668(this, 678546D99);
							if (num <= 91380880U)
							{
								goto IL_AA;
							}
							num *= 1850822563U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary197 = this.4E7C192F;
							uint key189 = num - 1172458705U;
							num = (1843932444U ^ num);
							467F5DB3.37CE4668 value103 = new 467F5DB3.37CE4668(this.22076BE7);
							num *= 1079928353U;
							dictionary197[key189] = value103;
							num <<= 21;
							if ((num ^ 160504870U) == 0U)
							{
								goto IL_2D;
							}
							num /= 581792468U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary198 = this.4E7C192F;
							num = (2055559033U & num);
							uint key190 = num ^ 204U;
							num &= 539691398U;
							IntPtr 678546D100 = ldftn(2CD26CDA);
							num /= 1829780536U;
							467F5DB3.37CE4668 value104 = new 467F5DB3.37CE4668(this, 678546D100);
							num = 1857618083U << (int)num;
							dictionary198[key190] = value104;
							num = 1999456045U + num;
							if (974532114U == num)
							{
								goto IL_2D;
							}
							num = 1128410124U / num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary199 = this.4E7C192F;
							uint key191 = num ^ 205U;
							IntPtr 678546D101 = ldftn(2B30605D);
							num = (213522768U & num);
							467F5DB3.37CE4668 value105 = new 467F5DB3.37CE4668(this, 678546D101);
							num = 264770083U * num;
							dictionary199[key191] = value105;
							num = 142899056U << (int)num;
							num = (19988718U | num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary200 = this.4E7C192F;
							num = 1291262886U << (int)num;
							uint key192 = num - 2147483442U;
							num = (570778726U | num);
							IntPtr 678546D102 = ldftn(26A23C05);
							num |= 1853368654U;
							dictionary200[key192] = new 467F5DB3.37CE4668(this, 678546D102);
							num -= 1541155352U;
							if (703350453U / num != 0U)
							{
								goto IL_AA;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary201 = this.4E7C192F;
							num = 607477210U / num;
							uint key193 = num - 4294967089U;
							num /= 183661765U;
							num /= 115221560U;
							IntPtr 678546D103 = ldftn(3F3659CB);
							num %= 341866368U;
							dictionary201[key193] = new 467F5DB3.37CE4668(this, 678546D103);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary202 = this.4E7C192F;
							uint key194 = num ^ 208U;
							num = 1834039254U << (int)num;
							num = 1511939632U / num;
							dictionary202[key194] = new 467F5DB3.37CE4668(this.5DC53681);
							num = 839726415U + num;
							if (num % 1438545690U == 0U)
							{
								goto IL_06;
							}
							num ^= 1054954681U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary203 = this.4E7C192F;
							num >>= 17;
							uint key195 = num ^ 1703U;
							num = 1253982989U / num;
							num = 791896769U * num;
							dictionary203[key195] = new 467F5DB3.37CE4668(this.316B556C);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary204 = this.4E7C192F;
							uint key196 = num ^ 1028875285U;
							num += 1507032097U;
							num >>= 12;
							IntPtr 678546D104 = ldftn(7DFA6A70);
							num %= 65240233U;
							467F5DB3.37CE4668 value106 = new 467F5DB3.37CE4668(this, 678546D104);
							num = (1234005372U | num);
							dictionary204[key196] = value106;
							if (1113064400U > num)
							{
								goto IL_2D;
							}
							num = 2054378404U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary205 = this.4E7C192F;
							num = 296364331U + num;
							dictionary205[num ^ 1648340784U] = new 467F5DB3.37CE4668(this.647078C3);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary206 = this.4E7C192F;
							uint key197 = num ^ 1648340791U;
							num = 1127832947U % num;
							num ^= 1148157355U;
							IntPtr 678546D105 = ldftn(50404ACC);
							num >>= 20;
							467F5DB3.37CE4668 value107 = new 467F5DB3.37CE4668(this, 678546D105);
							num += 1264781662U;
							dictionary206[key197] = value107;
							num -= 1568676030U;
							if ((num ^ 374629100U) == 0U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary207 = this.4E7C192F;
							uint key198 = num ^ 3991073216U;
							num = 2086343930U >> (int)num;
							IntPtr 678546D106 = ldftn(513A23AF);
							num &= 2085489098U;
							dictionary207[key198] = new 467F5DB3.37CE4668(this, 678546D106);
							num *= 1489896664U;
							if (554463420U == num)
							{
								goto IL_2D;
							}
							num = (474904321U | num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary208 = this.4E7C192F;
							num = 1403207551U % num;
							uint key199 = num ^ 382030027U;
							num = 1867703U << (int)num;
							IntPtr 678546D107 = ldftn(110A0B3C);
							num = (2000834035U ^ num);
							467F5DB3.37CE4668 value108 = new 467F5DB3.37CE4668(this, 678546D107);
							num = (1748268665U | num);
							dictionary208[key199] = value108;
							num = 769805697U / num;
							if (num > 570575460U)
							{
								goto IL_06;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary209 = this.4E7C192F;
							uint key200 = num ^ 215U;
							num = 548568884U << (int)num;
							num -= 210324647U;
							IntPtr 678546D108 = ldftn(59C158B0);
							num -= 2055735954U;
							dictionary209[key200] = new 467F5DB3.37CE4668(this, 678546D108);
							num = (952719326U ^ num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary210 = this.4E7C192F;
							num %= 586225040U;
							uint key201 = num ^ 363075901U;
							num *= 661330005U;
							dictionary210[key201] = new 467F5DB3.37CE4668(this.110A0B3C);
							num = (772151326U ^ num);
							if (num == 1179192019U)
							{
								goto IL_83;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary211 = this.4E7C192F;
							num += 1287210368U;
							uint key202 = num - 3059764670U;
							IntPtr 678546D109 = ldftn(151023C3);
							num = 1610108045U + num;
							dictionary211[key202] = new 467F5DB3.37CE4668(this, 678546D109);
							num |= 153883718U;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary212 = this.4E7C192F;
							uint key203 = num ^ 528261052U;
							467F5DB3.37CE4668 value109 = new 467F5DB3.37CE4668(this.20BE7653);
							num = 155848954U << (int)num;
							dictionary212[key203] = value109;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary213 = this.4E7C192F;
							num = (475026545U | num);
							uint key204 = num ^ 1590984234U;
							num = 599198434U * num;
							IntPtr 678546D110 = ldftn(373E71EE);
							num = (441082316U | num);
							dictionary213[key204] = new 467F5DB3.37CE4668(this, 678546D110);
							num ^= 1663241418U;
							if (482224593 << (int)num == 0)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary214 = this.4E7C192F;
							uint key205 = num - 3707598376U;
							IntPtr 678546D111 = ldftn(239304DE);
							num = 1235777481U / num;
							467F5DB3.37CE4668 value110 = new 467F5DB3.37CE4668(this, 678546D111);
							num -= 70524992U;
							dictionary214[key205] = value110;
							num = 329741588U * num;
							if (num > 1592462623U)
							{
								goto IL_2D;
							}
							num <<= 18;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary215 = this.4E7C192F;
							num += 1266961890U;
							uint key206 = num ^ 931417407U;
							num /= 350757615U;
							467F5DB3.37CE4668 value111 = new 467F5DB3.37CE4668(this.292E3E9D);
							num = (945242912U & num);
							dictionary215[key206] = value111;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary216 = this.4E7C192F;
							uint key207 = num + 222U;
							num /= 1834817653U;
							IntPtr 678546D112 = ldftn(647078C3);
							num &= 16986652U;
							dictionary216[key207] = new 467F5DB3.37CE4668(this, 678546D112);
							num %= 1348733643U;
							if (num % 1192125011U != 0U)
							{
								goto IL_06;
							}
							num = (554185631U ^ num);
							Dictionary<uint, 467F5DB3.37CE4668> dictionary217 = this.4E7C192F;
							uint key208 = num + 3740781888U;
							num = 293492994U - num;
							num %= 582222043U;
							IntPtr 678546D113 = ldftn(41B07E9D);
							num *= 808743260U;
							467F5DB3.37CE4668 value112 = new 467F5DB3.37CE4668(this, 678546D113);
							num %= 566315449U;
							dictionary217[key208] = value112;
							num = 402853499U * num;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary218 = this.4E7C192F;
							uint key209 = num ^ 1560287781U;
							num <<= 31;
							num += 319961558U;
							IntPtr 678546D114 = ldftn(7DFA6A70);
							num /= 336491167U;
							467F5DB3.37CE4668 value113 = new 467F5DB3.37CE4668(this, 678546D114);
							num = 1747656167U >> (int)num;
							dictionary218[key209] = value113;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary219 = this.4E7C192F;
							num = (541210963U & num);
							uint key210 = num + 4290769102U;
							num >>= 28;
							IntPtr 678546D115 = ldftn(19584976);
							num %= 1930240645U;
							dictionary219[key210] = new 467F5DB3.37CE4668(this, 678546D115);
							num >>= 17;
							num >>= 5;
							Dictionary<uint, 467F5DB3.37CE4668> dictionary220 = this.4E7C192F;
							uint key211 = num + 226U;
							num -= 246512531U;
							467F5DB3.37CE4668 value114 = new 467F5DB3.37CE4668(this.5AA0115D);
							num = 1246838844U % num;
							dictionary220[key211] = value114;
							num >>= 28;
							if (1140667767U == num)
							{
								goto IL_2D;
							}
							Dictionary<uint, 467F5DB3.37CE4668> dictionary221 = this.4E7C192F;
							num += 891947123U;
							uint key212 = num ^ 891947156U;
							num = 1256465215U + num;
							467F5DB3.37CE4668 value115 = new 467F5DB3.37CE4668(this.22076BE7);
							num = 675286317U << (int)num;
							dictionary221[key212] = value115;
							if (1575299636U > num)
							{
								goto Block_124;
							}
						}
					}
				}
				Block_124:
				num = 1013152514U + num;
				Dictionary<uint, 467F5DB3.37CE4668> dictionary222 = this.4E7C192F;
				num ^= 777667663U;
				uint key213 = num + 1443283351U;
				num = 1585074674U * num;
				num += 252269985U;
				IntPtr 678546D116 = ldftn(3F3659CB);
				num = 670916593U << (int)num;
				467F5DB3.37CE4668 value116 = new 467F5DB3.37CE4668(this, 678546D116);
				num *= 1535341280U;
				dictionary222[key213] = value116;
				num &= 444277836U;
				if (num / 1492799610U != 0U)
				{
					goto IL_06;
				}
				num &= 303648693U;
				Dictionary<uint, 467F5DB3.37CE4668> dictionary223 = this.4E7C192F;
				uint key214 = num ^ 33620197U;
				IntPtr 678546D117 = ldftn(07164ABD);
				num /= 1098787057U;
				467F5DB3.37CE4668 value117 = new 467F5DB3.37CE4668(this, 678546D117);
				num ^= 494210018U;
				dictionary223[key214] = value117;
				if (1616208459U <= num)
				{
					goto IL_06;
				}
				Dictionary<uint, 467F5DB3.37CE4668> dictionary224 = this.4E7C192F;
				uint key215 = num + 3800757508U;
				IntPtr 678546D118 = ldftn(0B982BF4);
				num &= 1323248236U;
				dictionary224[key215] = new 467F5DB3.37CE4668(this, 678546D118);
				num = 74270732U % num;
			}
			while (num >= 562907921U);
			Dictionary<uint, 467F5DB3.37CE4668> dictionary225 = this.4E7C192F;
			num += 329519906U;
			uint key216 = num ^ 403790793U;
			IntPtr 678546D119 = ldftn(26A23C05);
			num %= 180027675U;
			467F5DB3.37CE4668 value118 = new 467F5DB3.37CE4668(this, 678546D119);
			num = 2034702143U >> (int)num;
			dictionary225[key216] = value118;
			if (714755256U <= num)
			{
				goto IL_2D;
			}
			Dictionary<uint, 467F5DB3.37CE4668> dictionary226 = this.4E7C192F;
			num -= 1215248498U;
			uint key217 = num - 3079718687U;
			num -= 535039971U;
			num = 1810970097U + num;
			467F5DB3.37CE4668 value119 = new 467F5DB3.37CE4668(this.316B556C);
			num |= 815404552U;
			dictionary226[key217] = value119;
			num = (174873866U | num);
			Dictionary<uint, 467F5DB3.37CE4668> dictionary227 = this.4E7C192F;
			uint key218 = num ^ 1006632950U;
			num = 1118330227U % num;
			IntPtr 678546D120 = ldftn(141E7CA7);
			num *= 1598118833U;
			dictionary227[key218] = new 467F5DB3.37CE4668(this, 678546D120);
			num &= 236326019U;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary228 = this.4E7C192F;
			num = 542511284U << (int)num;
			uint key219 = num ^ 542511198U;
			num |= 1565806253U;
			dictionary228[key219] = new 467F5DB3.37CE4668(this.2CD26CDA);
			if (773013421U * num == 0U)
			{
				continue;
			}
			Dictionary<uint, 467F5DB3.37CE4668> dictionary229 = this.4E7C192F;
			num >>= 13;
			uint key220 = num ^ 256601U;
			num = 652219534U / num;
			IntPtr 678546D121 = ldftn(37EF1767);
			num *= 393440354U;
			dictionary229[key220] = new 467F5DB3.37CE4668(this, 678546D121);
			if ((2013035905U ^ num) == 0U)
			{
				continue;
			}
			num |= 1951860496U;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary230 = this.4E7C192F;
			num = 666722855U << (int)num;
			uint key221 = num - 654311188U;
			num = (1781163422U | num);
			IntPtr 678546D122 = ldftn(151023C3);
			num += 1526360567U;
			467F5DB3.37CE4668 value120 = new 467F5DB3.37CE4668(this, 678546D122);
			num -= 116216507U;
			dictionary230[key221] = value120;
			if (1036661455U % num == 0U)
			{
				continue;
			}
			Dictionary<uint, 467F5DB3.37CE4668> dictionary231 = this.4E7C192F;
			uint key222 = num - 3275193325U;
			num = 1552101048U << (int)num;
			num = (2037129690U ^ num);
			IntPtr 678546D123 = ldftn(19584976);
			num >>= 21;
			dictionary231[key222] = new 467F5DB3.37CE4668(this, 678546D123);
			Dictionary<uint, 467F5DB3.37CE4668> dictionary232 = this.4E7C192F;
			uint key223 = num - 989U;
			num &= 846491951U;
			num &= 342304611U;
			IntPtr 678546D124 = ldftn(55087A3D);
			num = (374890176U & num);
			467F5DB3.37CE4668 value121 = new 467F5DB3.37CE4668(this, 678546D124);
			num = (1341393602U & num);
			dictionary232[key223] = value121;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary233 = this.4E7C192F;
			uint key224 = num ^ 239U;
			num = (1851664154U & num);
			dictionary233[key224] = new 467F5DB3.37CE4668(this.76493535);
			num %= 1769144367U;
			if (num == 1223433620U)
			{
				goto IL_2D;
			}
			Dictionary<uint, 467F5DB3.37CE4668> dictionary234 = this.4E7C192F;
			num = (762329601U & num);
			uint key225 = num ^ 240U;
			467F5DB3.37CE4668 value122 = new 467F5DB3.37CE4668(this.756316D4);
			num ^= 454193740U;
			dictionary234[key225] = value122;
			num |= 1149521957U;
			num *= 1510957572U;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary235 = this.4E7C192F;
			num >>= 8;
			uint key226 = num ^ 1870450U;
			num = (606667702U | num);
			IntPtr 678546D125 = ldftn(756316D4);
			num ^= 37969354U;
			467F5DB3.37CE4668 value123 = new 467F5DB3.37CE4668(this, 678546D125);
			num = (476672713U ^ num);
			dictionary235[key226] = value123;
			num = 186863023U - num;
			if (num * 1252686435U == 0U)
			{
				goto IL_2D;
			}
			num = (633155101U | num);
			Dictionary<uint, 467F5DB3.37CE4668> dictionary236 = this.4E7C192F;
			num <<= 9;
			uint key227 = num - 2136866062U;
			num = 532501988U >> (int)num;
			IntPtr 678546D126 = ldftn(19584976);
			num *= 1375090185U;
			467F5DB3.37CE4668 value124 = new 467F5DB3.37CE4668(this, 678546D126);
			num = 2086474925U << (int)num;
			dictionary236[key227] = value124;
			if ((645938843U ^ num) == 0U)
			{
				continue;
			}
			Dictionary<uint, 467F5DB3.37CE4668> dictionary237 = this.4E7C192F;
			num = 1388398244U >> (int)num;
			uint key228 = num ^ 21042U;
			num = 1502630047U << (int)num;
			IntPtr 678546D127 = ldftn(20BE7653);
			num = 309291038U * num;
			dictionary237[key228] = new 467F5DB3.37CE4668(this, 678546D127);
			num = 759440497U << (int)num;
			if (619842130 << (int)num == 0)
			{
				continue;
			}
			num -= 912546044U;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary238 = this.4E7C192F;
			uint key229 = num - 2648567072U;
			IntPtr 678546D128 = ldftn(2CD26CDA);
			num += 2089768202U;
			dictionary238[key229] = new 467F5DB3.37CE4668(this, 678546D128);
			num += 385496199U;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary239 = this.4E7C192F;
			uint key230 = num ^ 828864336U;
			num &= 1544640618U;
			IntPtr 678546D129 = ldftn(07164ABD);
			num = 2096636293U / num;
			dictionary239[key230] = new 467F5DB3.37CE4668(this, 678546D129);
			num = 1914448187U - num;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary240 = this.4E7C192F;
			num &= 1194793321U;
			uint key231 = num ^ 1108609494U;
			num = 755839171U * num;
			IntPtr 678546D130 = ldftn(02E20289);
			num %= 150870060U;
			467F5DB3.37CE4668 value125 = new 467F5DB3.37CE4668(this, 678546D130);
			num = (442592869U ^ num);
			dictionary240[key231] = value125;
			if (1295937054U == num)
			{
				goto IL_2D;
			}
			Dictionary<uint, 467F5DB3.37CE4668> dictionary241 = this.4E7C192F;
			num = 127339725U / num;
			dictionary241[num + 247U] = new 467F5DB3.37CE4668(this.26A23C05);
			if (2138925065U == num)
			{
				goto IL_2D;
			}
			num = 157425309U * num;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary242 = this.4E7C192F;
			uint key232 = num ^ 248U;
			num <<= 0;
			num |= 50611410U;
			467F5DB3.37CE4668 value126 = new 467F5DB3.37CE4668(this.756316D4);
			num &= 1337339382U;
			dictionary242[key232] = value126;
			num = (526855068U & num);
			if (num + 1153986754U == 0U)
			{
				continue;
			}
			Dictionary<uint, 467F5DB3.37CE4668> dictionary243 = this.4E7C192F;
			num %= 1230719817U;
			uint key233 = num ^ 50593897U;
			num = 352077069U >> (int)num;
			num = 291405393U << (int)num;
			dictionary243[key233] = new 467F5DB3.37CE4668(this.756316D4);
			num /= 1357805119U;
			num &= 1305378311U;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary244 = this.4E7C192F;
			num = (1638668156U | num);
			uint key234 = num - 1638667906U;
			num = 271540771U + num;
			IntPtr 678546D131 = ldftn(5CB53BAA);
			num = 1918588394U / num;
			467F5DB3.37CE4668 value127 = new 467F5DB3.37CE4668(this, 678546D131);
			num = 1522564328U % num;
			dictionary244[key234] = value127;
			if (1779567216U <= num)
			{
				continue;
			}
			num %= 725701332U;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary245 = this.4E7C192F;
			num = 397748383U * num;
			uint key235 = num + 251U;
			num = (347170871U & num);
			467F5DB3.37CE4668 value128 = new 467F5DB3.37CE4668(this.0B982BF4);
			num = 1108098525U - num;
			dictionary245[key235] = value128;
			Dictionary<uint, 467F5DB3.37CE4668> dictionary246 = this.4E7C192F;
			num = 261240488U / num;
			uint key236 = num - 4294967044U;
			num <<= 17;
			dictionary246[key236] = new 467F5DB3.37CE4668(this.30711BF0);
			if ((num ^ 335695643U) != 0U)
			{
				num = (33782447U | num);
				Dictionary<uint, 467F5DB3.37CE4668> dictionary247 = this.4E7C192F;
				num = 1522298385U + num;
				uint key237 = num ^ 1556080701U;
				num %= 1150579325U;
				467F5DB3.37CE4668 value129 = new 467F5DB3.37CE4668(this.0B982BF4);
				num = 2047294778U + num;
				dictionary247[key237] = value129;
				num -= 1320687090U;
				if (num != 782987005U)
				{
					break;
				}
				goto IL_2D;
			}
			IL_5D:
			num = 1596093187U / num;
			Stack<467F5DB3.371F2AF7> stack3 = new Stack<467F5DB3.371F2AF7>();
			num = 1130449299U % num;
			this.65EB1F68 = stack3;
			if (num == 557724985U)
			{
				continue;
			}
			IL_83:
			num += 492637702U;
			List<467F5DB3.37FA30B9> list2 = new List<467F5DB3.37FA30B9>();
			num |= 889403286U;
			this.311B0F7E = list2;
			if ((227869658U ^ num) != 0U)
			{
				goto IL_AA;
			}
		}
		Dictionary<uint, 467F5DB3.37CE4668> dictionary248 = this.4E7C192F;
		uint key238 = num - 1132108941U;
		num = 1014115167U << (int)num;
		dictionary248[key238] = new 467F5DB3.37CE4668(this.4F9D077C);
		num ^= 1356271362U;
		num += 1750564792U;
		Dictionary<uint, 467F5DB3.37CE4668> dictionary249 = this.4E7C192F;
		num += 1587156555U;
		uint key239 = num + 2004907002U;
		num = 1251672105U - num;
		IntPtr 678546D132 = ldftn(316B556C);
		num ^= 1472073139U;
		dictionary249[key239] = new 467F5DB3.37CE4668(this, 678546D132);
	}

	// Token: 0x0600022F RID: 559 RVA: 0x00300984 File Offset: 0x002FE584
	private void 154055D0(467F5DB3.37FA30B9 19D13A22)
	{
		this.65EB1F68.Push(19D13A22.52809797());
	}

	// Token: 0x06000230 RID: 560 RVA: 0x003009A8 File Offset: 0x002FE5A8
	private 467F5DB3.37FA30B9 026905F8()
	{
		uint num = 1446009743U;
		Stack<467F5DB3.371F2AF7> stack = this.65EB1F68;
		num |= 868430378U;
		return stack.Pop();
	}

	// Token: 0x06000231 RID: 561 RVA: 0x003009D0 File Offset: 0x002FE5D0
	private 467F5DB3.37FA30B9 22AC4C1B()
	{
		uint num = 1538270910U;
		num = (1675177907U & num);
		Stack<467F5DB3.371F2AF7> stack = this.65EB1F68;
		num <<= 16;
		return stack.Peek();
	}

	// Token: 0x06000232 RID: 562 RVA: 0x00300A00 File Offset: 0x002FE600
	private byte 301D0658()
	{
		uint num = 1365967438U;
		num = 1413163140U + num;
		long num2 = this.4E7216B9;
		long num3 = (long)this.0749791D;
		num = 953572619U * num;
		long num4 = num3;
		num |= 1736052510U;
		long value = num2 + num4;
		num |= 2143298013U;
		byte result = Marshal.ReadByte(new IntPtr(value));
		num = (90400401U | num);
		int num5 = this.0749791D;
		num = 979257280U + num;
		this.0749791D = num5 + (int)(num ^ 3126704030U);
		return result;
	}

	// Token: 0x06000233 RID: 563 RVA: 0x00300A70 File Offset: 0x002FE670
	private short 534F3A25()
	{
		long num = this.4E7216B9;
		uint num2 = 553013311U;
		long num3 = (long)this.0749791D;
		num2 = 866592196U >> (int)num2;
		long value = num + num3;
		num2 >>= 16;
		IntPtr ptr = new IntPtr(value);
		num2 ^= 1336422923U;
		short result = Marshal.ReadInt16(ptr);
		num2 *= 677193852U;
		num2 /= 1793292116U;
		int num4 = this.0749791D;
		num2 = 624041729U + num2;
		int num5 = (int)(num2 + 3670925568U);
		num2 = 1513114457U * num2;
		int num6 = num4 + num5;
		num2 &= 2094147575U;
		this.0749791D = num6;
		return result;
	}

	// Token: 0x06000234 RID: 564 RVA: 0x00300AF8 File Offset: 0x002FE6F8
	private int 26642191()
	{
		long num = this.4E7216B9;
		uint num2 = 1068386338U;
		num2 &= 1944863926U;
		int result = Marshal.ReadInt32(new IntPtr(num + (long)this.0749791D));
		num2 = 870346273U >> (int)num2;
		num2 /= 1538220157U;
		int num3 = this.0749791D;
		num2 /= 1081041389U;
		int num4 = num3 + (int)(num2 - 4294967292U);
		num2 &= 1095394383U;
		this.0749791D = num4;
		return result;
	}

	// Token: 0x06000235 RID: 565 RVA: 0x00300B68 File Offset: 0x002FE768
	private long 49C337B0()
	{
		uint num = 761678887U;
		num -= 2138009367U;
		long num2 = this.4E7216B9;
		num >>= 17;
		long num3 = (long)this.0749791D;
		num += 1455518214U;
		long value = num2 + num3;
		num = (922879401U | num);
		IntPtr ptr = new IntPtr(value);
		num -= 878864792U;
		long result = Marshal.ReadInt64(ptr);
		num >>= 30;
		num = (1038499373U & num);
		num = (1946448350U ^ num);
		this.0749791D += (int)(num ^ 1946448343U);
		return result;
	}

	// Token: 0x06000236 RID: 566 RVA: 0x00300BE8 File Offset: 0x002FE7E8
	private float 5F4C6581()
	{
		uint num = 1184832326U;
		int value = this.26642191();
		num &= 2045735176U;
		byte[] bytes = BitConverter.GetBytes(value);
		num = 1437740855U % num;
		return BitConverter.ToSingle(bytes, (int)(num ^ 354623031U));
	}

	// Token: 0x06000237 RID: 567 RVA: 0x00300C24 File Offset: 0x002FE824
	private double 28373AC1()
	{
		uint num = 24197211U;
		long value = this.49C337B0();
		num &= 1137185310U;
		byte[] bytes = BitConverter.GetBytes(value);
		num ^= 657673868U;
		int startIndex = (int)(num + 3649872234U);
		num = 982205315U * num;
		return BitConverter.ToDouble(bytes, startIndex);
	}

	// Token: 0x06000238 RID: 568 RVA: 0x00300C68 File Offset: 0x002FE868
	private void 23123A83()
	{
		for (;;)
		{
			IL_00:
			byte b = this.301D0658();
			uint num = 442320804U;
			byte b2 = b;
			num = (1288061199U & num);
			int num6;
			int 623A;
			467F5DB3.74D46A00 74D46A2;
			bool flag3;
			int num15;
			for (;;)
			{
				IL_18:
				int num2 = this.26642191();
				num ^= 1961034650U;
				int num3 = num2;
				for (;;)
				{
					num = 670653613U - num;
					int num4 = this.26642191();
					if (num >= 572680438U)
					{
						for (;;)
						{
							IL_48:
							num -= 978409603U;
							int num5 = this.26642191();
							num |= 1737954693U;
							num6 = num5;
							if ((1079671108U & num) == 0U)
							{
								goto IL_00;
							}
							num ^= 2144213974U;
							int num7 = this.26642191();
							num -= 951911737U;
							623A = num7;
							num = 233448003U >> (int)num;
							if (1908282324U != num)
							{
								for (;;)
								{
									IL_A8:
									467F5DB3.74D46A00 74D46A = null;
									num <<= 19;
									74D46A2 = 74D46A;
									num /= 171122301U;
									int num8 = (int)(num - 6U);
									num = (24522711U & num);
									int num9 = num8;
									if (num + 2037805989U != 0U)
									{
										while (105255105U >= num)
										{
											int num10 = num9;
											num <<= 29;
											if (num10 >= this.69866088.Count)
											{
												num += 2795576195U;
											}
											else
											{
												num = 1265578336U;
												num = 1007430123U - num;
												467F5DB3.74D46A00 74D46A3 = this.69866088[num9];
												if ((602690431U ^ num) == 0U)
												{
													goto IL_00;
												}
												467F5DB3.74D46A00 74D46A4 = 74D46A3;
												num = 1325359173U * num;
												int num11 = 74D46A4.40532304();
												num = 158666435U / num;
												int num12 = num3;
												num |= 1721834371U;
												if (num11 == num12)
												{
													int num13 = 74D46A3.74685482();
													int num14 = num4;
													num ^= 0U;
													if (num13 == num14)
													{
														74D46A2 = 74D46A3;
														if (num >> 0 != 0U)
														{
															goto IL_1CB;
														}
														goto IL_00;
													}
												}
												num <<= 31;
												if (num >= 59584647U)
												{
													num9 += (int)(num + 2147483649U);
													num += 2147483654U;
													continue;
												}
												break;
											}
											IL_1CB:
											num /= 1753630083U;
											if (759846557U == num)
											{
												break;
											}
											bool flag = 74D46A2 != null;
											num |= 2145088923U;
											if (flag)
											{
												goto IL_3B2;
											}
											bool flag2 = (num ^ 2145088923U) != 0U;
											num -= 486213331U;
											flag3 = flag2;
											if (num << 25 == 0U)
											{
												goto IL_00;
											}
											int 1AF5160A = num3;
											num = 1606883295U - num;
											int 2DB = num4;
											num >>= 16;
											74D46A2 = new 467F5DB3.74D46A00(1AF5160A, 2DB);
											num -= 1360143366U;
											num15 = (int)(num - 2934888672U);
											if (num > 2111917834U)
											{
												goto Block_12;
											}
											goto IL_A8;
										}
										goto IL_18;
									}
									goto IL_00;
								}
								Block_12:
								while ((1805927029U ^ num) != 0U)
								{
									int num16 = num15;
									num = 2058443986U >> (int)num;
									int count = this.69866088.Count;
									num = 270736656U * num;
									if (num16 >= count)
									{
										goto Block_16;
									}
									num = 3041499U;
									if (num >= 491476265U)
									{
										goto IL_48;
									}
									List<467F5DB3.74D46A00> list = this.69866088;
									num = (973031663U & num);
									467F5DB3.74D46A00 74D46A5 = list[num15];
									467F5DB3.74D46A00 74D46A6 = 74D46A2;
									467F5DB3.74D46A00 5FA = 74D46A5;
									num = 2062434170U + num;
									uint num17 = (uint)74D46A6.355255BD(5FA);
									num /= 1285496600U;
									if (num17 < (num ^ 1U))
									{
										goto Block_14;
									}
									num = 402285106U - num;
									int num18 = num15 + (int)(num - 402285104U);
									num = 868298179U >> (int)num;
									num15 = num18;
									num ^= 2934882560U;
								}
								goto IL_00;
							}
							break;
						}
					}
				}
			}
			IL_355:
			num -= 1586435992U;
			if (1203113806U >= num)
			{
				continue;
			}
			bool flag4 = flag3;
			num ^= 3315232907U;
			if (flag4)
			{
				goto IL_3B2;
			}
			num = 973814603U / num;
			if (380969162U > num)
			{
				List<467F5DB3.74D46A00> list2 = this.69866088;
				num = (1063588162U | num);
				list2.Add(74D46A2);
				num += 1081500761U;
				goto IL_3B2;
			}
			continue;
			Block_16:
			num ^= 2342488968U;
			goto IL_355;
			Block_14:
			num /= 317598027U;
			List<467F5DB3.74D46A00> list3 = this.69866088;
			num = (233243577U | num);
			list3.Insert(num15, 74D46A2);
			bool flag5 = num - 233243576U != 0U;
			num ^= 355933969U;
			flag3 = flag5;
			goto IL_355;
			IL_3B2:
			if (num != 335563263U)
			{
				467F5DB3.74D46A00 74D46A7 = 74D46A2;
				byte 47D122D = b2;
				int 33135B = num6;
				num = 227954452U << (int)num;
				74D46A7.195657AE(47D122D, 33135B, 623A);
				if (1930036726U != num)
				{
					break;
				}
			}
		}
	}

	// Token: 0x06000239 RID: 569 RVA: 0x0030105C File Offset: 0x002FEC5C
	private TypeCode 32704198(467F5DB3.37FA30B9 05015E9A, 467F5DB3.37FA30B9 2A2069CA)
	{
		uint num;
		TypeCode typeCode;
		for (;;)
		{
			IL_00:
			num = 2053715862U;
			typeCode = 05015E9A.02557F0D();
			TypeCode typeCode3;
			for (;;)
			{
				num = 768434200U << (int)num;
				TypeCode typeCode2 = 2A2069CA.02557F0D();
				num = (157620870U ^ num);
				typeCode3 = typeCode2;
				if ((num ^ 1229131189U) != 0U)
				{
					goto IL_36;
				}
				for (;;)
				{
					IL_6C:
					bool flag = typeCode3 != TypeCode.Empty;
					num = (69480751U ^ num);
					num ^= 3576800903U;
					if (!flag)
					{
						goto IL_9F;
					}
					num = 1445135175U + num;
					if (typeCode3 == (TypeCode)(num ^ 3194012404U))
					{
						goto Block_3;
					}
					uint num2 = (uint)typeCode;
					num *= 1960391209U;
					if (num2 == num - 2839548723U)
					{
						break;
					}
					num = 959673211U % num;
					if (typeCode3 != (TypeCode)(num ^ 959673201U))
					{
						goto IL_171;
					}
					if (num + 373564703U == 0U)
					{
						goto IL_00;
					}
					TypeCode typeCode4 = typeCode;
					num ^= 618813222U;
					uint num3 = num ^ 500245588U;
					num = (146024578U | num);
					if (typeCode4 != num3)
					{
						goto Block_10;
					}
					num = 798953187U >> (int)num;
					if (1951487866U >> (int)num != 0U)
					{
						return typeCode3;
					}
				}
				num = 39942466U * num;
				if ((num ^ 381691025U) == 0U)
				{
					continue;
				}
				TypeCode typeCode5 = typeCode3;
				uint num4 = num - 2948188849U;
				num = 139594513U << (int)num;
				if (typeCode5 != num4)
				{
					goto Block_6;
				}
				if ((1737715550U & num) != 0U)
				{
					return typeCode;
				}
				continue;
				IL_171:
				num = (1851999329U | num);
				uint num5 = (uint)typeCode;
				num += 2080839700U;
				if (num5 == num + 75853949U)
				{
					break;
				}
				num -= 917573234U;
				if (num == 1869223310U)
				{
					goto IL_00;
				}
				if (typeCode3 == (TypeCode)(num - 3301540113U))
				{
					goto Block_18;
				}
				num = 870992656U * num;
				if (num - 1461481051U == 0U)
				{
					continue;
				}
				if (typeCode == (TypeCode)(num ^ 552440030U))
				{
					goto IL_2CA;
				}
				num &= 188621070U;
				if ((1449799148U ^ num) == 0U)
				{
					goto IL_00;
				}
				uint num6 = (uint)typeCode3;
				num = (64772691U | num);
				if (num6 == num + 4228097467U)
				{
					goto Block_25;
				}
				TypeCode typeCode6 = typeCode;
				num = 276458689U * num;
				uint num7 = num - 3001621638U;
				num = 469725825U + num;
				if (typeCode6 == num7)
				{
					goto IL_318;
				}
				if (1174734030U - num == 0U)
				{
					goto IL_00;
				}
				if (typeCode3 == (int)num + (TypeCode)823619833)
				{
					goto Block_28;
				}
				if (num != 1888959454U)
				{
					goto Block_29;
				}
				IL_36:
				bool flag2 = typeCode != TypeCode.Empty;
				num *= 1060900829U;
				if (!flag2)
				{
					goto IL_9F;
				}
				TypeCode typeCode7 = typeCode;
				uint num8 = num ^ 1748877231U;
				num += 0U;
				if (typeCode7 == num8)
				{
					goto IL_9F;
				}
				num = 1357539416U + num;
				if (1601197724U <= num)
				{
					goto IL_6C;
				}
			}
			num = 1007566955U % num;
			if (num <= 268663492U)
			{
				continue;
			}
			TypeCode typeCode8 = typeCode3;
			uint num9 = num ^ 1007566946U;
			num &= 810106280U;
			if (typeCode8 != num9)
			{
				TypeCode typeCode9 = typeCode3;
				num /= 1139219743U;
				uint num10 = num + 11U;
				num ^= 805830696U;
				if (typeCode9 != num10)
				{
					goto Block_15;
				}
			}
			num += 729177755U;
			if (num <= 1904377657U)
			{
				return typeCode;
			}
			continue;
			Block_18:
			TypeCode typeCode10 = typeCode;
			num *= 831266960U;
			uint num11 = num - 173555783U;
			num <<= 0;
			if (typeCode10 != num11)
			{
				num = (360597761U & num);
				TypeCode typeCode11 = typeCode;
				uint num12 = num ^ 5783563U;
				num = 732526354U - num;
				num ^= 554268482U;
				if (typeCode11 != num12)
				{
					goto Block_20;
				}
			}
			num /= 1238576067U;
			if (num % 1719079431U == 0U)
			{
				return typeCode;
			}
		}
		Block_3:
		num ^= 3596451163U;
		IL_9F:
		return (TypeCode)(num ^ 1748877230U);
		Block_6:
		num ^= 273827590U;
		return (TypeCode)(num - 1414678278U);
		Block_10:
		return (TypeCode)(num ^ 502607071U);
		Block_15:
		return (TypeCode)(num - 805830696U);
		Block_20:
		num &= 1639470301U;
		return (TypeCode)(num - 1589328U);
		Block_25:
		num ^= 588368515U;
		IL_2CA:
		num ^= 1888961683U;
		return (TypeCode)(num - 1350226997U);
		Block_28:
		num ^= 0U;
		IL_318:
		num = 1136286193U << (int)num;
		return (TypeCode)(num ^ 2668625933U);
		Block_29:
		TypeCode typeCode12 = typeCode;
		uint num13 = num ^ 3471347487U;
		num = (371275893U & num);
		if (typeCode12 != num13)
		{
			num /= 177144739U;
			TypeCode typeCode3;
			TypeCode typeCode13 = typeCode3;
			uint num14 = num ^ 11U;
			num *= 178539535U;
			if (typeCode13 != num14)
			{
				num = (255684528U ^ num);
				return (int)num + (TypeCode)(-255684519);
			}
			num ^= 102762516U;
		}
		num >>= 20;
		return (TypeCode)(num ^ 105U);
	}

	// Token: 0x0600023A RID: 570 RVA: 0x003013FC File Offset: 0x002FEFFC
	private unsafe 467F5DB3.37FA30B9 5A457CFC(467F5DB3.37FA30B9 028635D7, 467F5DB3.37FA30B9 554A74F2, bool 5D63497E, bool 61D25C19)
	{
		uint num;
		long 0E0B;
		long num26;
		uint num35;
		int num37;
		int num39;
		uint num40;
		467F5DB3.6B576539 6B2;
		IntPtr intPtr2;
		for (;;)
		{
			IL_00:
			num = 820997595U;
			num %= 1250434185U;
			TypeCode typeCode = this.32704198(028635D7, 554A74F2);
			num %= 1157759091U;
			TypeCode typeCode2 = typeCode;
			if (966994478U != num)
			{
				int value;
				for (;;)
				{
					object obj = typeCode2;
					object obj2 = num + 3473969710U;
					num *= 932053991U;
					object obj3 = obj - obj2;
					num = 439554256U % num;
					switch (obj3)
					{
					case 0:
						goto IL_85;
					case 1:
					{
						num |= 637160967U;
						if (!61D25C19)
						{
							goto IL_6A3;
						}
						if (636946028U == num)
						{
							goto IL_00;
						}
						uint num2 = 028635D7.437B0320();
						num = 1243490290U + num;
						uint num3 = num2;
						num = 1003247269U << (int)num;
						num %= 299582488U;
						uint num4 = 554A74F2.437B0320();
						if (620188685U == num)
						{
							continue;
						}
						num = 685442615U * num;
						int num6;
						if (!5D63497E)
						{
							int num5 = (int)num3;
							num = 1547254885U - num;
							num6 = num5 + (int)num4;
						}
						else
						{
							int num7 = (int)num3;
							int num8 = (int)num4;
							num /= 863792316U;
							num6 = checked(num7 + num8);
							num += 52682660U;
						}
						num = 1403916935U << (int)num;
						value = num6;
						if ((562965423U ^ num) != 0U)
						{
							goto Block_39;
						}
						continue;
					}
					case 2:
						num ^= 41769500U;
						if (61D25C19)
						{
							num >>= 24;
							num = 1103037636U >> (int)num;
							ulong num9 = 028635D7.67922FD7();
							num ^= 1411793518U;
							num *= 714170263U;
							ulong num10 = 554A74F2.67922FD7();
							num = 1046628107U - num;
							if ((num ^ 1307654782U) == 0U)
							{
								goto IL_00;
							}
							long num13;
							if (!5D63497E)
							{
								num = 369562155U / num;
								long num11 = (long)num9;
								long num12 = (long)num10;
								num ^= 1835486023U;
								num13 = num11 + num12;
							}
							else
							{
								num13 = (long)(checked(num9 + num10));
								num += 918847221U;
							}
							num = 321345315U >> (int)num;
							0E0B = num13;
							if (num / 208495315U != 0U)
							{
								continue;
							}
						}
						else
						{
							if (973869516U == num)
							{
								goto IL_00;
							}
							long num14 = 028635D7.E1698415();
							num -= 1109687909U;
							long num15 = num14;
							num &= 2106537403U;
							if (1107896333U > num)
							{
								continue;
							}
							long num16 = 554A74F2.E1698415();
							num *= 509178697U;
							long num17 = num16;
							num *= 2133872909U;
							num *= 1788375492U;
							long num18;
							if (!5D63497E)
							{
								num /= 1528303700U;
								if (589198281U / num == 0U)
								{
									goto IL_80;
								}
								num18 = num15 + num17;
							}
							else
							{
								if (num / 1668371U == 0U)
								{
									goto IL_00;
								}
								long num19 = num15;
								num = (451178954U & num);
								num18 = checked(num19 + num17);
								num += 4118793977U;
							}
							num = (1769295183U | num);
							0E0B = num18;
							num += 2528182623U;
						}
						num = (390408697U ^ num);
						if (143462611U < num)
						{
							goto Block_18;
						}
						continue;
					case 3:
					{
						num = 2139564849U << (int)num;
						if (658577952U == num)
						{
							continue;
						}
						if (61D25C19)
						{
							if ((num ^ 1659575363U) == 0U)
							{
								goto IL_00;
							}
							num = (1812353392U & num);
							ulong num20 = 028635D7.67922FD7();
							num = (1329954554U & num);
							ulong num21 = num20;
							num = 1896285888U >> (int)num;
							if ((1497960265U & num) == 0U)
							{
								goto IL_00;
							}
							ulong num22 = 554A74F2.67922FD7();
							num ^= 71001472U;
							num = 108421431U + num;
							long num25;
							if (!5D63497E)
							{
								long num23 = (long)num21;
								long num24 = (long)num22;
								num = 1281129373U / num;
								num25 = num23 + num24;
							}
							else
							{
								num25 = (long)(checked(num21 + num22));
								num ^= 2075313271U;
							}
							num %= 1280657791U;
							num26 = num25;
						}
						else
						{
							num = (1806379047U & num);
							if ((num ^ 456921688U) == 0U)
							{
								goto IL_85;
							}
							long num27 = 028635D7.E1698415();
							num %= 1543768673U;
							long num28 = num27;
							if (1845171687U + num == 0U)
							{
								goto IL_80;
							}
							num |= 48845806U;
							long num29 = 554A74F2.E1698415();
							long num32;
							if (!5D63497E)
							{
								num %= 1094872791U;
								if (1830620827U - num == 0U)
								{
									continue;
								}
								long num30 = num28;
								num = 1883468708U + num;
								long num31 = num29;
								num = 1073306660U * num;
								num32 = num30 + num31;
							}
							else
							{
								num32 = checked(num28 + num29);
								num ^= 854580070U;
							}
							num = (547696778U & num);
							num26 = num32;
							num += 4294705016U;
						}
						num = 983711086U - num;
						num %= 174794701U;
						TypeCode typeCode3 = 028635D7.02557F0D();
						num += 681584107U;
						TypeCode typeCode4 = typeCode2;
						num = 702562410U / num;
						if (typeCode3 != typeCode4)
						{
							goto Block_55;
						}
						num >>= 22;
						if ((736637137U & num) == 0U)
						{
							goto Block_56;
						}
						continue;
					}
					case 4:
					{
						467F5DB3.37FA30B9 37FA30B;
						if (!61D25C19)
						{
							num = (1502707285U | num);
							if (num - 1744183607U == 0U)
							{
								goto IL_80;
							}
							37FA30B = 028635D7;
						}
						else
						{
							if (num == 1746540801U)
							{
								continue;
							}
							37FA30B = 028635D7.374AB499();
							num += 1098935813U;
						}
						num += 1936524305U;
						float num33 = 37FA30B.8E4073FD();
						num = 17792088U / num;
						float num34 = num33;
						if (!61D25C19)
						{
							goto Block_22;
						}
						num &= 2135438029U;
						if (1349001616U > num)
						{
							goto Block_24;
						}
						continue;
					}
					case 5:
						num = 852904869U / num;
						if (num == 764613916U)
						{
							goto IL_80;
						}
						if (61D25C19)
						{
							goto IL_4E1;
						}
						if (num < 1017060843U)
						{
							goto Block_29;
						}
						goto IL_85;
					}
					break;
					IL_85:
					if (num >= 498159855U)
					{
						goto IL_80;
					}
					if (61D25C19)
					{
						num >>= 30;
						if (num <= 1861503792U)
						{
							num35 = 028635D7.437B0320();
							num |= 1604593729U;
							if ((num & 695144156U) != 0U)
							{
								goto IL_CD;
							}
						}
					}
					else
					{
						int num36 = 028635D7.D6BFBC24();
						num = (1580224142U | num);
						num37 = num36;
						num >>= 15;
						num = 1327503873U % num;
						int num38 = 554A74F2.D6BFBC24();
						num = (1945908572U & num);
						num39 = num38;
						num /= 903821018U;
						num -= 770844536U;
						if (5D63497E)
						{
							goto IL_1B2;
						}
						num <<= 27;
						if (1013526239U != num)
						{
							goto Block_7;
						}
					}
				}
				if (542337928 << (int)num != 0)
				{
					goto IL_80;
				}
				continue;
				IL_CD:
				num -= 1476928676U;
				num40 = 554A74F2.437B0320();
				if (1092899535U != num)
				{
					break;
				}
				continue;
				IL_1B2:
				num += 1084821948U;
				if (num < 567030264U)
				{
					goto Block_8;
				}
				continue;
				IL_505:
				467F5DB3.37FA30B9 37FA30B2;
				double num41 = 37FA30B2.B7D5DC99();
				num *= 896223450U;
				double num42 = num41;
				num <<= 22;
				num /= 128064083U;
				467F5DB3.37FA30B9 37FA30B3;
				if (!61D25C19)
				{
					if (num >> 29 != 0U)
					{
						continue;
					}
					37FA30B3 = 554A74F2;
				}
				else
				{
					num &= 1931628706U;
					if ((1373772576U ^ num) == 0U)
					{
						continue;
					}
					num = 1269575112U / num;
					37FA30B3 = 554A74F2.374AB499();
					num ^= 634787555U;
				}
				num <<= 24;
				double num43 = 37FA30B3.B7D5DC99();
				num = 1609066432U % num;
				double num44 = num43;
				if (num != 1494162099U)
				{
					goto Block_33;
				}
				continue;
				IL_4E1:
				num = (288896079U | num);
				num <<= 0;
				37FA30B2 = 028635D7.374AB499();
				num += 4006071218U;
				goto IL_505;
				Block_29:
				37FA30B2 = 028635D7;
				goto IL_505;
				IL_6A3:
				if (num <= 1535854399U)
				{
					num = 1555568652U << (int)num;
					int num45 = 028635D7.D6BFBC24();
					num = 1964661599U + num;
					int num46 = num45;
					num %= 636174252U;
					num <<= 0;
					int num47 = 554A74F2.D6BFBC24();
					num = (1781800436U ^ num);
					int num50;
					if (!5D63497E)
					{
						if (1269772968U >> (int)num == 0U)
						{
							goto IL_CD;
						}
						int num48 = num46;
						int num49 = num47;
						num = 1068714625U * num;
						num50 = num48 + num49;
					}
					else
					{
						num = (1958106525U | num);
						if ((937239563U ^ num) == 0U)
						{
							goto IL_80;
						}
						int num51 = num46;
						num = (413992757U ^ num);
						num50 = checked(num51 + num47);
						num += 3325238437U;
					}
					value = num50;
					num += 1077633457U;
					goto IL_75D;
				}
				continue;
				Block_22:
				num &= 2064653003U;
				if (255749676U <= num)
				{
					goto IL_80;
				}
				467F5DB3.37FA30B9 37FA30B4 = 554A74F2;
				IL_424:
				num |= 1336740630U;
				float num52 = 37FA30B4.8E4073FD();
				num = 134818972U - num;
				float num53 = num52;
				if (num != 1161510338U)
				{
					goto Block_25;
				}
				goto IL_80;
				Block_24:
				37FA30B4 = 554A74F2.374AB499();
				num ^= 0U;
				goto IL_424;
				IL_75D:
				num %= 1945115577U;
				num = 1723485967U - num;
				TypeCode typeCode5 = 028635D7.02557F0D();
				TypeCode typeCode6 = typeCode2;
				num = 404507838U >> (int)num;
				467F5DB3.6B576539 6B;
				if (typeCode5 != typeCode6)
				{
					num >>= 30;
					num %= 1853971109U;
					6B = (467F5DB3.6B576539)554A74F2;
				}
				else
				{
					num = 380174455U % num;
					num += 790125410U;
					6B = (467F5DB3.6B576539)028635D7;
					num ^= 791073945U;
				}
				num &= 1471962636U;
				6B2 = 6B;
				num &= 2098879597U;
				IntPtr intPtr = new IntPtr(value);
				num = 1247034060U << (int)num;
				intPtr2 = intPtr;
				num *= 900935547U;
				if (1755317562U != num)
				{
					goto Block_45;
				}
				goto IL_80;
				Block_39:
				goto IL_75D;
			}
			IL_80:
			num <<= 30;
			if (num * 1733706060U == 0U)
			{
				goto Block_57;
			}
		}
		int num56;
		if (!5D63497E)
		{
			num = 709305374U / num;
			int num54 = (int)num35;
			num %= 2033799087U;
			int num55 = (int)num40;
			num = (310454576U & num);
			num56 = num54 + num55;
		}
		else
		{
			int num57 = (int)num35;
			int num58 = (int)num40;
			num = 128859449U - num;
			num56 = checked(num57 + num58);
			num ^= 1194396U;
		}
		int 0A = num56;
		goto IL_1E1;
		Block_7:
		int num59 = num37;
		num += 1776375339U;
		int num60 = num59 + num39;
		goto IL_1D6;
		Block_8:
		num60 = checked(num37 + num39);
		num += 2536139751U;
		IL_1D6:
		0A = num60;
		num += 1444850133U;
		IL_1E1:
		return new 467F5DB3.1C0911B0(0A);
		Block_18:
		return new 467F5DB3.06E010E5(0E0B);
		Block_25:
		num = 743718162U * num;
		float 7D;
		if (!5D63497E)
		{
			num = 1780220239U << (int)num;
			float num34;
			float num61 = num34;
			num = 539771193U - num;
			float num53;
			float num62 = num53;
			num += 345923838U;
			7D = num61 + num62;
		}
		else
		{
			float num34;
			float num63 = num34;
			float num53;
			float num64 = num53;
			num += 1796100851U;
			7D = num63 + num64;
			num += 389551576U;
		}
		num = (2032234367U & num);
		return new 467F5DB3.3D312057(7D);
		Block_33:
		double 7E9E;
		if (!5D63497E)
		{
			double num42;
			double num65 = num42;
			num = 1478521614U << (int)num;
			double num44;
			7E9E = num65 + num44;
		}
		else
		{
			double num42;
			double num66 = num42;
			double num44;
			double num67 = num44;
			num = 2059425472U * num;
			7E9E = num66 + num67;
			num += 1190667022U;
		}
		num >>= 16;
		return new 467F5DB3.07A85735(7E9E);
		Block_45:
		num <<= 27;
		void* ptr = intPtr2.ToPointer();
		num = 323975264U % num;
		Type type = 6B2.62D13369();
		num = (260444922U & num);
		object 36FA1F = Pointer.Box(ptr, type);
		467F5DB3.6B576539 6B3 = 6B2;
		num = (1453291586U | num);
		return new 467F5DB3.6B576539(36FA1F, 6B3.62D13369());
		Block_55:
		467F5DB3.6B576539 6B4 = (467F5DB3.6B576539)554A74F2;
		goto IL_A29;
		Block_56:
		6B4 = (467F5DB3.6B576539)028635D7;
		num ^= 0U;
		IL_A29:
		num = (2099338198U & num);
		467F5DB3.6B576539 6B5 = 6B4;
		long value2 = num26;
		num -= 353527573U;
		IntPtr intPtr3 = new IntPtr(value2);
		num = (843012718U & num);
		intPtr2 = intPtr3;
		void* ptr2 = intPtr2.ToPointer();
		num = (1855805939U | num);
		467F5DB3.6B576539 6B6 = 6B5;
		num = 1693609162U - num;
		Type type2 = 6B6.62D13369();
		num >>= 21;
		object 36FA1F2 = Pointer.Box(ptr2, type2);
		Type 53375D = 6B5.62D13369();
		num |= 2092910942U;
		return new 467F5DB3.6B576539(36FA1F2, 53375D);
		Block_57:
		throw new InvalidOperationException();
	}

	// Token: 0x0600023B RID: 571 RVA: 0x00301EC0 File Offset: 0x002FFAC0
	private unsafe 467F5DB3.37FA30B9 510E58E5(467F5DB3.37FA30B9 57ED4726, 467F5DB3.37FA30B9 294D2B96, bool 41EF20FB, bool 707F032B)
	{
		uint num;
		TypeCode typeCode2;
		467F5DB3.6B576539 6B2;
		IntPtr intPtr2;
		float num26;
		float num27;
		double num29;
		double num31;
		uint num32;
		uint num34;
		long 0E0B;
		int num59;
		for (;;)
		{
			IL_00:
			num = 1437162911U;
			TypeCode typeCode = this.32704198(57ED4726, 294D2B96);
			num -= 551367640U;
			typeCode2 = typeCode;
			if (1173696131U > num)
			{
				uint num4;
				uint num6;
				for (;;)
				{
					uint num2 = (uint)typeCode2;
					num = 300829185U - num;
					uint num3 = num2 - (num - 3710001201U);
					num <<= 1;
					switch (num3)
					{
					case 0:
						goto IL_68;
					case 1:
						num = 1334278522U % num;
						if (707F032B)
						{
							num = (697640591U & num);
							num4 = 57ED4726.437B0320();
							num -= 774975369U;
							if (num <= 127545526U)
							{
								continue;
							}
							num += 1854764158U;
							uint num5 = 294D2B96.437B0320();
							num = (13260677U | num);
							num6 = num5;
							num &= 1262447274U;
							if (!41EF20FB)
							{
								goto Block_37;
							}
							num |= 954673422U;
							if (num >= 1098413325U)
							{
								goto Block_39;
							}
							goto IL_68;
						}
						else
						{
							if ((393499845U & num) != 0U)
							{
								goto Block_40;
							}
							continue;
						}
						break;
					case 2:
					{
						num = 1868247751U * num;
						if (707F032B)
						{
							goto Block_9;
						}
						num = 201942310U - num;
						num %= 126360066U;
						long num7 = 57ED4726.E1698415();
						num = 1845262637U * num;
						if (num <= 924200053U)
						{
							goto IL_00;
						}
						num |= 233861686U;
						long num8 = 294D2B96.E1698415();
						num = (1350578401U ^ num);
						if (317207183U >> (int)num != 0U)
						{
							goto Block_12;
						}
						continue;
					}
					case 3:
					{
						num = 2020433335U + num;
						if (254304118U >= num)
						{
							continue;
						}
						num = 1167397625U << (int)num;
						long num17;
						if (707F032B)
						{
							num = (485039016U ^ num);
							num >>= 2;
							ulong num9 = 57ED4726.67922FD7();
							num &= 779961797U;
							ulong num10 = num9;
							if (302258364U > num)
							{
								goto IL_00;
							}
							num = 1014628600U + num;
							ulong num11 = 294D2B96.67922FD7();
							num %= 1245658164U;
							ulong num12 = num11;
							num = 1200955460U + num;
							num <<= 13;
							long num15;
							if (!41EF20FB)
							{
								num >>= 8;
								if ((num ^ 1114384737U) == 0U)
								{
									goto IL_9B;
								}
								long num13 = (long)num10;
								num = 337135506U << (int)num;
								long num14 = (long)num12;
								num = (1073414452U ^ num);
								num15 = num13 - num14;
							}
							else
							{
								num |= 499988355U;
								long num16 = (long)num10;
								num %= 668801007U;
								num15 = checked(num16 - (long)num12);
								num += 92100336U;
							}
							num17 = num15;
							if (68110185U > num)
							{
								continue;
							}
						}
						else
						{
							num = (1972982065U ^ num);
							if (1581588443U == num)
							{
								goto IL_00;
							}
							long num18 = 57ED4726.E1698415();
							long num19 = 294D2B96.E1698415();
							num = 1057296862U * num;
							long num20 = num19;
							num = 1385512060U * num;
							long num23;
							if (!41EF20FB)
							{
								num = (506411683U | num);
								long num21 = num18;
								long num22 = num20;
								num = (929131059U ^ num);
								num23 = num21 - num22;
							}
							else
							{
								num -= 239412116U;
								long num24 = num18;
								num = 446917310U - num;
								long num25 = num20;
								num /= 1738963165U;
								num23 = checked(num24 - num25);
								num += 2841547159U;
							}
							num17 = num23;
							num += 2189735182U;
						}
						num = 1026097973U - num;
						if (num * 217720911U == 0U)
						{
							goto IL_00;
						}
						num -= 1199389561U;
						467F5DB3.6B576539 6B;
						if (57ED4726.02557F0D() != typeCode2)
						{
							6B = (467F5DB3.6B576539)294D2B96;
						}
						else
						{
							num = 1119108782U << (int)num;
							if ((1279087991U & num) == 0U)
							{
								continue;
							}
							num -= 745627593U;
							6B = (467F5DB3.6B576539)57ED4726;
							num ^= 3066437921U;
						}
						6B2 = 6B;
						num = 989096621U / num;
						long value = num17;
						num += 1357061971U;
						IntPtr intPtr = new IntPtr(value);
						num = (731785527U & num);
						intPtr2 = intPtr;
						num = (899093383U & num);
						if ((996484143U ^ num) != 0U)
						{
							goto Block_57;
						}
						continue;
					}
					case 4:
					{
						num /= 255154691U;
						if (num << 20 == 0U)
						{
							continue;
						}
						467F5DB3.37FA30B9 37FA30B;
						if (!707F032B)
						{
							num -= 384915709U;
							37FA30B = 57ED4726;
						}
						else
						{
							num = 1790252831U * num;
							if (num % 1812799529U == 0U)
							{
								break;
							}
							37FA30B = 57ED4726.374AB499();
							num ^= 3916673659U;
						}
						num *= 2015240864U;
						num26 = 37FA30B.8E4073FD();
						467F5DB3.37FA30B9 37FA30B2;
						if (!707F032B)
						{
							if (num == 190333286U)
							{
								goto IL_00;
							}
							37FA30B2 = 294D2B96;
						}
						else
						{
							num %= 806358233U;
							37FA30B2 = 294D2B96.374AB499();
							num += 806358233U;
						}
						num ^= 473831596U;
						num27 = 37FA30B2.8E4073FD();
						if (1525028211U < num)
						{
							goto IL_68;
						}
						num &= 996499174U;
						if (41EF20FB)
						{
							goto IL_490;
						}
						if ((num & 1112109304U) != 0U)
						{
							goto Block_24;
						}
						goto IL_68;
					}
					case 5:
					{
						num = (1573327994U | num);
						num |= 588392719U;
						467F5DB3.37FA30B9 37FA30B3;
						if (!707F032B)
						{
							37FA30B3 = 57ED4726;
						}
						else
						{
							if (num == 382862147U)
							{
								goto IL_68;
							}
							37FA30B3 = 57ED4726.374AB499();
							num += 0U;
						}
						double num28 = 37FA30B3.B7D5DC99();
						num = 1034970586U + num;
						num29 = num28;
						if (num >= 1243292449U)
						{
							continue;
						}
						467F5DB3.37FA30B9 37FA30B4;
						if (!707F032B)
						{
							num *= 603018595U;
							37FA30B4 = 294D2B96;
						}
						else
						{
							if (1367424097U < num)
							{
								goto IL_00;
							}
							37FA30B4 = 294D2B96.374AB499();
							num ^= 643144498U;
						}
						double num30 = 37FA30B4.B7D5DC99();
						num %= 1494508025U;
						num31 = num30;
						num = (498685635U & num);
						if (1368675984U <= num)
						{
							goto IL_00;
						}
						if (!41EF20FB)
						{
							goto Block_32;
						}
						if (1487418045U != num)
						{
							goto Block_34;
						}
						continue;
					}
					}
					goto IL_63;
					IL_9B:
					num32 = 57ED4726.437B0320();
					if (num > 1058960275U)
					{
						break;
					}
					continue;
					IL_68:
					num ^= 1652646817U;
					if (num == 521818332U)
					{
						goto IL_63;
					}
					num ^= 119750240U;
					if (!707F032B)
					{
						goto IL_141;
					}
					if (num >= 54414387U)
					{
						goto IL_9B;
					}
					goto IL_00;
				}
				num = (1526955859U | num);
				uint num33 = 294D2B96.437B0320();
				num = 645806204U % num;
				num34 = num33;
				if (1463684532U == num)
				{
					continue;
				}
				num = 213285245U % num;
				if (!41EF20FB)
				{
					goto Block_4;
				}
				num = 1470916455U * num;
				if (num != 335376577U)
				{
					goto Block_5;
				}
				continue;
				IL_141:
				num = 1702569098U / num;
				if (92366534U <= num)
				{
					continue;
				}
				int num35 = 57ED4726.D6BFBC24();
				num = 606692195U >> (int)num;
				int num36 = num35;
				num >>= 22;
				if (num <= 1622355315U)
				{
					goto Block_7;
				}
				continue;
				Block_12:
				num *= 321481091U;
				long num39;
				if (!41EF20FB)
				{
					if (1169303818U > num)
					{
						break;
					}
					long num7;
					long num37 = num7;
					num <<= 31;
					long num8;
					long num38 = num8;
					num = 2086627523U / num;
					num39 = num37 - num38;
				}
				else
				{
					num <<= 25;
					if (354843989U <= num)
					{
						continue;
					}
					long num7;
					long num40 = num7;
					long num8;
					long num41 = num8;
					num = (560543016U ^ num);
					num39 = checked(num40 - num41);
					num += 3566652120U;
				}
				num |= 1699494864U;
				0E0B = num39;
				num += 2163593328U;
				IL_37C:
				num = 834152141U + num;
				if (1063535449U % num != 0U)
				{
					goto Block_16;
				}
				continue;
				Block_9:
				num = (1776764100U & num);
				ulong num42 = 57ED4726.67922FD7();
				ulong num43 = 294D2B96.67922FD7();
				num <<= 18;
				long num46;
				if (!41EF20FB)
				{
					num >>= 30;
					long num44 = (long)num42;
					num = (887192102U | num);
					long num45 = (long)num43;
					num = 2073626673U << (int)num;
					num46 = num44 - num45;
				}
				else
				{
					long num47 = (long)num42;
					num = (1431398659U ^ num);
					long num48 = (long)num43;
					num >>= 11;
					num46 = checked(num47 - num48);
					num += 3862389779U;
				}
				0E0B = num46;
				goto IL_37C;
				IL_490:
				if (num >> 1 != 0U)
				{
					goto Block_25;
				}
				continue;
				Block_32:
				if (1318274091U >= num)
				{
					goto Block_33;
				}
				continue;
				Block_37:
				num = 1275023691U % num;
				int num51;
				if (1759652482U > num)
				{
					int num49 = (int)num4;
					num %= 518551851U;
					int num50 = (int)num6;
					num %= 511990047U;
					num51 = num49 - num50;
					goto IL_677;
				}
				continue;
				Block_40:
				num >>= 28;
				int num52 = 57ED4726.D6BFBC24();
				num = (668499754U & num);
				int num53 = 294D2B96.D6BFBC24();
				num += 1684688399U;
				int num56;
				if (!41EF20FB)
				{
					num = (1190028328U & num);
					int num54 = num52;
					num = 2116638578U / num;
					int num55 = num53;
					num = (1622305954U & num);
					num56 = num54 - num55;
				}
				else
				{
					num |= 335114978U;
					if (num <= 418907779U)
					{
						continue;
					}
					int num57 = num52;
					num = 1311127207U << (int)num;
					int num58 = num53;
					num %= 258757617U;
					num56 = checked(num57 - num58);
					num += 4095267825U;
				}
				num59 = num56;
				num += 1148312012U;
				IL_73C:
				num ^= 186404382U;
				if (2013940281U > num)
				{
					goto Block_43;
				}
				continue;
				IL_677:
				num ^= 1185036141U;
				num59 = num51;
				goto IL_73C;
				Block_39:
				num51 = (int)(checked(num4 - num6));
				num += 2296677107U;
				goto IL_677;
			}
			break;
		}
		IL_63:
		num = 692453753U - num;
		throw new InvalidOperationException();
		Block_4:
		int num60 = (int)num32;
		num ^= 1094548260U;
		int num61 = num60 - (int)num34;
		goto IL_13A;
		Block_5:
		int num62 = (int)num32;
		num = 2001893494U >> (int)num;
		int num63 = (int)num34;
		num = 871713955U + num;
		num61 = checked(num62 - num63);
		num ^= 2039428267U;
		IL_13A:
		int 0A = num61;
		goto IL_1FA;
		Block_7:
		num = 56637417U - num;
		int num64 = 294D2B96.D6BFBC24();
		num >>= 0;
		int num65 = num64;
		num -= 986021276U;
		int num66;
		if (!41EF20FB)
		{
			int num36;
			num66 = num36 - num65;
		}
		else
		{
			num = 1038301813U << (int)num;
			int num36;
			int num67 = num36;
			int num68 = num65;
			num = (925174154U & num);
			num66 = checked(num67 - num68);
			num ^= 3902454205U;
		}
		num %= 1928351116U;
		0A = num66;
		num += 4158690856U;
		IL_1FA:
		num = 2079484655U % num;
		return new 467F5DB3.1C0911B0(0A);
		Block_16:
		return new 467F5DB3.06E010E5(0E0B);
		Block_24:
		float num69 = num26;
		num = 1532982711U >> (int)num;
		float num70 = num27;
		num /= 1787191687U;
		float 7D = num69 - num70;
		goto IL_4AB;
		Block_25:
		7D = num26 - num27;
		num += 3571163452U;
		IL_4AB:
		return new 467F5DB3.3D312057(7D);
		Block_33:
		double num71 = num29;
		num = 696667708U >> (int)num;
		double 7E9E = num71 - num31;
		goto IL_5B3;
		Block_34:
		double num72 = num29;
		num = (999693279U ^ num);
		7E9E = num72 - num31;
		num += 3811212843U;
		IL_5B3:
		return new 467F5DB3.07A85735(7E9E);
		Block_43:
		TypeCode typeCode3 = 57ED4726.02557F0D();
		num >>= 28;
		TypeCode typeCode4 = typeCode2;
		num = 516652641U * num;
		467F5DB3.6B576539 6B3;
		if (typeCode3 != typeCode4)
		{
			num >>= 3;
			if (255461762U >= num)
			{
				goto IL_63;
			}
			6B3 = (467F5DB3.6B576539)294D2B96;
		}
		else
		{
			num = 531504063U / num;
			6B3 = (467F5DB3.6B576539)57ED4726;
			num ^= 258326320U;
		}
		num = (1137706442U ^ num);
		467F5DB3.6B576539 6B4 = 6B3;
		int value2 = num59;
		num = 63443415U * num;
		void* ptr = new IntPtr(value2).ToPointer();
		num = 225005376U - num;
		object 36FA1F = Pointer.Box(ptr, 6B4.62D13369());
		467F5DB3.6B576539 6B5 = 6B4;
		num += 1459696660U;
		return new 467F5DB3.6B576539(36FA1F, 6B5.62D13369());
		Block_57:
		num -= 885012886U;
		void* ptr2 = intPtr2.ToPointer();
		num <<= 18;
		Type type = 6B2.62D13369();
		num |= 824267839U;
		object 36FA1F2 = Pointer.Box(ptr2, type);
		num = 811564895U % num;
		467F5DB3.6B576539 6B6 = 6B2;
		num *= 1109555508U;
		Type 53375D = 6B6.62D13369();
		num *= 2027690219U;
		return new 467F5DB3.6B576539(36FA1F2, 53375D);
	}

	// Token: 0x0600023C RID: 572 RVA: 0x00302984 File Offset: 0x00300584
	private 467F5DB3.37FA30B9 4B295531(467F5DB3.37FA30B9 31EF71FB, 467F5DB3.37FA30B9 0AC13BDD, bool 63B27266, bool 4CA52003)
	{
		uint num = 1959596079U;
		long 0E0B;
		float num15;
		float num17;
		double num19;
		double num20;
		int 0A;
		int num29;
		int num31;
		for (;;)
		{
			IL_07:
			num *= 833686810U;
			num = 1728258267U * num;
			TypeCode typeCode = this.32704198(31EF71FB, 0AC13BDD);
			num <<= 12;
			for (;;)
			{
				TypeCode typeCode2 = typeCode;
				num = 1118846480U - num;
				uint num2 = num ^ 3158973977U;
				num <<= 30;
				switch (typeCode2 - num2)
				{
				case 0:
					goto IL_7A;
				case 1:
				case 3:
					IL_5A4:
					num /= 1550869459U;
					if (1218388163U >= num)
					{
						goto Block_35;
					}
					continue;
				case 2:
					num -= 1154435716U;
					if (841488990U >= num)
					{
						continue;
					}
					if (4CA52003)
					{
						if (num < 1995336455U)
						{
							goto IL_07;
						}
						ulong num3 = 31EF71FB.67922FD7();
						num = (850461269U & num);
						ulong num4 = num3;
						if (num - 1536910467U == 0U)
						{
							goto IL_07;
						}
						num = 1320227924U + num;
						ulong num5 = 0AC13BDD.67922FD7();
						num /= 34936075U;
						ulong num6 = num5;
						num /= 1966350788U;
						long num9;
						if (!63B27266)
						{
							if (189732784U == num)
							{
								goto IL_07;
							}
							long num7 = (long)num4;
							num += 1285576795U;
							long num8 = (long)num6;
							num /= 1349143546U;
							num9 = num7 * num8;
						}
						else
						{
							if (411126411U == num)
							{
								continue;
							}
							num9 = (long)(checked(num4 * num6));
							num ^= 0U;
						}
						0E0B = num9;
						if (num + 1219448033U == 0U)
						{
							goto IL_75;
						}
					}
					else
					{
						long num10 = 31EF71FB.E1698415();
						num *= 701715352U;
						if (num == 1495350900U)
						{
							goto IL_7A;
						}
						long num11 = 0AC13BDD.E1698415();
						num |= 5723334U;
						long num13;
						if (!63B27266)
						{
							long num12 = num10;
							num = 229377586U >> (int)num;
							num13 = num12 * num11;
						}
						else
						{
							num <<= 12;
							if (19283871U == num)
							{
								continue;
							}
							long num14 = num10;
							num = 1195784927U - num;
							num13 = checked(num14 * num11);
							num ^= 3352390343U;
						}
						num %= 554122178U;
						0E0B = num13;
						num ^= 3584024U;
					}
					if (num << 14 == 0U)
					{
						goto Block_19;
					}
					goto IL_A9;
				case 4:
				{
					467F5DB3.37FA30B9 37FA30B;
					if (!4CA52003)
					{
						num = 1180203552U << (int)num;
						if (num >= 1368002656U)
						{
							goto IL_07;
						}
						37FA30B = 31EF71FB;
					}
					else
					{
						num = 870704U * num;
						num <<= 28;
						37FA30B = 31EF71FB.374AB499();
						num += 1180203552U;
					}
					num &= 814228326U;
					num15 = 37FA30B.8E4073FD();
					num ^= 427167473U;
					if (num >= 1954551791U)
					{
						goto IL_07;
					}
					467F5DB3.37FA30B9 37FA30B2;
					if (!4CA52003)
					{
						37FA30B2 = 0AC13BDD;
					}
					else
					{
						num = 478498968U % num;
						37FA30B2 = 0AC13BDD.374AB499();
						num ^= 444141334U;
					}
					float num16 = 37FA30B2.8E4073FD();
					num >>= 29;
					num17 = num16;
					num = (1953241466U | num);
					if (num << 6 == 0U)
					{
						goto IL_07;
					}
					num = (109926477U | num);
					if (!63B27266)
					{
						goto Block_25;
					}
					num = (1863404295U ^ num);
					if (569534767U >= num)
					{
						goto Block_27;
					}
					break;
				}
				case 5:
				{
					if (num - 389835072U == 0U)
					{
						goto IL_07;
					}
					num += 1696087876U;
					467F5DB3.37FA30B9 37FA30B3;
					if (!4CA52003)
					{
						37FA30B3 = 31EF71FB;
					}
					else
					{
						num = 1237088191U >> (int)num;
						num = 1151027576U << (int)num;
						37FA30B3 = 31EF71FB.374AB499();
						num += 2769829700U;
					}
					num = (1354917919U & num);
					double num18 = 37FA30B3.B7D5DC99();
					num *= 774057661U;
					num19 = num18;
					467F5DB3.37FA30B9 37FA30B4;
					if (!4CA52003)
					{
						37FA30B4 = 0AC13BDD;
					}
					else
					{
						num -= 304875501U;
						num -= 1548123846U;
						37FA30B4 = 0AC13BDD.374AB499();
						num += 1852999347U;
					}
					num20 = 37FA30B4.B7D5DC99();
					if (584273765U != num)
					{
						goto Block_31;
					}
					continue;
				}
				default:
					num += 0U;
					goto IL_75;
				}
				IL_C5:
				num = 1752041306U * num;
				uint num21 = 0AC13BDD.437B0320();
				num = 909533660U / num;
				uint num22 = num21;
				num = 1426594068U - num;
				num *= 1636855677U;
				uint num24;
				int num26;
				if (!63B27266)
				{
					num >>= 25;
					int num23 = (int)num24;
					num = 74852809U >> (int)num;
					int num25 = (int)num22;
					num /= 1068589078U;
					num26 = num23 * num25;
				}
				else
				{
					num26 = (int)(checked(num24 * num22));
					num += 1223431484U;
				}
				num /= 373908207U;
				0A = num26;
				if (468336466U + num != 0U)
				{
					goto Block_5;
				}
				continue;
				IL_A9:
				num |= 901594101U;
				uint num27 = 31EF71FB.437B0320();
				num /= 524965992U;
				num24 = num27;
				goto IL_C5;
				IL_7A:
				if (num >= 348659268U)
				{
					goto IL_07;
				}
				num = 1390419596U << (int)num;
				if (4CA52003)
				{
					if (840893605U < num)
					{
						goto IL_A9;
					}
					goto IL_07;
				}
				else
				{
					num += 797266095U;
					int num28 = 31EF71FB.D6BFBC24();
					num = (1884450950U & num);
					num29 = num28;
					num >>= 3;
					int num30 = 0AC13BDD.D6BFBC24();
					num -= 1849230928U;
					num31 = num30;
					num = 1353147672U + num;
					num %= 1504335810U;
					if (63B27266)
					{
						goto IL_1D2;
					}
					num |= 1381256606U;
					if (num >= 1005470403U)
					{
						goto Block_7;
					}
					continue;
				}
				IL_75:
				goto IL_5A4;
			}
			Block_25:
			if ((1028618104U ^ num) != 0U)
			{
				goto Block_26;
			}
			continue;
			Block_31:
			if (!63B27266)
			{
				if (num * 1300245547U != 0U)
				{
					goto Block_33;
				}
			}
			else
			{
				num = 2100197343U * num;
				if ((num & 1997563929U) != 0U)
				{
					goto Block_34;
				}
			}
		}
		Block_5:
		goto IL_201;
		Block_7:
		int num32 = num29;
		num &= 70075249U;
		int num33 = num32 * num31;
		goto IL_1EB;
		IL_1D2:
		int num34 = num29;
		num = (232597971U ^ num);
		num33 = checked(num34 * num31);
		num ^= 651809223U;
		IL_1EB:
		num ^= 1526233518U;
		0A = num33;
		num ^= 1591556862U;
		IL_201:
		return new 467F5DB3.1C0911B0(0A);
		Block_19:
		return new 467F5DB3.06E010E5(0E0B);
		Block_26:
		double num35 = (double)num15;
		num = 1705587016U % num;
		double num36 = num35 * (double)num17;
		goto IL_490;
		Block_27:
		num36 = (double)(num15 * num17);
		num += 1269636816U;
		IL_490:
		return new 467F5DB3.07A85735(num36);
		Block_33:
		double num37 = num19;
		num &= 2098823144U;
		double 7E9E = num37 * num20;
		goto IL_594;
		Block_34:
		7E9E = num19 * num20;
		num += 1828750420U;
		IL_594:
		num = (981869712U & num);
		return new 467F5DB3.07A85735(7E9E);
		Block_35:
		throw new InvalidOperationException();
	}

	// Token: 0x0600023D RID: 573 RVA: 0x00302F50 File Offset: 0x00300B50
	private 467F5DB3.37FA30B9 5A115239(467F5DB3.37FA30B9 6002106F, 467F5DB3.37FA30B9 11DD699E, bool 51AE0138)
	{
		uint num;
		int num6;
		long 0E0B;
		for (;;)
		{
			IL_00:
			num = 1833449185U;
			TypeCode typeCode = this.32704198(6002106F, 11DD699E);
			num -= 1897662030U;
			TypeCode typeCode2 = typeCode;
			for (;;)
			{
				int num2 = typeCode2 - (TypeCode)(num ^ 4230754458U);
				num |= 73162943U;
				switch (num2)
				{
				case 0:
					goto IL_5D;
				case 1:
				case 3:
					IL_315:
					num += 993797781U;
					if (num != 813574407U)
					{
						goto Block_16;
					}
					continue;
				case 2:
					goto IL_11F;
				case 4:
					num &= 1980439886U;
					if (!51AE0138)
					{
						goto Block_9;
					}
					if ((467210295U & num) != 0U)
					{
						goto Block_10;
					}
					break;
				case 5:
					goto IL_27C;
				default:
					if (1720603977U > num)
					{
						goto IL_00;
					}
					num += 0U;
					break;
				}
				goto IL_315;
			}
			IL_FC:
			num /= 738617843U;
			if (num <= 141897469U)
			{
				break;
			}
			continue;
			IL_5D:
			num = (1647324184U & num);
			num = 513354608U / num;
			if (51AE0138)
			{
				num /= 1545825261U;
				goto IL_7B;
			}
			num = (238096862U ^ num);
			int num3 = 6002106F.D6BFBC24();
			num = 485645857U / num;
			num = (1038708312U ^ num);
			int num4 = 11DD699E.D6BFBC24();
			num ^= 798361794U;
			int num5 = num3 / num4;
			num |= 1224703134U;
			num6 = num5;
			num += 2699854174U;
			IL_B6:
			goto IL_FC;
			IL_7B:
			num *= 2145875133U;
			int num7 = (int)6002106F.437B0320();
			num *= 384132449U;
			num = (142761519U | num);
			uint num8 = 11DD699E.437B0320();
			num -= 517365971U;
			int num9 = num7 / (int)num8;
			num = (1514372092U | num);
			num6 = num9;
			goto IL_B6;
			IL_11F:
			num += 1026302575U;
			if (1667312655U < num)
			{
				continue;
			}
			if (51AE0138)
			{
				if (154238608U + num == 0U)
				{
					goto IL_7B;
				}
				num /= 1134913946U;
				long num10 = (long)6002106F.67922FD7();
				ulong num11 = 11DD699E.67922FD7();
				num |= 2320567U;
				ulong num12 = num11;
				num = 441459305U >> (int)num;
				long num13 = (long)num12;
				num = 317330998U / num;
				0E0B = num10 / num13;
				if ((num ^ 1654859900U) != 0U)
				{
					goto Block_7;
				}
				continue;
			}
			else
			{
				num = 1537107819U - num;
				if (748762984U > num)
				{
					goto Block_8;
				}
				goto IL_B6;
			}
			IL_27C:
			num = 1010793988U - num;
			if (!51AE0138)
			{
				if ((num ^ 806951389U) != 0U)
				{
					goto Block_13;
				}
			}
			else
			{
				num ^= 1159464294U;
				if (1324032976U * num != 0U)
				{
					goto Block_14;
				}
			}
		}
		int 0A = num6;
		num |= 418082788U;
		return new 467F5DB3.1C0911B0(0A);
		Block_7:
		goto IL_1D2;
		Block_8:
		num += 84369893U;
		long num14 = 6002106F.E1698415();
		long num15 = 11DD699E.E1698415();
		num %= 296296409U;
		long num16 = num15;
		long num17 = num14 / num16;
		num >>= 22;
		0E0B = num17;
		num ^= 6102521U;
		IL_1D2:
		return new 467F5DB3.06E010E5(0E0B);
		Block_9:
		num >>= 24;
		467F5DB3.37FA30B9 37FA30B = 6002106F;
		goto IL_20F;
		Block_10:
		37FA30B = 6002106F.374AB499();
		num ^= 1946685562U;
		IL_20F:
		num ^= 1792353108U;
		float num18 = 37FA30B.8E4073FD();
		num %= 505614068U;
		num <<= 19;
		467F5DB3.37FA30B9 37FA30B2;
		if (!51AE0138)
		{
			37FA30B2 = 11DD699E;
		}
		else
		{
			num = 1697320122U - num;
			37FA30B2 = 11DD699E.374AB499();
			num += 4279563078U;
		}
		num &= 883246902U;
		float num19 = 37FA30B2.8E4073FD();
		num |= 1232762444U;
		float 7D = num18 / num19;
		num = 718221464U >> (int)num;
		return new 467F5DB3.3D312057(7D);
		Block_13:
		467F5DB3.37FA30B9 37FA30B3 = 6002106F;
		goto IL_2BE;
		Block_14:
		37FA30B3 = 6002106F.374AB499();
		num ^= 1159464294U;
		IL_2BE:
		num = 895105012U - num;
		double num20 = 37FA30B3.B7D5DC99();
		467F5DB3.37FA30B9 37FA30B4;
		if (!51AE0138)
		{
			num += 1592799195U;
			37FA30B4 = 11DD699E;
		}
		else
		{
			num >>= 19;
			37FA30B4 = 11DD699E.374AB499();
			num += 1418148824U;
		}
		num <<= 22;
		double num21 = 37FA30B4.B7D5DC99();
		num |= 272715162U;
		return new 467F5DB3.07A85735(num20 / num21);
		Block_16:
		throw new InvalidOperationException();
	}

	// Token: 0x0600023E RID: 574 RVA: 0x0030328C File Offset: 0x00300E8C
	private 467F5DB3.37FA30B9 465A415C(467F5DB3.37FA30B9 5A597AE8, 467F5DB3.37FA30B9 2BD35DFD, bool 42B00530)
	{
		uint num;
		for (;;)
		{
			num = 1964447175U;
			TypeCode typeCode = 5A597AE8.02557F0D();
			num /= 1680218880U;
			TypeCode typeCode2 = typeCode;
			num /= 550513698U;
			uint num2 = (uint)typeCode2;
			num = (623055228U ^ num);
			if (num2 != num - 623055219U)
			{
				if ((897344753U & num) == 0U)
				{
					continue;
				}
			}
			else
			{
				num %= 1010378629U;
				num *= 1450731455U;
				if (!42B00530)
				{
					goto IL_B9;
				}
				if (num > 1542391156U)
				{
					goto IL_8A;
				}
			}
			uint num3 = (uint)typeCode2;
			num >>= 22;
			if (num3 != (num ^ 159U))
			{
				break;
			}
			if (num * 1576740635U != 0U)
			{
				goto Block_3;
			}
		}
		throw new InvalidOperationException();
		IL_8A:
		int num4 = (int)5A597AE8.437B0320();
		num /= 103773865U;
		uint num5 = 2BD35DFD.437B0320();
		num = 1575301283U >> (int)num;
		uint num6 = num5;
		return new 467F5DB3.1C0911B0(num4 % (int)num6);
		IL_B9:
		num <<= 13;
		int num7 = 5A597AE8.D6BFBC24();
		int num8 = 2BD35DFD.D6BFBC24();
		num %= 49303454U;
		return new 467F5DB3.1C0911B0(num7 % num8);
		Block_3:
		if (42B00530)
		{
			num >>= 3;
			long num9 = (long)5A597AE8.67922FD7();
			num -= 980234101U;
			ulong num10 = 2BD35DFD.67922FD7();
			num ^= 1912895875U;
			ulong num11 = num10;
			num >>= 17;
			long num12 = (long)num11;
			num &= 733377752U;
			return new 467F5DB3.06E010E5(num9 % num12);
		}
		num = 79323018U * num;
		if ((2147355245U ^ num) != 0U)
		{
			long num13 = 5A597AE8.E1698415();
			num &= 980569823U;
			long num14 = 2BD35DFD.E1698415();
			num <<= 5;
			long num15 = num14;
			long num16 = num15;
			num = (233718087U & num);
			long 0E0B = num13 % num16;
			num = (1076260181U & num);
			return new 467F5DB3.06E010E5(0E0B);
		}
		goto IL_8A;
	}

	// Token: 0x0600023F RID: 575 RVA: 0x00303430 File Offset: 0x00301030
	private 467F5DB3.37FA30B9 429B3EBB(467F5DB3.37FA30B9 055A2190, 467F5DB3.37FA30B9 5BC111E4)
	{
		uint num;
		for (;;)
		{
			TypeCode typeCode = this.32704198(055A2190, 5BC111E4);
			for (;;)
			{
				object obj = typeCode;
				num = 2036350386U;
				object obj2 = num - 2036350377U;
				num &= 1868706568U;
				object obj3 = obj - obj2;
				num ^= 1993566479U;
				switch (obj3)
				{
				case 0:
					goto IL_5D;
				case 1:
				case 3:
					goto IL_19A;
				case 2:
					goto IL_98;
				case 4:
					goto IL_D6;
				case 5:
					goto IL_13B;
				default:
					if (166151995U != num)
					{
						goto Block_1;
					}
					break;
				}
			}
			IL_98:
			if (1188061972U >= num)
			{
				goto Block_2;
			}
			continue;
			IL_D6:
			if (2002805583U > num)
			{
				int size = IntPtr.Size;
				num %= 1472997204U;
				uint num2 = num + 3763120117U;
				num = 139203182U - num;
				if (size == num2)
				{
					goto IL_120;
				}
				num <<= 12;
				if ((num & 1073630681U) != 0U)
				{
					goto Block_5;
				}
			}
		}
		Block_1:
		num += 0U;
		IL_58:
		goto IL_19A;
		IL_5D:
		num = 432894473U + num;
		int num3 = 055A2190.D6BFBC24();
		num >>= 17;
		int num4 = 5BC111E4.D6BFBC24();
		num = 62327592U * num;
		int num5 = num4;
		num = 1490299450U >> (int)num;
		return new 467F5DB3.1C0911B0(num3 ^ num5);
		Block_2:
		long num6 = 055A2190.E1698415();
		num = 525951683U >> (int)num;
		long num7 = 5BC111E4.E1698415();
		long num8 = num7;
		num %= 1864528226U;
		long 0E0B = num6 ^ num8;
		num = 201670564U + num;
		return new 467F5DB3.06E010E5(0E0B);
		Block_5:
		float 7D = 0f;
		goto IL_135;
		IL_120:
		num |= 1664644884U;
		7D = float.NaN;
		num += 2683105441U;
		IL_135:
		return new 467F5DB3.3D312057(7D);
		IL_13B:
		uint size2 = (uint)IntPtr.Size;
		num = 737418145U >> (int)num;
		double 7E9E;
		if (size2 != num + 4294944796U)
		{
			num = 599668503U - num;
			if (num > 968297987U)
			{
				goto IL_58;
			}
			7E9E = 0.0;
		}
		else
		{
			7E9E = double.NaN;
			num ^= 599623879U;
		}
		num <<= 22;
		return new 467F5DB3.07A85735(7E9E);
		IL_19A:
		num &= 1376001152U;
		if (num >> 15 != 0U)
		{
			throw new InvalidOperationException();
		}
		goto IL_58;
	}

	// Token: 0x06000240 RID: 576 RVA: 0x003035F0 File Offset: 0x003011F0
	private 467F5DB3.37FA30B9 06B105FE(467F5DB3.37FA30B9 4DC21A05, 467F5DB3.37FA30B9 259A21F0)
	{
		uint num;
		for (;;)
		{
			num = 198462428U;
			num = (812327214U | num);
			TypeCode typeCode = this.32704198(4DC21A05, 259A21F0);
			num &= 826149625U;
			if (num >= 822222205U)
			{
				for (;;)
				{
					int num2 = typeCode - (TypeCode)(num - 826149615U);
					num = (1141786435U ^ num);
					switch (num2)
					{
					case 0:
						goto IL_65;
					case 1:
					case 3:
						goto IL_1BD;
					case 2:
						goto IL_BC;
					case 4:
						num <<= 0;
						if (num >= 1205678089U)
						{
							goto Block_2;
						}
						continue;
					case 5:
					{
						num >>= 5;
						int size = IntPtr.Size;
						uint num3 = num ^ 61440617U;
						num &= 1026495646U;
						if (size != num3)
						{
							goto Block_4;
						}
						if (1717526430U != num)
						{
							goto Block_6;
						}
						continue;
					}
					}
					goto Block_0;
				}
				IL_65:
				num = 2134139405U << (int)num;
				if ((229331561U ^ num) != 0U)
				{
					break;
				}
				continue;
				Block_4:
				num = 1040271003U * num;
				if ((num & 320099002U) != 0U)
				{
					goto Block_5;
				}
				continue;
				Block_0:
				num += 0U;
			}
			IL_1BD:
			if (1150497411U + num != 0U)
			{
				goto Block_7;
			}
			continue;
			goto IL_1BD;
		}
		num -= 528759830U;
		int num4 = 4DC21A05.D6BFBC24();
		num = (1228760858U & num);
		int num5 = 259A21F0.D6BFBC24();
		num /= 1142635504U;
		int num6 = num5;
		int num7 = num6;
		num &= 1559300980U;
		int 0A = num4 | num7;
		num *= 436170839U;
		return new 467F5DB3.1C0911B0(0A);
		IL_BC:
		num <<= 9;
		num -= 101467756U;
		long num8 = 4DC21A05.E1698415();
		num = (1937144985U ^ num);
		long num9 = 259A21F0.E1698415();
		num = 318340023U * num;
		long num10 = num9;
		long 0E0B = num8 | num10;
		num = (1551965540U & num);
		return new 467F5DB3.06E010E5(0E0B);
		Block_2:
		uint size2 = (uint)IntPtr.Size;
		num |= 1131547061U;
		float 7D;
		if (size2 != (num ^ 2003979707U))
		{
			7D = 0f;
		}
		else
		{
			7D = float.NaN;
			num += 0U;
		}
		num = 2053531428U >> (int)num;
		return new 467F5DB3.3D312057(7D);
		Block_5:
		double 7E9E = 0.0;
		goto IL_1AF;
		Block_6:
		7E9E = double.NaN;
		num ^= 3502985032U;
		IL_1AF:
		num = 701172502U - num;
		return new 467F5DB3.07A85735(7E9E);
		Block_7:
		throw new InvalidOperationException();
	}

	// Token: 0x06000241 RID: 577 RVA: 0x003037CC File Offset: 0x003013CC
	private 467F5DB3.37FA30B9 1DF7021C(467F5DB3.37FA30B9 3F1F22AE, 467F5DB3.37FA30B9 31995746)
	{
		uint num = 2009017418U;
		for (;;)
		{
			IL_06:
			num = 332493696U % num;
			TypeCode typeCode = this.32704198(3F1F22AE, 31995746);
			num &= 649611451U;
			if (num % 990319496U != 0U)
			{
				for (;;)
				{
					object obj = typeCode;
					num /= 537817497U;
					object obj2 = num ^ 9U;
					num >>= 4;
					object obj3 = obj - obj2;
					num |= 1590316936U;
					switch (obj3)
					{
					case 0:
						goto IL_76;
					case 1:
					case 3:
						goto IL_18B;
					case 2:
						goto IL_B7;
					case 4:
						if (796735430U - num == 0U)
						{
							goto IL_06;
						}
						if (IntPtr.Size == (int)(num ^ 1590316940U))
						{
							goto IL_11F;
						}
						num <<= 13;
						if (num * 381371818U != 0U)
						{
							goto Block_4;
						}
						continue;
					case 5:
					{
						num &= 433073597U;
						uint size = (uint)IntPtr.Size;
						num >>= 28;
						if (size == num - 4294967293U)
						{
							goto IL_174;
						}
						num = 637082542U + num;
						if (num < 909978665U)
						{
							goto Block_6;
						}
						continue;
					}
					}
					break;
				}
				num ^= 0U;
			}
			IL_18B:
			num = 1359562854U - num;
			if (2069911092U < num)
			{
				goto Block_7;
			}
			continue;
			goto IL_18B;
		}
		IL_76:
		num >>= 26;
		int num2 = 3F1F22AE.D6BFBC24();
		num = 793387627U >> (int)num;
		num = 478823297U >> (int)num;
		int num3 = 31995746.D6BFBC24();
		num -= 1306864240U;
		return new 467F5DB3.1C0911B0(num2 & num3);
		IL_B7:
		long num4 = 3F1F22AE.E1698415();
		num -= 1890999731U;
		long num5 = 31995746.E1698415();
		num %= 1722103107U;
		long 0E0B = num4 & num5;
		num /= 1456030206U;
		return new 467F5DB3.06E010E5(0E0B);
		Block_4:
		float 7D = 0f;
		goto IL_12C;
		IL_11F:
		7D = float.NaN;
		num ^= 389762952U;
		IL_12C:
		return new 467F5DB3.3D312057(7D);
		Block_6:
		double 7E9E = 0.0;
		goto IL_185;
		IL_174:
		7E9E = double.NaN;
		num ^= 637082542U;
		IL_185:
		return new 467F5DB3.07A85735(7E9E);
		Block_7:
		throw new InvalidOperationException();
	}

	// Token: 0x06000242 RID: 578 RVA: 0x0030397C File Offset: 0x0030157C
	private int 486B7876(467F5DB3.37FA30B9 31633A4A, 467F5DB3.37FA30B9 2FD05CBE, bool 32DD4979, int 6BAE0021)
	{
		uint num2;
		for (;;)
		{
			IL_00:
			int num = 6BAE0021;
			num2 = 690581439U;
			for (;;)
			{
				IL_0B:
				TypeCode typeCode = 31633A4A.02557F0D();
				num2 -= 213394477U;
				TypeCode typeCode2 = typeCode;
				num2 -= 595919883U;
				object obj4;
				for (;;)
				{
					num2 -= 447373878U;
					TypeCode typeCode3 = 2FD05CBE.02557F0D();
					TypeCode typeCode4 = typeCode2;
					num2 /= 1920690817U;
					uint num3 = num2 ^ 0U;
					num2 ^= 1096754632U;
					if (typeCode4 == num3)
					{
						goto IL_8D;
					}
					num2 <<= 12;
					TypeCode typeCode5 = typeCode3;
					uint num4 = num2 ^ 4066152449U;
					num2 = 2066747930U << (int)num2;
					if (typeCode5 == num4)
					{
						num2 += 3324973999U;
						goto IL_8D;
					}
					num2 = 889155025U / num2;
					if (num2 + 571890035U == 0U)
					{
						goto IL_0B;
					}
					if (typeCode2 == (int)num2 + TypeCode.Double)
					{
						goto IL_17E;
					}
					uint num5 = (uint)typeCode3;
					num2 -= 677607882U;
					if (num5 == num2 - 3617359400U)
					{
						goto Block_10;
					}
					num2 ^= 209529895U;
					if (num2 * 1833588903U != 0U)
					{
						uint num6 = (uint)typeCode2;
						num2 -= 542194755U;
						if (num6 != (num2 ^ 3146804675U))
						{
							num2 ^= 1269309689U;
							TypeCode typeCode6 = typeCode3;
							num2 = 154827657U >> (int)num2;
							uint num7 = num2 - 5U;
							num2 = (443252159U ^ num2);
							if (typeCode6 == num7)
							{
								num2 ^= 2717585507U;
							}
							else
							{
								if (510343324U < num2)
								{
									goto IL_0B;
								}
								if (typeCode2 != (int)num2 + (TypeCode)(-443252130))
								{
									TypeCode typeCode7 = typeCode3;
									uint num8 = num2 ^ 443252134U;
									num2 = 1270896482U << (int)num2;
									if (typeCode7 == num8)
									{
										num2 ^= 277298605U;
									}
									else
									{
										num2 = 656999296U - num2;
										TypeCode typeCode8 = typeCode2;
										num2 = 1326855514U + num2;
										uint num9 = num2 + 2494367535U;
										num2 %= 1688757036U;
										if (typeCode8 != num9)
										{
											num2 = 1907376639U >> (int)num2;
											if (num2 == 1044198064U)
											{
												goto IL_8D;
											}
											TypeCode typeCode9 = typeCode3;
											num2 &= 1408853626U;
											uint num10 = num2 ^ 83529U;
											num2 += 661207155U;
											if (typeCode9 != num10)
											{
												break;
											}
											num2 += 3745519355U;
										}
										num2 ^= 1236491661U;
										if (1503549986U + num2 != 0U)
										{
											goto Block_28;
										}
										continue;
									}
								}
								if (num2 << 13 == 0U)
								{
									goto IL_0B;
								}
								if (!32DD4979)
								{
									goto Block_22;
								}
								if (920546935U > num2)
								{
									goto Block_23;
								}
								continue;
							}
						}
						if ((num2 ^ 397756223U) != 0U)
						{
							goto Block_15;
						}
						continue;
					}
					IL_A8:
					object obj = 2FD05CBE.6B58D7F4();
					num2 /= 714943955U;
					object obj2 = obj;
					num2 += 661290670U;
					if (num2 > 1494165155U)
					{
						goto IL_00;
					}
					object obj3 = obj4;
					object obj5 = obj2;
					num2 %= 1072594172U;
					if (obj3 == obj5)
					{
						goto Block_3;
					}
					if (308955282U >= num2)
					{
						continue;
					}
					if (obj2 == null)
					{
						goto Block_5;
					}
					if (num2 > 545467008U)
					{
						goto Block_6;
					}
					continue;
					IL_8D:
					num2 <<= 4;
					object obj6 = 31633A4A.6B58D7F4();
					num2 <<= 7;
					obj4 = obj6;
					goto IL_A8;
				}
				IL_4CB:
				num2 += 1953387804U;
				if ((num2 ^ 1878879458U) == 0U)
				{
					break;
				}
				int num11 = num;
				uint num12 = num2 ^ 2614678479U;
				num2 = (1734615235U ^ num2);
				if (num11 < num12)
				{
					num = (int)(num2 - 4240241421U);
				}
				else
				{
					int num13 = num;
					uint num14 = num2 ^ 4240241420U;
					num2 ^= 0U;
					if (num13 > num14)
					{
						num2 = 921056817U << (int)num2;
						int num15 = (int)(num2 ^ 1667436545U);
						num2 &= 1858672083U;
						num = num15;
						num2 += 2591810316U;
					}
				}
				if (num2 * 519459269U != 0U)
				{
					return num;
				}
				continue;
				Block_15:
				num2 = (52695827U | num2);
				float num16 = 31633A4A.8E4073FD();
				num2 |= 1728598182U;
				if (1414544303U * num2 == 0U)
				{
					break;
				}
				num2 = 1260217668U >> (int)num2;
				num2 %= 1956131485U;
				float value = 2FD05CBE.8E4073FD();
				num2 -= 1003250428U;
				int num17 = num16.CompareTo(value);
				num2 = (268197147U | num2);
				num = num17;
				if (num2 % 2075668041U != 0U)
				{
					num2 += 1466605972U;
					goto IL_4CB;
				}
				break;
				IL_17E:
				num2 >>= 15;
				if ((num2 & 750784709U) == 0U)
				{
					double num18 = 31633A4A.B7D5DC99();
					num2 = 228602902U << (int)num2;
					num2 >>= 13;
					double value2 = 2FD05CBE.B7D5DC99();
					num2 *= 14551991U;
					num = num18.CompareTo(value2);
					num2 ^= 2897250308U;
					goto IL_4CB;
				}
				break;
				Block_10:
				num2 ^= 3617359414U;
				goto IL_17E;
				Block_6:
				if (obj4 == null)
				{
					goto Block_7;
				}
				goto IL_4CB;
				IL_3BB:
				num2 += 1971198232U;
				int num19;
				num = num19;
				num2 ^= 575919098U;
				goto IL_4CB;
				Block_23:
				num2 = 1665221294U * num2;
				ulong num20 = 31633A4A.67922FD7();
				num2 %= 1489241833U;
				if (num2 != 646059958U)
				{
					num2 /= 740887438U;
					ulong value3 = 2FD05CBE.67922FD7();
					num2 >>= 23;
					num19 = num20.CompareTo(value3);
					num2 += 2411435057U;
					goto IL_3BB;
				}
				break;
				Block_22:
				long num21 = 31633A4A.E1698415();
				num2 |= 619390292U;
				long value4 = 2FD05CBE.E1698415();
				num2 += 1355814452U;
				num19 = num21.CompareTo(value4);
				goto IL_3BB;
				Block_28:
				int num23;
				if (!32DD4979)
				{
					int num22 = 31633A4A.D6BFBC24();
					num2 = 822877697U - num2;
					int value5 = 2FD05CBE.D6BFBC24();
					num2 += 2131241852U;
					num23 = num22.CompareTo(value5);
				}
				else
				{
					uint num24 = 31633A4A.437B0320();
					num2 = 1379485236U / num2;
					num23 = num24.CompareTo(2FD05CBE.437B0320());
					num2 ^= 1627029851U;
				}
				num = num23;
				num2 ^= 1200685033U;
				goto IL_4CB;
			}
		}
		Block_3:
		num2 = 818029047U * num2;
		return (int)(num2 + 2856627787U);
		Block_5:
		num2 = (2016823161U | num2);
		return (int)(num2 ^ 2138996730U);
		Block_7:
		return (int)(num2 + 3633676620U);
	}

	// Token: 0x06000243 RID: 579 RVA: 0x00303EEC File Offset: 0x00301AEC
	private 467F5DB3.37FA30B9 0DDB11CD(467F5DB3.37FA30B9 09FF2D73)
	{
		uint num = 1879116471U;
		if (1721127888 << (int)num != 0)
		{
			goto IL_18;
		}
		TypeCode typeCode;
		for (;;)
		{
			IL_27:
			uint num2 = (uint)typeCode;
			num <<= 24;
			if (num2 == num + 2332033033U)
			{
				goto IL_72;
			}
			if (1121549107 << (int)num != 0 && typeCode != (TypeCode)(num - 1962934261U))
			{
				if (699406629U >> (int)num != 0U)
				{
					break;
				}
			}
			else
			{
				num = 1245252448U << (int)num;
				if (num <= 1835286339U)
				{
					goto Block_6;
				}
			}
		}
		throw new InvalidOperationException();
		IL_72:
		if (num >= 643304112U)
		{
			int 0A = ~09FF2D73.D6BFBC24();
			num <<= 8;
			return new 467F5DB3.1C0911B0(0A);
		}
		goto IL_18;
		Block_6:
		return new 467F5DB3.06E010E5(~09FF2D73.E1698415());
		IL_18:
		TypeCode typeCode2 = 09FF2D73.02557F0D();
		num %= 130943511U;
		typeCode = typeCode2;
		goto IL_27;
	}

	// Token: 0x06000244 RID: 580 RVA: 0x00303FB8 File Offset: 0x00301BB8
	private 467F5DB3.37FA30B9 5B8857D3(467F5DB3.37FA30B9 7BDC3280)
	{
		uint num;
		for (;;)
		{
			num = 2081049264U;
			TypeCode typeCode = 7BDC3280.02557F0D();
			num ^= 703754148U;
			TypeCode typeCode2 = typeCode;
			num = 190121793U << (int)num;
			object obj = typeCode2;
			object obj2 = num - 1947205623U;
			num = 1352471763U * num;
			object obj3 = obj - obj2;
			num = (59328178U ^ num);
			switch (obj3)
			{
			case 0:
				goto IL_72;
			case 1:
			case 3:
				goto IL_EA;
			case 2:
				goto IL_87;
			case 4:
				num >>= 0;
				if (92105075U / num == 0U)
				{
					goto Block_2;
				}
				continue;
			case 5:
				goto IL_C5;
			}
			break;
		}
		if (1223255078U * num != 0U)
		{
			num += 0U;
			goto IL_EA;
		}
		goto IL_87;
		IL_72:
		int 0A = -7BDC3280.D6BFBC24();
		num = 288513492U % num;
		return new 467F5DB3.1C0911B0(0A);
		IL_87:
		return new 467F5DB3.06E010E5(-7BDC3280.E1698415());
		Block_2:
		num -= 1359291676U;
		float num2 = 7BDC3280.8E4073FD();
		num <<= 14;
		return new 467F5DB3.3D312057(-num2);
		IL_C5:
		num <<= 28;
		double num3 = 7BDC3280.B7D5DC99();
		num = (1110065370U | num);
		double 7E9E = -num3;
		num = (1381701990U ^ num);
		return new 467F5DB3.07A85735(7E9E);
		IL_EA:
		num |= 850557734U;
		throw new InvalidOperationException();
	}

	// Token: 0x06000245 RID: 581 RVA: 0x003040BC File Offset: 0x00301CBC
	private 467F5DB3.37FA30B9 07EA346F(467F5DB3.37FA30B9 04645AFA, 467F5DB3.37FA30B9 296662CB, bool 37122D8D)
	{
		uint num;
		for (;;)
		{
			num = 1079736965U;
			TypeCode typeCode = 04645AFA.02557F0D();
			num = 1397555609U * num;
			TypeCode typeCode2 = typeCode;
			num = (1641313536U & num);
			if (num - 502466246U != 0U)
			{
				for (;;)
				{
					TypeCode typeCode3 = typeCode2;
					num <<= 23;
					uint num2 = num - 4294967287U;
					num = (684011365U ^ num);
					if (typeCode3 == num2)
					{
						break;
					}
					num = 1790068967U * num;
					if ((1650002514U & num) != 0U)
					{
						if (typeCode2 == (TypeCode)(num ^ 92023848U))
						{
							goto IL_10A;
						}
						num ^= 419587952U;
						if (num - 400694411U != 0U)
						{
							goto Block_8;
						}
					}
				}
				num -= 947142144U;
				if (37122D8D)
				{
					break;
				}
				if ((1923774418U ^ num) != 0U)
				{
					goto Block_4;
				}
				continue;
				IL_10A:
				num += 2092439598U;
				if (37122D8D)
				{
					num >>= 3;
					if ((1725764087U & num) != 0U)
					{
						goto Block_6;
					}
				}
				else
				{
					num = (542779820U | num);
					if (num >= 434207006U)
					{
						goto Block_7;
					}
				}
			}
		}
		uint num3 = 04645AFA.437B0320();
		int num4 = 296662CB.D6BFBC24();
		num = 2077629359U + num;
		int num5 = num4;
		int num6 = num5;
		int num7 = (int)(num + 2480468747U);
		num = (2065637095U | num);
		int num8 = num6 & num7;
		num <<= 9;
		int 0A = num3 >> num8;
		num = 886833194U / num;
		return new 467F5DB3.1C0911B0(0A);
		Block_4:
		num >>= 4;
		int num9 = 04645AFA.D6BFBC24();
		num = 978088128U - num;
		num = 751257893U % num;
		int num10 = 296662CB.D6BFBC24();
		int num11 = num10;
		num -= 617834338U;
		int num12 = num11 & (int)(num + 592674822U);
		num = 1365656577U + num;
		return new 467F5DB3.1C0911B0(num9 >> num12);
		Block_6:
		num ^= 1732866737U;
		ulong num13 = 04645AFA.67922FD7();
		num >>= 21;
		num -= 366563380U;
		int num14 = 296662CB.D6BFBC24();
		num ^= 2091663338U;
		int num15 = num14;
		num = 1916668872U * num;
		int num16 = num15 & (int)(num ^ 2397728719U);
		num += 290412259U;
		long 0E0B = num13 >> num16;
		num %= 1353603377U;
		return new 467F5DB3.06E010E5(0E0B);
		Block_7:
		num = 1259427553U / num;
		long num17 = 04645AFA.E1698415();
		num = 1982074935U << (int)num;
		int num18 = 296662CB.D6BFBC24();
		int num19 = num18;
		int num20 = (int)(num - 1982074872U);
		num = 2013278657U + num;
		return new 467F5DB3.06E010E5(num17 >> (num19 & num20));
		Block_8:
		throw new InvalidOperationException();
	}

	// Token: 0x06000246 RID: 582 RVA: 0x003042B4 File Offset: 0x00301EB4
	private 467F5DB3.37FA30B9 357227E7(467F5DB3.37FA30B9 521B669F, 467F5DB3.37FA30B9 13FC36DF)
	{
		uint num = 1429946576U;
		TypeCode typeCode2;
		if (857030118U < num)
		{
			TypeCode typeCode = 521B669F.02557F0D();
			num = 1780382890U << (int)num;
			typeCode2 = typeCode;
			num = 1148458196U % num;
			goto IL_2E;
		}
		do
		{
			IL_43:
			uint num2 = (uint)typeCode2;
			num /= 366222220U;
			if (num2 == num - 4294967287U)
			{
				goto IL_8D;
			}
		}
		while (num == 1165232125U);
		if (num != 1101875127U)
		{
			throw new InvalidOperationException();
		}
		goto IL_2E;
		IL_8D:
		num &= 1937010830U;
		long num3 = 521B669F.E1698415();
		num /= 260394314U;
		int num4 = 13FC36DF.D6BFBC24();
		long 0E0B = num3 << (num4 & (int)(num + 63U));
		num &= 1755191370U;
		return new 467F5DB3.06E010E5(0E0B);
		IL_2E:
		uint num5 = (uint)typeCode2;
		num = 844055655U % num;
		if (num5 != num - 844055646U)
		{
			goto IL_43;
		}
		int num6 = 521B669F.D6BFBC24();
		int num7 = 13FC36DF.D6BFBC24();
		int 0A = num6 << (num7 & (int)(num ^ 844055672U));
		num = 1137276313U * num;
		return new 467F5DB3.1C0911B0(0A);
	}

	// Token: 0x06000247 RID: 583 RVA: 0x00304394 File Offset: 0x00301F94
	private unsafe 467F5DB3.37FA30B9 147D558B(object 4A36655E, Type 78CB2287)
	{
		uint num;
		467F5DB3.37FA30B9 37FA30B2;
		for (;;)
		{
			IL_00:
			467F5DB3.37FA30B9 37FA30B = 4A36655E as 467F5DB3.37FA30B9;
			num = 1137921295U;
			37FA30B2 = 37FA30B;
			num &= 117528523U;
			if (num != 1079127305U)
			{
				for (;;)
				{
					num ^= 231097593U;
					if (78CB2287.IsEnum)
					{
						break;
					}
					num -= 1348035721U;
					if (num <= 237519832U)
					{
						goto IL_00;
					}
					TypeCode typeCode = Type.GetTypeCode(78CB2287);
					num = 768559322U + num;
					TypeCode typeCode2 = typeCode;
					num /= 1298929527U;
					if (num >> 21 != 0U)
					{
						goto IL_00;
					}
					uint num2 = (uint)typeCode2;
					num = 2072397058U * num;
					uint num3 = num2 - (num + 2372743421U);
					num = 542840766U % num;
					switch (num3)
					{
					case 0:
						goto IL_1D0;
					case 1:
						goto IL_235;
					case 2:
						num %= 1592228565U;
						if ((1895657774U ^ num) == 0U)
						{
							goto IL_00;
						}
						if (37FA30B2 == null)
						{
							goto Block_17;
						}
						if (num + 959212976U != 0U)
						{
							goto Block_18;
						}
						continue;
					case 3:
						goto IL_2E0;
					case 4:
						goto IL_354;
					case 5:
						goto IL_3AC;
					case 6:
						goto IL_416;
					case 7:
					{
						bool flag = 37FA30B2 != null;
						num = 1852253632U << (int)num;
						if (flag)
						{
							goto IL_4BA;
						}
						num = 2110719509U + num;
						if (1930235351 << (int)num != 0)
						{
							goto Block_32;
						}
						continue;
					}
					case 8:
					{
						num = 424037243U * num;
						bool flag2 = 37FA30B2 != null;
						num -= 1012873164U;
						if (!flag2)
						{
							goto Block_33;
						}
						if (num < 1913735338U)
						{
							goto Block_34;
						}
						continue;
					}
					case 9:
						goto IL_52E;
					case 10:
						num = 1860783545U + num;
						if ((837251521U ^ num) != 0U)
						{
							goto Block_38;
						}
						continue;
					case 11:
						goto IL_5DA;
					case 12:
					case 13:
					case 14:
						break;
					case 15:
						goto IL_623;
					default:
						num ^= 0U;
						break;
					}
					num = (1588348214U | num);
					num = 348612103U + num;
					Type typeFromHandle = typeof(IntPtr);
					num = (1875645328U ^ num);
					if (78CB2287 == typeFromHandle)
					{
						goto Block_43;
					}
					num = 26549916U + num;
					Type typeFromHandle2 = typeof(UIntPtr);
					num = 56311092U - num;
					if (78CB2287 == typeFromHandle2)
					{
						num <<= 26;
						if (951661741U == num)
						{
							goto IL_00;
						}
						bool flag3 = 37FA30B2 != null;
						num = 1422936672U >> (int)num;
						if (flag3)
						{
							goto Block_51;
						}
						if (4A36655E == null)
						{
							goto Block_52;
						}
						num *= 967639612U;
						if (1874094577U >> (int)num != 0U)
						{
							goto Block_53;
						}
					}
					else
					{
						if (78CB2287.IsValueType)
						{
							goto Block_54;
						}
						bool isArray = 78CB2287.IsArray;
						num = (1160526700U ^ num);
						if (isArray)
						{
							num <<= 30;
							if (num == 163250996U)
							{
								goto IL_00;
							}
							if (37FA30B2 == null)
							{
								goto Block_60;
							}
							num = 1827746676U >> (int)num;
							if (2008962582U + num != 0U)
							{
								goto Block_61;
							}
						}
						else
						{
							if (!78CB2287.IsPointer)
							{
								goto IL_9B2;
							}
							num = 637275151U << (int)num;
							if (1292116028U >> (int)num == 0U)
							{
								break;
							}
							bool flag4 = 37FA30B2 != null;
							num ^= 421424881U;
							if (flag4)
							{
								goto Block_64;
							}
							if (443370669U <= num)
							{
								goto Block_66;
							}
						}
					}
				}
				IL_33:
				bool flag5 = 37FA30B2 != null;
				num = 1963609221U >> (int)num;
				if (!flag5)
				{
					goto IL_72;
				}
				num = (1292778951U | num);
				if (num != 1815087410U)
				{
					object obj = 37FA30B2.6B58D7F4();
					num %= 235760208U;
					4A36655E = obj;
					num ^= 113981301U;
					goto IL_72;
				}
				continue;
				IL_235:
				num = (1580148273U | num);
				bool flag6 = 37FA30B2 != null;
				num <<= 30;
				if (!flag6)
				{
					goto Block_14;
				}
				num |= 231216727U;
				if (425002893U < num)
				{
					goto Block_15;
				}
				goto IL_33;
				IL_72:
				num |= 1814002950U;
				if ((1501710110U & num) == 0U)
				{
					continue;
				}
				if (4A36655E != null)
				{
					num = 1533425162U << (int)num;
					object obj2 = 4A36655E;
					num += 454888776U;
					bool flag7 = obj2 is Enum;
					num %= 326458040U;
					num += 1626680862U;
					if (!flag7)
					{
						num >>= 19;
						4A36655E = Enum.ToObject(78CB2287, 4A36655E);
						num ^= 1813999813U;
					}
				}
				num = 906780991U * num;
				if (4A36655E != null)
				{
					if (num << 30 != 0U)
					{
						break;
					}
					continue;
				}
				else
				{
					num = 99306411U + num;
					if (1712274235U > num)
					{
						goto Block_7;
					}
					continue;
				}
				IL_1D0:
				num = 449990748U + num;
				bool flag8 = 37FA30B2 != null;
				num ^= 964176734U;
				if (!flag8)
				{
					if (num * 650263478U != 0U)
					{
						goto Block_12;
					}
					continue;
				}
				else
				{
					num /= 466178205U;
					if ((num & 655767144U) == 0U)
					{
						goto Block_13;
					}
					continue;
				}
				IL_2E0:
				if (701847124U < num)
				{
					continue;
				}
				bool flag9 = 37FA30B2 != null;
				num = (910494799U & num);
				if (!flag9)
				{
					num *= 227374619U;
					if (899828507 << (int)num != 0)
					{
						goto Block_21;
					}
					goto IL_72;
				}
				else
				{
					num = (1621258877U | num);
					if (365894021U - num != 0U)
					{
						goto Block_22;
					}
					continue;
				}
				IL_3AC:
				num /= 1634678387U;
				if ((num & 1013848967U) != 0U)
				{
					continue;
				}
				bool flag10 = 37FA30B2 != null;
				num = (1777470473U ^ num);
				if (!flag10)
				{
					goto Block_26;
				}
				if (44712077U <= num)
				{
					goto Block_27;
				}
				continue;
				IL_416:
				num *= 160370184U;
				if (num < 901188992U)
				{
					continue;
				}
				if (37FA30B2 == null)
				{
					goto Block_29;
				}
				num = (1099116558U | num);
				if (num >= 1514362872U)
				{
					goto Block_30;
				}
				continue;
				IL_52E:
				if (37FA30B2 == null)
				{
					num /= 1794448970U;
					if (num < 1090653835U)
					{
						goto Block_36;
					}
					continue;
				}
				else
				{
					if (num < 1630538258U)
					{
						goto Block_37;
					}
					continue;
				}
				IL_5DA:
				if (37FA30B2 != null)
				{
					goto IL_5FF;
				}
				num |= 735139717U;
				if ((286413902U & num) != 0U)
				{
					goto Block_41;
				}
				continue;
				Block_54:
				num = 990735003U << (int)num;
				if (37FA30B2 != null)
				{
					goto Block_55;
				}
				num = 145969477U >> (int)num;
				if (num >> 10 == 0U)
				{
					goto Block_56;
				}
				continue;
				Block_64:
				num = 1528248607U - num;
				if ((num ^ 2009401300U) != 0U)
				{
					goto Block_65;
				}
				continue;
				Block_66:
				if (4A36655E == null)
				{
					goto Block_67;
				}
				if (1975536694U >> (int)num != 0U)
				{
					goto Block_68;
				}
				continue;
				IL_9B2:
				num = 1455044705U + num;
				bool flag11 = 37FA30B2 != null;
				num = (1606549889U & num);
				if (!flag11)
				{
					goto Block_69;
				}
				if (905341163 << (int)num != 0)
				{
					goto Block_70;
				}
				goto IL_33;
				IL_354:
				num ^= 1550269178U;
				if (1908944711U < num)
				{
					goto Block_23;
				}
				goto IL_72;
				Block_43:
				num += 564998399U;
				if (num > 1400525259U)
				{
					goto IL_72;
				}
				bool flag12 = 37FA30B2 != null;
				num %= 558573833U;
				if (flag12)
				{
					if (1406629583U >= num)
					{
						goto Block_46;
					}
				}
				else
				{
					num ^= 1556365777U;
					bool flag13 = 4A36655E != null;
					num *= 1200114671U;
					if (flag13)
					{
						goto IL_70A;
					}
					num = (522026161U ^ num);
					if (737155915U + num != 0U)
					{
						goto Block_48;
					}
				}
			}
		}
		Enum 1E3A6B = (Enum)4A36655E;
		goto IL_129;
		Block_7:
		num %= 2094752675U;
		1E3A6B = (Enum)Activator.CreateInstance(78CB2287);
		num ^= 504758239U;
		IL_129:
		return new 467F5DB3.14624823(1E3A6B);
		Block_12:
		bool 5FE92F = Convert.ToBoolean(4A36655E);
		goto IL_227;
		Block_13:
		467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
		num |= 1112897244U;
		5FE92F = 37FA30B3.A8DF755E();
		num ^= 1073755544U;
		IL_227:
		num %= 908604492U;
		return new 467F5DB3.0BAB1405(5FE92F);
		Block_14:
		num = 1403546719U % num;
		char 28C = Convert.ToChar(4A36655E);
		goto IL_287;
		Block_15:
		467F5DB3.37FA30B9 37FA30B4 = 37FA30B2;
		num = 854158552U / num;
		28C = 37FA30B4.C8DBDBAA();
		num += 1403546719U;
		IL_287:
		return new 467F5DB3.06B44EBD(28C);
		Block_17:
		sbyte 43912B = Convert.ToSByte(4A36655E);
		goto IL_2DA;
		Block_18:
		467F5DB3.37FA30B9 37FA30B5 = 37FA30B2;
		num = 2073648458U >> (int)num;
		43912B = 37FA30B5.3D1BD445();
		num ^= 542840767U;
		IL_2DA:
		return new 467F5DB3.745721FC(43912B);
		Block_21:
		object value = 4A36655E;
		num = 1617964706U >> (int)num;
		byte 287768DC = Convert.ToByte(value);
		goto IL_34E;
		Block_22:
		287768DC = 37FA30B2.76883720();
		num += 2669447577U;
		IL_34E:
		return new 467F5DB3.1A802882(287768DC);
		Block_23:
		bool flag14 = 37FA30B2 != null;
		num = 1393501368U % num;
		short 22CD01C;
		if (!flag14)
		{
			num <<= 12;
			object value2 = 4A36655E;
			num ^= 1186204635U;
			22CD01C = Convert.ToInt16(value2);
		}
		else
		{
			467F5DB3.37FA30B9 37FA30B6 = 37FA30B2;
			num ^= 3615319U;
			22CD01C = 37FA30B6.D204A80D();
			num += 1640463596U;
		}
		return new 467F5DB3.3CC25312(22CD01C);
		Block_26:
		num %= 1607812567U;
		object value3 = 4A36655E;
		num = 422129543U << (int)num;
		ushort 4EB81B1D = Convert.ToUInt16(value3);
		goto IL_410;
		Block_27:
		467F5DB3.37FA30B9 37FA30B7 = 37FA30B2;
		num = 162138583U % num;
		4EB81B1D = 37FA30B7.E91B7AB7();
		num ^= 3082160599U;
		IL_410:
		return new 467F5DB3.03CF3096(4EB81B1D);
		Block_29:
		object value4 = 4A36655E;
		num = 284628106U + num;
		int 0A = Convert.ToInt32(value4);
		goto IL_46B;
		Block_30:
		467F5DB3.37FA30B9 37FA30B8 = 37FA30B2;
		num -= 1082867207U;
		0A = 37FA30B8.D6BFBC24();
		num += 1359102595U;
		IL_46B:
		num = (1565663189U ^ num);
		return new 467F5DB3.1C0911B0(0A);
		Block_32:
		object value5 = 4A36655E;
		num = (1153714131U | num);
		uint 4C6E61B = Convert.ToUInt32(value5);
		goto IL_4D0;
		IL_4BA:
		467F5DB3.37FA30B9 37FA30B9 = 37FA30B2;
		num = 1833139165U + num;
		4C6E61B = 37FA30B9.437B0320();
		num ^= 277625866U;
		IL_4D0:
		num = (649922465U | num);
		return new 467F5DB3.2DB44737(4C6E61B);
		Block_33:
		object value6 = 4A36655E;
		num %= 1987404758U;
		long 0E0B = Convert.ToInt64(value6);
		goto IL_528;
		Block_34:
		467F5DB3.37FA30B9 37FA30B10 = 37FA30B2;
		num = 705722230U + num;
		0E0B = 37FA30B10.E1698415();
		num += 3589245066U;
		IL_528:
		return new 467F5DB3.06E010E5(0E0B);
		Block_36:
		object value7 = 4A36655E;
		num = 63786041U * num;
		ulong 5BBF2E = Convert.ToUInt64(value7);
		goto IL_57B;
		Block_37:
		467F5DB3.37FA30B9 37FA30B11 = 37FA30B2;
		num /= 1680172149U;
		5BBF2E = 37FA30B11.67922FD7();
		num += 0U;
		IL_57B:
		num >>= 7;
		return new 467F5DB3.00C71221(5BBF2E);
		Block_38:
		float 7D;
		if (37FA30B2 == null)
		{
			7D = Convert.ToSingle(4A36655E);
		}
		else
		{
			num += 1839883126U;
			467F5DB3.37FA30B9 37FA30B12 = 37FA30B2;
			num = (1843161037U | num);
			7D = 37FA30B12.8E4073FD();
			num += 2437248394U;
		}
		num = 936537803U / num;
		return new 467F5DB3.3D312057(7D);
		Block_41:
		double 7E9E = Convert.ToDouble(4A36655E);
		goto IL_615;
		IL_5FF:
		467F5DB3.37FA30B9 37FA30B13 = 37FA30B2;
		num = 287977752U * num;
		7E9E = 37FA30B13.B7D5DC99();
		num += 815382511U;
		IL_615:
		num ^= 1352945759U;
		return new 467F5DB3.07A85735(7E9E);
		IL_623:
		num = 1700932326U % num;
		string 4E1B313C;
		if (37FA30B2 == null)
		{
			4E1B313C = (string)4A36655E;
		}
		else
		{
			num = (2054243030U | num);
			object obj3 = 37FA30B2;
			num = 1904889772U / num;
			4E1B313C = obj3.ToString();
			num ^= 72410028U;
		}
		return new 467F5DB3.32D66DFC(4E1B313C);
		Block_46:
		467F5DB3.37FA30B9 37FA30B14 = 37FA30B2;
		num = 1110401655U % num;
		IntPtr 6C1245F = 37FA30B14.8C5D656E();
		num = 312167526U >> (int)num;
		return new 467F5DB3.00086387(6C1245F);
		Block_48:
		IntPtr 6C1245F2 = IntPtr.Zero;
		goto IL_718;
		IL_70A:
		6C1245F2 = (IntPtr)4A36655E;
		num += 4144665711U;
		IL_718:
		return new 467F5DB3.00086387(6C1245F2);
		Block_51:
		num >>= 13;
		467F5DB3.37FA30B9 37FA30B15 = 37FA30B2;
		num = 85263114U << (int)num;
		UIntPtr 10D22B3E = 37FA30B15.103B638B();
		num = 791743764U << (int)num;
		return new 467F5DB3.01BD2A31(10D22B3E);
		Block_52:
		num ^= 1323980889U;
		UIntPtr 10D22B3E2 = UIntPtr.Zero;
		goto IL_7D5;
		Block_53:
		10D22B3E2 = (UIntPtr)4A36655E;
		num ^= 1048329401U;
		IL_7D5:
		return new 467F5DB3.01BD2A31(10D22B3E2);
		Block_55:
		num |= 1949116990U;
		return new 467F5DB3.7EA91122(37FA30B2.6B58D7F4());
		Block_56:
		object 534D4E3B;
		if (4A36655E != null)
		{
			534D4E3B = 4A36655E;
		}
		else
		{
			534D4E3B = Activator.CreateInstance(78CB2287);
			num ^= 0U;
		}
		num >>= 9;
		return new 467F5DB3.7EA91122(534D4E3B);
		Block_60:
		object obj4 = 4A36655E;
		num |= 1069897323U;
		Array 413C5DF = (Array)obj4;
		goto IL_8C4;
		Block_61:
		467F5DB3.37FA30B9 37FA30B16 = 37FA30B2;
		num = (420230464U & num);
		413C5DF = (Array)37FA30B16.6B58D7F4();
		num += 4156892459U;
		IL_8C4:
		num += 978739259U;
		return new 467F5DB3.705703B5(413C5DF);
		Block_65:
		467F5DB3.37FA30B9 37FA30B17 = 37FA30B2;
		num = (65473838U & num);
		void* ptr = Pointer.Unbox(37FA30B17.6B58D7F4());
		num = 874383161U + num;
		return new 467F5DB3.6B576539(Pointer.Box(ptr, 78CB2287), 78CB2287);
		Block_67:
		num = 1468946194U * num;
		void* ptr2 = num - 1890890738U;
		goto IL_995;
		Block_68:
		object ptr3 = 4A36655E;
		num = 2062101107U % num;
		ptr2 = Pointer.Unbox(ptr3);
		num ^= 1831857746U;
		IL_995:
		num = 207573521U / num;
		object 36FA1F = Pointer.Box(ptr2, 78CB2287);
		num <<= 30;
		return new 467F5DB3.6B576539(36FA1F, 78CB2287);
		Block_69:
		num <<= 6;
		object <<EMPTY_NAME>> = 4A36655E;
		goto IL_9FE;
		Block_70:
		467F5DB3.37FA30B9 37FA30B18 = 37FA30B2;
		num = 1165823027U / num;
		<<EMPTY_NAME>> = 37FA30B18.6B58D7F4();
		num ^= 3489685506U;
		IL_9FE:
		num <<= 2;
		return new 467F5DB3.4CF55D0F(<<EMPTY_NAME>>);
	}

	// Token: 0x06000248 RID: 584 RVA: 0x00304DAC File Offset: 0x003029AC
	private string 45DF429C(int 013E7985)
	{
		uint num = 656548117U;
		Dictionary<int, object> obj;
		if (1269325040U > num)
		{
			do
			{
				obj = 467F5DB3.38D3571D;
				num = 270609449U / num;
			}
			while (num % 1075401027U != 0U);
		}
		Monitor.Enter(obj);
		string result;
		try
		{
			num |= 28315657U;
			object obj2;
			if (2041185629 << (int)num != 0)
			{
				string text2;
				do
				{
					bool flag = 467F5DB3.38D3571D.TryGetValue(013E7985, out obj2);
					num = 673268411U * num;
					if (flag)
					{
						goto IL_65;
					}
					Module module = this.25F821A5;
					num <<= 0;
					string text = module.ResolveString(013E7985);
					num <<= 6;
					text2 = text;
					num *= 2045725610U;
				}
				while (num + 2053260376U == 0U);
				Dictionary<int, object> dictionary = 467F5DB3.38D3571D;
				num = (1288573429U & num);
				dictionary.Add(013E7985, text2);
				do
				{
					string text3 = text2;
					num <<= 8;
					result = text3;
				}
				while (657338223U >= num);
				return result;
			}
			IL_65:
			object obj3 = obj2;
			num *= 805903589U;
			result = (string)obj3;
		}
		finally
		{
			do
			{
				num = 2001164979U;
				Monitor.Exit(obj);
			}
			while (num < 361907963U);
		}
		return result;
	}

	// Token: 0x06000249 RID: 585 RVA: 0x00304ECC File Offset: 0x00302ACC
	private Type 6AA34183(int 1ADD01F9)
	{
		Dictionary<int, object> dictionary = 467F5DB3.38D3571D;
		uint num = 713260357U;
		Dictionary<int, object> obj = dictionary;
		Type result;
		lock (obj)
		{
			num = 1556496860U * num;
			do
			{
				Dictionary<int, object> dictionary2 = 467F5DB3.38D3571D;
				num -= 52905000U;
				object obj2;
				bool flag = dictionary2.TryGetValue(1ADD01F9, out obj2);
				num = 1000348875U * num;
				if (flag)
				{
					if (num * 1584072692U == 0U)
					{
						break;
					}
				}
				else
				{
					if (2058094382U < num)
					{
						continue;
					}
					Module module = this.25F821A5;
					num *= 1249398363U;
					Type type = module.ResolveType(1ADD01F9);
					num = (1189963361U & num);
					Type type2 = type;
					num %= 1814001541U;
					Dictionary<int, object> dictionary3 = 467F5DB3.38D3571D;
					num = 1553007963U << (int)num;
					dictionary3.Add(1ADD01F9, type2);
					num = 1519221798U << (int)num;
					if (835938099U % num != 0U)
					{
						result = type2;
						if (num != 877071507U)
						{
							break;
						}
						continue;
					}
				}
				object obj3 = obj2;
				num = (951130706U | num);
				result = (Type)obj3;
			}
			while (844502008U > num);
		}
		return result;
	}

	// Token: 0x0600024A RID: 586 RVA: 0x00304FF4 File Offset: 0x00302BF4
	private MethodBase 12F8138C(int 6E2A7C3A)
	{
		Dictionary<int, object> dictionary = 467F5DB3.38D3571D;
		uint num = 1852965702U;
		Dictionary<int, object> obj = dictionary;
		num %= 1718621954U;
		Monitor.Enter(obj);
		MethodBase result;
		try
		{
			num = 2139829082U + num;
			MethodBase methodBase3;
			if (num != 1994728315U)
			{
				do
				{
					Dictionary<int, object> dictionary2 = 467F5DB3.38D3571D;
					num -= 757955205U;
					object obj2;
					bool flag = dictionary2.TryGetValue(6E2A7C3A, out obj2);
					num = 629021065U % num;
					if (!flag)
					{
						goto IL_76;
					}
					object obj3 = obj2;
					num = 1042959544U / num;
					MethodBase methodBase = (MethodBase)obj3;
					num = 722161160U + num;
					result = methodBase;
				}
				while (1781399873U < num);
				return result;
				IL_76:
				num -= 682953757U;
				if (num != 359597031U)
				{
					MethodBase methodBase2 = this.25F821A5.ResolveMethod(6E2A7C3A);
					num = 1606498563U + num;
					methodBase3 = methodBase2;
				}
			}
			Dictionary<int, object> dictionary3 = 467F5DB3.38D3571D;
			num /= 1752196819U;
			num += 1692553033U;
			object value = methodBase3;
			num = (521365398U & num);
			dictionary3.Add(6E2A7C3A, value);
			num %= 735121870U;
			MethodBase methodBase4 = methodBase3;
			num += 366943788U;
			result = methodBase4;
		}
		finally
		{
			num = 1307998396U;
			if (364213235U != num)
			{
				Monitor.Exit(obj);
			}
		}
		return result;
	}

	// Token: 0x0600024B RID: 587 RVA: 0x00305118 File Offset: 0x00302D18
	private FieldInfo 0D675DC8(int 748E14B5)
	{
		Dictionary<int, object> dictionary;
		uint num;
		do
		{
			dictionary = 467F5DB3.38D3571D;
			num = 760310686U;
		}
		while (1021191400U / num == 0U);
		object obj = dictionary;
		num = 1841913512U + num;
		Monitor.Enter(obj);
		FieldInfo result;
		try
		{
			FieldInfo fieldInfo3;
			for (;;)
			{
				Dictionary<int, object> dictionary2 = 467F5DB3.38D3571D;
				num *= 223742208U;
				num = 1199722684U >> (int)num;
				object obj2;
				if (dictionary2.TryGetValue(748E14B5, out obj2))
				{
					num = 1253666733U % num;
					if (num != 1147559582U)
					{
						FieldInfo fieldInfo = (FieldInfo)obj2;
						num -= 467237626U;
						result = fieldInfo;
						if (num >> 12 != 0U)
						{
							break;
						}
						continue;
					}
				}
				num += 1063481409U;
				if ((num ^ 2052292102U) == 0U)
				{
					break;
				}
				num -= 178978911U;
				FieldInfo fieldInfo2 = this.25F821A5.ResolveField(748E14B5);
				num = 374939173U + num;
				fieldInfo3 = fieldInfo2;
				if ((num ^ 302449113U) != 0U)
				{
					467F5DB3.38D3571D.Add(748E14B5, fieldInfo3);
					num ^= 2069262728U;
					if (510857031U - num != 0U)
					{
						goto Block_6;
					}
				}
			}
			return result;
			Block_6:
			result = fieldInfo3;
		}
		finally
		{
			Monitor.Exit(dictionary);
		}
		return result;
	}

	// Token: 0x0600024C RID: 588 RVA: 0x00305238 File Offset: 0x00302E38
	private 467F5DB3.37FA30B9 60BB31CB(MethodBase 06C92F25)
	{
		uint num;
		Dictionary<int, 467F5DB3.37FA30B9> dictionary;
		object[] array2;
		for (;;)
		{
			num = 1834902393U;
			ParameterInfo[] parameters = 06C92F25.GetParameters();
			num = (1011316942U ^ num);
			if (1559853912U > num)
			{
				do
				{
					dictionary = new Dictionary<int, 467F5DB3.37FA30B9>();
					num /= 1580600524U;
					int num2 = parameters.Length;
					num = 1004164709U * num;
					object[] array = new object[num2];
					num = (299182686U ^ num);
					array2 = array;
					num = 883049398U << (int)num;
				}
				while (num + 1109863905U == 0U);
				ParameterInfo[] array3 = parameters;
				num <<= 23;
				int num3 = array3.Length;
				int num4 = (int)(num + 1U);
				num <<= 1;
				int num5 = num3 - num4;
				num *= 37840121U;
				int num6 = num5;
				if (306933328U != num)
				{
					for (;;)
					{
						uint num7 = (uint)num6;
						num &= 950601624U;
						if (num7 < num - 0U)
						{
							goto Block_5;
						}
						num = 1641430747U;
						467F5DB3.37FA30B9 37FA30B = this.026905F8();
						467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
						num += 1491820029U;
						bool flag = 37FA30B2.535FA4FE();
						num <<= 3;
						if (flag)
						{
							if (742990985U % num == 0U)
							{
								break;
							}
							Dictionary<int, 467F5DB3.37FA30B9> dictionary2 = dictionary;
							int key = num6;
							467F5DB3.37FA30B9 value = 37FA30B;
							num <<= 5;
							dictionary2[key] = value;
							num ^= 395329216U;
						}
						if (num + 616389710U == 0U)
						{
							break;
						}
						object[] array4 = array2;
						num = (1911433395U & num);
						int num8 = num6;
						num = 784342412U % num;
						object 4A36655E = 37FA30B;
						num &= 454362749U;
						ParameterInfo[] array5 = parameters;
						num &= 605831194U;
						ParameterInfo parameterInfo = array5[num6];
						num = (728647457U | num);
						Type parameterType = parameterInfo.ParameterType;
						num = 506023874U / num;
						array4[num8] = this.147D558B(4A36655E, parameterType).6B58D7F4();
						num %= 337188874U;
						int num9 = num6;
						num = 331422589U * num;
						int num10 = (int)(num - uint.MaxValue);
						num >>= 13;
						num6 = num9 - num10;
						num += 0U;
					}
				}
			}
		}
		Block_5:
		num |= 1101927965U;
		num = 2043745060U / num;
		ConstructorInfo constructorInfo = (ConstructorInfo)06C92F25;
		num <<= 4;
		object 4A36655E2 = constructorInfo.Invoke(array2);
		Dictionary<int, 467F5DB3.37FA30B9>.Enumerator enumerator = dictionary.GetEnumerator();
		num >>= 31;
		using (Dictionary<int, 467F5DB3.37FA30B9>.Enumerator enumerator2 = enumerator)
		{
			for (;;)
			{
				while (enumerator2.MoveNext())
				{
					num = 133841031U;
					KeyValuePair<int, 467F5DB3.37FA30B9> keyValuePair = enumerator2.Current;
					num = (2087584982U | num);
					if (num / 890135221U != 0U)
					{
						467F5DB3.37FA30B9 value2 = keyValuePair.Value;
						object[] array6 = array2;
						num = (977683995U ^ num);
						int key2 = keyValuePair.Key;
						num >>= 28;
						value2.59A76885(array6[key2]);
						num += 4294967292U;
					}
				}
				break;
			}
		}
		return this.147D558B(4A36655E2, 06C92F25.DeclaringType);
	}

	// Token: 0x0600024D RID: 589 RVA: 0x00305498 File Offset: 0x00303098
	private bool 4E51314E(MethodBase 17B760BE, object 46613881, ref object 09752F4E, object[] 07972573)
	{
		uint num;
		for (;;)
		{
			IL_00:
			Type declaringType = 17B760BE.DeclaringType;
			num = 30107880U;
			Type type = declaringType;
			while (type != null)
			{
				num ^= 819739060U;
				Type type2 = type;
				num = 1251944946U / num;
				if (!type2.IsGenericType)
				{
					goto IL_20A;
				}
				num = (915610095U & num);
				Type genericTypeDefinition = type.GetGenericTypeDefinition();
				RuntimeTypeHandle handle = typeof(Nullable<>).TypeHandle;
				num |= 399988868U;
				Type typeFromHandle = Type.GetTypeFromHandle(handle);
				num /= 206376481U;
				num += 0U;
				if (genericTypeDefinition != typeFromHandle)
				{
					goto IL_20A;
				}
				num += 1978292304U;
				num |= 1449753786U;
				string name = 17B760BE.Name;
				string b = "get_HasValue";
				num -= 1390426004U;
				bool flag = string.Equals(name, b, (int)num + (StringComparison)(-621495651));
				num = 886250184U - num;
				if (flag)
				{
					num |= 1087667216U;
					if (num % 180294719U != 0U)
					{
						goto IL_BB;
					}
				}
				else
				{
					num |= 1492991994U;
					if (1155688900U == num)
					{
						goto IL_00;
					}
					string name2 = 17B760BE.Name;
					num = 111229667U - num;
					if (string.Equals(name2, "get_Value", (int)num + (StringComparison)1499383068))
					{
						if (46613881 == null)
						{
							goto Block_6;
						}
						num = 604787101U + num;
						if (num / 171736265U != 0U)
						{
							goto Block_7;
						}
					}
					else if (num << 15 != 0U)
					{
						num = 2017865092U - num;
						string name3 = 17B760BE.Name;
						string value = "GetValueOrDefault";
						num |= 1644317868U;
						bool flag2 = name3.Equals(value, (StringComparison)(num ^ 4087807672U));
						num ^= 765279368U;
						if (!flag2)
						{
							goto IL_202;
						}
						if (num >= 398209530U)
						{
							goto Block_11;
						}
						goto IL_00;
					}
				}
			}
			break;
		}
		return (num ^ 30107880U) != 0U;
		IL_BB:
		object obj = 46613881;
		num *= 1268729345U;
		object obj2 = null;
		num &= 681850371U;
		object obj3 = obj > obj2;
		num -= 1103388621U;
		09752F4E = obj3;
		goto IL_202;
		Block_6:
		throw new InvalidOperationException();
		Block_7:
		object obj4 = 46613881;
		num = (930178415U ^ num);
		09752F4E = obj4;
		if (num >> 1 != 0U)
		{
			num += 3764312138U;
			goto IL_202;
		}
		goto IL_BB;
		Block_11:
		bool flag3 = 46613881 != null;
		num |= 1347292536U;
		if (!flag3)
		{
			num %= 188748939U;
			Type declaringType2 = 17B760BE.DeclaringType;
			num = 96418744U % num;
			object obj5 = Activator.CreateInstance(Nullable.GetUnderlyingType(declaringType2));
			num = 211707957U >> (int)num;
			46613881 = obj5;
			num += 3732918128U;
		}
		num = 703149350U - num;
		09752F4E = 46613881;
		num += 2463259786U;
		IL_202:
		return (num ^ 3728458293U) != 0U;
		IL_20A:
		num = 1286895148U >> (int)num;
		return num - 643447574U != 0U;
	}

	// Token: 0x0600024E RID: 590 RVA: 0x003056C4 File Offset: 0x003032C4
	private 467F5DB3.37FA30B9 679E4C07(MethodBase 0B2C41C8, bool 358E669A)
	{
		MethodInfo methodInfo;
		uint num;
		Dictionary<int, 467F5DB3.37FA30B9> dictionary;
		object[] array3;
		467F5DB3.37FA30B9 37FA30B2;
		object obj4;
		object[] array7;
		for (;;)
		{
			IL_00:
			methodInfo = (0B2C41C8 as MethodInfo);
			num = 1116813617U;
			object obj3;
			for (;;)
			{
				IL_0F:
				num = (311379397U | num);
				ParameterInfo[] parameters = 0B2C41C8.GetParameters();
				num = 1128421324U / num;
				ParameterInfo[] array = parameters;
				num = 1569206766U + num;
				for (;;)
				{
					IL_35:
					dictionary = new Dictionary<int, 467F5DB3.37FA30B9>();
					num = 1252918592U / num;
					if (num > 1892511055U)
					{
						goto IL_00;
					}
					do
					{
						IL_51:
						object[] array2 = new object[array.Length];
						num /= 984882888U;
						array3 = array2;
						for (;;)
						{
							IL_66:
							ParameterInfo[] array4 = array;
							num &= 176904500U;
							int num2 = array4.Length - (int)(num ^ 1U);
							num = 1095574984U * num;
							int num3 = num2;
							if (1239902103 << (int)num != 0)
							{
								while ((num & 742275529U) == 0U)
								{
									int num4 = num3;
									num /= 996485787U;
									uint num5 = num + 0U;
									num = 772102671U - num;
									if (num4 < num5)
									{
										goto Block_8;
									}
									num = 243672766U;
									if (num < 64163689U)
									{
										goto IL_66;
									}
									num &= 1849492381U;
									467F5DB3.37FA30B9 37FA30B = this.026905F8();
									num %= 1429369300U;
									37FA30B2 = 37FA30B;
									num |= 30478451U;
									if (num >= 1049103532U)
									{
										goto IL_0F;
									}
									467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
									num >>= 8;
									bool flag = 37FA30B3.535FA4FE();
									num &= 24779898U;
									if (flag)
									{
										num += 1923745127U;
										if (num % 1486846969U == 0U)
										{
											goto IL_51;
										}
										Dictionary<int, 467F5DB3.37FA30B9> dictionary2 = dictionary;
										int key = num3;
										num = 67569488U % num;
										dictionary2[key] = 37FA30B2;
										num += 4228058306U;
									}
									num = 704255343U / num;
									if (num << 18 == 0U)
									{
										goto IL_35;
									}
									object[] array5 = array3;
									num = (1129978498U ^ num);
									int num6 = num3;
									num = 1460694858U >> (int)num;
									num *= 372011537U;
									object 4A36655E = 37FA30B2;
									num = 17913392U << (int)num;
									ParameterInfo[] array6 = array;
									num = 2016968385U >> (int)num;
									int num7 = num3;
									num = (1017806114U & num);
									ParameterInfo parameterInfo = array6[num7];
									num <<= 23;
									467F5DB3.37FA30B9 37FA30B4 = this.147D558B(4A36655E, parameterInfo.ParameterType);
									num *= 1125987022U;
									array5[num6] = 37FA30B4.6B58D7F4();
									if ((num ^ 1803312601U) == 0U)
									{
										break;
									}
									int num8 = num3;
									num &= 1199982165U;
									int num9 = (int)(num - uint.MaxValue);
									num += 1993166808U;
									num3 = num8 - num9;
									num += 2301800488U;
								}
								goto IL_00;
							}
							goto IL_0F;
						}
						Block_8:;
					}
					while (438379905U > num);
					num = 2014927440U - num;
					467F5DB3.37FA30B9 37FA30B5;
					if (!0B2C41C8.IsStatic)
					{
						if (612900808U + num == 0U)
						{
							goto IL_00;
						}
						num = (1818118657U ^ num);
						37FA30B5 = this.026905F8();
					}
					else
					{
						num = 966283137U * num;
						37FA30B5 = null;
						num += 109714047U;
					}
					num *= 1495747897U;
					37FA30B2 = 37FA30B5;
					if ((num ^ 354359474U) == 0U)
					{
						goto IL_0F;
					}
					object obj;
					if (37FA30B2 == null)
					{
						num >>= 20;
						if (num % 989549769U == 0U)
						{
							goto IL_00;
						}
						obj = null;
					}
					else
					{
						num %= 1318600120U;
						if (394920280U == num)
						{
							goto IL_0F;
						}
						467F5DB3.37FA30B9 37FA30B6 = 37FA30B2;
						num = 76381044U + num;
						obj = 37FA30B6.6B58D7F4();
						num += 3681222893U;
					}
					object obj2;
					if ((obj2 = obj) == null)
					{
						if (num == 804878486U)
						{
							continue;
						}
						obj2 = null;
						num += 0U;
					}
					obj3 = obj2;
					num = (1695634039U & num);
					if (num >= 574182384U)
					{
						goto IL_00;
					}
					num = (49689626U ^ num);
					if (358E669A)
					{
						num = (1878726620U & num);
						bool flag2 = obj3 != null;
						num *= 1834167673U;
						num += 1511272163U;
						if (!flag2)
						{
							goto Block_20;
						}
					}
					num = (1210730009U | num);
					if (1708673674U <= num)
					{
						goto IL_00;
					}
					obj4 = null;
					num = 2023498257U >> (int)num;
					bool isConstructor = 0B2C41C8.IsConstructor;
					num /= 692658906U;
					if (isConstructor)
					{
						num = (1547139457U | num);
						num = 1917390226U - num;
						Type declaringType = 0B2C41C8.DeclaringType;
						num %= 1946303999U;
						bool isValueType = declaringType.IsValueType;
						num ^= 370250769U;
						if (isValueType)
						{
							break;
						}
					}
					num = 2097496063U >> (int)num;
					if (862283499U > num)
					{
						goto IL_00;
					}
					object <<EMPTY_NAME>> = obj3;
					num = (86925485U | num);
					object[] 2 = array3;
					num ^= 1249524040U;
					bool flag3 = this.4E51314E(0B2C41C8, <<EMPTY_NAME>>, ref obj4, 2);
					num = 1064857265U + num;
					num += 2301774488U;
					if (flag3)
					{
						goto IL_C2D;
					}
					num %= 841242384U;
					if (1828918977 << (int)num == 0)
					{
						goto IL_0F;
					}
					if (358E669A)
					{
						goto IL_BF7;
					}
					num /= 947026581U;
					if (111966956U >> (int)num == 0U)
					{
						goto IL_00;
					}
					num += 1006109721U;
					bool isVirtual = 0B2C41C8.IsVirtual;
					num ^= 1006109721U;
					if (!isVirtual)
					{
						goto IL_BF7;
					}
					if (669470433U != num)
					{
						goto Block_35;
					}
				}
				num /= 1713642036U;
				if (1294078896 << (int)num != 0)
				{
					goto Block_25;
				}
			}
			Block_20:
			if (num - 1880704870U != 0U)
			{
				break;
			}
			continue;
			Block_25:
			Type declaringType2 = 0B2C41C8.DeclaringType;
			num = 1352796408U * num;
			obj3 = Activator.CreateInstance(declaringType2, array3);
			bool flag4 = 37FA30B2 != null;
			num %= 206513564U;
			if (!flag4)
			{
				goto IL_C2D;
			}
			if (1578437230U >> (int)num != 0U)
			{
				goto Block_27;
			}
			continue;
			Block_35:
			bool isFinal = 0B2C41C8.IsFinal;
			num = 150292011U << (int)num;
			num ^= 150292011U;
			if (isFinal)
			{
				goto IL_BF7;
			}
			num = (1960728601U & num);
			if (num < 383731810U)
			{
				ParameterInfo[] array;
				int num10 = array.Length;
				num = 144925370U + num;
				int num11 = num10 + (int)(num ^ 144925371U);
				num = 984635049U % num;
				array7 = new object[num11];
				num ^= 705851215U;
				object[] array8 = array7;
				int num12 = (int)(num ^ 751724802U);
				num /= 1726234803U;
				object obj5 = obj3;
				num = 521359828U << (int)num;
				array8[num12] = obj5;
				int num13 = (int)(num + 3773607468U);
				num = (305139419U | num);
				int num14 = num13;
				if (494815203U != num)
				{
					for (;;)
					{
						num = 1904756507U % num;
						if (num << 29 == 0U)
						{
							break;
						}
						int num15 = num14;
						int num16 = array.Length;
						num /= 1013580270U;
						if (num15 >= num16)
						{
							goto Block_41;
						}
						object[] array9 = array7;
						int num17 = num14;
						int num18 = 1;
						num = 1048410681U;
						int num19 = num17 + num18;
						num = 486361099U / num;
						object[] array10 = array3;
						num = (1211700965U | num);
						object obj6 = array10[num14];
						num *= 4544417U;
						array9[num19] = obj6;
						num = 438197627U << (int)num;
						if (num > 1383405567U)
						{
							break;
						}
						int num20 = num14;
						int num21 = (int)(num - 1137422175U);
						num >>= 16;
						int num22 = num20 + num21;
						num &= 1313159406U;
						num14 = num22;
						num += 523460373U;
					}
				}
			}
		}
		throw new NullReferenceException();
		Block_27:
		bool flag5 = 37FA30B2.535FA4FE();
		num += 0U;
		if (flag5)
		{
			467F5DB3.37FA30B9 37FA30B7 = 37FA30B2;
			num |= 1012861102U;
			object obj3;
			object 4A36655E2 = obj3;
			num = 640827269U * num;
			37FA30B7.59A76885(this.147D558B(4A36655E2, 0B2C41C8.DeclaringType).6B58D7F4());
			num += 3112283034U;
			goto IL_C2D;
		}
		goto IL_C2D;
		Block_41:
		Dictionary<MethodBase, DynamicMethod> dictionary3 = 467F5DB3.480D2F8A;
		num -= 41436210U;
		Dictionary<MethodBase, DynamicMethod> dictionary4 = dictionary3;
		object obj7 = dictionary4;
		num = 1252854786U << (int)num;
		Monitor.Enter(obj7);
		DynamicMethod dynamicMethod;
		try
		{
			do
			{
				IL_6D3:
				Dictionary<MethodBase, DynamicMethod> dictionary5 = 467F5DB3.480D2F8A;
				num = 963911222U % num;
				bool flag6 = dictionary5.TryGetValue(0B2C41C8, out dynamicMethod);
				num >>= 26;
				if (!flag6)
				{
					if ((1342057343U ^ num) == 0U)
					{
						continue;
					}
					ILGenerator ilgenerator;
					for (;;)
					{
						object[] array11 = array7;
						num = 1805937263U - num;
						int num23 = array11.Length;
						num = 996807853U % num;
						int num24 = num23;
						num = (962337784U ^ num);
						Type[] array12 = new Type[num24];
						num += 2003729146U;
						Type[] array13 = array12;
						if (1038161553 << (int)num != 0)
						{
							for (;;)
							{
								IL_74C:
								Type[] array14 = array13;
								int num25 = (int)(num - 2040826447U);
								num = 933112712U + num;
								Type declaringType3 = 0B2C41C8.DeclaringType;
								num -= 2117105239U;
								array14[num25] = declaringType3;
								int num26 = (int)(num - 856833920U);
								num ^= 219500911U;
								int num27 = num26;
								if ((num ^ 116814213U) != 0U)
								{
									for (;;)
									{
										num = 401948567U * num;
										if (num << 12 == 0U)
										{
											goto IL_6D3;
										}
										int num28 = num27;
										ParameterInfo[] array;
										int num29 = array.Length;
										num = 901414354U - num;
										if (num28 >= num29)
										{
											break;
										}
										Type[] array15 = array13;
										num = 101592761U;
										int num30 = num27 + (int)(num - 101592760U);
										ParameterInfo[] array16 = array;
										num = 1402093944U / num;
										int num31 = num27;
										num = 1160999885U << (int)num;
										ParameterInfo parameterInfo2 = array16[num31];
										num = 5051788U * num;
										Type parameterType = parameterInfo2.ParameterType;
										num = 502035472U - num;
										array15[num30] = parameterType;
										num = 567307416U - num;
										if (num + 1055792840U == 0U)
										{
											goto IL_6D3;
										}
										int num32 = num27;
										int num33 = (int)(num + 2004387705U);
										num <<= 31;
										int num34 = num32 + num33;
										num = (430207032U & num);
										num27 = num34;
										num ^= 1040674543U;
									}
									num = (121188181U & num);
									string name = "";
									num = 831392348U + num;
									if (methodInfo == null)
									{
										goto IL_8A6;
									}
									MethodInfo methodInfo2 = methodInfo;
									num += 193605227U;
									Type returnType = methodInfo2.ReturnType;
									RuntimeTypeHandle handle = typeof(void).TypeHandle;
									num = 1233852564U % num;
									if (returnType == Type.GetTypeFromHandle(handle))
									{
										num += 859538737U;
										goto IL_8A6;
									}
									Type returnType2 = methodInfo.ReturnType;
									num += 859538737U;
									IL_8BD:
									num *= 777742791U;
									Type[] parameterTypes = array13;
									num = 1080117716U + num;
									RuntimeTypeHandle handle2 = typeof(467F5DB3).TypeHandle;
									num ^= 1734607581U;
									Module module = Type.GetTypeFromHandle(handle2).Module;
									bool skipVisibility = (num ^ 1876395155U) != 0U;
									num %= 1897278738U;
									DynamicMethod dynamicMethod2 = new DynamicMethod(name, returnType2, parameterTypes, module, skipVisibility);
									num %= 541793590U;
									dynamicMethod = dynamicMethod2;
									num ^= 1584689108U;
									ilgenerator = dynamicMethod.GetILGenerator();
									ILGenerator ilgenerator2 = ilgenerator;
									num /= 1933279032U;
									bool flag7 = 37FA30B2.535FA4FE();
									num = (321012720U & num);
									OpCode opcode;
									if (!flag7)
									{
										opcode = OpCodes.Ldarg;
									}
									else
									{
										num = (1679900118U ^ num);
										opcode = OpCodes.Ldarga;
										num ^= 1679900118U;
									}
									ilgenerator2.Emit(opcode, (int)(num ^ 0U));
									num += 1900112462U;
									int num35 = (int)(num ^ 1900112463U);
									for (;;)
									{
										num = 1171917782U - num;
										int num36 = num35;
										num &= 1415850145U;
										int num37 = array13.Length;
										num = 971143261U - num;
										if (num36 >= num37)
										{
											goto Block_62;
										}
										num = 951591638U;
										if (1314653043U == num)
										{
											goto IL_74C;
										}
										ILGenerator ilgenerator3 = ilgenerator;
										num = 891620841U << (int)num;
										Dictionary<int, 467F5DB3.37FA30B9> dictionary6 = dictionary;
										num = (1842966580U | num);
										OpCode opcode2;
										if (!dictionary6.ContainsKey(num35 - (int)(num - 2144956467U)))
										{
											num |= 461576999U;
											opcode2 = OpCodes.Ldarg;
										}
										else
										{
											opcode2 = OpCodes.Ldarga;
											num ^= 133891U;
										}
										ilgenerator3.Emit(opcode2, num35);
										if ((num & 1676566375U) == 0U)
										{
											goto IL_6D3;
										}
										num35 += (int)(num ^ 2145090358U);
										num ^= 244978041U;
									}
									IL_8A6:
									returnType2 = null;
									goto IL_8BD;
								}
								break;
							}
						}
					}
					Block_62:
					num = 216346495U / num;
					ILGenerator ilgenerator4 = ilgenerator;
					num &= 313398115U;
					ilgenerator4.Emit(OpCodes.Call, methodInfo);
					ILGenerator ilgenerator5 = ilgenerator;
					num *= 2070551828U;
					OpCode ret = OpCodes.Ret;
					num >>= 21;
					ilgenerator5.Emit(ret);
					Dictionary<MethodBase, DynamicMethod> dictionary7 = 467F5DB3.480D2F8A;
					DynamicMethod value = dynamicMethod;
					num = 331496274U >> (int)num;
					dictionary7[0B2C41C8] = value;
					num ^= 331496284U;
				}
			}
			while (num == 1679779719U);
		}
		finally
		{
			do
			{
				num = 682759625U;
				Monitor.Exit(dictionary4);
			}
			while (num + 1012951357U == 0U);
		}
		num = 1912671487U;
		if (num != 1973104512U)
		{
			MethodBase methodBase = dynamicMethod;
			object obj8 = null;
			object[] parameters2 = array7;
			num = (246837018U & num);
			object obj9 = methodBase.Invoke(obj8, parameters2);
			num = 1138558424U / num;
			obj4 = obj9;
			num = 598160671U << (int)num;
		}
		Dictionary<int, 467F5DB3.37FA30B9> dictionary8 = dictionary;
		num = 1429349401U >> (int)num;
		Dictionary<int, 467F5DB3.37FA30B9>.Enumerator enumerator = dictionary8.GetEnumerator();
		num %= 2112769777U;
		using (Dictionary<int, 467F5DB3.37FA30B9>.Enumerator enumerator2 = enumerator)
		{
			for (;;)
			{
				for (;;)
				{
					num &= 1873485304U;
					if (num % 888345991U == 0U)
					{
						num -= 2106554681U;
						Dictionary<int, 467F5DB3.37FA30B9>.Enumerator enumerator2;
						bool flag8 = enumerator2.MoveNext();
						num += 1261337776U;
						if (!flag8)
						{
							goto Block_66;
						}
						KeyValuePair<int, 467F5DB3.37FA30B9> keyValuePair = enumerator2.Current;
						467F5DB3.37FA30B9 value2 = keyValuePair.Value;
						object[] array17 = array7;
						int key2 = keyValuePair.Key;
						num = 25195449U;
						int num38 = (int)(num ^ 25195448U);
						num %= 589759531U;
						value2.59A76885(array17[key2 + num38]);
						num += 4269771848U;
					}
				}
			}
			Block_66:;
		}
		IL_BDB:
		Dictionary<int, 467F5DB3.37FA30B9> dictionary9 = dictionary;
		num = 305678680U;
		dictionary9.Clear();
		num ^= 305678680U;
		goto IL_C2D;
		IL_BF7:
		if ((313611436U ^ num) != 0U)
		{
			num = (41300242U ^ num);
			object obj3;
			object obj10 = obj3;
			object[] parameters3 = array3;
			num %= 64823887U;
			obj4 = 0B2C41C8.Invoke(obj10, parameters3);
			num += 4253667054U;
		}
		IL_C2D:
		num /= 1995650573U;
		if (num / 1528760801U == 0U)
		{
			Dictionary<int, 467F5DB3.37FA30B9>.Enumerator enumerator2 = dictionary.GetEnumerator();
			try
			{
				if (102647869 << (int)num != 0)
				{
				}
				for (;;)
				{
					IL_CAB:
					num = 167470064U << (int)num;
					num = (710021443U ^ num);
					bool flag9 = enumerator2.MoveNext();
					num = 2144358929U + num;
					if (!flag9)
					{
						break;
					}
					num = 883174791U;
					if (1648064379U % num != 0U)
					{
						KeyValuePair<int, 467F5DB3.37FA30B9> keyValuePair2 = enumerator2.Current;
						467F5DB3.37FA30B9 value3 = keyValuePair2.Value;
						num = 1045047001U / num;
						value3.59A76885(array3[keyValuePair2.Key]);
						num ^= 1U;
					}
				}
				goto IL_D01;
				goto IL_CAB;
			}
			finally
			{
				do
				{
					num = 1847268508U;
					((IDisposable)enumerator2).Dispose();
				}
				while (1060837363U >= num);
			}
			do
			{
				IL_D01:
				if (methodInfo != null)
				{
					num = 1758150077U;
					if (num + 773218766U == 0U)
					{
						continue;
					}
					MethodInfo methodInfo3 = methodInfo;
					num |= 1816624423U;
					Type returnType3 = methodInfo3.ReturnType;
					Type typeFromHandle = typeof(void);
					num = 2129688834U + num;
					if (returnType3 != typeFromHandle)
					{
						goto IL_D5B;
					}
				}
				num = 79179657U;
			}
			while (num >= 1729526588U);
			return null;
			IL_D5B:
			num = 321990782U + num;
			object 4A36655E3 = obj4;
			num <<= 30;
			return this.147D558B(4A36655E3, methodInfo.ReturnType);
		}
		goto IL_BDB;
	}

	// Token: 0x0600024F RID: 591 RVA: 0x0030649C File Offset: 0x0030409C
	private 467F5DB3.37FA30B9 592F513D(int 74CB52EE, bool 18537AE7)
	{
		uint num2;
		Dictionary<int, 467F5DB3.37FA30B9> dictionary;
		object[] array2;
		for (;;)
		{
			int num = this.0749791D;
			num2 = 1697015858U;
			if (635203599U < num2)
			{
				goto IL_1A;
			}
			goto IL_41;
			IL_5E:
			dictionary = new Dictionary<int, 467F5DB3.37FA30B9>();
			if (num2 << 18 != 0U)
			{
				goto IL_41;
			}
			object[] array = null;
			num2 = 1473520434U * num2;
			array2 = array;
			ushort num4;
			uint num3 = (uint)num4;
			num2 = 698842480U * num2;
			if (num3 > (num2 ^ 1828716544U))
			{
				num2 %= 1157571678U;
				int num5 = (int)num4;
				num2 = 1047735066U + num2;
				object[] array3 = new object[num5];
				num2 /= 762124549U;
				array2 = array3;
				if (num2 > 2046982591U)
				{
					continue;
				}
				int num6 = (int)num4;
				num2 = 827738636U * num2;
				int num7 = num6 - (int)(num2 + 2639490025U);
				if (num2 / 585639201U == 0U)
				{
					goto IL_1A;
				}
				for (;;)
				{
					num2 *= 147332741U;
					int num8 = num7;
					num2 = 843205027U << (int)num2;
					uint num9 = num2 ^ 2734686208U;
					num2 |= 990195309U;
					if (num8 < num9)
					{
						break;
					}
					num2 = 1840918177U;
					467F5DB3.37FA30B9 37FA30B = this.026905F8();
					num2 /= 970870891U;
					if (37FA30B.535FA4FE())
					{
						num2 = 1848586534U + num2;
						Dictionary<int, 467F5DB3.37FA30B9> dictionary2 = dictionary;
						int key = num7;
						467F5DB3.37FA30B9 value = 37FA30B;
						num2 = (1451909948U | num2);
						dictionary2[key] = value;
						num2 ^= 2125427518U;
					}
					object[] array4 = array2;
					int num10 = num7;
					num2 = (1628520969U | num2);
					num2 = (1136728931U ^ num2);
					object 4A36655E = 37FA30B;
					num2 = (1364085948U & num2);
					num2 = 1414954745U * num2;
					int 1ADD01F = this.26642191();
					num2 /= 44064566U;
					Type 78CB = this.6AA34183(1ADD01F);
					num2 ^= 96038731U;
					467F5DB3.37FA30B9 37FA30B2 = this.147D558B(4A36655E, 78CB);
					num2 = (1481788835U & num2);
					object obj = 37FA30B2.6B58D7F4();
					num2 = 12649917U % num2;
					array4[num10] = obj;
					num2 = 1535062188U / num2;
					int num11 = num7;
					int num12 = (int)(num2 ^ 1709U);
					num2 &= 1964400081U;
					int num13 = num11 - num12;
					num2 = 534531494U + num2;
					num7 = num13;
					num2 ^= 2104542782U;
				}
				num2 ^= 3590663789U;
			}
			num2 = (1332239953U | num2);
			int num14 = this.26642191();
			num2 = 1678851035U >> (int)num2;
			int num15 = num14;
			num2 = 1202790537U - num2;
			if (73821371U >> (int)num2 == 0U)
			{
				goto IL_41;
			}
			int num16 = this.0749791D;
			num2 /= 2124161311U;
			74CB52EE = num16;
			num2 = (2074893023U | num2);
			int num17 = num;
			num2 = 326061253U / num2;
			this.0749791D = num17;
			num2 = 1199657576U + num2;
			if (num2 <= 136191758U)
			{
				continue;
			}
			num2 = 1537942841U + num2;
			if (18537AE7)
			{
				if (array2 != null)
				{
					num2 = 1535263410U >> (int)num2;
					object[] array5 = array2;
					num2 ^= 47207219U;
					bool flag = array5[(int)(num2 ^ 789672554U)];
					num2 += 1947927863U;
					if (flag)
					{
						goto IL_30A;
					}
					num2 += 0U;
				}
				if (num2 >= 1892168466U)
				{
					break;
				}
				goto IL_41;
			}
			IL_30A:
			if (55196661U / num2 == 0U)
			{
				goto Block_12;
			}
			goto IL_41;
			IL_1A:
			num2 ^= 398032428U;
			int num18 = 74CB52EE;
			num2 = (769474370U & num2);
			this.0749791D = num18;
			if (num2 <= 6833406U)
			{
				goto IL_5E;
			}
			IL_41:
			num2 &= 280782935U;
			num4 = (ushort)this.534F3A25();
			num2 &= 1140468392U;
			goto IL_5E;
		}
		throw new NullReferenceException();
		Block_12:
		467F5DB3 467F5DB = new 467F5DB3();
		num2 ^= 335181355U;
		object[] 560004FE = array2;
		num2 -= 1164908817U;
		object 4A36655E2 = 467F5DB.37F432DB(560004FE, 74CB52EE);
		Dictionary<int, 467F5DB3.37FA30B9>.Enumerator enumerator = dictionary.GetEnumerator();
		try
		{
			if (1927641317 << (int)num2 != 0)
			{
				goto IL_356;
			}
			KeyValuePair<int, 467F5DB3.37FA30B9> keyValuePair2;
			do
			{
				IL_35B:
				KeyValuePair<int, 467F5DB3.37FA30B9> keyValuePair = enumerator.Current;
				num2 = 1849720793U;
				keyValuePair2 = keyValuePair;
				num2 = 2033464793U * num2;
			}
			while ((num2 ^ 2021809568U) == 0U);
			num2 = (363363268U & num2);
			467F5DB3.37FA30B9 value2 = keyValuePair2.Value;
			num2 <<= 9;
			value2.59A76885(array2[keyValuePair2.Key]);
			num2 += 449800313U;
			IL_356:
			num2 <<= 12;
			if (enumerator.MoveNext())
			{
				goto IL_35B;
			}
			if (585574804U >> (int)num2 == 0U)
			{
				goto IL_356;
			}
		}
		finally
		{
			num2 = 1120942363U;
			num2 = 122833403U + num2;
			((IDisposable)enumerator).Dispose();
		}
		num2 = 1546676969U;
		Type type2;
		if (1522559609U < num2)
		{
			int num15;
			if (num15 == 0)
			{
				goto IL_49A;
			}
			num2 = (632385445U ^ num2);
			Type type = this.6AA34183(num15);
			num2 >>= 19;
			type2 = type;
			num2 *= 1278957580U;
		}
		Type type3 = type2;
		num2 |= 746013999U;
		RuntimeTypeHandle handle = typeof(void).TypeHandle;
		num2 = 707538974U + num2;
		Type typeFromHandle = Type.GetTypeFromHandle(handle);
		num2 = 908802784U - num2;
		num2 ^= 1112537530U;
		if (type3 == typeFromHandle)
		{
			goto IL_49A;
		}
		num2 += 356456743U;
		if (num2 >> 13 == 0U)
		{
			goto IL_49A;
		}
		IL_490:
		return this.147D558B(4A36655E2, type2);
		IL_49A:
		num2 = (1114048056U & num2);
		if (894980766U < num2)
		{
			return null;
		}
		goto IL_490;
	}

	// Token: 0x06000250 RID: 592 RVA: 0x00306978 File Offset: 0x00304578
	private bool 5E751AD4(object 04513854, Type 40793CAF)
	{
		uint num = 1510808620U;
		Type type2;
		for (;;)
		{
			num = (477985618U | num);
			if (04513854 == null)
			{
				break;
			}
			num = 1662263890U + num;
			if (671943955U > num)
			{
				goto IL_BE;
			}
			num = (52782767U ^ num);
			Type type = 04513854.GetType();
			num = 297034993U / num;
			type2 = type;
			if (num <= 643511035U)
			{
				Type type3 = type2;
				num += 1622105914U;
				num |= 1315970560U;
				if (type3 == 40793CAF)
				{
					goto IL_B6;
				}
				num = 1574457157U * num;
				if (1310536168U + num != 0U)
				{
					goto Block_5;
				}
			}
		}
		num = 1561991222U + num;
		return num - 3147274163U != 0U;
		Block_5:
		num = (1467556501U | num);
		Type c = type2;
		num = 1961253791U >> (int)num;
		bool flag = 40793CAF.IsAssignableFrom(c);
		num |= 1175088218U;
		if (!flag)
		{
			goto IL_BE;
		}
		num ^= 687158209U;
		IL_B6:
		return num + 2432737479U != 0U;
		IL_BE:
		num = (166005509U | num);
		return (num ^ 1341091839U) != 0U;
	}

	// Token: 0x06000251 RID: 593 RVA: 0x00306A54 File Offset: 0x00304654
	private void 2D1405EA(Exception 46903814)
	{
		uint num;
		for (;;)
		{
			IL_00:
			num = 887227335U;
			this.65EB1F68.Clear();
			num = 1383216567U << (int)num;
			if (num * 1372001776U != 0U)
			{
				goto IL_2F;
			}
			467F5DB3.42FB763B 42FB763B2;
			for (;;)
			{
				IL_4E:
				if (this.58991615 == null)
				{
					if ((num ^ 572292700U) == 0U)
					{
						goto IL_00;
					}
					this.65D141FE = 46903814;
					if (num == 624785979U)
					{
						goto IL_00;
					}
					num ^= 0U;
				}
				IL_5D3:
				while ((num ^ 1371491053U) != 0U)
				{
					Stack<467F5DB3.74D46A00> stack = this.7E2027B1;
					num = 672753412U - num;
					bool count = stack.Count != 0;
					num = (1835336492U | num);
					if (!count)
					{
						goto Block_30;
					}
					for (;;)
					{
						num = 447225432U;
						if (num << 30 != 0U)
						{
							goto IL_00;
						}
						Stack<467F5DB3.74D46A00> stack2 = this.7E2027B1;
						num = 430073161U * num;
						467F5DB3.74D46A00 74D46A = stack2.Peek();
						num &= 2107733530U;
						List<467F5DB3.42FB763B> list = 74D46A.5A314F34();
						int num2;
						if (this.58991615 != null)
						{
							num &= 998861018U;
							List<467F5DB3.42FB763B> list2 = list;
							467F5DB3.42FB763B item = this.58991615;
							num = 488985760U << (int)num;
							num2 = list2.IndexOf(item) + (int)(num ^ 2684354561U);
						}
						else
						{
							num -= 1623722152U;
							num2 = (int)(num + 658944656U);
							num ^= 2025409904U;
						}
						this.58991615 = null;
						int num3 = num2;
						if (num <= 1180526686U)
						{
							goto IL_2F;
						}
						for (;;)
						{
							num &= 143816037U;
							if (963468518U == num)
							{
								goto IL_00;
							}
							if (num3 >= list.Count)
							{
								break;
							}
							num = 973751993U;
							List<467F5DB3.42FB763B> list3 = list;
							int index = num3;
							num = (833031764U | num);
							467F5DB3.42FB763B 42FB763B = list3[index];
							num = 46156179U >> (int)num;
							42FB763B2 = 42FB763B;
							num &= 1592019749U;
							467F5DB3.42FB763B 42FB763B3 = 42FB763B2;
							num ^= 667511401U;
							byte b = 42FB763B3.725458AE();
							num &= 880242373U;
							byte b2 = b;
							if (num == 685462181U)
							{
								goto IL_00;
							}
							if (b2 != 0)
							{
								byte b3 = b2;
								uint num4 = num ^ 608266816U;
								num = 121570908U + num;
								if (b3 == num4)
								{
									goto IL_2EA;
								}
							}
							else
							{
								if (1457784776U == num)
								{
									goto IL_2F;
								}
								Type type = 46903814.GetType();
								num = 433144701U << (int)num;
								Type type2 = type;
								if (1194992004U == num)
								{
									goto IL_00;
								}
								467F5DB3.42FB763B 42FB763B4 = 42FB763B2;
								num >>= 14;
								int 1ADD01F = 42FB763B4.23206D20();
								num = 160524130U * num;
								Type type3 = this.6AA34183(1ADD01F);
								num = 1357068646U * num;
								Type type4 = type3;
								num = 1596466161U >> (int)num;
								if ((num ^ 2003304561U) == 0U)
								{
									goto IL_00;
								}
								if (type2 == type4)
								{
									goto IL_270;
								}
								if (1298822471U * num == 0U)
								{
									goto IL_00;
								}
								Type type5 = type2;
								Type c = type4;
								num |= 1338445677U;
								bool flag = type5.IsSubclassOf(c);
								num += 3686359326U;
								if (flag)
								{
									goto Block_14;
								}
							}
							num = 807538335U >> (int)num;
							if (1134567222U % num != 0U)
							{
								goto IL_2F;
							}
							int num5 = num3;
							num /= 314597012U;
							int num6 = num5 + (int)(num + 1U);
							num += 18366944U;
							num3 = num6;
							num ^= 2702721504U;
						}
						num = 534906708U - num;
						if (num >= 647572322U)
						{
							break;
						}
						num = 1532510654U % num;
						Stack<467F5DB3.74D46A00> stack3 = this.7E2027B1;
						num = 679361788U + num;
						stack3.Pop();
						num &= 926232345U;
						int num7 = list.Count;
						for (;;)
						{
							num |= 1770793061U;
							int num8 = num7;
							uint num9 = num + 2456016779U;
							num |= 179244746U;
							if (num8 <= num9)
							{
								break;
							}
							num = 1509580170U;
							List<467F5DB3.42FB763B> list4 = list;
							int num10 = num7;
							int num11 = (int)(num - 1509580169U);
							num = 165640444U << (int)num;
							467F5DB3.42FB763B 42FB763B5 = list4[num10 - num11];
							num >>= 14;
							467F5DB3.42FB763B 42FB763B6 = 42FB763B5;
							num = 571239792U + num;
							467F5DB3.42FB763B 42FB763B7 = 42FB763B6;
							num = 524227230U + num;
							byte b4 = 42FB763B7.725458AE();
							uint num12 = num ^ 1095595935U;
							num >>= 11;
							if (b4 == num12)
							{
								goto IL_4B2;
							}
							num += 1669019433U;
							467F5DB3.42FB763B 42FB763B8 = 42FB763B6;
							num &= 1608480110U;
							uint num13 = (uint)42FB763B8.725458AE();
							num = 2025154655U << (int)num;
							if (num13 == (num ^ 760879044U))
							{
								num ^= 760364654U;
								goto IL_4B2;
							}
							IL_4F5:
							if (num < 2098284840U)
							{
								int num14 = num7;
								int num15 = (int)(num + 3534088257U);
								num *= 1104576039U;
								int num16 = num14 - num15;
								num = 771429108U / num;
								num7 = num16;
								num ^= 68165648U;
								continue;
							}
							goto IL_4E;
							IL_4B2:
							num = (1888581501U | num);
							Stack<int> stack4 = this.456178D7;
							num = (1371481929U | num);
							467F5DB3.42FB763B 42FB763B9 = 42FB763B6;
							num |= 251354175U;
							int item2 = 42FB763B9.012472E6();
							num /= 1359815813U;
							stack4.Push(item2);
							num += 760879039U;
							goto IL_4F5;
						}
						num = (302133147U & num);
						if (130643891U + num == 0U)
						{
							goto IL_00;
						}
						Stack<int> stack5 = this.456178D7;
						num = 175640079U - num;
						bool count2 = stack5.Count != 0;
						num -= 2017724553U;
						num += 2469165059U;
						if (!count2)
						{
							break;
						}
						if (2146715131U > num)
						{
							goto Block_27;
						}
					}
				}
				continue;
				goto IL_5D3;
			}
			IL_270:
			num = (534267707U ^ num);
			this.7E2027B1.Pop();
			num = 1673552466U << (int)num;
			Stack<467F5DB3.371F2AF7> stack6 = this.65EB1F68;
			num = 2020896663U >> (int)num;
			num = (227428480U & num);
			stack6.Push(new 467F5DB3.4CF55D0F(this.65D141FE));
			num = 1610636947U / num;
			this.0749791D = 42FB763B2.012472E6();
			if (834105744U != num)
			{
				break;
			}
			continue;
			Block_14:
			num += 3565129666U;
			goto IL_270;
			Block_27:
			num = 1544752684U + num;
			int num17 = this.456178D7.Pop();
			num -= 1528369049U;
			this.0749791D = num17;
			if ((num ^ 611603930U) != 0U)
			{
				return;
			}
			goto IL_2F;
			IL_2EA:
			this.58991615 = 42FB763B2;
			num += 1494286490U;
			num -= 2114023881U;
			Stack<467F5DB3.371F2AF7> stack7 = this.65EB1F68;
			467F5DB3.371F2AF7 item3 = new 467F5DB3.4CF55D0F(this.65D141FE);
			num *= 1576995752U;
			stack7.Push(item3);
			num = (326181850U & num);
			num ^= 1443636631U;
			this.0749791D = 42FB763B2.23206D20();
			if (num / 1799907520U == 0U)
			{
				return;
			}
			IL_2F:
			num /= 449674739U;
			Stack<int> stack8 = this.456178D7;
			num = (593383150U | num);
			stack8.Clear();
			goto IL_4E;
		}
		return;
		Block_30:
		num = 1155427617U + num;
		throw 46903814;
	}

	// Token: 0x06000252 RID: 594 RVA: 0x00307070 File Offset: 0x00304C70
	private void 5B954D41()
	{
		for (;;)
		{
			uint num = 1773490994U;
			num = 903098909U % num;
			Type type = this.6AA34183(this.026905F8().D6BFBC24());
			num = 1325098645U % num;
			Type 78CB = type;
			467F5DB3.37FA30B9 37FA30B2;
			if (1654683249U > num)
			{
				num = 1005675904U >> (int)num;
				467F5DB3.37FA30B9 37FA30B = this.026905F8();
				num %= 441856201U;
				37FA30B2 = 37FA30B;
				num = 1198868201U * num;
			}
			467F5DB3.37FA30B9 37FA30B3 = this.026905F8();
			num <<= 16;
			467F5DB3.37FA30B9 37FA30B4 = this.147D558B(37FA30B3.6B58D7F4(), 78CB);
			num = (1556619657U & num);
			if (37FA30B2.535FA4FE())
			{
				if (867369584U == num)
				{
					continue;
				}
				467F5DB3.37FA30B9 5FA538FB = 37FA30B4;
				num = (966092251U & num);
				467F5DB3.37FA30B9 5D = 37FA30B2;
				num += 435560022U;
				37FA30B4 = new 467F5DB3.05DF5272(5FA538FB, 5D);
				num += 705290666U;
			}
			if (2146173181U > num)
			{
				List<467F5DB3.37FA30B9> list = this.311B0F7E;
				num = (1128497061U ^ num);
				467F5DB3.37FA30B9 item = 37FA30B4;
				num = 104749285U / num;
				list.Add(item);
				if (num <= 1405766955U)
				{
					break;
				}
			}
		}
	}

	// Token: 0x06000253 RID: 595 RVA: 0x00307160 File Offset: 0x00304D60
	private void 26A23C05()
	{
		uint num = 427704112U;
		num <<= 6;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = (28512849U | num);
		int num2 = 37FA30B.D6BFBC24();
		num = 770050217U - num;
		num = 629299775U + num;
		List<467F5DB3.74D46A00> list = this.69866088;
		num = (1918526963U | num);
		List<467F5DB3.74D46A00>.Enumerator enumerator = list.GetEnumerator();
		num = 1328239634U - num;
		using (List<467F5DB3.74D46A00>.Enumerator enumerator2 = enumerator)
		{
			do
			{
				for (;;)
				{
					num = 1598647077U + num;
					if (429664823U <= num)
					{
						num %= 177163411U;
						if (!enumerator2.MoveNext())
						{
							break;
						}
					}
					467F5DB3.74D46A00 74D46A = enumerator2.Current;
					num = 166989415U;
					467F5DB3.74D46A00 74D46A2 = 74D46A;
					467F5DB3.74D46A00 74D46A3 = 74D46A2;
					num /= 1606054040U;
					int num3 = 74D46A3.40532304();
					num += 1974211917U;
					int num4 = num2;
					num = (1706717169U ^ num);
					num ^= 1260786855U;
					if (num3 == num4)
					{
						num -= 759914635U;
						Stack<467F5DB3.74D46A00> stack = this.7E2027B1;
						num = (510218523U | num);
						stack.Push(74D46A2);
						num ^= 1692218240U;
					}
				}
			}
			while ((833691657U & num) == 0U);
		}
	}

	// Token: 0x06000254 RID: 596 RVA: 0x00307288 File Offset: 0x00304E88
	private void 513A23AF()
	{
		uint num = 444141195U;
		do
		{
			num += 1035802842U;
			num = (1045906780U ^ num);
			int 0A = this.26642191();
			num |= 894330875U;
			this.154055D0(new 467F5DB3.1C0911B0(0A));
		}
		while ((1076777905U ^ num) == 0U);
	}

	// Token: 0x06000255 RID: 597 RVA: 0x003072D0 File Offset: 0x00304ED0
	private void 7F851614()
	{
		uint num = 1093730784U;
		if (1804817331U + num != 0U)
		{
			do
			{
				long 0E0B = this.49C337B0();
				num *= 1193097063U;
				this.154055D0(new 467F5DB3.06E010E5(0E0B));
			}
			while (969031144 << (int)num == 0);
		}
	}

	// Token: 0x06000256 RID: 598 RVA: 0x0030731C File Offset: 0x00304F1C
	private void 29262CE3()
	{
		uint num;
		do
		{
			num = 2048874869U;
			num = 1785996206U << (int)num;
			this.154055D0(new 467F5DB3.3D312057(this.5F4C6581()));
		}
		while (2147355162U < num);
	}

	// Token: 0x06000257 RID: 599 RVA: 0x0030735C File Offset: 0x00304F5C
	private void 6740321F()
	{
		uint num;
		do
		{
			num = 1953962907U;
			double 7E9E = this.28373AC1();
			num = (2147418683U | num);
			467F5DB3.37FA30B9 19D13A = new 467F5DB3.07A85735(7E9E);
			num = 1775960938U / num;
			this.154055D0(19D13A);
		}
		while (66995549U >> (int)num == 0U);
	}

	// Token: 0x06000258 RID: 600 RVA: 0x003073A4 File Offset: 0x00304FA4
	private void 438B5959()
	{
		uint num = 1019168565U;
		if (140058390U >> (int)num != 0U)
		{
			do
			{
				num = 976710384U / num;
				object <<EMPTY_NAME>> = null;
				num = 614340304U >> (int)num;
				467F5DB3.37FA30B9 19D13A = new 467F5DB3.4CF55D0F(<<EMPTY_NAME>>);
				num = (1575966554U & num);
				this.154055D0(19D13A);
			}
			while (num == 62543436U);
		}
	}

	// Token: 0x06000259 RID: 601 RVA: 0x00307400 File Offset: 0x00305000
	private void 192C77AD()
	{
		uint num;
		do
		{
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = 1560766243U;
			int 013E = 37FA30B.D6BFBC24();
			num = 134640942U * num;
			467F5DB3.37FA30B9 19D13A = new 467F5DB3.32D66DFC(this.45DF429C(013E));
			num /= 652551255U;
			this.154055D0(19D13A);
		}
		while (num >= 1444173564U);
	}

	// Token: 0x0600025A RID: 602 RVA: 0x0030744C File Offset: 0x0030504C
	private void 5D2B58DB()
	{
		uint num = 1987535050U;
		if ((140378158U ^ num) != 0U)
		{
			num = (649995042U ^ num);
			num = (330892849U & num);
			this.154055D0(this.22AC4C1B().15FAD4A1());
		}
	}

	// Token: 0x0600025B RID: 603 RVA: 0x0030748C File Offset: 0x0030508C
	private void 13BD01F0()
	{
		uint num = 882336408U;
		for (;;)
		{
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num %= 2052723823U;
			467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
			num -= 1041642698U;
			if ((1119447537U ^ num) != 0U)
			{
				467F5DB3.37FA30B9 37FA30B3 = this.026905F8();
				if ((873072193U & num) == 0U)
				{
					break;
				}
				num >>= 14;
				467F5DB3.37FA30B9 028635D = 37FA30B2;
				467F5DB3.37FA30B9 554A74F = 37FA30B3;
				bool 5D63497E = num + 4294714876U != 0U;
				num &= 1805460179U;
				bool 61D25C = num + 4294901248U != 0U;
				num <<= 8;
				this.154055D0(this.5A457CFC(028635D, 554A74F, 5D63497E, 61D25C));
				if (num < 1415011860U)
				{
					break;
				}
			}
		}
	}

	// Token: 0x0600025C RID: 604 RVA: 0x00307514 File Offset: 0x00305114
	private void 20BE7653()
	{
		uint num = 1239048179U;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = 285373686U << (int)num;
		467F5DB3.37FA30B9 37FA30B3;
		if (1454528919U <= num)
		{
			467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
			num = 646741633U + num;
			37FA30B3 = 37FA30B2;
			if (num * 1051215988U == 0U)
			{
				return;
			}
		}
		num = (1890992164U ^ num);
		467F5DB3.37FA30B9 028635D = 37FA30B;
		467F5DB3.37FA30B9 554A74F = 37FA30B3;
		num -= 2081776903U;
		467F5DB3.37FA30B9 19D13A = this.5A457CFC(028635D, 554A74F, (num ^ 1114954143U) != 0U, (num ^ 1114954142U) != 0U);
		num |= 572745842U;
		this.154055D0(19D13A);
	}

	// Token: 0x0600025D RID: 605 RVA: 0x00307598 File Offset: 0x00305198
	private void 55087A3D()
	{
		uint num;
		467F5DB3.37FA30B9 37FA30B;
		do
		{
			num = 1141322550U;
			37FA30B = this.026905F8();
		}
		while (1523609851U <= num);
		num = 1173309543U << (int)num;
		467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
		num = 1951999008U << (int)num;
		467F5DB3.37FA30B9 554A74F = 37FA30B2;
		num >>= 27;
		num = 1886920683U * num;
		num = 2111205893U + num;
		467F5DB3.37FA30B9 028635D = 37FA30B;
		num = (68758403U ^ num);
		this.154055D0(this.5A457CFC(028635D, 554A74F, (num ^ 2691767133U) != 0U, (num ^ 2691767133U) != 0U));
	}

	// Token: 0x0600025E RID: 606 RVA: 0x0030761C File Offset: 0x0030521C
	private void 679465DE()
	{
		uint num;
		do
		{
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = 1428430510U;
			467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
			num = 1834384448U / num;
			467F5DB3.37FA30B9 37FA30B3 = this.026905F8();
			num %= 952597338U;
			467F5DB3.37FA30B9 37FA30B4 = 37FA30B3;
			num = 851315824U + num;
			467F5DB3.37FA30B9 57ED = 37FA30B4;
			467F5DB3.37FA30B9 294D2B = 37FA30B2;
			bool 41EF20FB = num - 851315825U != 0U;
			num >>= 24;
			this.154055D0(this.510E58E5(57ED, 294D2B, 41EF20FB, num - 50U != 0U));
		}
		while ((num ^ 557727427U) == 0U);
	}

	// Token: 0x0600025F RID: 607 RVA: 0x00307688 File Offset: 0x00305288
	private void 408276BF()
	{
		uint num = 1858540600U;
		if (256770640U >> (int)num != 0U)
		{
			467F5DB3.37FA30B9 37FA30B;
			do
			{
				num = (2095742068U | num);
				37FA30B = this.026905F8();
				num *= 1966031033U;
			}
			while (num + 682765213U == 0U);
			num += 621480032U;
			467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
			num = 2013938008U % num;
			467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
			num = 1292389845U + num;
			467F5DB3.37FA30B9 57ED = 37FA30B3;
			467F5DB3.37FA30B9 294D2B = 37FA30B;
			num %= 982916613U;
			bool 41EF20FB = (num ^ 166155558U) != 0U;
			bool 707F032B = (num ^ 166155559U) != 0U;
			num = 1090286073U >> (int)num;
			this.154055D0(this.510E58E5(57ED, 294D2B, 41EF20FB, 707F032B));
		}
	}

	// Token: 0x06000260 RID: 608 RVA: 0x00307724 File Offset: 0x00305324
	private void 6D7B3921()
	{
		uint num;
		do
		{
			num = 564077071U;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num /= 624843545U;
			467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
			num ^= 1370432346U;
			467F5DB3.37FA30B9 37FA30B3 = this.026905F8();
			num |= 364986658U;
			num -= 1662081827U;
			467F5DB3.37FA30B9 57ED = 37FA30B3;
			467F5DB3.37FA30B9 294D2B = 37FA30B2;
			bool 41EF20FB = (num ^ 4074637398U) != 0U;
			num *= 2064649006U;
			bool 707F032B = (num ^ 2159099043U) != 0U;
			num = 1619341625U % num;
			467F5DB3.37FA30B9 19D13A = this.510E58E5(57ED, 294D2B, 41EF20FB, 707F032B);
			num <<= 0;
			this.154055D0(19D13A);
		}
		while ((2060871004U ^ num) == 0U);
	}

	// Token: 0x06000261 RID: 609 RVA: 0x003077A8 File Offset: 0x003053A8
	private void 120B316B()
	{
		uint num = 771120990U;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = 944660457U >> (int)num;
		do
		{
			467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
			num += 836919095U;
			467F5DB3.37FA30B9 31EF71FB = 37FA30B2;
			467F5DB3.37FA30B9 0AC13BDD = 37FA30B;
			num ^= 1590694500U;
			this.154055D0(this.4B295531(31EF71FB, 0AC13BDD, num - 1865567571U != 0U, (num ^ 1865567571U) != 0U));
		}
		while (num < 166356849U);
	}

	// Token: 0x06000262 RID: 610 RVA: 0x00307810 File Offset: 0x00305410
	private void 7BE36DE0()
	{
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		uint num = 686297993U;
		467F5DB3.37FA30B9 0AC13BDD = 37FA30B;
		num >>= 8;
		467F5DB3.37FA30B9 37FA30B2;
		if (267990972U - num != 0U)
		{
			num = 1720862029U * num;
			37FA30B2 = this.026905F8();
			num %= 2098730185U;
			if ((num ^ 1466176217U) == 0U)
			{
				return;
			}
		}
		num = (2011903658U & num);
		467F5DB3.37FA30B9 31EF71FB = 37FA30B2;
		num = 74338451U - num;
		467F5DB3.37FA30B9 19D13A = this.4B295531(31EF71FB, 0AC13BDD, num - 4277030514U != 0U, num + 17936781U != 0U);
		num /= 1636501549U;
		this.154055D0(19D13A);
	}

	// Token: 0x06000263 RID: 611 RVA: 0x00307898 File Offset: 0x00305498
	private void 022B2B36()
	{
		uint num = 940114030U;
		do
		{
			num = 511839108U % num;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num /= 1066754679U;
			467F5DB3.37FA30B9 0AC13BDD = 37FA30B;
			num = 924939444U >> (int)num;
			if (1349337885U < num)
			{
				break;
			}
			467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
			num *= 1798451333U;
			467F5DB3.37FA30B9 31EF71FB = 37FA30B2;
			num = 1922577340U << (int)num;
			467F5DB3.37FA30B9 19D13A = this.4B295531(31EF71FB, 0AC13BDD, (num ^ 696466369U) != 0U, (num ^ 696466369U) != 0U);
			num = (356538477U & num);
			this.154055D0(19D13A);
		}
		while (num + 1797401376U == 0U);
	}

	// Token: 0x06000264 RID: 612 RVA: 0x00307928 File Offset: 0x00305528
	private void 50404ACC()
	{
		uint num = 1681661465U;
		467F5DB3.37FA30B9 37FA30B;
		if (1193178260U < num)
		{
			do
			{
				num = 1669076070U / num;
				37FA30B = this.026905F8();
				num &= 1262504584U;
			}
			while (1372742189U <= num);
		}
		do
		{
			467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
			num %= 2103722253U;
			467F5DB3.37FA30B9 6002106F = 37FA30B2;
			num = (1247813119U ^ num);
			467F5DB3.37FA30B9 11DD699E = 37FA30B;
			bool 51AE = (num ^ 1247813119U) != 0U;
			num = (2116903738U | num);
			467F5DB3.37FA30B9 19D13A = this.5A115239(6002106F, 11DD699E, 51AE);
			num += 1650026012U;
			this.154055D0(19D13A);
		}
		while (num == 822106314U);
	}

	// Token: 0x06000265 RID: 613 RVA: 0x003079B0 File Offset: 0x003055B0
	private void 7F9B0F86()
	{
		uint num = 1970997950U;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = 1615486800U + num;
		467F5DB3.37FA30B9 37FA30B2;
		if (num >= 1106995316U)
		{
			num = 889589204U >> (int)num;
			37FA30B2 = this.026905F8();
		}
		467F5DB3.37FA30B9 6002106F = 37FA30B2;
		num = 316242923U + num;
		467F5DB3.37FA30B9 11DD699E = 37FA30B;
		bool 51AE = num + 3978670078U != 0U;
		num = (1156323721U | num);
		this.154055D0(this.5A115239(6002106F, 11DD699E, 51AE));
	}

	// Token: 0x06000266 RID: 614 RVA: 0x00307A18 File Offset: 0x00305618
	private void 41B07E9D()
	{
		uint num;
		467F5DB3.37FA30B9 2BD35DFD;
		do
		{
			num = 2145671872U;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num <<= 25;
			2BD35DFD = 37FA30B;
			num -= 913800854U;
		}
		while (num - 1777892211U == 0U);
		467F5DB3.37FA30B9 5A597AE = this.026905F8();
		do
		{
			num = 400386047U % num;
			this.154055D0(this.465A415C(5A597AE, 2BD35DFD, num + 3894581249U != 0U));
		}
		while (508952675U - num == 0U);
	}

	// Token: 0x06000267 RID: 615 RVA: 0x00307A80 File Offset: 0x00305680
	private void 22076BE7()
	{
		uint num = 223637092U;
		467F5DB3.37FA30B9 37FA30B2;
		467F5DB3.37FA30B9 37FA30B4;
		do
		{
			num += 1417086223U;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = 1642858615U >> (int)num;
			37FA30B2 = 37FA30B;
			num /= 591934140U;
			num += 871842337U;
			467F5DB3.37FA30B9 37FA30B3 = this.026905F8();
			num = (47532681U | num);
			37FA30B4 = 37FA30B3;
			num *= 1320501248U;
		}
		while (1927090483U == num);
		num = 1083327423U % num;
		467F5DB3.37FA30B9 5A597AE = 37FA30B4;
		467F5DB3.37FA30B9 2BD35DFD = 37FA30B2;
		bool 42B = num - 205767614U != 0U;
		num = 1866740495U * num;
		this.154055D0(this.465A415C(5A597AE, 2BD35DFD, 42B));
	}

	// Token: 0x06000268 RID: 616 RVA: 0x00307B08 File Offset: 0x00305708
	private void 69DE3561()
	{
		uint num = 1134637399U;
		467F5DB3.37FA30B9 <<EMPTY_NAME>>;
		do
		{
			num %= 177367716U;
			<<EMPTY_NAME>> = this.026905F8();
		}
		while (822300830U <= num);
		467F5DB3.37FA30B9 3F1F22AE = this.026905F8();
		num = 1770921903U % num;
		this.154055D0(this.1DF7021C(3F1F22AE, <<EMPTY_NAME>>));
	}

	// Token: 0x06000269 RID: 617 RVA: 0x00307B54 File Offset: 0x00305754
	private void 3A121000()
	{
		uint num = 1853491901U;
		for (;;)
		{
			num = (1978930374U | num);
			467F5DB3.37FA30B9 259A21F = this.026905F8();
			if (760695105U > num)
			{
				goto IL_3A;
			}
			IL_20:
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num >>= 24;
			if (319889093U == num)
			{
				continue;
			}
			IL_3A:
			num += 1057842449U;
			467F5DB3.37FA30B9 4DC21A = 37FA30B;
			num = (1795515590U | num);
			467F5DB3.37FA30B9 19D13A = this.06B105FE(4DC21A, 259A21F);
			num = (478227504U | num);
			this.154055D0(19D13A);
			if (num >= 246024551U)
			{
				break;
			}
			goto IL_20;
		}
	}

	// Token: 0x0600026A RID: 618 RVA: 0x00307BCC File Offset: 0x003057CC
	private void 55261814()
	{
		uint num = 1274944902U;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = 1906328934U - num;
		467F5DB3.37FA30B9 5BC111E = 37FA30B;
		num = 428500139U / num;
		467F5DB3.37FA30B9 055A;
		if (100808471U >> (int)num != 0U)
		{
			055A = this.026905F8();
		}
		num &= 165828268U;
		467F5DB3.37FA30B9 19D13A = this.429B3EBB(055A, 5BC111E);
		num = (1406151080U & num);
		this.154055D0(19D13A);
	}

	// Token: 0x0600026B RID: 619 RVA: 0x00307C30 File Offset: 0x00305830
	private void 229B29C5()
	{
		uint num = 1751205902U;
		if (1876720920U != num)
		{
			num -= 1710369131U;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num >>= 21;
			num <<= 21;
			467F5DB3.37FA30B9 09FF2D = 37FA30B;
			num &= 1740580697U;
			467F5DB3.37FA30B9 19D13A = this.0DDB11CD(09FF2D);
			num = 2066636052U << (int)num;
			this.154055D0(19D13A);
		}
	}

	// Token: 0x0600026C RID: 620 RVA: 0x00307C90 File Offset: 0x00305890
	private void 7DFA6A70()
	{
		uint num = 172689941U;
		467F5DB3.37FA30B9 7BDC = this.026905F8();
		num &= 1172573218U;
		467F5DB3.37FA30B9 19D13A = this.5B8857D3(7BDC);
		num -= 1263156723U;
		this.154055D0(19D13A);
	}

	// Token: 0x0600026D RID: 621 RVA: 0x00307CC8 File Offset: 0x003058C8
	private void 373E71EE()
	{
		uint num;
		467F5DB3.37FA30B9 37FA30B2;
		467F5DB3.37FA30B9 37FA30B3;
		do
		{
			num = 1398491776U;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = 1281116279U % num;
			37FA30B2 = 37FA30B;
			num &= 1738882029U;
			37FA30B3 = this.026905F8();
			num %= 274345798U;
		}
		while (num + 408879826U == 0U);
		467F5DB3.37FA30B9 04645AFA = 37FA30B3;
		num = (1175280559U & num);
		467F5DB3.37FA30B9 296662CB = 37FA30B2;
		num <<= 2;
		467F5DB3.37FA30B9 19D13A = this.07EA346F(04645AFA, 296662CB, num + 4158313420U != 0U);
		num ^= 1575513788U;
		this.154055D0(19D13A);
	}

	// Token: 0x0600026E RID: 622 RVA: 0x00307D3C File Offset: 0x0030593C
	private void 17843B06()
	{
		uint num = 1012863702U;
		if (num + 1291670337U == 0U)
		{
			goto IL_3D;
		}
		467F5DB3.37FA30B9 296662CB;
		do
		{
			IL_12:
			num |= 2002467621U;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = 1768388849U / num;
			296662CB = 37FA30B;
			num = (322383826U & num);
		}
		while ((353108366U ^ num) == 0U);
		IL_3D:
		467F5DB3.37FA30B9 04645AFA = this.026905F8();
		num %= 557407260U;
		num *= 1095391115U;
		467F5DB3.37FA30B9 19D13A = this.07EA346F(04645AFA, 296662CB, num + 1U != 0U);
		num *= 1082881536U;
		this.154055D0(19D13A);
		if ((2048674735U ^ num) != 0U)
		{
			return;
		}
		goto IL_12;
	}

	// Token: 0x0600026F RID: 623 RVA: 0x00307DC8 File Offset: 0x003059C8
	private void 141E7CA7()
	{
		uint num = 1837964672U;
		467F5DB3.37FA30B9 37FA30B2;
		467F5DB3.37FA30B9 37FA30B4;
		do
		{
			num = (2002483525U | num);
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num %= 1653765158U;
			37FA30B2 = 37FA30B;
			if (num - 1619993716U == 0U)
			{
				return;
			}
			num %= 665681149U;
			467F5DB3.37FA30B9 37FA30B3 = this.026905F8();
			num = (969881184U & num);
			37FA30B4 = 37FA30B3;
		}
		while (600863539U == num);
		num = 212277508U % num;
		467F5DB3.37FA30B9 521B669F = 37FA30B4;
		467F5DB3.37FA30B9 13FC36DF = 37FA30B2;
		num += 290210150U;
		467F5DB3.37FA30B9 19D13A = this.357227E7(521B669F, 13FC36DF);
		num = (1219252771U ^ num);
		this.154055D0(19D13A);
	}

	// Token: 0x06000270 RID: 624 RVA: 0x00307E48 File Offset: 0x00305A48
	private void 6B8C598E()
	{
		uint num = 1722429909U;
		if (num != 173830761U)
		{
			do
			{
				int 1ADD01F = this.026905F8().D6BFBC24();
				num = 55330202U / num;
				Type type = this.6AA34183(1ADD01F);
				num &= 1039099135U;
				Type 78CB = type;
				num = 1627993015U * num;
				this.154055D0(this.147D558B(this.026905F8(), 78CB));
			}
			while (2002125694U - num == 0U);
		}
	}

	// Token: 0x06000271 RID: 625 RVA: 0x00307EB0 File Offset: 0x00305AB0
	private void 02E20289()
	{
		uint num = 50595766U;
		int 1ADD01F = this.026905F8().D6BFBC24();
		num = 926375771U % num;
		Type type = this.6AA34183(1ADD01F);
		num = 508060886U - num;
		Type type2 = type;
		num *= 1934497194U;
		num = 1133190845U * num;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = 1957828239U * num;
		Type 21146C = type2;
		bool 72846F = (num ^ 1197060562U) != 0U;
		num &= 1943175150U;
		object 4A36655E = 37FA30B.F187362C(21146C, 72846F);
		Type 78CB = type2;
		num *= 1470921969U;
		this.154055D0(this.147D558B(4A36655E, 78CB));
	}

	// Token: 0x06000272 RID: 626 RVA: 0x00307F30 File Offset: 0x00305B30
	private void 4F9D077C()
	{
		uint num = 1529903959U;
		if (1598169183U <= num)
		{
			goto IL_33;
		}
		IL_11:
		num ^= 363466301U;
		Type type = this.6AA34183(this.026905F8().D6BFBC24());
		num = 320175216U - num;
		Type type2 = type;
		IL_33:
		num = 1221067330U % num;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		Type 21146C = type2;
		num = 1434022370U + num;
		bool 72846F = num - 2655089699U != 0U;
		num = 985745532U + num;
		object 4A36655E = 37FA30B.F187362C(21146C, 72846F);
		num *= 1459896567U;
		467F5DB3.37FA30B9 19D13A = this.147D558B(4A36655E, type2);
		num = 210982142U << (int)num;
		this.154055D0(19D13A);
		if (1864464443U != num)
		{
			return;
		}
		goto IL_11;
	}

	// Token: 0x06000273 RID: 627 RVA: 0x00307FCC File Offset: 0x00305BCC
	private void 38FE35C9()
	{
		uint num;
		do
		{
			num = 2075268030U;
			num |= 2951421U;
			int 1ADD01F = this.26642191();
			num >>= 4;
			Type t = this.6AA34183(1ADD01F);
			num |= 512514382U;
			int 0A = Marshal.SizeOf(t);
			num = 2062436710U + num;
			this.154055D0(new 467F5DB3.1C0911B0(0A));
		}
		while (num / 403143409U == 0U);
	}

	// Token: 0x06000274 RID: 628 RVA: 0x00308028 File Offset: 0x00305C28
	private void 756316D4()
	{
		uint num;
		Type type2;
		467F5DB3.37FA30B9 37FA30B;
		for (;;)
		{
			num = 2036016044U;
			Type type = this.6AA34183(this.026905F8().D6BFBC24());
			num = (814353980U & num);
			type2 = type;
			num += 402412399U;
			if (num >= 345974498U)
			{
				37FA30B = this.026905F8();
				num = 1241009480U << (int)num;
				bool flag = 37FA30B.535FA4FE();
				num += 1816340047U;
				if (!flag)
				{
					num %= 150144473U;
					if (!(37FA30B.6B58D7F4() is Pointer))
					{
						break;
					}
					num = (48247474U | num);
					467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
					num <<= 9;
					IntPtr 1B901B = new IntPtr(Pointer.Unbox(37FA30B2.6B58D7F4()));
					num = 1161627660U / num;
					37FA30B = new 467F5DB3.14F4779B(1B901B, type2);
					if (num > 1912869748U)
					{
						continue;
					}
					num ^= 2890081871U;
				}
				num = 1097604604U + num;
				if (num * 1919504392U != 0U)
				{
					goto Block_4;
				}
			}
		}
		num = 1769892233U + num;
		throw new ArgumentException();
		Block_4:
		num = 1445411003U * num;
		num &= 755449778U;
		object 4A36655E = 37FA30B;
		Type 78CB = type2;
		num = 1115962517U + num;
		467F5DB3.37FA30B9 19D13A = this.147D558B(4A36655E, 78CB);
		num &= 385773293U;
		this.154055D0(19D13A);
	}

	// Token: 0x06000275 RID: 629 RVA: 0x00308140 File Offset: 0x00305D40
	private void 4B3477AF()
	{
		uint num = 564005966U;
		if (41304717U >= num)
		{
			goto IL_4F;
		}
		IL_11:
		num = 1981375506U + num;
		num = (82521872U ^ num);
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num *= 1879537894U;
		int 748E14B = 37FA30B.D6BFBC24();
		num *= 964370406U;
		FieldInfo fieldInfo = this.0D675DC8(748E14B);
		if ((num ^ 1835546124U) == 0U)
		{
			goto IL_73;
		}
		IL_4F:
		num = 116940328U % num;
		467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
		num /= 721708795U;
		object obj = 37FA30B2.6B58D7F4();
		num >>= 10;
		IL_73:
		bool isStatic = fieldInfo.IsStatic;
		num = 1750805822U + num;
		if (!isStatic)
		{
			if (1565281387U % num == 0U)
			{
				goto IL_4F;
			}
			bool flag = obj != null;
			num = (1525312454U & num);
			num += 537986104U;
			if (!flag)
			{
				num = 923863203U << (int)num;
				if (num > 839781129U)
				{
					throw new NullReferenceException();
				}
			}
		}
		if ((4402395U ^ num) == 0U)
		{
			goto IL_11;
		}
		FieldInfo fieldInfo2 = fieldInfo;
		num = 1867264743U << (int)num;
		object obj2 = obj;
		num = 1831158434U / num;
		object value = fieldInfo2.GetValue(obj2);
		FieldInfo fieldInfo3 = fieldInfo;
		num = (1172312771U | num);
		Type fieldType = fieldInfo3.FieldType;
		num &= 1381990302U;
		467F5DB3.37FA30B9 19D13A = this.147D558B(value, fieldType);
		num = 36641791U >> (int)num;
		this.154055D0(19D13A);
		if (num <= 1052444392U)
		{
			return;
		}
		goto IL_4F;
	}

	// Token: 0x06000276 RID: 630 RVA: 0x00308278 File Offset: 0x00305E78
	private void 1A586B3E()
	{
		uint num = 51592551U;
		FieldInfo fieldInfo;
		if (978805971U - num != 0U)
		{
			do
			{
				num = 895567316U % num;
				num *= 205065142U;
				fieldInfo = this.0D675DC8(this.026905F8().D6BFBC24());
			}
			while (1057754604U >= num);
		}
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = (1478510246U ^ num);
		object obj = 37FA30B.6B58D7F4();
		num <<= 14;
		object obj2 = obj;
		num -= 760838132U;
		do
		{
			FieldInfo fieldInfo2 = fieldInfo;
			num = 911703317U + num;
			bool isStatic = fieldInfo2.IsStatic;
			num >>= 19;
			if (isStatic)
			{
				goto IL_AE;
			}
		}
		while ((394033063U ^ num) == 0U);
		bool flag = obj2 != null;
		num += 2134512057U;
		num += 2160455239U;
		if (!flag)
		{
			num += 866876099U;
			throw new NullReferenceException();
		}
		IL_AE:
		num &= 467349116U;
		num = 2024294286U + num;
		FieldInfo 3EDF6AD = fieldInfo;
		num = 1908478636U * num;
		this.154055D0(new 467F5DB3.1DEE779D(3EDF6AD, obj2));
	}

	// Token: 0x06000277 RID: 631 RVA: 0x00308358 File Offset: 0x00305F58
	private void 7A5A024A()
	{
		for (;;)
		{
			IL_00:
			int 748E14B = this.026905F8().D6BFBC24();
			uint num = 1622287156U;
			FieldInfo fieldInfo = this.0D675DC8(748E14B);
			num = 1814984163U << (int)num;
			FieldInfo fieldInfo2 = fieldInfo;
			num = 114972603U + num;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num /= 585462722U;
			object obj2;
			for (;;)
			{
				num = 1687843769U >> (int)num;
				object obj = this.026905F8().6B58D7F4();
				num += 1461536424U;
				obj2 = obj;
				num = 1816537696U % num;
				if (num % 1143692071U == 0U)
				{
					goto IL_00;
				}
				FieldInfo fieldInfo3 = fieldInfo2;
				num -= 387282869U;
				if (fieldInfo3.IsStatic)
				{
					break;
				}
				if (num >> 23 != 0U)
				{
					goto Block_2;
				}
			}
			IL_AE:
			num %= 546972890U;
			FieldInfo fieldInfo4 = fieldInfo2;
			object obj3 = obj2;
			num -= 778129962U;
			num /= 2036084300U;
			object 4A36655E = 37FA30B;
			FieldInfo fieldInfo5 = fieldInfo2;
			num = 1643844439U * num;
			Type fieldType = fieldInfo5.FieldType;
			num = 889402590U >> (int)num;
			467F5DB3.37FA30B9 37FA30B2 = this.147D558B(4A36655E, fieldType);
			num += 1038973314U;
			object value = 37FA30B2.6B58D7F4();
			num <<= 2;
			fieldInfo4.SetValue(obj3, value);
			if (num / 1657951039U != 0U)
			{
				return;
			}
			continue;
			Block_2:
			bool flag = obj2 != null;
			num <<= 17;
			num ^= 812036779U;
			if (!flag)
			{
				break;
			}
			goto IL_AE;
		}
		throw new NullReferenceException();
	}

	// Token: 0x06000278 RID: 632 RVA: 0x00308478 File Offset: 0x00306078
	private void 5AA0115D()
	{
		uint num = 1098281590U;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num &= 523916493U;
		int 748E14B = 37FA30B.D6BFBC24();
		num = 1101344324U % num;
		FieldInfo fieldInfo = this.0D675DC8(748E14B);
		num = 1636793087U << (int)num;
		FieldInfo fieldInfo2 = fieldInfo;
		num /= 384332213U;
		if (1142558104U != num)
		{
			num *= 1036792656U;
			467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
			FieldInfo fieldInfo3 = fieldInfo2;
			object obj = null;
			num = (761347113U & num);
			num = 1752371899U / num;
			object 4A36655E = 37FA30B2;
			Type fieldType = fieldInfo2.FieldType;
			num -= 1827306452U;
			fieldInfo3.SetValue(obj, this.147D558B(4A36655E, fieldType).6B58D7F4());
		}
	}

	// Token: 0x06000279 RID: 633 RVA: 0x00308510 File Offset: 0x00306110
	private void 3D5D5A63()
	{
		uint num = 1032727570U;
		for (;;)
		{
			Type type = this.6AA34183(this.026905F8().D6BFBC24());
			if (866277718U - num == 0U)
			{
				goto IL_60;
			}
			IL_24:
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num += 561910785U;
			467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
			num >>= 0;
			if (1903835465U == num)
			{
				continue;
			}
			467F5DB3.37FA30B9 37FA30B3 = this.026905F8();
			num &= 1970079315U;
			467F5DB3.37FA30B9 37FA30B4 = 37FA30B3;
			if (num < 520841352U)
			{
				continue;
			}
			IL_60:
			bool flag = 37FA30B4.535FA4FE();
			num = 1091185441U % num;
			if (!flag)
			{
				num &= 1133523466U;
				467F5DB3.37FA30B9 37FA30B5 = 37FA30B4;
				num = 1386551899U / num;
				if (37FA30B5.6B58D7F4() is Pointer)
				{
					num ^= 1446127957U;
					if (920219501U >= num)
					{
						goto IL_24;
					}
					467F5DB3.37FA30B9 37FA30B6 = 37FA30B4;
					num += 1097148060U;
					IntPtr 1B901B = new IntPtr(Pointer.Unbox(37FA30B6.6B58D7F4()));
					num <<= 8;
					Type 2C8510BE = type;
					num = (2145929777U & num);
					37FA30B4 = new 467F5DB3.14F4779B(1B901B, 2C8510BE);
					if (num > 715397542U)
					{
						continue;
					}
					num += 700574497U;
				}
				else
				{
					num = 344197065U >> (int)num;
					if (num % 232612686U != 0U)
					{
						break;
					}
					continue;
				}
			}
			if (651328909U / num != 0U)
			{
				goto IL_24;
			}
			467F5DB3.37FA30B9 37FA30B7 = 37FA30B4;
			num %= 732850621U;
			object 4A36655E = 37FA30B2;
			num -= 967266014U;
			Type 78CB = type;
			num %= 478484901U;
			467F5DB3.37FA30B9 37FA30B8 = this.147D558B(4A36655E, 78CB);
			num ^= 872944464U;
			37FA30B7.59A76885(37FA30B8.6B58D7F4());
			if (num != 1772448926U)
			{
				return;
			}
		}
		throw new ArgumentException();
	}

	// Token: 0x0600027A RID: 634 RVA: 0x00308674 File Offset: 0x00306274
	private void 2B30605D()
	{
		List<467F5DB3.37FA30B9> list = this.311B0F7E;
		uint num = 1011616032U;
		num = 1397889996U % num;
		ushort num2 = (ushort)this.534F3A25();
		num *= 1714114399U;
		int index = (int)num2;
		num = 1452506073U % num;
		467F5DB3.37FA30B9 37FA30B = list[index];
		num = 42825650U + num;
		467F5DB3.37FA30B9 19D13A = 37FA30B.15FAD4A1();
		num = 311364104U << (int)num;
		this.154055D0(19D13A);
	}

	// Token: 0x0600027B RID: 635 RVA: 0x003086D4 File Offset: 0x003062D4
	private void 2C861DAF()
	{
		uint num = 352525536U;
		if (1875267799U >> (int)num != 0U)
		{
			num /= 1430219599U;
			List<467F5DB3.37FA30B9> list = this.311B0F7E;
			int index = (int)((ushort)this.534F3A25());
			num -= 586353079U;
			467F5DB3.37FA30B9 64C = list[index];
			num = 700332355U + num;
			this.154055D0(new 467F5DB3.3DA7232B(64C));
		}
	}

	// Token: 0x0600027C RID: 636 RVA: 0x00308730 File Offset: 0x00306330
	private void 3F3659CB()
	{
		uint num = 695795860U;
		num = (307181703U ^ num);
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		467F5DB3.37FA30B9 37FA30B3;
		if (2052472768U >= num)
		{
			num = 1757556319U + num;
			List<467F5DB3.37FA30B9> list = this.311B0F7E;
			num = 1637700468U >> (int)num;
			num = 987511054U % num;
			int index = (int)((ushort)this.534F3A25());
			num >>= 25;
			467F5DB3.37FA30B9 37FA30B2 = list[index];
			num &= 93914111U;
			37FA30B3 = 37FA30B2;
			if (1365513695U < num)
			{
				return;
			}
		}
		467F5DB3.37FA30B9 37FA30B4 = 37FA30B3;
		object 4A36655E = 37FA30B;
		num = (58855913U | num);
		object 594737E = this.147D558B(4A36655E, 37FA30B3.303BF244()).6B58D7F4();
		num /= 2104102560U;
		37FA30B4.59A76885(594737E);
	}

	// Token: 0x0600027D RID: 637 RVA: 0x003087D4 File Offset: 0x003063D4
	private void 31FC0148()
	{
		uint num = 2093433481U;
		num |= 2002810708U;
		int 1ADD01F = this.026905F8().D6BFBC24();
		num -= 371269749U;
		Type type = this.6AA34183(1ADD01F);
		num = 1173061225U + num;
		this.3A06514C = type;
	}

	// Token: 0x0600027E RID: 638 RVA: 0x00308818 File Offset: 0x00306418
	private void 5CB53BAA()
	{
		uint num = 885135349U;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = 1651861198U - num;
		MethodBase methodBase = this.12F8138C(37FA30B.D6BFBC24());
		num = 1682969296U >> (int)num;
		MethodBase methodBase2 = methodBase;
		MethodBase 0B2C41C = methodBase2;
		bool 358E669A = (num ^ 50U) != 0U;
		num &= 1042423990U;
		467F5DB3.37FA30B9 37FA30B2 = this.679E4C07(0B2C41C, 358E669A);
		if (37FA30B2 != null)
		{
			num = 827148958U << (int)num;
			467F5DB3.37FA30B9 19D13A = 37FA30B2;
			num = 1312194423U / num;
			this.154055D0(19D13A);
			num ^= 51U;
		}
	}

	// Token: 0x0600027F RID: 639 RVA: 0x00308898 File Offset: 0x00306498
	private void 238B145E()
	{
		for (;;)
		{
			IL_00:
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			uint num = 112005829U;
			MethodBase methodBase = this.12F8138C(37FA30B.D6BFBC24());
			num = 1253788664U * num;
			for (;;)
			{
				num = 2071791827U + num;
				if (this.3A06514C != null)
				{
					ParameterInfo[] parameters = methodBase.GetParameters();
					num = 864305634U / num;
					num = 319117958U + num;
					Type[] array = new Type[parameters.Length];
					int num2 = (int)(num ^ 319117958U);
					ParameterInfo[] array2 = parameters;
					int num3 = (int)(num ^ 319117958U);
					num <<= 16;
					int num4 = num3;
					if (num == 2058298513U)
					{
						continue;
					}
					for (;;)
					{
						num = (286590911U & num);
						int num5 = num4;
						int num6 = array2.Length;
						num = 2109104314U % num;
						int num7 = num6;
						num = (321990893U & num);
						if (num5 >= num7)
						{
							break;
						}
						ParameterInfo parameterInfo = array2[num4];
						num = 1442120126U;
						ParameterInfo parameterInfo2 = parameterInfo;
						num = 454522203U - num;
						if (num <= 898334141U)
						{
							goto IL_00;
						}
						Type[] array3 = array;
						num ^= 591736044U;
						int num8 = num2;
						int num9 = (int)(num - 3865534320U);
						num = 1410353456U % num;
						int num10 = num8 + num9;
						num = 1820488683U / num;
						num2 = num10;
						Type parameterType = parameterInfo2.ParameterType;
						num = 1208369644U % num;
						array3[num8] = parameterType;
						int num11 = num4;
						int num12 = (int)(num - uint.MaxValue);
						num = 1144075558U << (int)num;
						num4 = num11 + num12;
						num ^= 515323174U;
					}
					Type type = this.3A06514C;
					string name = methodBase.Name;
					num -= 1665613748U;
					BindingFlags bindingAttr = (BindingFlags)(num - 2647175104U);
					Binder binder = null;
					num *= 103162397U;
					Type[] types = array;
					num += 1493326608U;
					ParameterModifier[] modifiers = null;
					num = 1672420757U + num;
					MethodInfo method = type.GetMethod(name, bindingAttr, binder, types, modifiers);
					num = 974926943U << (int)num;
					MethodInfo methodInfo = method;
					if ((num & 618666660U) == 0U)
					{
						break;
					}
					bool flag = methodInfo != null;
					num <<= 6;
					if (flag)
					{
						if (825626326U <= num)
						{
							continue;
						}
						MethodBase methodBase2 = methodInfo;
						num = (1582717106U ^ num);
						methodBase = methodBase2;
						num += 3585451854U;
					}
					if (450117647U == num)
					{
						break;
					}
					this.3A06514C = null;
					num += 895381163U;
				}
				if (394203330 << (int)num == 0)
				{
					break;
				}
				MethodBase 0B2C41C = methodBase;
				num = (193138037U | num);
				467F5DB3.37FA30B9 37FA30B2 = this.679E4C07(0B2C41C, (num ^ 1334833150U) != 0U);
				num <<= 9;
				467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
				bool flag2 = 37FA30B3 != null;
				num = 1374890961U / num;
				if (flag2)
				{
					if ((num ^ 78931254U) == 0U)
					{
						break;
					}
					467F5DB3.37FA30B9 19D13A = 37FA30B3;
					num = (1303252918U & num);
					this.154055D0(19D13A);
					num ^= 0U;
				}
				if (1826826615U > num)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000280 RID: 640 RVA: 0x00308AC8 File Offset: 0x003066C8
	private void 647078C3()
	{
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		uint num = 600126311U;
		object obj = 37FA30B.6B58D7F4();
		num %= 50157582U;
		MethodBase methodBase = obj as MethodBase;
		num >>= 29;
		MethodBase methodBase2 = methodBase;
		num = 100757595U - num;
		if (1365534968U < num || methodBase2 == null)
		{
			throw new ArgumentException();
		}
		num <<= 31;
		num = (1057427609U | num);
		467F5DB3.37FA30B9 37FA30B2 = this.679E4C07(methodBase2, (num ^ 3204911257U) != 0U);
		num <<= 18;
		467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
		if (37FA30B3 != null && num != 95648118U)
		{
			this.154055D0(37FA30B3);
			num += 0U;
		}
	}

	// Token: 0x06000281 RID: 641 RVA: 0x00308B64 File Offset: 0x00306764
	private void 29A31B2A()
	{
		uint num = 1485840199U;
		num = (922224863U & num);
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = 402286141U << (int)num;
		int 74CB52EE = 37FA30B.D6BFBC24();
		num = (1973887277U ^ num);
		467F5DB3.37FA30B9 37FA30B2 = this.592F513D(74CB52EE, num + 2003550291U != 0U);
		num &= 1913148479U;
		467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
		num = 423710871U >> (int)num;
		do
		{
			if (37FA30B3 != null)
			{
				num -= 1823761192U;
				if (1824290352U == num)
				{
					continue;
				}
				467F5DB3.37FA30B9 19D13A = 37FA30B3;
				num = (1091391671U | num);
				this.154055D0(19D13A);
				num ^= 3545087229U;
			}
		}
		while (1606827661U + num == 0U);
	}

	// Token: 0x06000282 RID: 642 RVA: 0x00308C00 File Offset: 0x00306800
	private void 110A0B3C()
	{
		int 74CB52EE = this.026905F8().D6BFBC24();
		uint num = 788531833U;
		bool 18537AE = num - 788531832U != 0U;
		num ^= 11479756U;
		467F5DB3.37FA30B9 37FA30B = this.592F513D(74CB52EE, 18537AE);
		num += 707358074U;
		467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
		do
		{
			if (37FA30B2 != null)
			{
				num = (1032398906U ^ num);
				if (1283545147U < num)
				{
					num <<= 13;
					this.154055D0(37FA30B2);
					num ^= 1830432303U;
				}
			}
		}
		while ((num ^ 787418168U) == 0U);
	}

	// Token: 0x06000283 RID: 643 RVA: 0x00308C78 File Offset: 0x00306878
	private void 17A41624()
	{
		uint num = 1577923136U;
		467F5DB3.37FA30B9 37FA30B2;
		if (num >= 375672159U)
		{
			int 6E2A7C3A = this.026905F8().D6BFBC24();
			num >>= 2;
			MethodBase methodBase = this.12F8138C(6E2A7C3A);
			num /= 111628774U;
			MethodBase methodBase2 = methodBase;
			num = (1206671307U & num);
			MethodBase 06C92F = methodBase2;
			num %= 535831110U;
			467F5DB3.37FA30B9 37FA30B = this.60BB31CB(06C92F);
			num = 141886095U / num;
			37FA30B2 = 37FA30B;
		}
		if (37FA30B2 != null)
		{
			num = 301748968U - num;
			467F5DB3.37FA30B9 19D13A = 37FA30B2;
			num >>= 11;
			this.154055D0(19D13A);
			num += 47171121U;
		}
	}

	// Token: 0x06000284 RID: 644 RVA: 0x00308D00 File Offset: 0x00306900
	private void 316B556C()
	{
		uint num = 1109262430U;
		if (121795256U - num == 0U)
		{
			goto IL_47;
		}
		Type type2;
		do
		{
			IL_12:
			num %= 303239013U;
			Type type = this.6AA34183(this.026905F8().D6BFBC24());
			num = 1661101929U >> (int)num;
			type2 = type;
		}
		while (num + 685646425U == 0U);
		IL_47:
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = 1965828600U - num;
		467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
		num -= 699167437U;
		for (;;)
		{
			if (type2.IsGenericType)
			{
				num %= 337523152U;
				if (1520260233 << (int)num == 0)
				{
					continue;
				}
				Type type3 = type2;
				num = (1351035997U & num);
				Type genericTypeDefinition = type3.GetGenericTypeDefinition();
				num = 875843374U * num;
				Type typeFromHandle = typeof(Nullable<>);
				num = 928594546U >> (int)num;
				num += 1252101182U;
				if (genericTypeDefinition == typeFromHandle)
				{
					break;
				}
			}
			if (935868302U > num)
			{
				goto IL_12;
			}
			if (!type2.IsValueType)
			{
				goto IL_220;
			}
			num |= 1466303912U;
			if (545010749U >= num)
			{
				goto IL_12;
			}
			Type type4 = type2;
			num *= 1324497444U;
			FieldInfo[] fields = type4.GetFields((BindingFlags)(num ^ 3270652648U));
			num |= 440754201U;
			FieldInfo[] array = fields;
			int num2 = (int)(num ^ 3673649821U);
			if (1897813669U >= num)
			{
				goto IL_12;
			}
			for (;;)
			{
				num = 158081208U - num;
				int num3 = num2;
				num = 60756262U >> (int)num;
				int num4 = array.Length;
				num |= 718959590U;
				if (num3 >= num4)
				{
					break;
				}
				num = 1671051303U;
				if (1279862880U >= num)
				{
					goto IL_12;
				}
				FieldInfo[] array2 = array;
				num = 1160279069U + num;
				int num5 = num2;
				num = 525273049U >> (int)num;
				FieldInfo fieldInfo = array2[num5];
				FieldInfo fieldInfo2 = fieldInfo;
				num = 839583498U + num;
				object obj = 37FA30B2.6B58D7F4();
				FieldInfo fieldInfo3 = fieldInfo;
				num /= 1308372746U;
				bool isValueType = fieldInfo3.FieldType.IsValueType;
				num += 575031758U;
				object value;
				if (!isValueType)
				{
					value = null;
				}
				else
				{
					value = Activator.CreateInstance(fieldInfo.FieldType);
					num += 0U;
				}
				num &= 418583954U;
				fieldInfo2.SetValue(obj, value);
				num = 878926714U * num;
				if (num < 2144161893U)
				{
					goto IL_12;
				}
				num2 += (int)(num - 2470702579U);
				num ^= 1236574057U;
			}
			if (num != 904271336U)
			{
				return;
			}
		}
		467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
		num %= 1104556836U;
		object 594737E = null;
		num = 143852705U * num;
		37FA30B3.59A76885(594737E);
		if (1704943874U - num != 0U)
		{
			return;
		}
		goto IL_12;
		IL_220:
		num = (1894136817U & num);
		37FA30B2.59A76885(null);
		if (num >= 557079566U)
		{
			return;
		}
		goto IL_12;
	}

	// Token: 0x06000285 RID: 645 RVA: 0x00308F48 File Offset: 0x00306B48
	private void 19584976()
	{
		for (;;)
		{
			uint num = 512521681U;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num %= 1012235067U;
			int num2 = 37FA30B.D6BFBC24();
			num = 215886445U + num;
			int num3 = num2;
			for (;;)
			{
				num >>= 4;
				467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
				num |= 1397490763U;
				467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
				num |= 682977157U;
				if (num <= 1904965484U)
				{
					break;
				}
				467F5DB3.37FA30B9 37FA30B4 = this.026905F8();
				num = 278593568U >> (int)num;
				if (725703079U <= num)
				{
					break;
				}
				num ^= 993790426U;
				467F5DB3.37FA30B9 31633A4A = 37FA30B4;
				467F5DB3.37FA30B9 2FD05CBE = 37FA30B3;
				num /= 1308910561U;
				bool 32DD = (num ^ 0U) != 0U;
				int 6BAE = num3;
				num &= 513280063U;
				int 0A = this.486B7876(31633A4A, 2FD05CBE, 32DD, 6BAE);
				num &= 1707490016U;
				this.154055D0(new 467F5DB3.1C0911B0(0A));
				if (num * 974732115U == 0U)
				{
					return;
				}
			}
		}
	}

	// Token: 0x06000286 RID: 646 RVA: 0x00309008 File Offset: 0x00306C08
	private void 626604EE()
	{
		uint num;
		do
		{
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = 1037529666U;
			int num2 = 37FA30B.D6BFBC24();
			num = 1594584644U >> (int)num;
			int 6BAE = num2;
			num *= 2128155497U;
			467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
			num = 1450662172U << (int)num;
			467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
			467F5DB3.37FA30B9 37FA30B4;
			do
			{
				37FA30B4 = this.026905F8();
			}
			while (num <= 714554509U);
			num = 1977900848U >> (int)num;
			467F5DB3.37FA30B9 31633A4A = 37FA30B4;
			num = 571357178U % num;
			467F5DB3.37FA30B9 2FD05CBE = 37FA30B3;
			num = 370228191U + num;
			bool 32DD = (num ^ 941585368U) != 0U;
			num = 561325765U + num;
			this.154055D0(new 467F5DB3.1C0911B0(this.486B7876(31633A4A, 2FD05CBE, 32DD, 6BAE)));
		}
		while (718609734U > num);
	}

	// Token: 0x06000287 RID: 647 RVA: 0x003090B0 File Offset: 0x00306CB0
	private void 59C158B0()
	{
		uint num = 365394414U;
		num -= 857876036U;
		Type elementType = this.6AA34183(this.026905F8().D6BFBC24());
		num = 1263104053U >> (int)num;
		this.154055D0(new 467F5DB3.705703B5(Array.CreateInstance(elementType, this.026905F8().D6BFBC24())));
	}

	// Token: 0x06000288 RID: 648 RVA: 0x00309108 File Offset: 0x00306D08
	private void 0B982BF4()
	{
		uint num = 812532747U;
		for (;;)
		{
			num = 1845919516U * num;
			num >>= 28;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = 1094993546U % num;
			int 1ADD01F = 37FA30B.D6BFBC24();
			num = 566171810U << (int)num;
			Type type = this.6AA34183(1ADD01F);
			num = (880574104U | num);
			Type type2 = type;
			num = (1699045264U ^ num);
			for (;;)
			{
				num = 2028283814U * num;
				467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
				num = (1166612877U | num);
				if (381705832U > num)
				{
					break;
				}
				num = 73882876U % num;
				467F5DB3.37FA30B9 37FA30B3 = this.026905F8();
				num &= 1787242892U;
				467F5DB3.37FA30B9 37FA30B4 = 37FA30B3;
				num = 1678925677U % num;
				num = 1364987432U + num;
				Array array = this.026905F8().6B58D7F4() as Array;
				num += 656627529U;
				Array array2 = array;
				bool flag = array2 != null;
				num = 426838414U << (int)num;
				if (!flag)
				{
					goto Block_2;
				}
				if (num << 31 != 0U)
				{
					break;
				}
				Array array3 = array2;
				num = (281880557U ^ num);
				object 4A36655E = 37FA30B2;
				Type 78CB = type2;
				num = 90527125U - num;
				object 4A36655E2 = this.147D558B(4A36655E, 78CB);
				num *= 378545120U;
				Type type3 = array2.GetType();
				num ^= 1764502889U;
				467F5DB3.37FA30B9 37FA30B5 = this.147D558B(4A36655E2, type3.GetElementType());
				num = (1486375140U & num);
				array3.SetValue(37FA30B5.6B58D7F4(), 37FA30B4.D6BFBC24());
				if (num + 687433980U != 0U)
				{
					return;
				}
			}
		}
		Block_2:
		throw new ArgumentException();
	}

	// Token: 0x06000289 RID: 649 RVA: 0x00309250 File Offset: 0x00306E50
	private void 07164ABD()
	{
		uint num = 1248465720U;
		num *= 253721392U;
		num = 1406022587U >> (int)num;
		int 1ADD01F = this.026905F8().D6BFBC24();
		num *= 1719430062U;
		Type type = this.6AA34183(1ADD01F);
		467F5DB3.37FA30B9 37FA30B;
		if (2145464527U <= num)
		{
			do
			{
				37FA30B = this.026905F8();
			}
			while (num << 6 == 0U);
		}
		Array array;
		do
		{
			num %= 680079659U;
			467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
			num *= 1648720702U;
			object obj = 37FA30B2.6B58D7F4();
			num -= 1194556591U;
			array = (obj as Array);
			num = 1515739072U - num;
			while (array != null)
			{
				if (461196558U < num)
				{
					goto Block_3;
				}
			}
		}
		while (669792148 << (int)num == 0);
		throw new ArgumentException();
		Block_3:
		Array array2 = array;
		num = (236605739U | num);
		int index = 37FA30B.D6BFBC24();
		num += 25841098U;
		object value = array2.GetValue(index);
		num ^= 1805210346U;
		Type 78CB = type;
		num = (382343836U & num);
		this.154055D0(this.147D558B(value, 78CB));
	}

	// Token: 0x0600028A RID: 650 RVA: 0x00309344 File Offset: 0x00306F44
	private void 239304DE()
	{
		uint num = 821062112U;
		if (num / 385244394U == 0U)
		{
			goto IL_55;
		}
		IL_12:
		num >>= 21;
		object obj = this.026905F8().6B58D7F4();
		num >>= 19;
		Array array = obj as Array;
		num &= 1955484955U;
		Array array2 = array;
		num = 1052146249U << (int)num;
		if ((851984539U ^ num) == 0U)
		{
			return;
		}
		IL_55:
		if (array2 == null)
		{
			throw new ArgumentException();
		}
		num -= 1090655928U;
		if ((num ^ 937785905U) == 0U)
		{
			goto IL_12;
		}
		num += 773992926U;
		int length = array2.Length;
		num += 1599081129U;
		this.154055D0(new 467F5DB3.1C0911B0(length));
		if ((num ^ 22481710U) == 0U)
		{
			goto IL_12;
		}
	}

	// Token: 0x0600028B RID: 651 RVA: 0x003093F4 File Offset: 0x00306FF4
	private void 58080A16()
	{
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		uint num = 1466703218U;
		467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
		Array array2;
		if (764369492U - num != 0U)
		{
			num = 2024170968U % num;
			467F5DB3.37FA30B9 37FA30B3 = this.026905F8();
			num = 1689392887U * num;
			object obj = 37FA30B3.6B58D7F4();
			num &= 1250624403U;
			Array array = obj as Array;
			num = 1856254165U % num;
			array2 = array;
			if (array2 == null)
			{
				num = 1595878750U << (int)num;
				throw new ArgumentException();
			}
		}
		num &= 1524778519U;
		Array 128018FF = array2;
		num >>= 18;
		467F5DB3.37FA30B9 37FA30B4 = 37FA30B2;
		num = (959722399U | num);
		this.154055D0(new 467F5DB3.67EB01D1(128018FF, 37FA30B4.D6BFBC24()));
	}

	// Token: 0x0600028C RID: 652 RVA: 0x00309490 File Offset: 0x00307090
	private void 7F3C140C()
	{
		uint num = 276983719U;
		num &= 1606055178U;
		int 6E2A7C3A = this.026905F8().D6BFBC24();
		num = 689182660U + num;
		467F5DB3.37FA30B9 19D13A = new 467F5DB3.6C3B2692(this.12F8138C(6E2A7C3A));
		num += 1258174917U;
		this.154055D0(19D13A);
	}

	// Token: 0x0600028D RID: 653 RVA: 0x003094D8 File Offset: 0x003070D8
	private void 76493535()
	{
		uint num = 1962148773U;
		MethodBase methodBase2;
		for (;;)
		{
			IL_07:
			num = 16461875U >> (int)num;
			num &= 80110432U;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num += 88483844U;
			int 6E2A7C3A = 37FA30B.D6BFBC24();
			num >>= 6;
			MethodBase methodBase = this.12F8138C(6E2A7C3A);
			num = 144724725U * num;
			methodBase2 = methodBase;
			num >>= 3;
			for (;;)
			{
				IL_5C:
				Type type = this.026905F8().6B58D7F4().GetType();
				for (;;)
				{
					IL_6E:
					Type declaringType = methodBase2.DeclaringType;
					MethodBase methodBase3 = methodBase2;
					num = 1947690166U * num;
					ParameterInfo[] parameters = methodBase3.GetParameters();
					num *= 1096421808U;
					num ^= 2082828838U;
					Type[] array = new Type[parameters.Length];
					num &= 1371370502U;
					Type[] array2 = array;
					num = (333709458U | num);
					int num2 = (int)(num ^ 333721750U);
					num = 2005090322U >> (int)num;
					ParameterInfo[] array3 = parameters;
					for (;;)
					{
						IL_D4:
						int num3 = (int)(num + 4294966818U);
						if (num % 1105932348U == 0U)
						{
							goto IL_07;
						}
						for (;;)
						{
							num = 1581399164U >> (int)num;
							int num4 = num3;
							ParameterInfo[] array4 = array3;
							num *= 157754588U;
							int num5 = array4.Length;
							num = 283472821U - num;
							int num6 = num5;
							num |= 964511059U;
							if (num4 >= num6)
							{
								MethodInfo methodInfo;
								for (;;)
								{
									bool flag = type != null;
									num = 638611258U * num;
									num ^= 1222402460U;
									if (!flag)
									{
										goto IL_2F7;
									}
									Type type2 = type;
									Type type3 = declaringType;
									num += 1327124338U;
									if (type2 == type3)
									{
										goto Block_11;
									}
									num = 387664711U;
									if ((num ^ 1348613627U) == 0U)
									{
										goto IL_6E;
									}
									Type type4 = type;
									num -= 1946644837U;
									MemberInfo memberInfo = methodBase2;
									num /= 871250533U;
									string name = memberInfo.Name;
									num &= 719791814U;
									BindingFlags bindingAttr = (BindingFlags)(num ^ 77876U);
									num ^= 1808486010U;
									Binder binder = null;
									num = (1927830806U & num);
									CallingConventions callConvention = (int)num + (CallingConventions)(-1657293837);
									Type[] types = array2;
									num -= 455242944U;
									MethodInfo method = type4.GetMethod(name, bindingAttr, binder, callConvention, types, null);
									num = (194392061U | num);
									methodInfo = method;
									if (2031038433U >> (int)num == 0U)
									{
										goto IL_5C;
									}
									bool flag2 = methodInfo != null;
									num = 255618309U + num;
									if (flag2)
									{
										if (num >= 1675701443U)
										{
											goto IL_D4;
										}
										MethodInfo methodInfo2 = methodInfo;
										num -= 1556248204U;
										MethodInfo baseDefinition = methodInfo2.GetBaseDefinition();
										num >>= 24;
										MethodBase methodBase4 = methodBase2;
										num += 1593076992U;
										if (baseDefinition == methodBase4)
										{
											break;
										}
									}
									num = 1210536896U / num;
									Type type5 = type;
									num = 534735236U + num;
									Type baseType = type5.BaseType;
									num ^= 1855860151U;
									type = baseType;
									num += 3460172712U;
								}
								methodBase2 = methodInfo;
								if (801668183U <= num)
								{
									goto Block_9;
								}
							}
							ParameterInfo parameterInfo = array3[num3];
							num = 1681944500U;
							if (2083874255U + num == 0U)
							{
								goto IL_07;
							}
							Type[] array5 = array2;
							int num7 = num2;
							num = 474316609U + num;
							int num8 = num7 + (int)(num ^ 2156261108U);
							num %= 1841255101U;
							num2 = num8;
							array5[num7] = parameterInfo.ParameterType;
							int num9 = num3;
							num <<= 30;
							int num10 = (int)(num ^ 1U);
							num /= 1314855383U;
							int num11 = num9 + num10;
							num = 450838868U * num;
							num3 = num11;
							num += 478U;
						}
					}
				}
			}
		}
		Block_9:
		goto IL_2F7;
		Block_11:
		num ^= 4042969462U;
		IL_2F7:
		num <<= 6;
		num = 224690050U * num;
		MethodBase 0DEB6D = methodBase2;
		num %= 362219939U;
		467F5DB3.37FA30B9 19D13A = new 467F5DB3.6C3B2692(0DEB6D);
		num = 1352797569U - num;
		this.154055D0(19D13A);
	}

	// Token: 0x0600028E RID: 654 RVA: 0x00309814 File Offset: 0x00307414
	private void 30711BF0()
	{
		uint num = 1921588054U;
		if (num >= 875122099U)
		{
			do
			{
				num ^= 1697655401U;
				num &= 2133930598U;
				this.0749791D = this.026905F8().D6BFBC24();
			}
			while ((num ^ 161092252U) == 0U);
		}
	}

	// Token: 0x0600028F RID: 655 RVA: 0x00309860 File Offset: 0x00307460
	private void 724F534D()
	{
		this.026905F8();
	}

	// Token: 0x06000290 RID: 656 RVA: 0x00309874 File Offset: 0x00307474
	private void 37EF1767()
	{
		for (;;)
		{
			IL_00:
			Stack<int> stack = this.456178D7;
			uint num = 359885913U;
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = (941325465U | num);
			stack.Push(37FA30B.D6BFBC24());
			num -= 510950785U;
			if (1858084970 << (int)num != 0)
			{
				goto IL_44;
			}
			IL_64:
			int num3;
			for (;;)
			{
				IL_16D:
				num = 1874885120U >> (int)num;
				if (1515520727U >> (int)num == 0U)
				{
					goto IL_00;
				}
				Stack<467F5DB3.74D46A00> stack2 = this.7E2027B1;
				num = 1982745378U << (int)num;
				bool count = stack2.Count != 0;
				num /= 1906850076U;
				if (!count)
				{
					break;
				}
				num = 1096446208U - num;
				if (num <= 1011842608U)
				{
					goto IL_00;
				}
				int num2 = num3;
				num /= 292584264U;
				num = 1536973130U + num;
				467F5DB3.74D46A00 74D46A = this.7E2027B1.Peek();
				num = 1458839586U << (int)num;
				if (num2 <= 74D46A.74685482())
				{
					goto Block_7;
				}
				Stack<467F5DB3.74D46A00> stack3 = this.7E2027B1;
				num = 1955734557U;
				List<467F5DB3.42FB763B> list = stack3.Pop().5A314F34();
				if (num >= 1483567656U)
				{
					List<467F5DB3.42FB763B> list2 = list;
					num = (882927483U | num);
					int num4 = list2.Count;
					while (num >= 124479124U)
					{
						uint num5 = (uint)num4;
						num = (1148738787U & num);
						if (num5 <= num - 1144013923U)
						{
							num += 3150953373U;
							goto IL_16D;
						}
						List<467F5DB3.42FB763B> list3 = list;
						int num6 = num4;
						int num7 = 1;
						num = 1458000446U;
						int index = num6 - num7;
						num &= 902847467U;
						467F5DB3.42FB763B 42FB763B = list3[index];
						if ((uint)42FB763B.725458AE() == num + 3946819032U)
						{
							num = 195973110U >> (int)num;
							num = (1300832791U | num);
							Stack<int> stack4 = this.456178D7;
							467F5DB3.42FB763B 42FB763B2 = 42FB763B;
							num = (2069042463U & num);
							int item = 42FB763B2.012472E6();
							num = 1865495839U << (int)num;
							stack4.Push(item);
							num += 2235585066U;
						}
						int num8 = num4 - (int)(num ^ 348148267U);
						num = 1390022795U * num;
						num4 = num8;
						num ^= 3252771761U;
					}
					goto IL_00;
				}
				goto IL_00;
			}
			IL_214:
			num = 1984385391U * num;
			if (num - 1042381404U == 0U)
			{
				goto IL_44;
			}
			Exception ex = null;
			num = 1950420680U >> (int)num;
			this.65D141FE = ex;
			if (821770826U <= num)
			{
				continue;
			}
			num += 1752697153U;
			this.65EB1F68.Clear();
			if (1429107759U > num)
			{
				continue;
			}
			num -= 1206602337U;
			num = 73738411U - num;
			int num9 = this.456178D7.Pop();
			num = 281021095U + num;
			this.0749791D = num9;
			if (num * 1664484741U != 0U)
			{
				break;
			}
			continue;
			Block_7:
			num += 2080096257U;
			goto IL_214;
			IL_44:
			num = 1172832930U + num;
			int num10 = this.026905F8().D6BFBC24();
			num = 757887552U / num;
			num3 = num10;
			goto IL_64;
		}
	}

	// Token: 0x06000291 RID: 657 RVA: 0x00309B2C File Offset: 0x0030772C
	private void 24564138()
	{
		uint num = 1780692389U;
		num = 2040596754U + num;
		bool flag = this.65D141FE != null;
		num |= 965364288U;
		if (flag)
		{
			if (1402873459U < num)
			{
				this.2D1405EA(this.65D141FE);
				if ((num & 1333206896U) == 0U)
				{
					return;
				}
			}
			return;
		}
		Stack<int> stack = this.456178D7;
		num = 18775471U / num;
		int num2 = stack.Pop();
		num ^= 1959099102U;
		this.0749791D = num2;
	}

	// Token: 0x06000292 RID: 658 RVA: 0x00309BA0 File Offset: 0x003077A0
	private void 0E732E49()
	{
		uint num = 717901796U;
		for (;;)
		{
			num = 312171756U >> (int)num;
			bool flag = this.026905F8().D6BFBC24() != 0;
			num = 1066227158U << (int)num;
			if (flag)
			{
				num = 898697374U >> (int)num;
			}
			else
			{
				if (num * 2106606197U == 0U)
				{
					continue;
				}
				num = 527525581U % num;
				num = (828637469U ^ num);
				Exception <<EMPTY_NAME>> = this.65D141FE;
				num = 143993412U / num;
				this.2D1405EA(<<EMPTY_NAME>>);
				if (112862989U != num)
				{
					return;
				}
			}
			this.7E2027B1.Pop();
			if (892231269U - num != 0U)
			{
				num -= 1636507468U;
				Stack<467F5DB3.371F2AF7> stack = this.65EB1F68;
				num = (87960175U ^ num);
				object 2 = this.65D141FE;
				num %= 1659452664U;
				467F5DB3.371F2AF7 item = new 467F5DB3.4CF55D0F(2);
				num = (1465871688U & num);
				stack.Push(item);
				num >>= 7;
				467F5DB3.42FB763B 42FB763B = this.58991615;
				num = 652225570U + num;
				int num2 = 42FB763B.012472E6();
				num /= 1000569980U;
				this.0749791D = num2;
				if ((789400279U ^ num) != 0U)
				{
					num = 710564353U + num;
					this.58991615 = null;
					if (num >> 9 != 0U)
					{
						break;
					}
				}
			}
		}
	}

	// Token: 0x06000293 RID: 659 RVA: 0x00309CC8 File Offset: 0x003078C8
	private void 1EA46AB1()
	{
		uint num = 315635994U;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = (987003064U ^ num);
		int 1ADD01F = 37FA30B.D6BFBC24();
		num >>= 30;
		Type type = this.6AA34183(1ADD01F);
		num *= 2006330863U;
		if ((1815618097U ^ num) != 0U)
		{
			object 4A36655E = this.026905F8();
			Type 78CB = type;
			num <<= 20;
			467F5DB3.37FA30B9 37FA30B2 = this.147D558B(4A36655E, 78CB);
			num <<= 21;
			object <<EMPTY_NAME>> = 37FA30B2.6B58D7F4();
			num = (1792302247U | num);
			467F5DB3.37FA30B9 19D13A = new 467F5DB3.4CF55D0F(<<EMPTY_NAME>>);
			num = 1293319265U + num;
			this.154055D0(19D13A);
		}
	}

	// Token: 0x06000294 RID: 660 RVA: 0x00309D50 File Offset: 0x00307950
	private void 4920583E()
	{
		uint num;
		Type type2;
		do
		{
			num = 2055293677U;
			int 1ADD01F = this.026905F8().D6BFBC24();
			num <<= 20;
			Type type = this.6AA34183(1ADD01F);
			num = (465466141U | num);
			type2 = type;
			num |= 1084512121U;
		}
		while (760429583U / num != 0U);
		do
		{
			num ^= 1661471087U;
			object 4A36655E = this.026905F8().6B58D7F4();
			Type 78CB = type2;
			num >>= 15;
			467F5DB3.37FA30B9 19D13A = this.147D558B(4A36655E, 78CB);
			num = (1940416749U | num);
			this.154055D0(19D13A);
		}
		while (num + 183968124U == 0U);
	}

	// Token: 0x06000295 RID: 661 RVA: 0x00309DD8 File Offset: 0x003079D8
	private void 151023C3()
	{
		uint num = 1625833313U;
		object obj2;
		for (;;)
		{
			IL_06:
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = 1428567472U << (int)num;
			int 1ADD01F = 37FA30B.D6BFBC24();
			num = 454784735U - num;
			Type type = this.6AA34183(1ADD01F);
			num -= 1077366990U;
			if (789336134U + num != 0U)
			{
				for (;;)
				{
					IL_43:
					num = 1368540176U << (int)num;
					467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
					num = (23865535U ^ num);
					if ((1378576069U ^ num) == 0U)
					{
						goto IL_06;
					}
					for (;;)
					{
						object obj = 37FA30B2.6B58D7F4();
						num = 1793133611U << (int)num;
						obj2 = obj;
						if (obj2 == null)
						{
							num = (290415892U & num);
							if (1360160445U >= num)
							{
								goto Block_2;
							}
						}
						else
						{
							num >>= 3;
							if (1473317207U + num == 0U)
							{
								goto IL_06;
							}
							bool isValueType = type.IsValueType;
							num <<= 8;
							if (isValueType)
							{
								num %= 1542606441U;
								if (num / 476251035U != 0U)
								{
									goto IL_06;
								}
							}
							else
							{
								num = 664089964U << (int)num;
								TypeCode typeCode = Type.GetTypeCode(type);
								num = 1063746974U % num;
								if (num >> 17 != 0U)
								{
									TypeCode typeCode2 = typeCode;
									num = 1816408862U * num;
									uint num2 = num + 196187175U;
									num *= 745023474U;
									switch (typeCode2 - num2)
									{
									case 0:
										goto IL_1BF;
									case 1:
										goto IL_1F9;
									case 2:
										goto IL_240;
									case 3:
										goto IL_26E;
									case 4:
										goto IL_28E;
									case 5:
										goto IL_2BE;
									case 6:
										goto IL_2FB;
									case 7:
										goto IL_329;
									case 8:
									{
										num <<= 10;
										if (num == 128140172U)
										{
											goto IL_06;
										}
										long 0E0B = (long)obj2;
										num /= 1512065469U;
										this.154055D0(new 467F5DB3.06E010E5(0E0B));
										if (857957512U != num)
										{
											return;
										}
										continue;
									}
									case 9:
										goto IL_387;
									case 10:
										goto IL_3B1;
									case 11:
										goto IL_3E3;
									}
									break;
								}
								goto IL_43;
							}
						}
						Type type2 = type;
						object obj3 = obj2;
						num |= 1296462053U;
						if (type2 != obj3.GetType())
						{
							goto Block_5;
						}
						num %= 1736709384U;
						if (num == 1211657252U)
						{
							goto IL_06;
						}
						num = 1419247868U / num;
						467F5DB3.37FA30B9 19D13A = 37FA30B2;
						num >>= 19;
						this.154055D0(19D13A);
						if (725116932 << (int)num != 0)
						{
							return;
						}
					}
					num |= 1068984707U;
					if (57430621U <= num)
					{
						goto Block_21;
					}
					continue;
					IL_1F9:
					num ^= 1622489479U;
					if (165364737U < num)
					{
						goto Block_12;
					}
					continue;
					IL_240:
					num &= 238488988U;
					num += 1556746856U;
					this.154055D0(new 467F5DB3.745721FC((sbyte)obj2));
					if (47257895U + num != 0U)
					{
						return;
					}
					continue;
					IL_2BE:
					num ^= 825190392U;
					if (num != 2147247264U)
					{
						goto Block_15;
					}
				}
				IL_1BF:
				if (num - 562969769U == 0U)
				{
					continue;
				}
				num -= 2037783333U;
				object obj4 = obj2;
				num = 1486951072U * num;
				this.154055D0(new 467F5DB3.0BAB1405((bool)obj4));
				if ((num ^ 1315772540U) != 0U)
				{
					return;
				}
				continue;
				Block_12:
				num = 361851013U << (int)num;
				object obj5 = obj2;
				num = (170477976U & num);
				this.154055D0(new 467F5DB3.06B44EBD((char)obj5));
				if (num >> 25 == 0U)
				{
					return;
				}
				continue;
				IL_2FB:
				num = (169762034U & num);
				467F5DB3.37FA30B9 19D13A2 = new 467F5DB3.1C0911B0((int)obj2);
				num += 978414181U;
				this.154055D0(19D13A2);
				if (num % 81951928U != 0U)
				{
					return;
				}
				continue;
				IL_329:
				uint 4C6E61B = (uint)obj2;
				num = 257450051U + num;
				this.154055D0(new 467F5DB3.2DB44737(4C6E61B));
				if ((600863912U ^ num) != 0U)
				{
					return;
				}
				continue;
				IL_3E3:
				object obj6 = obj2;
				num *= 701373627U;
				double 7E9E = (double)obj6;
				num = (456535614U & num);
				467F5DB3.37FA30B9 19D13A3 = new 467F5DB3.07A85735(7E9E);
				num /= 523139670U;
				this.154055D0(19D13A3);
				if ((num ^ 24012256U) != 0U)
				{
					return;
				}
			}
		}
		Block_2:
		throw new NullReferenceException();
		Block_5:
		num = 656412539U << (int)num;
		throw new InvalidCastException();
		IL_26E:
		num = 1537179274U >> (int)num;
		this.154055D0(new 467F5DB3.1A802882((byte)obj2));
		return;
		IL_28E:
		num = 1239048634U + num;
		object obj7 = obj2;
		num = (2012635949U | num);
		short 22CD01C = (short)obj7;
		num = 1878996391U << (int)num;
		this.154055D0(new 467F5DB3.3CC25312(22CD01C));
		return;
		Block_15:
		num %= 1233391817U;
		ushort 4EB81B1D = (ushort)obj2;
		num = 1777022953U * num;
		467F5DB3.37FA30B9 19D13A4 = new 467F5DB3.03CF3096(4EB81B1D);
		num *= 463812927U;
		this.154055D0(19D13A4);
		return;
		IL_387:
		num &= 1147889351U;
		object obj8 = obj2;
		num &= 569076768U;
		ulong 5BBF2E = (ulong)obj8;
		num &= 1852793902U;
		this.154055D0(new 467F5DB3.00C71221(5BBF2E));
		return;
		IL_3B1:
		num ^= 341604357U;
		object obj9 = obj2;
		num = (517417821U & num);
		float 7D = (float)obj9;
		num /= 937446892U;
		467F5DB3.37FA30B9 19D13A5 = new 467F5DB3.3D312057(7D);
		num /= 1822127531U;
		this.154055D0(19D13A5);
		return;
		Block_21:
		throw new InvalidCastException();
	}

	// Token: 0x06000296 RID: 662 RVA: 0x0030A218 File Offset: 0x00307E18
	private void 5D2121D4()
	{
		uint num2;
		do
		{
			long num = this.4E7216B9;
			num2 = 2031181271U;
			long num3 = (long)((ulong)this.026905F8().437B0320());
			num2 = 796489594U + num2;
			IntPtr ptr = new IntPtr(num + num3);
			num2 /= 2069852675U;
			this.154055D0(new 467F5DB3.1C0911B0(Marshal.ReadInt32(ptr)));
		}
		while (970798361U == num2);
	}

	// Token: 0x06000297 RID: 663 RVA: 0x0030A270 File Offset: 0x00307E70
	private void 5DC53681()
	{
		uint num = 1517697343U;
		if (num + 1451259410U != 0U)
		{
			goto IL_12;
		}
		int num3;
		int num5;
		for (;;)
		{
			IL_41:
			int num2 = num3;
			num <<= 30;
			int num4 = num2 >> (int)(num ^ 2147483672U);
			num = (467692268U & num);
			num5 = num4;
			num <<= 1;
			if (1030576549U == num)
			{
				goto IL_12;
			}
			int num6 = num5;
			uint num7 = num ^ 10U;
			num = 1338072864U * num;
			if (num6 > num7)
			{
				break;
			}
			if (num << 6 == 0U)
			{
				goto IL_8F;
			}
		}
		int num8 = num5;
		uint num9 = num - 4294967269U;
		num = (8349550U & num);
		num ^= 0U;
		if (num8 == num9)
		{
			goto IL_186;
		}
		num = 2122860086U * num;
		int num10 = num5;
		uint num11 = num ^ 43U;
		num += 0U;
		if (num10 == num11)
		{
			goto IL_201;
		}
		if (677528169U != num)
		{
			num += 0U;
			goto IL_35E;
		}
		IL_12:
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num = 1183269732U % num;
		int num12 = 37FA30B.D6BFBC24();
		num <<= 29;
		num3 = num12;
		num -= 332017986U;
		if (num >= 1050823783U)
		{
			goto IL_41;
		}
		IL_8F:
		int num13 = num5 - (int)(num ^ 1U);
		num /= 291266869U;
		switch (num13)
		{
		case 0:
		case 1:
		{
			IL_186:
			if (1631719866U >> (int)num == 0U)
			{
				goto IL_12;
			}
			num = 244395702U * num;
			Module module = this.25F821A5;
			num /= 2040013613U;
			ModuleHandle moduleHandle = module.ModuleHandle;
			num |= 1361129004U;
			num = 2072786586U - num;
			int typeToken = num3;
			num &= 1041322575U;
			RuntimeTypeHandle runtimeTypeHandle = moduleHandle.ResolveTypeHandle(typeToken);
			num = 599855252U / num;
			467F5DB3.37FA30B9 19D13A = new 467F5DB3.7EA91122(runtimeTypeHandle);
			num = (647841674U ^ num);
			this.154055D0(19D13A);
			if (589112972U / num == 0U)
			{
				return;
			}
			goto IL_41;
		}
		case 2:
		case 4:
			break;
		case 3:
		{
			num = (1208233958U & num);
			Module module2 = this.25F821A5;
			num = (521169896U | num);
			ModuleHandle moduleHandle2 = module2.ModuleHandle;
			num >>= 23;
			ModuleHandle moduleHandle = moduleHandle2;
			RuntimeFieldHandle runtimeFieldHandle = moduleHandle.ResolveFieldHandle(num3);
			num ^= 1454782732U;
			object 534D4E3B = runtimeFieldHandle;
			num += 1241661635U;
			this.154055D0(new 467F5DB3.7EA91122(534D4E3B));
			return;
		}
		case 5:
			IL_201:
			num = 631459287U >> (int)num;
			if (num >= 250088302U)
			{
				num += 155925556U;
				ModuleHandle moduleHandle3 = this.25F821A5.ModuleHandle;
				num <<= 4;
				ModuleHandle moduleHandle = moduleHandle3;
				int methodToken = num3;
				num = 1544229036U << (int)num;
				RuntimeMethodHandle runtimeMethodHandle = moduleHandle.ResolveMethodHandle(methodToken);
				num &= 1921590825U;
				object 534D4E3B2 = runtimeMethodHandle;
				num &= 1813982338U;
				this.154055D0(new 467F5DB3.7EA91122(534D4E3B2));
				return;
			}
			goto IL_41;
		default:
		{
			num = 1951408503U + num;
			int num14 = num5;
			uint num15 = num ^ 1951408509U;
			num = (497704236U ^ num);
			if (num14 != num15)
			{
				num += 2516943781U;
			}
			else
			{
				if (1718185025U <= num)
				{
					try
					{
						num <<= 26;
						if (600862513U != num)
						{
							do
							{
								num += 1011167078U;
								num = (1386944964U & num);
								ModuleHandle moduleHandle4 = this.25F821A5.ModuleHandle;
								num = (1494764953U & num);
								ModuleHandle moduleHandle = moduleHandle4;
								this.154055D0(new 467F5DB3.7EA91122(moduleHandle.ResolveFieldHandle(num3)));
							}
							while (1659337672U < num);
						}
						return;
					}
					catch (object obj)
					{
						num = 1404442102U;
						num = (23621116U & num);
						if (1745769490U >= num)
						{
							do
							{
								num += 1017517101U;
								num ^= 1745361740U;
								Module module3 = this.25F821A5;
								num /= 743053087U;
								ModuleHandle moduleHandle5 = module3.ModuleHandle;
								num >>= 30;
								ModuleHandle moduleHandle = moduleHandle5;
								num = 954213910U * num;
								object 534D4E3B3 = moduleHandle.ResolveMethodHandle(num3);
								num = (1378776706U & num);
								467F5DB3.37FA30B9 19D13A2 = new 467F5DB3.7EA91122(534D4E3B3);
								num *= 796552421U;
								this.154055D0(19D13A2);
							}
							while (num == 2114344084U);
						}
						return;
					}
					break;
				}
				goto IL_12;
			}
			break;
		}
		}
		IL_35E:
		num = (1319071125U & num);
		throw new InvalidOperationException();
	}

	// Token: 0x06000298 RID: 664 RVA: 0x0030A608 File Offset: 0x00308208
	private void 468F47CF()
	{
		uint num = 1687958433U;
		num = (1110317333U & num);
		object obj = this.026905F8().6B58D7F4();
		num ^= 1797539439U;
		Exception ex = obj as Exception;
		num = (951220885U ^ num);
		num &= 916409651U;
		if (ex == null)
		{
			num = (2015114546U ^ num);
			throw new ArgumentException();
		}
		throw ex;
	}

	// Token: 0x06000299 RID: 665 RVA: 0x0030A660 File Offset: 0x00308260
	private void 6F4478F8()
	{
		uint num = 1402168734U;
		num = 1202802365U / num;
		bool flag = this.65D141FE != null;
		num -= 59534712U;
		if (!flag)
		{
			throw new InvalidOperationException();
		}
		num /= 63450616U;
		throw this.65D141FE;
	}

	// Token: 0x0600029A RID: 666 RVA: 0x0030A6A4 File Offset: 0x003082A4
	private void 16951CC1()
	{
		uint num = 2038456412U;
		if (947277811U > num)
		{
			goto IL_3B;
		}
		IL_11:
		num /= 410064571U;
		int 1ADD01F = this.026905F8().D6BFBC24();
		num = 436147178U * num;
		Type 40793CAF = this.6AA34183(1ADD01F);
		num = (762517386U & num);
		IL_3B:
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num *= 532811465U;
		467F5DB3.37FA30B9 37FA30B2 = 37FA30B;
		num ^= 1576077303U;
		bool flag = this.5E751AD4(37FA30B2.6B58D7F4(), 40793CAF);
		num = 655053429U % num;
		if (!flag)
		{
			num += 1328690252U;
			throw new InvalidCastException();
		}
		num += 1846238417U;
		467F5DB3.37FA30B9 19D13A = 37FA30B;
		num ^= 321393959U;
		this.154055D0(19D13A);
		if ((186219999U ^ num) != 0U)
		{
			return;
		}
		goto IL_11;
	}

	// Token: 0x0600029B RID: 667 RVA: 0x0030A750 File Offset: 0x00308350
	private void 7FA87F62()
	{
		uint num = 2088903702U;
		if (1752988646U * num == 0U)
		{
			goto IL_50;
		}
		IL_12:
		num = 1679702672U - num;
		num = 1201670022U / num;
		467F5DB3.37FA30B9 37FA30B = this.026905F8();
		num &= 1871139216U;
		int 1ADD01F = 37FA30B.D6BFBC24();
		num = 870653687U + num;
		Type 40793CAF = this.6AA34183(1ADD01F);
		if (num % 297870083U == 0U)
		{
			goto IL_57;
		}
		IL_50:
		467F5DB3.37FA30B9 37FA30B2 = this.026905F8();
		IL_57:
		object <<EMPTY_NAME>> = 37FA30B2.6B58D7F4();
		num &= 304752151U;
		if (!this.5E751AD4(<<EMPTY_NAME>>, 40793CAF))
		{
			if ((num & 1836205732U) == 0U)
			{
				goto IL_12;
			}
			37FA30B2 = new 467F5DB3.4CF55D0F(null);
			num ^= 0U;
		}
		if (num + 1895637588U == 0U)
		{
			goto IL_12;
		}
		num = (1967726310U | num);
		this.154055D0(37FA30B2);
		if (num >= 1269899450U)
		{
			return;
		}
		goto IL_12;
	}

	// Token: 0x0600029C RID: 668 RVA: 0x0030A810 File Offset: 0x00308410
	private void 2CD26CDA()
	{
		uint num;
		467F5DB3.37FA30B9 37FA30B2;
		for (;;)
		{
			467F5DB3.37FA30B9 37FA30B = this.026905F8();
			num = 112615003U;
			37FA30B2 = 37FA30B;
			467F5DB3.37FA30B9 37FA30B3 = 37FA30B2;
			num = 1095193668U >> (int)num;
			object obj = 37FA30B3.6B58D7F4();
			num = 1012932168U % num;
			bool flag = obj is IConvertible;
			num &= 849244178U;
			if (flag)
			{
				num = (2005672833U | num);
				if ((num ^ 533274422U) == 0U)
				{
					continue;
				}
				467F5DB3.37FA30B9 37FA30B4 = 37FA30B2;
				num = 1873114729U >> (int)num;
				double d = 37FA30B4.B7D5DC99();
				if (num < 442725249U)
				{
					continue;
				}
				for (;;)
				{
					bool flag2 = double.IsNaN(d);
					num = 1023232763U / num;
					if (flag2)
					{
						break;
					}
					if (num != 291790887U)
					{
						goto Block_3;
					}
				}
				IL_A8:
				num = 1065359871U - num;
				if (2001678735U >= num)
				{
					break;
				}
				continue;
				Block_3:
				bool flag3 = double.IsInfinity(d);
				num |= 768868400U;
				if (flag3)
				{
					num ^= 768868400U;
					goto IL_A8;
				}
			}
			else
			{
				37FA30B2 = new 467F5DB3.07A85735(double.NaN);
				num += 768868401U;
			}
			num = 953762622U / num;
			if (63708827U > num)
			{
				goto Block_6;
			}
		}
		throw new OverflowException();
		Block_6:
		num = 564809438U * num;
		this.154055D0(37FA30B2);
	}

	// Token: 0x0600029D RID: 669 RVA: 0x0030A918 File Offset: 0x00308518
	private unsafe void 292E3E9D()
	{
		uint num;
		IntPtr item;
		for (;;)
		{
			num = 510665418U;
			IntPtr cb = this.026905F8().8C5D656E();
			num = 1764571879U >> (int)num;
			IntPtr intPtr = Marshal.AllocHGlobal(cb);
			num = 265294452U >> (int)num;
			item = intPtr;
			num &= 1478495213U;
			if (num << 15 != 0U)
			{
				List<IntPtr> list = this.11A91B03;
				num -= 1461392473U;
				list.Add(item);
				num |= 923342016U;
				if (num >= 1685218281U)
				{
					break;
				}
			}
		}
		num <<= 20;
		void* ptr = item.ToPointer();
		num &= 1473647994U;
		Type typeFromHandle = typeof(void*);
		num &= 1701604778U;
		467F5DB3.37FA30B9 19D13A = new 467F5DB3.4CF55D0F(Pointer.Box(ptr, typeFromHandle));
		num |= 175902110U;
		this.154055D0(19D13A);
	}

	// Token: 0x0600029E RID: 670 RVA: 0x0030A9D4 File Offset: 0x003085D4
	private void 1FFE5400()
	{
		List<IntPtr>.Enumerator enumerator = this.11A91B03.GetEnumerator();
		uint num = 1805078016U;
		using (List<IntPtr>.Enumerator enumerator2 = enumerator)
		{
			while (776734512U >> (int)num != 0U)
			{
				if (!enumerator2.MoveNext())
				{
					if (num % 1449986097U != 0U)
					{
						break;
					}
				}
				else
				{
					num = 1798726655U;
					Marshal.FreeHGlobal(enumerator2.Current);
					num += 6351361U;
				}
			}
		}
	}

	// Token: 0x0600029F RID: 671 RVA: 0x0030AA6C File Offset: 0x0030866C
	public object 37F432DB(object[] 560004FE, int 7D3066C4)
	{
		uint num;
		do
		{
			num = 1244793361U;
			this.0749791D = 7D3066C4;
			num = 73950745U / num;
		}
		while (num > 397479293U);
		num = (1147405390U ^ num);
		467F5DB3.37FA30B9 19D13A = new 467F5DB3.705703B5(560004FE);
		num |= 47269240U;
		this.154055D0(19D13A);
		object result;
		try
		{
			for (;;)
			{
				num = 1679040272U;
				try
				{
					if (num > 379811682U)
					{
						num = (1528659694U & num);
						Dictionary<uint, 467F5DB3.37CE4668> dictionary = this.4E7C192F;
						num -= 1643055567U;
						num /= 849503954U;
						uint key = (uint)this.301D0658();
						num = 985877452U >> (int)num;
						467F5DB3.37CE4668 37CE = dictionary[key];
						num = (956631849U & num);
						37CE();
					}
					num &= 1642346672U;
					bool flag = this.0749791D != 0;
					num = 238501304U % num;
					if (flag || num >> 29 != 0U)
					{
						continue;
					}
				}
				catch (Exception ex)
				{
					num = 1219914069U;
					Exception <<EMPTY_NAME>> = ex;
					num = 1361269718U << (int)num;
					if (num + 1201031255U != 0U)
					{
						this.2D1405EA(<<EMPTY_NAME>>);
					}
					continue;
				}
				break;
			}
			num = 1070100463U;
			num = 2105885629U * num;
			object obj = this.026905F8().6B58D7F4();
			num = (2140292527U | num);
			result = obj;
		}
		finally
		{
			this.1FFE5400();
		}
		return result;
	}

	// Token: 0x060002A0 RID: 672 RVA: 0x0030ABD4 File Offset: 0x003087D4
	// Note: this type is marked as 'beforefieldinit'.
	static 467F5DB3()
	{
		uint num = 1998081342U;
		if (num != 345184172U)
		{
			do
			{
				467F5DB3.38D3571D = new Dictionary<int, object>();
			}
			while ((881599820U ^ num) == 0U);
			do
			{
				Dictionary<MethodBase, DynamicMethod> dictionary = new Dictionary<MethodBase, DynamicMethod>();
				num = (852131177U | num);
				467F5DB3.480D2F8A = dictionary;
			}
			while (1417949084U == num);
		}
	}

	// Token: 0x0400015E RID: 350
	private readonly Dictionary<uint, 467F5DB3.37CE4668> 4E7C192F;

	// Token: 0x0400015F RID: 351
	private readonly Module 25F821A5;

	// Token: 0x04000160 RID: 352
	private readonly long 4E7216B9;

	// Token: 0x04000161 RID: 353
	private int 0749791D;

	// Token: 0x04000162 RID: 354
	private Type 3A06514C;

	// Token: 0x04000163 RID: 355
	private Stack<467F5DB3.371F2AF7> 65EB1F68;

	// Token: 0x04000164 RID: 356
	private static readonly Dictionary<int, object> 38D3571D;

	// Token: 0x04000165 RID: 357
	private static readonly Dictionary<MethodBase, DynamicMethod> 480D2F8A;

	// Token: 0x04000166 RID: 358
	private List<467F5DB3.37FA30B9> 311B0F7E;

	// Token: 0x04000167 RID: 359
	private List<467F5DB3.74D46A00> 69866088;

	// Token: 0x04000168 RID: 360
	private Stack<467F5DB3.74D46A00> 7E2027B1;

	// Token: 0x04000169 RID: 361
	private Stack<int> 456178D7;

	// Token: 0x0400016A RID: 362
	private Exception 65D141FE;

	// Token: 0x0400016B RID: 363
	private 467F5DB3.42FB763B 58991615;

	// Token: 0x0400016C RID: 364
	private List<IntPtr> 11A91B03;

	// Token: 0x0200004D RID: 77
	private static class 191E6F46
	{
	}

	// Token: 0x0200004E RID: 78
	private abstract class 37FA30B9
	{
		// Token: 0x06000317 RID: 791
		public abstract 467F5DB3.37FA30B9 15FAD4A1();

		// Token: 0x06000318 RID: 792
		public abstract object 6B58D7F4();

		// Token: 0x06000319 RID: 793
		public abstract void 59A76885(object 594737E9);

		// Token: 0x0600031A RID: 794 RVA: 0x002FC34C File Offset: 0x002F9F4C
		public virtual bool 535FA4FE()
		{
			uint num = 893199558U;
			return (num ^ 893199558U) != 0U;
		}

		// Token: 0x0600031B RID: 795 RVA: 0x0030B8CC File Offset: 0x003094CC
		public virtual 467F5DB3.371F2AF7 52809797()
		{
			throw new InvalidOperationException();
		}

		// Token: 0x0600031C RID: 796 RVA: 0x0030B8E0 File Offset: 0x003094E0
		public virtual 467F5DB3.37FA30B9 374AB499()
		{
			return this;
		}

		// Token: 0x0600031D RID: 797 RVA: 0x0030B8CC File Offset: 0x003094CC
		public virtual Type 303BF244()
		{
			throw new InvalidOperationException();
		}

		// Token: 0x0600031E RID: 798 RVA: 0x0030B8CC File Offset: 0x003094CC
		public virtual TypeCode 02557F0D()
		{
			throw new InvalidOperationException();
		}

		// Token: 0x0600031F RID: 799 RVA: 0x0030B8F4 File Offset: 0x003094F4
		public virtual bool A8DF755E()
		{
			return Convert.ToBoolean(this.6B58D7F4());
		}

		// Token: 0x06000320 RID: 800 RVA: 0x0030B914 File Offset: 0x00309514
		public virtual sbyte 3D1BD445()
		{
			return Convert.ToSByte(this.6B58D7F4());
		}

		// Token: 0x06000321 RID: 801 RVA: 0x0030B934 File Offset: 0x00309534
		public virtual short D204A80D()
		{
			return Convert.ToInt16(this.6B58D7F4());
		}

		// Token: 0x06000322 RID: 802 RVA: 0x0030B954 File Offset: 0x00309554
		public virtual int D6BFBC24()
		{
			return Convert.ToInt32(this.6B58D7F4());
		}

		// Token: 0x06000323 RID: 803 RVA: 0x0030B974 File Offset: 0x00309574
		public virtual long E1698415()
		{
			return Convert.ToInt64(this.6B58D7F4());
		}

		// Token: 0x06000324 RID: 804 RVA: 0x0030B994 File Offset: 0x00309594
		public virtual char C8DBDBAA()
		{
			uint num = 1079075392U;
			object value = this.6B58D7F4();
			num = 1981441120U - num;
			return Convert.ToChar(value);
		}

		// Token: 0x06000325 RID: 805 RVA: 0x0030B9BC File Offset: 0x003095BC
		public virtual byte 76883720()
		{
			uint num = 227309152U;
			num = 1222459061U << (int)num;
			return Convert.ToByte(this.6B58D7F4());
		}

		// Token: 0x06000326 RID: 806 RVA: 0x0030B9E8 File Offset: 0x003095E8
		public virtual ushort E91B7AB7()
		{
			return Convert.ToUInt16(this.6B58D7F4());
		}

		// Token: 0x06000327 RID: 807 RVA: 0x0030BA08 File Offset: 0x00309608
		public virtual uint 437B0320()
		{
			return Convert.ToUInt32(this.6B58D7F4());
		}

		// Token: 0x06000328 RID: 808 RVA: 0x0030BA28 File Offset: 0x00309628
		public virtual ulong 67922FD7()
		{
			return Convert.ToUInt64(this.6B58D7F4());
		}

		// Token: 0x06000329 RID: 809 RVA: 0x0030BA48 File Offset: 0x00309648
		public virtual float 8E4073FD()
		{
			uint num = 1744270804U;
			num = 179639499U * num;
			object value = this.6B58D7F4();
			num = 2114537210U + num;
			return Convert.ToSingle(value);
		}

		// Token: 0x0600032A RID: 810 RVA: 0x0030BA78 File Offset: 0x00309678
		public virtual double B7D5DC99()
		{
			return Convert.ToDouble(this.6B58D7F4());
		}

		// Token: 0x0600032B RID: 811 RVA: 0x0030BA98 File Offset: 0x00309698
		public override string ToString()
		{
			uint num;
			object obj2;
			do
			{
				num = 2016628187U;
				object obj = this.6B58D7F4();
				num ^= 1222775831U;
				obj2 = obj;
				num = 105853679U + num;
			}
			while (217189095U >= num);
			bool flag = obj2 != null;
			num <<= 10;
			if (!flag)
			{
				num = 1086531867U / num;
				if (103768177U >= num)
				{
					return null;
				}
			}
			num *= 7078317U;
			object value = obj2;
			num = 11820556U << (int)num;
			return Convert.ToString(value);
		}

		// Token: 0x0600032C RID: 812 RVA: 0x0030B8CC File Offset: 0x003094CC
		public virtual IntPtr 8C5D656E()
		{
			throw new InvalidOperationException();
		}

		// Token: 0x0600032D RID: 813 RVA: 0x0030B8CC File Offset: 0x003094CC
		public virtual UIntPtr 103B638B()
		{
			throw new InvalidOperationException();
		}

		// Token: 0x0600032E RID: 814 RVA: 0x0030B8CC File Offset: 0x003094CC
		public virtual object F187362C(Type 21146C93, bool 72846F16)
		{
			throw new InvalidOperationException();
		}
	}

	// Token: 0x0200004F RID: 79
	private abstract class 371F2AF7 : 467F5DB3.37FA30B9
	{
		// Token: 0x06000330 RID: 816 RVA: 0x0030B8E0 File Offset: 0x003094E0
		public override 467F5DB3.371F2AF7 52809797()
		{
			return this;
		}

		// Token: 0x06000331 RID: 817 RVA: 0x002FC34C File Offset: 0x002F9F4C
		public override TypeCode 02557F0D()
		{
			uint num = 893199558U;
			return (TypeCode)(num ^ 893199558U);
		}

		// Token: 0x06000332 RID: 818 RVA: 0x0030BB0C File Offset: 0x0030970C
		protected 371F2AF7()
		{
			uint num = 344545617U;
			if (num - 1112169201U != 0U)
			{
				num <<= 24;
				base..ctor();
			}
		}
	}

	// Token: 0x02000050 RID: 80
	private sealed class 1C0911B0 : 467F5DB3.371F2AF7
	{
		// Token: 0x06000333 RID: 819 RVA: 0x0030BB3C File Offset: 0x0030973C
		public 1C0911B0(int 0A163903)
		{
			uint num = 1746819131U;
			do
			{
				num = (1936736798U & num);
				num = (1694961570U | num);
				this.3725403F = 0A163903;
			}
			while (num == 1466319688U);
		}

		// Token: 0x06000334 RID: 820 RVA: 0x0030BB78 File Offset: 0x00309778
		public override Type 303BF244()
		{
			return typeof(int);
		}

		// Token: 0x06000335 RID: 821 RVA: 0x0030BB98 File Offset: 0x00309798
		public override TypeCode 02557F0D()
		{
			return TypeCode.Int32;
		}

		// Token: 0x06000336 RID: 822 RVA: 0x0030BBA8 File Offset: 0x003097A8
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 622072986U;
			int 0A = this.3725403F;
			num %= 1726767891U;
			return new 467F5DB3.1C0911B0(0A);
		}

		// Token: 0x06000337 RID: 823 RVA: 0x0030BBD0 File Offset: 0x003097D0
		public override object 6B58D7F4()
		{
			uint num = 1651723106U;
			num = 1065435252U << (int)num;
			return this.3725403F;
		}

		// Token: 0x06000338 RID: 824 RVA: 0x0030BBFC File Offset: 0x003097FC
		public override void 59A76885(object 375260D2)
		{
			uint num = 1615221693U;
			if (700463729U <= num)
			{
				do
				{
					num <<= 2;
					int num2 = Convert.ToInt32(375260D2);
					num |= 957841397U;
					this.3725403F = num2;
				}
				while ((num ^ 653996391U) == 0U);
			}
		}

		// Token: 0x06000339 RID: 825 RVA: 0x0030BC44 File Offset: 0x00309844
		public override bool A8DF755E()
		{
			uint num = 1059003890U;
			return this.3725403F > (int)(num ^ 1059003890U);
		}

		// Token: 0x0600033A RID: 826 RVA: 0x0030BC68 File Offset: 0x00309868
		public override sbyte 3D1BD445()
		{
			return (sbyte)this.3725403F;
		}

		// Token: 0x0600033B RID: 827 RVA: 0x0030BC7C File Offset: 0x0030987C
		public override short D204A80D()
		{
			uint num = 165043000U;
			num ^= 1725587020U;
			return (short)this.3725403F;
		}

		// Token: 0x0600033C RID: 828 RVA: 0x0030BCA0 File Offset: 0x003098A0
		public override int D6BFBC24()
		{
			uint num = 1944809850U;
			num >>= 18;
			return this.3725403F;
		}

		// Token: 0x0600033D RID: 829 RVA: 0x0030BCC4 File Offset: 0x003098C4
		public override long E1698415()
		{
			uint num = 1863326881U;
			long num2 = (long)this.3725403F;
			num = 392981844U >> (int)num;
			return num2;
		}

		// Token: 0x0600033E RID: 830 RVA: 0x0030BCEC File Offset: 0x003098EC
		public override char C8DBDBAA()
		{
			return (char)this.3725403F;
		}

		// Token: 0x0600033F RID: 831 RVA: 0x0030BD08 File Offset: 0x00309908
		public override byte 76883720()
		{
			uint num = 44568137U;
			byte b = (byte)this.3725403F;
			num = (2042369018U ^ num);
			return b;
		}

		// Token: 0x06000340 RID: 832 RVA: 0x0030BCEC File Offset: 0x003098EC
		public override ushort E91B7AB7()
		{
			return (ushort)this.3725403F;
		}

		// Token: 0x06000341 RID: 833 RVA: 0x0030BCA0 File Offset: 0x003098A0
		public override uint 437B0320()
		{
			uint num = 1944809850U;
			num >>= 18;
			return (uint)this.3725403F;
		}

		// Token: 0x06000342 RID: 834 RVA: 0x0030BD2C File Offset: 0x0030992C
		public override ulong 67922FD7()
		{
			uint num = 574839022U;
			num %= 625040384U;
			return (ulong)this.3725403F;
		}

		// Token: 0x06000343 RID: 835 RVA: 0x0030BD50 File Offset: 0x00309950
		public override float 8E4073FD()
		{
			return (float)this.3725403F;
		}

		// Token: 0x06000344 RID: 836 RVA: 0x0030BD64 File Offset: 0x00309964
		public override double B7D5DC99()
		{
			return (double)this.3725403F;
		}

		// Token: 0x06000345 RID: 837 RVA: 0x0030BD80 File Offset: 0x00309980
		public override IntPtr 8C5D656E()
		{
			return new IntPtr(this.3725403F);
		}

		// Token: 0x06000346 RID: 838 RVA: 0x0030BDA0 File Offset: 0x003099A0
		public override UIntPtr 103B638B()
		{
			uint num = 1093954738U;
			uint value = (uint)this.3725403F;
			num += 1073229006U;
			return new UIntPtr(value);
		}

		// Token: 0x06000347 RID: 839 RVA: 0x0030BDC8 File Offset: 0x003099C8
		public override 467F5DB3.37FA30B9 374AB499()
		{
			uint num = 1414688090U;
			num = 1519482643U / num;
			return new 467F5DB3.2DB44737((uint)this.3725403F);
		}

		// Token: 0x06000348 RID: 840 RVA: 0x0030BDF0 File Offset: 0x003099F0
		public override object F187362C(Type 65F744CD, bool 43E80075)
		{
			uint num = 49950637U;
			if (num * 1735334727U == 0U)
			{
				goto IL_44;
			}
			for (;;)
			{
				IL_12:
				RuntimeTypeHandle handle = typeof(IntPtr).TypeHandle;
				num ^= 1356952123U;
				Type typeFromHandle = Type.GetTypeFromHandle(handle);
				num = 1223041798U << (int)num;
				if (65F744CD == typeFromHandle)
				{
					break;
				}
				num >>= 1;
				if (1794800112U / num == 0U)
				{
					goto IL_44;
				}
				num += 1962869186U;
				RuntimeTypeHandle handle2 = typeof(UIntPtr).TypeHandle;
				num >>= 16;
				if (65F744CD != Type.GetTypeFromHandle(handle2))
				{
					num = 671161958U / num;
					TypeCode typeCode = Type.GetTypeCode(65F744CD);
					num &= 1135687098U;
					object obj = typeCode;
					num = (2111586619U ^ num);
					object obj2 = num + 2183371634U;
					num = 412167986U >> (int)num;
					object obj3 = obj - obj2;
					num -= 1813477197U;
					switch (obj3)
					{
					case 0:
						goto IL_217;
					case 1:
						if (!43E80075)
						{
							goto Block_19;
						}
						num %= 1045778957U;
						if (2072720267U != num)
						{
							goto Block_20;
						}
						continue;
					case 2:
						goto IL_27C;
					case 3:
						if (num * 789522047U != 0U)
						{
							goto Block_21;
						}
						continue;
					case 4:
						num = 1988764662U << (int)num;
						if (num > 505957627U)
						{
							goto Block_14;
						}
						continue;
					case 5:
						goto IL_476;
					case 6:
						num |= 1827176181U;
						if (43E80075)
						{
							goto IL_37B;
						}
						if (num % 1403086430U != 0U)
						{
							goto Block_18;
						}
						continue;
					case 7:
						if (num + 1409616737U == 0U)
						{
							continue;
						}
						num = 1519153010U + num;
						if (43E80075)
						{
							goto IL_4F3;
						}
						if (num >= 74340417U)
						{
							goto Block_28;
						}
						continue;
					case 8:
						goto IL_572;
					case 9:
						num |= 523051069U;
						num = (1457590024U ^ num);
						if (!43E80075)
						{
							goto Block_30;
						}
						if (1321284929U * num != 0U)
						{
							goto Block_32;
						}
						continue;
					}
					goto Block_9;
				}
				if (!43E80075)
				{
					goto Block_7;
				}
				num = 756429922U % num;
				if (num < 256594456U)
				{
					goto Block_8;
				}
			}
			if (727414620U * num != 0U)
			{
				goto IL_44;
			}
			goto IL_8A;
			Block_7:
			num = (1093274286U ^ num);
			num += 2102748992U;
			uint num2 = (uint)this.3725403F;
			num >>= 7;
			uint value = num2;
			goto IL_18C;
			Block_8:
			value = (uint)this.3725403F;
			num += 24920171U;
			IL_18C:
			num = 2064873786U * num;
			return new UIntPtr(value);
			Block_9:
			num += 0U;
			goto IL_572;
			IL_217:
			num = (21123383U | num);
			if (1508586155 << (int)num != 0)
			{
				sbyte b2;
				if (!43E80075)
				{
					num += 1990272761U;
					if (1110603904U <= num)
					{
						goto IL_77;
					}
					num |= 1230252244U;
					sbyte b = (sbyte)this.3725403F;
					num &= 418591102U;
					b2 = b;
				}
				else
				{
					b2 = checked((sbyte)((uint)this.3725403F));
					num ^= 2604333955U;
				}
				return b2;
			}
			goto IL_44;
			IL_27C:
			num %= 1464170311U;
			num ^= 2102464610U;
			short num4;
			if (!43E80075)
			{
				num ^= 2095348765U;
				num = 469269769U - num;
				short num3 = (short)this.3725403F;
				num &= 1469907063U;
				num4 = num3;
			}
			else
			{
				uint num5 = (uint)this.3725403F;
				num /= 1060659450U;
				num4 = checked((short)num5);
				num ^= 1451229185U;
			}
			return num4;
			Block_14:
			num = 233581178U + num;
			int num6;
			if (!43E80075)
			{
				num = 439179082U << (int)num;
				if (num >= 1906799221U)
				{
					goto IL_69;
				}
				num6 = this.3725403F;
			}
			else
			{
				num += 2093039568U;
				num = 1739464758U + num;
				int num7 = (int)(checked((uint)this.3725403F));
				num = 828595841U % num;
				num6 = num7;
				num += 4137460095U;
			}
			return num6;
			Block_18:
			long num8 = (long)this.3725403F;
			num %= 1856729304U;
			long num9 = num8;
			goto IL_39A;
			IL_37B:
			num /= 1320961537U;
			num = (1089745303U | num);
			num9 = (long)((ulong)this.3725403F);
			num += 3785223342U;
			IL_39A:
			num = (1879453504U | num);
			return num9;
			Block_19:
			num += 2030401879U;
			byte b3 = (byte)this.3725403F;
			num >>= 13;
			byte b4 = b3;
			goto IL_405;
			Block_20:
			num ^= 712383613U;
			uint num10 = (uint)this.3725403F;
			num = 1437411377U / num;
			byte b5 = (byte)num10;
			num = 710628388U * num;
			b4 = b5;
			num ^= 710619988U;
			IL_405:
			num = (1938636973U & num);
			return b4;
			Block_21:
			ushort num11;
			if (!43E80075)
			{
				if (num <= 94273225U)
				{
					goto IL_44;
				}
				num11 = checked((ushort)this.3725403F);
			}
			else
			{
				num *= 664480822U;
				if ((538590324U & num) == 0U)
				{
					goto IL_8A;
				}
				num |= 184294903U;
				uint num12 = (uint)this.3725403F;
				num = 398142542U - num;
				num11 = checked((ushort)num12);
				num += 1261158262U;
			}
			return num11;
			IL_476:
			num = 2060129980U * num;
			uint num13;
			if (!43E80075)
			{
				num = 1328506634U - num;
				num13 = checked((uint)this.3725403F);
			}
			else
			{
				num13 = (uint)this.3725403F;
				num += 2871935410U;
			}
			num ^= 1848117530U;
			return num13;
			Block_28:
			num = 1333403854U << (int)num;
			uint num14 = checked((uint)this.3725403F);
			goto IL_50C;
			IL_4F3:
			if (num <= 1476945848U)
			{
				goto IL_D4;
			}
			num14 = (uint)this.3725403F;
			num ^= 2306145079U;
			IL_50C:
			num = 698447595U % num;
			return num14;
			Block_30:
			double num16;
			if ((1319125289U ^ num) != 0U)
			{
				double num15 = (double)this.3725403F;
				num = (1098216100U ^ num);
				num16 = num15;
				goto IL_56C;
			}
			goto IL_44;
			Block_32:
			num16 = this.3725403F;
			num ^= 1098216100U;
			IL_56C:
			return num16;
			IL_572:
			throw new ArgumentException();
			for (;;)
			{
				IL_44:
				int size = IntPtr.Size;
				uint num17 = num + 1048576004U;
				num |= 175071333U;
				if (size == num17)
				{
					break;
				}
				if (43E80075)
				{
					goto IL_E0;
				}
				num = 609559919U >> (int)num;
				if (948727027U != num)
				{
					goto IL_D4;
				}
			}
			if ((573010057U & num) != 0U)
			{
				goto IL_69;
			}
			goto IL_12;
			IL_E0:
			long value2;
			if (1477644087U <= num)
			{
				value2 = (long)((ulong)this.3725403F);
				num += 892553414U;
				goto IL_FA;
			}
			goto IL_77;
			IL_69:
			num = 2007833383U - num;
			if (43E80075)
			{
				goto IL_8A;
			}
			IL_77:
			num = (699745253U ^ num);
			int value3 = this.3725403F;
			goto IL_A2;
			IL_8A:
			uint num18 = (uint)this.3725403F;
			num = (1990016466U | num);
			value3 = checked((int)num18);
			num ^= 2109032181U;
			IL_A2:
			IntPtr intPtr = new IntPtr(value3);
			num <<= 4;
			return intPtr;
			IL_D4:
			value2 = (long)this.3725403F;
			IL_FA:
			num %= 378944574U;
			return new IntPtr(value2);
		}

		// Token: 0x040001C4 RID: 452
		private int 3725403F;
	}

	// Token: 0x02000051 RID: 81
	private sealed class 06E010E5 : 467F5DB3.371F2AF7
	{
		// Token: 0x06000349 RID: 841 RVA: 0x0030C374 File Offset: 0x00309F74
		public 06E010E5(long 0E0B6625)
		{
			uint num = 1994947927U;
			if ((1718185856U ^ num) != 0U)
			{
				do
				{
					base..ctor();
					if (num == 867637902U)
					{
						break;
					}
					num = 1383942377U << (int)num;
					this.1376772D = 0E0B6625;
				}
				while (1427712958U > num);
			}
		}

		// Token: 0x0600034A RID: 842 RVA: 0x0030C3C4 File Offset: 0x00309FC4
		public override Type 303BF244()
		{
			return typeof(long);
		}

		// Token: 0x0600034B RID: 843 RVA: 0x0030C3E4 File Offset: 0x00309FE4
		public override TypeCode 02557F0D()
		{
			return TypeCode.Int64;
		}

		// Token: 0x0600034C RID: 844 RVA: 0x0030C3F4 File Offset: 0x00309FF4
		public override 467F5DB3.37FA30B9 374AB499()
		{
			return new 467F5DB3.00C71221((ulong)this.1376772D);
		}

		// Token: 0x0600034D RID: 845 RVA: 0x0030C414 File Offset: 0x0030A014
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 2075349019U;
			long 0E0B = this.1376772D;
			num = 1620260119U >> (int)num;
			return new 467F5DB3.06E010E5(0E0B);
		}

		// Token: 0x0600034E RID: 846 RVA: 0x0030C440 File Offset: 0x0030A040
		public override object 6B58D7F4()
		{
			return this.1376772D;
		}

		// Token: 0x0600034F RID: 847 RVA: 0x0030C460 File Offset: 0x0030A060
		public override void 59A76885(object 4BA47C76)
		{
			uint num = 205421110U;
			long num2 = Convert.ToInt64(4BA47C76);
			num = 88869124U * num;
			this.1376772D = num2;
		}

		// Token: 0x06000350 RID: 848 RVA: 0x0030C488 File Offset: 0x0030A088
		public override bool A8DF755E()
		{
			uint num = 90209731U;
			num &= 1668295932U;
			long num2 = this.1376772D;
			num = 908938763U << (int)num;
			long num3 = (long)(num ^ 908938763U);
			num /= 1778788049U;
			return num2 > num3;
		}

		// Token: 0x06000351 RID: 849 RVA: 0x0030C4CC File Offset: 0x0030A0CC
		public override char C8DBDBAA()
		{
			uint num = 2146781423U;
			char c = (char)this.1376772D;
			num >>= 12;
			return c;
		}

		// Token: 0x06000352 RID: 850 RVA: 0x0030C4F0 File Offset: 0x0030A0F0
		public override byte 76883720()
		{
			uint num = 1645502069U;
			byte b = (byte)this.1376772D;
			num = 1427060555U >> (int)num;
			return b;
		}

		// Token: 0x06000353 RID: 851 RVA: 0x0030C518 File Offset: 0x0030A118
		public override sbyte 3D1BD445()
		{
			uint num = 1453668489U;
			sbyte b = (sbyte)this.1376772D;
			num = 840721903U / num;
			return b;
		}

		// Token: 0x06000354 RID: 852 RVA: 0x0030C53C File Offset: 0x0030A13C
		public override short D204A80D()
		{
			uint num = 1997302641U;
			short num2 = (short)this.1376772D;
			num = (314598682U & num);
			return num2;
		}

		// Token: 0x06000355 RID: 853 RVA: 0x0030C560 File Offset: 0x0030A160
		public override int D6BFBC24()
		{
			return (int)this.1376772D;
		}

		// Token: 0x06000356 RID: 854 RVA: 0x0030C57C File Offset: 0x0030A17C
		public override long E1698415()
		{
			return this.1376772D;
		}

		// Token: 0x06000357 RID: 855 RVA: 0x0030C4CC File Offset: 0x0030A0CC
		public override ushort E91B7AB7()
		{
			uint num = 2146781423U;
			ushort num2 = (ushort)this.1376772D;
			num >>= 12;
			return num2;
		}

		// Token: 0x06000358 RID: 856 RVA: 0x0030C598 File Offset: 0x0030A198
		public override uint 437B0320()
		{
			return (uint)this.1376772D;
		}

		// Token: 0x06000359 RID: 857 RVA: 0x0030C57C File Offset: 0x0030A17C
		public override ulong 67922FD7()
		{
			return (ulong)this.1376772D;
		}

		// Token: 0x0600035A RID: 858 RVA: 0x0030C5B4 File Offset: 0x0030A1B4
		public override float 8E4073FD()
		{
			uint num = 87231852U;
			num *= 518998150U;
			float num2 = (float)this.1376772D;
			num = 1619347213U + num;
			return num2;
		}

		// Token: 0x0600035B RID: 859 RVA: 0x0030C5E0 File Offset: 0x0030A1E0
		public override double B7D5DC99()
		{
			return (double)this.1376772D;
		}

		// Token: 0x0600035C RID: 860 RVA: 0x0030C5FC File Offset: 0x0030A1FC
		public override IntPtr 8C5D656E()
		{
			int size = IntPtr.Size;
			uint num = 101674576U;
			uint num2 = num ^ 101674580U;
			num >>= 5;
			long value;
			if (size != num2 && num / 1055603630U == 0U)
			{
				num = (605444063U ^ num);
				value = this.1376772D;
			}
			else
			{
				long num3 = (long)((int)this.1376772D);
				num = 1949378149U >> (int)num;
				value = num3;
				num += 606474145U;
			}
			num = (1875379617U | num);
			return new IntPtr(value);
		}

		// Token: 0x0600035D RID: 861 RVA: 0x0030C674 File Offset: 0x0030A274
		public override UIntPtr 103B638B()
		{
			int size = UIntPtr.Size;
			uint num = 1023558906U;
			uint num2 = num ^ 1023558910U;
			num = 859137096U >> (int)num;
			ulong value;
			if (size != num2)
			{
				value = (ulong)this.1376772D;
			}
			else
			{
				num = 1016549846U % num;
				uint num3 = (uint)this.1376772D;
				num = (1920040306U | num);
				value = (ulong)num3;
				num += 2374927002U;
			}
			num = 1150057426U / num;
			return new UIntPtr(value);
		}

		// Token: 0x0600035E RID: 862 RVA: 0x0030C6E0 File Offset: 0x0030A2E0
		public override object F187362C(Type 06031584, bool 21F64D72)
		{
			uint num = 54745095U;
			if (114697054U == num)
			{
				goto IL_35;
			}
			for (;;)
			{
				IL_11:
				num = 1030949879U - num;
				if (06031584 == typeof(IntPtr))
				{
					break;
				}
				num <<= 27;
				if (num + 1849510422U != 0U)
				{
					Type typeFromHandle = typeof(UIntPtr);
					num = 1809801220U + num;
					if (06031584 == typeFromHandle)
					{
						goto Block_4;
					}
					num = 1567957941U << (int)num;
					num = 416820338U >> (int)num;
					TypeCode typeCode = Type.GetTypeCode(06031584);
					TypeCode typeCode2 = typeCode;
					num *= 1619422043U;
					uint num2 = num ^ 192617677U;
					num |= 1821195722U;
					switch (typeCode2 - num2)
					{
					case 0:
						goto IL_1AA;
					case 1:
						if (num <= 834287183U)
						{
							continue;
						}
						if (!21F64D72)
						{
							goto Block_20;
						}
						if (1279797142U <= num)
						{
							goto Block_21;
						}
						continue;
					case 2:
						if (1383476844U * num != 0U)
						{
							goto Block_10;
						}
						continue;
					case 3:
						num *= 1045119748U;
						if ((num & 1381055481U) == 0U)
						{
							continue;
						}
						if (!21F64D72)
						{
							num = 182732038U >> (int)num;
							if (675823948U != num)
							{
								goto Block_24;
							}
							continue;
						}
						else
						{
							num %= 1106784165U;
							if ((num & 272774955U) != 0U)
							{
								goto Block_25;
							}
							continue;
						}
						break;
					case 4:
						goto IL_2AB;
					case 5:
						goto IL_421;
					case 6:
						if (21F64D72)
						{
							goto IL_328;
						}
						if (786305363U % num != 0U)
						{
							goto Block_18;
						}
						continue;
					case 7:
						goto IL_490;
					case 8:
						goto IL_520;
					case 9:
						goto IL_4CC;
					}
					goto Block_7;
				}
			}
			if (num >> 24 != 0U)
			{
				goto IL_35;
			}
			goto IL_68;
			Block_4:
			if (1471094358U - num != 0U)
			{
				num = (320955648U | num);
				ulong value;
				if (!21F64D72)
				{
					num *= 1279028111U;
					num /= 204284928U;
					ulong num3 = (ulong)this.1376772D;
					num += 61030086U;
					value = num3;
				}
				else
				{
					num = (869284691U ^ num);
					value = (ulong)this.1376772D;
					num ^= 3414974618U;
				}
				return new UIntPtr(value);
			}
			goto IL_68;
			Block_7:
			num ^= 0U;
			goto IL_520;
			IL_1AA:
			num = 1590583344U * num;
			if (num >= 1969969562U)
			{
				num /= 1554210894U;
				sbyte b;
				if (!21F64D72)
				{
					num = (1926765637U | num);
					num = 2134604339U >> (int)num;
					b = checked((sbyte)this.1376772D);
				}
				else
				{
					num = (923739265U ^ num);
					num ^= 2040730571U;
					ulong num4 = (ulong)this.1376772D;
					num >>= 22;
					sbyte b2 = (sbyte)num4;
					num %= 1061368345U;
					b = b2;
					num += 66706071U;
				}
				return b;
			}
			goto IL_55;
			Block_10:
			num = (2073765555U ^ num);
			short num6;
			if (!21F64D72)
			{
				num |= 2072062955U;
				if (num < 159676644U)
				{
					goto IL_68;
				}
				num = 1770466738U % num;
				short num5 = (short)this.1376772D;
				num &= 1039363912U;
				num6 = num5;
			}
			else
			{
				num >>= 10;
				if (num >= 1937054466U)
				{
					goto IL_35;
				}
				ulong num7 = (ulong)this.1376772D;
				num = 1765946833U + num;
				short num8 = (short)num7;
				num = 732502801U >> (int)num;
				num6 = num8;
				num ^= 696462679U;
			}
			return num6;
			IL_2AB:
			num = (1023243505U | num);
			if ((num ^ 344080044U) != 0U)
			{
				int num9;
				if (!21F64D72)
				{
					num9 = checked((int)this.1376772D);
				}
				else
				{
					if (923402562U % num == 0U)
					{
						goto IL_55;
					}
					num = 1963283689U + num;
					ulong num10 = (ulong)this.1376772D;
					num += 2056586830U;
					num9 = checked((int)num10);
					num ^= 275162313U;
				}
				num %= 520376693U;
				return num9;
			}
			goto IL_68;
			Block_18:
			long num11 = this.1376772D;
			goto IL_34E;
			IL_328:
			num += 207818305U;
			ulong num12 = (ulong)this.1376772D;
			num = 214910409U << (int)num;
			checked
			{
				num11 = (long)num12;
				num ^= 366048714U;
				IL_34E:
				return num11;
				Block_20:
				byte b3 = (byte)this.1376772D;
				goto IL_394;
				Block_21:
				ulong num13 = (ulong)this.1376772D;
				num = 1881607798U % num;
				b3 = (byte)num13;
				num ^= 1876487526U;
				IL_394:
				return b3;
				Block_24:
				num ^= 612720058U;
				ushort num14 = (ushort)this.1376772D;
				goto IL_40D;
				Block_25:
				uint num15 = (uint)this.1376772D;
				num = 372783202U % num;
				num14 = (ushort)num15;
				num ^= 576617339U;
				IL_40D:
				num = 1721709323U << (int)num;
				return num14;
				IL_421:;
			}
			if (num >= 748304718U)
			{
				uint num17;
				if (!21F64D72)
				{
					num = 1066357686U - num;
					num = 152316956U % num;
					uint num16 = (uint)this.1376772D;
					num = 1174756053U << (int)num;
					num17 = num16;
				}
				else
				{
					num *= 704858427U;
					num = 1176699815U / num;
					uint num18 = (uint)(checked((ulong)this.1376772D));
					num = 832075884U >> (int)num;
					num17 = num18;
					num += 510101396U;
				}
				return num17;
			}
			goto IL_35;
			IL_490:
			ulong num19;
			if (!21F64D72)
			{
				num = 1705581161U >> (int)num;
				num19 = checked((ulong)this.1376772D);
			}
			else
			{
				num19 = (ulong)this.1376772D;
				num ^= 1877366668U;
			}
			num = 481064264U % num;
			return num19;
			IL_4CC:
			double num21;
			if (!21F64D72)
			{
				if ((1532892592U & num) == 0U)
				{
					goto IL_35;
				}
				double num20 = (double)this.1376772D;
				num = 1581347718U * num;
				num21 = num20;
			}
			else
			{
				num += 2122077702U;
				double num22 = this.1376772D;
				num = 1996322124U + num;
				num21 = num22;
				num ^= 1105140896U;
			}
			num = (184902860U ^ num);
			return num21;
			IL_520:
			throw new ArgumentException();
			IL_35:
			if (21F64D72)
			{
				goto IL_68;
			}
			num = 785338372U >> (int)num;
			if ((num ^ 197027315U) == 0U)
			{
				goto IL_11;
			}
			IL_55:
			num = (1526294550U & num);
			long value2 = this.1376772D;
			goto IL_8E;
			IL_68:
			ulong num23 = (ulong)this.1376772D;
			num ^= 232681232U;
			long num24 = (long)num23;
			num = 804798134U >> (int)num;
			value2 = num24;
			num += 3490179408U;
			IL_8E:
			num += 1007569073U;
			IntPtr intPtr = new IntPtr(value2);
			num = (1668613931U | num);
			return intPtr;
		}

		// Token: 0x040001C5 RID: 453
		private long 1376772D;
	}

	// Token: 0x02000052 RID: 82
	private sealed class 3D312057 : 467F5DB3.371F2AF7
	{
		// Token: 0x0600035F RID: 863 RVA: 0x0030CC14 File Offset: 0x0030A814
		public 3D312057(float 7D442193)
		{
			uint num = 210395511U;
			base..ctor();
			if (1684961761U > num)
			{
				do
				{
					this.04D27930 = 7D442193;
				}
				while (num > 1363246844U);
			}
		}

		// Token: 0x06000360 RID: 864 RVA: 0x0030CC4C File Offset: 0x0030A84C
		public override Type 303BF244()
		{
			return typeof(float);
		}

		// Token: 0x06000361 RID: 865 RVA: 0x0030CC64 File Offset: 0x0030A864
		public override TypeCode 02557F0D()
		{
			return TypeCode.Single;
		}

		// Token: 0x06000362 RID: 866 RVA: 0x0030CC74 File Offset: 0x0030A874
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 282482546U;
			num <<= 0;
			return new 467F5DB3.3D312057(this.04D27930);
		}

		// Token: 0x06000363 RID: 867 RVA: 0x0030CC9C File Offset: 0x0030A89C
		public override object 6B58D7F4()
		{
			uint num = 1635530638U;
			num = (1978805405U ^ num);
			float num2 = this.04D27930;
			num += 1692089834U;
			return num2;
		}

		// Token: 0x06000364 RID: 868 RVA: 0x0030CCCC File Offset: 0x0030A8CC
		public override void 59A76885(object 58D2063F)
		{
			uint num = 1355774517U;
			num = (478772802U & num);
			float num2 = Convert.ToSingle(58D2063F);
			num = 604637818U / num;
			this.04D27930 = num2;
		}

		// Token: 0x06000365 RID: 869 RVA: 0x0030CCFC File Offset: 0x0030A8FC
		public override bool A8DF755E()
		{
			return Convert.ToBoolean(this.04D27930);
		}

		// Token: 0x06000366 RID: 870 RVA: 0x0030CD1C File Offset: 0x0030A91C
		public override sbyte 3D1BD445()
		{
			uint num = 1074612096U;
			sbyte b = (sbyte)this.04D27930;
			num = (715874186U ^ num);
			return b;
		}

		// Token: 0x06000367 RID: 871 RVA: 0x0030CD40 File Offset: 0x0030A940
		public override short D204A80D()
		{
			return (short)this.04D27930;
		}

		// Token: 0x06000368 RID: 872 RVA: 0x0030CD5C File Offset: 0x0030A95C
		public override int D6BFBC24()
		{
			uint num = 93875150U;
			num = (331946782U ^ num);
			int num2 = (int)this.04D27930;
			num /= 2024880801U;
			return num2;
		}

		// Token: 0x06000369 RID: 873 RVA: 0x0030CD88 File Offset: 0x0030A988
		public override long E1698415()
		{
			return (long)this.04D27930;
		}

		// Token: 0x0600036A RID: 874 RVA: 0x0030CDA4 File Offset: 0x0030A9A4
		public override char C8DBDBAA()
		{
			uint num = 2089161459U;
			char c = (char)this.04D27930;
			num %= 1645944539U;
			return c;
		}

		// Token: 0x0600036B RID: 875 RVA: 0x0030CDC8 File Offset: 0x0030A9C8
		public override byte 76883720()
		{
			return (byte)this.04D27930;
		}

		// Token: 0x0600036C RID: 876 RVA: 0x0030CDA4 File Offset: 0x0030A9A4
		public override ushort E91B7AB7()
		{
			uint num = 2089161459U;
			ushort num2 = (ushort)this.04D27930;
			num %= 1645944539U;
			return num2;
		}

		// Token: 0x0600036D RID: 877 RVA: 0x0030CDDC File Offset: 0x0030A9DC
		public override uint 437B0320()
		{
			return (uint)this.04D27930;
		}

		// Token: 0x0600036E RID: 878 RVA: 0x0030CDF8 File Offset: 0x0030A9F8
		public override ulong 67922FD7()
		{
			uint num = 257232177U;
			num = 1106854957U * num;
			ulong num2 = (ulong)this.04D27930;
			num |= 1494051727U;
			return num2;
		}

		// Token: 0x0600036F RID: 879 RVA: 0x0030CE24 File Offset: 0x0030AA24
		public override float 8E4073FD()
		{
			return this.04D27930;
		}

		// Token: 0x06000370 RID: 880 RVA: 0x0030CE40 File Offset: 0x0030AA40
		public override double B7D5DC99()
		{
			return (double)this.04D27930;
		}

		// Token: 0x06000371 RID: 881 RVA: 0x0030CE54 File Offset: 0x0030AA54
		public override IntPtr 8C5D656E()
		{
			uint size = (uint)IntPtr.Size;
			uint num = 1666283650U;
			long value;
			if (size != (num ^ 1666283654U))
			{
				num = 114713510U * num;
				if (2034258374U * num != 0U)
				{
					value = (long)this.04D27930;
					goto IL_57;
				}
			}
			num = 812196674U * num;
			long num2 = (long)((int)this.04D27930);
			num = (1284734283U | num);
			value = num2;
			num += 3778701949U;
			IL_57:
			return new IntPtr(value);
		}

		// Token: 0x06000372 RID: 882 RVA: 0x0030CEC0 File Offset: 0x0030AAC0
		public override UIntPtr 103B638B()
		{
			uint num = 337656760U;
			ulong value;
			if (1840655428U * num != 0U)
			{
				do
				{
					uint size = (uint)IntPtr.Size;
					num = 743259758U - num;
					if (size == (num ^ 405602994U))
					{
						goto IL_42;
					}
				}
				while (1932986274U < num);
				value = (ulong)this.04D27930;
				goto IL_6A;
			}
			IL_42:
			num = 253442275U * num;
			uint num2 = (uint)this.04D27930;
			num /= 538985323U;
			ulong num3 = (ulong)num2;
			num = 27544237U - num;
			value = num3;
			num ^= 428427290U;
			IL_6A:
			return new UIntPtr(value);
		}

		// Token: 0x06000373 RID: 883 RVA: 0x0030CF3C File Offset: 0x0030AB3C
		public override object F187362C(Type 05662EDA, bool 46386BA0)
		{
			uint num;
			for (;;)
			{
				IL_00:
				num = 1534414469U;
				RuntimeTypeHandle handle = typeof(IntPtr).TypeHandle;
				num = 1542871904U - num;
				if (05662EDA == Type.GetTypeFromHandle(handle))
				{
					break;
				}
				for (;;)
				{
					IL_50:
					num &= 346434278U;
					if (num >= 1191318995U)
					{
						goto IL_00;
					}
					num >>= 4;
					Type typeFromHandle = typeof(UIntPtr);
					num = 2097546090U >> (int)num;
					if (05662EDA == typeFromHandle)
					{
						goto Block_2;
					}
					while (num != 1481251318U)
					{
						num |= 732117980U;
						TypeCode typeCode = Type.GetTypeCode(05662EDA);
						num = 292823595U % num;
						TypeCode typeCode2 = typeCode;
						num >>= 28;
						if (1914184372U <= num)
						{
							break;
						}
						uint num2 = (uint)typeCode2;
						num = 748236268U % num;
						switch (num2 - (num + 5U))
						{
						case 0U:
							if (num * 181010661U == 0U)
							{
								goto Block_7;
							}
							goto IL_50;
						case 1U:
							goto IL_1CE;
						case 2U:
							goto IL_171;
						case 3U:
							goto IL_1FE;
						case 4U:
							goto IL_1B9;
						case 5U:
							goto IL_22E;
						case 6U:
							goto IL_26C;
						case 7U:
							goto IL_24B;
						default:
							if (num + 1082860442U != 0U)
							{
								goto Block_6;
							}
							break;
						}
					}
					goto IL_26;
				}
				IL_171:
				num = 968569030U - num;
				if (2134116341U / num != 0U)
				{
					goto Block_9;
				}
				continue;
				IL_1CE:
				num += 958795772U;
				if (1055738373U > num)
				{
					goto Block_12;
				}
				continue;
				IL_1FE:
				num &= 592281566U;
				if (775433100U >= num)
				{
					goto Block_13;
				}
				continue;
				IL_26C:
				if (1808997322U > num)
				{
					goto Block_15;
				}
				continue;
				Block_6:
				num ^= 0U;
				goto IL_26C;
			}
			num = (1179075579U & num);
			IL_26:
			num |= 2045710163U;
			long num3 = (long)this.04D27930;
			num = 716455049U - num;
			IntPtr intPtr = new IntPtr(num3);
			num >>= 21;
			return intPtr;
			Block_2:
			num &= 1103580222U;
			byte b2;
			checked
			{
				UIntPtr uintPtr = new UIntPtr((ulong)this.04D27930);
				num = (1915683360U & num);
				return uintPtr;
				Block_7:
				sbyte b;
				if (!46386BA0)
				{
					b = (sbyte)this.04D27930;
				}
				else
				{
					uint num4 = (uint)this.04D27930;
					num = 1915374590U >> (int)num;
					b = (sbyte)num4;
					num ^= 1915374590U;
				}
				return b;
				Block_9:
				short num5;
				if (!46386BA0)
				{
					num5 = (short)this.04D27930;
				}
				else
				{
					if ((1560951575U ^ num) == 0U)
					{
						goto IL_26;
					}
					num5 = (short)((uint)this.04D27930);
					unchecked
					{
						num += 0U;
					}
				}
				return num5;
				IL_1B9:
				num |= 516257744U;
				return (int)this.04D27930;
				Block_12:
				num &= 2144760226U;
				b2 = (byte)this.04D27930;
			}
			num = 2129265086U - num;
			return b2;
			Block_13:
			num -= 1756893691U;
			ushort num6 = (ushort)this.04D27930;
			num = 2088505870U - num;
			return num6;
			IL_22E:
			uint num7 = (uint)this.04D27930;
			num += 1844592025U;
			uint num8 = num7;
			num = (1844265931U | num);
			return num8;
			IL_24B:
			if (num - 2094670238U != 0U)
			{
				num -= 852522678U;
				return checked((ulong)this.04D27930);
			}
			goto IL_26;
			Block_15:
			throw new ArgumentException();
		}

		// Token: 0x040001C6 RID: 454
		private float 04D27930;
	}

	// Token: 0x02000053 RID: 83
	private sealed class 07A85735 : 467F5DB3.371F2AF7
	{
		// Token: 0x06000374 RID: 884 RVA: 0x0030D1C8 File Offset: 0x0030ADC8
		public 07A85735(double 7E9E7160)
		{
			uint num = 222050534U;
			base..ctor();
			if (442007046U % num != 0U)
			{
				num = (1781883422U ^ num);
				this.55F73EBB = 7E9E7160;
			}
		}

		// Token: 0x06000375 RID: 885 RVA: 0x0030D1FC File Offset: 0x0030ADFC
		public override Type 303BF244()
		{
			return typeof(double);
		}

		// Token: 0x06000376 RID: 886 RVA: 0x0030D21C File Offset: 0x0030AE1C
		public override TypeCode 02557F0D()
		{
			uint num = 338193044U;
			return (TypeCode)(num ^ 338193050U);
		}

		// Token: 0x06000377 RID: 887 RVA: 0x0030D238 File Offset: 0x0030AE38
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 1609393652U;
			double 7E9E = this.55F73EBB;
			num -= 1787242623U;
			return new 467F5DB3.07A85735(7E9E);
		}

		// Token: 0x06000378 RID: 888 RVA: 0x0030D260 File Offset: 0x0030AE60
		public override object 6B58D7F4()
		{
			return this.55F73EBB;
		}

		// Token: 0x06000379 RID: 889 RVA: 0x0030D280 File Offset: 0x0030AE80
		public override void 59A76885(object 1C94153C)
		{
			this.55F73EBB = (double)1C94153C;
		}

		// Token: 0x0600037A RID: 890 RVA: 0x0030D29C File Offset: 0x0030AE9C
		public override bool A8DF755E()
		{
			return Convert.ToBoolean(this.55F73EBB);
		}

		// Token: 0x0600037B RID: 891 RVA: 0x0030D2BC File Offset: 0x0030AEBC
		public override sbyte 3D1BD445()
		{
			uint num = 1887053168U;
			sbyte b = (sbyte)this.55F73EBB;
			num <<= 8;
			return b;
		}

		// Token: 0x0600037C RID: 892 RVA: 0x0030D2E0 File Offset: 0x0030AEE0
		public override short D204A80D()
		{
			return (short)this.55F73EBB;
		}

		// Token: 0x0600037D RID: 893 RVA: 0x0030D2FC File Offset: 0x0030AEFC
		public override int D6BFBC24()
		{
			return (int)this.55F73EBB;
		}

		// Token: 0x0600037E RID: 894 RVA: 0x0030D318 File Offset: 0x0030AF18
		public override long E1698415()
		{
			return (long)this.55F73EBB;
		}

		// Token: 0x0600037F RID: 895 RVA: 0x0030D32C File Offset: 0x0030AF2C
		public override char C8DBDBAA()
		{
			uint num = 1627023979U;
			num = 1738147190U >> (int)num;
			char c = (char)this.55F73EBB;
			num = 1671511914U / num;
			return c;
		}

		// Token: 0x06000380 RID: 896 RVA: 0x0030D35C File Offset: 0x0030AF5C
		public override byte 76883720()
		{
			return (byte)this.55F73EBB;
		}

		// Token: 0x06000381 RID: 897 RVA: 0x0030D32C File Offset: 0x0030AF2C
		public override ushort E91B7AB7()
		{
			uint num = 1627023979U;
			num = 1738147190U >> (int)num;
			ushort num2 = (ushort)this.55F73EBB;
			num = 1671511914U / num;
			return num2;
		}

		// Token: 0x06000382 RID: 898 RVA: 0x0030D378 File Offset: 0x0030AF78
		public override uint 437B0320()
		{
			return (uint)this.55F73EBB;
		}

		// Token: 0x06000383 RID: 899 RVA: 0x0030D38C File Offset: 0x0030AF8C
		public override ulong 67922FD7()
		{
			uint num = 1079188595U;
			ulong num2 = (ulong)this.55F73EBB;
			num *= 939655537U;
			return num2;
		}

		// Token: 0x06000384 RID: 900 RVA: 0x0030D3B0 File Offset: 0x0030AFB0
		public override float 8E4073FD()
		{
			uint num = 1945457810U;
			num = 1061901920U - num;
			float num2 = (float)this.55F73EBB;
			num -= 1561880302U;
			return num2;
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0030D3DC File Offset: 0x0030AFDC
		public override double B7D5DC99()
		{
			return this.55F73EBB;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x0030D3F0 File Offset: 0x0030AFF0
		public override IntPtr 8C5D656E()
		{
			uint size = (uint)IntPtr.Size;
			uint num = 1645611597U;
			long value;
			if (size != num + 2649355703U)
			{
				num |= 111748745U;
				if ((num ^ 1810133452U) != 0U)
				{
					num = 10028119U % num;
					value = (long)this.55F73EBB;
					goto IL_5F;
				}
			}
			num &= 560143761U;
			long num2 = (long)((int)this.55F73EBB);
			num = 1076718752U / num;
			value = num2;
			num ^= 10028117U;
			IL_5F:
			num >>= 4;
			return new IntPtr(value);
		}

		// Token: 0x06000387 RID: 903 RVA: 0x0030D46C File Offset: 0x0030B06C
		public override UIntPtr 103B638B()
		{
			uint num = 918507475U;
			for (;;)
			{
				uint size = (uint)IntPtr.Size;
				num = (597189453U | num);
				if (size != num + 3359674405U)
				{
					break;
				}
				if (num <= 1020358587U)
				{
					goto Block_2;
				}
			}
			num ^= 628260375U;
			num = 404693170U << (int)num;
			ulong value = (ulong)this.55F73EBB;
			goto IL_6C;
			Block_2:
			uint num2 = (uint)this.55F73EBB;
			num &= 1004475522U;
			ulong num3 = (ulong)num2;
			num <<= 5;
			value = num3;
			num ^= 1824531008U;
			IL_6C:
			return new UIntPtr(value);
		}

		// Token: 0x06000388 RID: 904 RVA: 0x0030D4EC File Offset: 0x0030B0EC
		public override object F187362C(Type 6E6943A4, bool 631D22E2)
		{
			uint num;
			for (;;)
			{
				num = 1996712152U;
				Type typeFromHandle = typeof(IntPtr);
				num -= 904020214U;
				if (6E6943A4 == typeFromHandle)
				{
					break;
				}
				for (;;)
				{
					num -= 2082556461U;
					if (49705244U >= num)
					{
						goto IL_1E;
					}
					RuntimeTypeHandle handle = typeof(UIntPtr).TypeHandle;
					num = 816119964U * num;
					Type typeFromHandle2 = Type.GetTypeFromHandle(handle);
					num /= 1905596049U;
					if (6E6943A4 == typeFromHandle2)
					{
						goto Block_1;
					}
					TypeCode typeCode = Type.GetTypeCode(6E6943A4);
					num = 1520986248U >> (int)num;
					TypeCode typeCode2 = typeCode;
					num = (222495172U | num);
					if ((num ^ 1631674247U) != 0U)
					{
						object obj = typeCode2;
						num |= 613836296U;
						object obj2 = num + 3525871673U;
						num %= 687360784U;
						object obj3 = obj - obj2;
						num ^= 1922113316U;
						switch (obj3)
						{
						case 0:
							num = 818825645U / num;
							if (17393989U != num)
							{
								goto Block_4;
							}
							continue;
						case 1:
							goto IL_227;
						case 2:
							goto IL_19D;
						case 3:
							goto IL_247;
						case 4:
							goto IL_1EB;
						case 5:
							goto IL_25F;
						case 6:
							goto IL_212;
						case 7:
							goto IL_28D;
						case 8:
							goto IL_2C9;
						case 9:
							goto IL_2B5;
						}
						goto Block_3;
					}
				}
				Block_4:
				if (631D22E2)
				{
					goto IL_161;
				}
				if (960001698U > num)
				{
					goto Block_6;
				}
				continue;
				IL_1EB:
				if (1400452937U >> (int)num != 0U)
				{
					goto Block_8;
				}
				continue;
				IL_227:
				if (126696223U != num)
				{
					goto Block_9;
				}
				continue;
				IL_25F:
				num = 216407901U + num;
				if (num >= 1972987376U)
				{
					goto Block_11;
				}
				continue;
				IL_28D:
				num /= 1045170329U;
				if (num != 1626701569U)
				{
					goto Block_12;
				}
			}
			IL_1E:
			num = 1028791198U - num;
			long value = checked((long)this.55F73EBB);
			num /= 323239681U;
			return new IntPtr(value);
			Block_1:
			num = 1789924644U * num;
			ulong num2 = (ulong)this.55F73EBB;
			num = 1488326287U / num;
			ulong value2 = num2;
			num ^= 32001434U;
			return new UIntPtr(value2);
			Block_3:
			num ^= 0U;
			goto IL_2C9;
			Block_6:
			num &= 170602128U;
			sbyte b = (sbyte)this.55F73EBB;
			num = 1280203723U * num;
			sbyte b2 = b;
			goto IL_18F;
			IL_161:
			num *= 1751736502U;
			uint num3 = (uint)this.55F73EBB;
			num = 1954681134U << (int)num;
			sbyte b3 = (sbyte)num3;
			num = 1739667871U * num;
			b2 = b3;
			num += 1251350126U;
			IL_18F:
			num = 1914831701U - num;
			return b2;
			IL_19D:
			num = (279084209U | num);
			checked
			{
				short num4;
				if (!631D22E2)
				{
					num = 925633719U >> (int)num;
					num4 = (short)this.55F73EBB;
				}
				else
				{
					num <<= 17;
					num = 121653857U / num;
					num4 = (short)((uint)this.55F73EBB);
					num ^= 27U;
				}
				return num4;
				Block_8:
				int num5 = (int)this.55F73EBB;
				num = unchecked(1464076321U - num);
				return num5;
				IL_212:
				num &= 1774484915U;
				return (long)this.55F73EBB;
				Block_9:
				num = (910439690U & num);
				return (byte)this.55F73EBB;
				IL_247:
				if (num != 1882022364U)
				{
					return (ushort)this.55F73EBB;
				}
				goto IL_1E;
				Block_11:
				num = 633865113U >> (int)num;
				return (uint)this.55F73EBB;
				Block_12:
				ulong num6 = (ulong)this.55F73EBB;
				num = (1955359742U ^ num);
				return num6;
				IL_2B5:
				double num7 = this.55F73EBB;
				num = (335703546U & num);
				return num7;
				IL_2C9:
				throw new ArgumentException();
			}
		}

		// Token: 0x040001C7 RID: 455
		private double 55F73EBB;
	}

	// Token: 0x02000054 RID: 84
	private sealed class 32D66DFC : 467F5DB3.371F2AF7
	{
		// Token: 0x06000389 RID: 905 RVA: 0x0030D7C8 File Offset: 0x0030B3C8
		public 32D66DFC(string 4E1B313C)
		{
			uint num = 1915960678U;
			num = 207501293U << (int)num;
			num >>= 17;
			this.1EDA312A = 4E1B313C;
		}

		// Token: 0x0600038A RID: 906 RVA: 0x0030D800 File Offset: 0x0030B400
		public override Type 303BF244()
		{
			return typeof(string);
		}

		// Token: 0x0600038B RID: 907 RVA: 0x002FC330 File Offset: 0x002F9F30
		public override TypeCode 02557F0D()
		{
			uint num = 366420344U;
			return (TypeCode)(num ^ 366420345U);
		}

		// Token: 0x0600038C RID: 908 RVA: 0x0030D818 File Offset: 0x0030B418
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			return new 467F5DB3.32D66DFC(this.1EDA312A);
		}

		// Token: 0x0600038D RID: 909 RVA: 0x0030D838 File Offset: 0x0030B438
		public override object 6B58D7F4()
		{
			uint num = 605374872U;
			num = 1134525077U + num;
			return this.1EDA312A;
		}

		// Token: 0x0600038E RID: 910 RVA: 0x0030D85C File Offset: 0x0030B45C
		public override void 59A76885(object 14CB3CF7)
		{
			uint num = 2102414145U;
			if (239417726U < num)
			{
				do
				{
					num *= 1033921636U;
					string text;
					if (14CB3CF7 == null)
					{
						text = null;
					}
					else
					{
						text = Convert.ToString(14CB3CF7);
						num ^= 0U;
					}
					num = 860841500U * num;
					this.1EDA312A = text;
				}
				while (1444952499U % num == 0U);
			}
		}

		// Token: 0x0600038F RID: 911 RVA: 0x0030D8B8 File Offset: 0x0030B4B8
		public override bool A8DF755E()
		{
			uint num = 574424353U;
			num %= 1218727731U;
			return this.1EDA312A != null;
		}

		// Token: 0x06000390 RID: 912 RVA: 0x0030D838 File Offset: 0x0030B438
		public override string ToString()
		{
			uint num = 605374872U;
			num = 1134525077U + num;
			return this.1EDA312A;
		}

		// Token: 0x040001C8 RID: 456
		private string 1EDA312A;
	}

	// Token: 0x02000055 RID: 85
	private sealed class 3CC25312 : 467F5DB3.37FA30B9
	{
		// Token: 0x06000391 RID: 913 RVA: 0x0030D8DC File Offset: 0x0030B4DC
		public 3CC25312(short 22CD01C8)
		{
			uint num = 17197410U;
			if (365319000U > num)
			{
				base..ctor();
				num >>= 14;
			}
			this.79C70BAF = 22CD01C8;
		}

		// Token: 0x06000392 RID: 914 RVA: 0x0030D910 File Offset: 0x0030B510
		public override Type 303BF244()
		{
			return typeof(short);
		}

		// Token: 0x06000393 RID: 915 RVA: 0x0030D928 File Offset: 0x0030B528
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 410011910U;
			short 22CD01C = this.79C70BAF;
			num = 1219644196U + num;
			return new 467F5DB3.3CC25312(22CD01C);
		}

		// Token: 0x06000394 RID: 916 RVA: 0x0030D950 File Offset: 0x0030B550
		public override object 6B58D7F4()
		{
			uint num = 619865267U;
			short num2 = this.79C70BAF;
			num = 170404831U >> (int)num;
			return num2;
		}

		// Token: 0x06000395 RID: 917 RVA: 0x0030D97C File Offset: 0x0030B57C
		public override void 59A76885(object 27C024CA)
		{
			uint num = 2095933555U;
			num /= 1618484764U;
			short num2 = Convert.ToInt16(27C024CA);
			num = 1946315891U << (int)num;
			this.79C70BAF = num2;
		}

		// Token: 0x06000396 RID: 918 RVA: 0x0030D9B4 File Offset: 0x0030B5B4
		public override 467F5DB3.371F2AF7 52809797()
		{
			uint num = 2063733702U;
			int 0A = this.D6BFBC24();
			num /= 1431928112U;
			return new 467F5DB3.1C0911B0(0A);
		}

		// Token: 0x06000397 RID: 919 RVA: 0x0030D9DC File Offset: 0x0030B5DC
		public override sbyte 3D1BD445()
		{
			uint num = 144261387U;
			sbyte b = (sbyte)this.79C70BAF;
			num /= 662600000U;
			return b;
		}

		// Token: 0x06000398 RID: 920 RVA: 0x0030DA00 File Offset: 0x0030B600
		public override byte 76883720()
		{
			uint num = 194595102U;
			num = 2050253585U + num;
			byte b = (byte)this.79C70BAF;
			num |= 1630826870U;
			return b;
		}

		// Token: 0x06000399 RID: 921 RVA: 0x0030DA2C File Offset: 0x0030B62C
		public override short D204A80D()
		{
			return this.79C70BAF;
		}

		// Token: 0x0600039A RID: 922 RVA: 0x0030DA48 File Offset: 0x0030B648
		public override ushort E91B7AB7()
		{
			uint num = 1872721963U;
			num = 395074533U << (int)num;
			ushort num2 = (ushort)this.79C70BAF;
			num <<= 20;
			return num2;
		}

		// Token: 0x0600039B RID: 923 RVA: 0x0030DA2C File Offset: 0x0030B62C
		public override int D6BFBC24()
		{
			return (int)this.79C70BAF;
		}

		// Token: 0x0600039C RID: 924 RVA: 0x0030DA2C File Offset: 0x0030B62C
		public override uint 437B0320()
		{
			return (uint)this.79C70BAF;
		}

		// Token: 0x040001C9 RID: 457
		private short 79C70BAF;
	}

	// Token: 0x02000056 RID: 86
	private sealed class 03CF3096 : 467F5DB3.37FA30B9
	{
		// Token: 0x0600039D RID: 925 RVA: 0x0030DA78 File Offset: 0x0030B678
		public 03CF3096(ushort 4EB81B1D)
		{
			uint num = 1413353517U;
			if (num >> 26 == 0U)
			{
				goto IL_20;
			}
			IL_12:
			num = 1962084393U % num;
			base..ctor();
			IL_20:
			num &= 1862434692U;
			this.34D15890 = 4EB81B1D;
			if (1506352091U > num)
			{
				return;
			}
			goto IL_12;
		}

		// Token: 0x0600039E RID: 926 RVA: 0x0030DAC0 File Offset: 0x0030B6C0
		public override Type 303BF244()
		{
			uint num = 1731673252U;
			RuntimeTypeHandle handle = typeof(ushort).TypeHandle;
			num = (1978810971U | num);
			return Type.GetTypeFromHandle(handle);
		}

		// Token: 0x0600039F RID: 927 RVA: 0x0030DAE8 File Offset: 0x0030B6E8
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 132855294U;
			num <<= 7;
			ushort 4EB81B1D = this.34D15890;
			num = (596730347U ^ num);
			return new 467F5DB3.03CF3096(4EB81B1D);
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x0030DB18 File Offset: 0x0030B718
		public override object 6B58D7F4()
		{
			uint num = 1309150835U;
			num += 1101017976U;
			return this.34D15890;
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x0030DB40 File Offset: 0x0030B740
		public override void 59A76885(object 44FF4FD5)
		{
			uint num = 1461929314U;
			ushort num2 = Convert.ToUInt16(44FF4FD5);
			num = (1547183004U | num);
			this.34D15890 = num2;
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x0030D9B4 File Offset: 0x0030B5B4
		public override 467F5DB3.371F2AF7 52809797()
		{
			uint num = 2063733702U;
			int 0A = this.D6BFBC24();
			num /= 1431928112U;
			return new 467F5DB3.1C0911B0(0A);
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x0030DB68 File Offset: 0x0030B768
		public override sbyte 3D1BD445()
		{
			uint num = 190343059U;
			num = 1440219824U >> (int)num;
			return (sbyte)this.34D15890;
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x0030DB90 File Offset: 0x0030B790
		public override byte 76883720()
		{
			return (byte)this.34D15890;
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x0030DBAC File Offset: 0x0030B7AC
		public override short D204A80D()
		{
			uint num = 82735131U;
			short num2 = (short)this.34D15890;
			num = 1094331967U + num;
			return num2;
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x0030DBD0 File Offset: 0x0030B7D0
		public override ushort E91B7AB7()
		{
			uint num = 686521437U;
			num = 29232697U - num;
			return this.34D15890;
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x0030DBD0 File Offset: 0x0030B7D0
		public override int D6BFBC24()
		{
			uint num = 686521437U;
			num = 29232697U - num;
			return (int)this.34D15890;
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x0030DBD0 File Offset: 0x0030B7D0
		public override uint 437B0320()
		{
			uint num = 686521437U;
			num = 29232697U - num;
			return (uint)this.34D15890;
		}

		// Token: 0x040001CA RID: 458
		private ushort 34D15890;
	}

	// Token: 0x02000057 RID: 87
	private sealed class 0BAB1405 : 467F5DB3.37FA30B9
	{
		// Token: 0x060003A9 RID: 937 RVA: 0x0030DBF4 File Offset: 0x0030B7F4
		public 0BAB1405(bool 5FE92F94)
		{
			uint num = 1120624607U;
			do
			{
				base..ctor();
				num = 741830472U >> (int)num;
			}
			while (num >= 765357886U);
			do
			{
				this.3C2017D9 = 5FE92F94;
			}
			while ((974522798U & num) != 0U);
		}

		// Token: 0x060003AA RID: 938 RVA: 0x0030DC3C File Offset: 0x0030B83C
		public override Type 303BF244()
		{
			return typeof(bool);
		}

		// Token: 0x060003AB RID: 939 RVA: 0x0030DC5C File Offset: 0x0030B85C
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			return new 467F5DB3.0BAB1405(this.3C2017D9);
		}

		// Token: 0x060003AC RID: 940 RVA: 0x0030DC7C File Offset: 0x0030B87C
		public override object 6B58D7F4()
		{
			uint num = 551421183U;
			num += 1430409392U;
			bool flag = this.3C2017D9;
			num <<= 10;
			return flag;
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0030DCAC File Offset: 0x0030B8AC
		public override void 59A76885(object 3FFD0435)
		{
			uint num = 1087927880U;
			do
			{
				num = 1182823225U >> (int)num;
				this.3C2017D9 = Convert.ToBoolean(3FFD0435);
			}
			while (num >> 3 == 0U);
		}

		// Token: 0x060003AE RID: 942 RVA: 0x0030D9B4 File Offset: 0x0030B5B4
		public override 467F5DB3.371F2AF7 52809797()
		{
			uint num = 2063733702U;
			int 0A = this.D6BFBC24();
			num /= 1431928112U;
			return new 467F5DB3.1C0911B0(0A);
		}

		// Token: 0x060003AF RID: 943 RVA: 0x0030DCE8 File Offset: 0x0030B8E8
		public override int D6BFBC24()
		{
			uint num = 488846235U;
			if (242373758U != num)
			{
				num *= 698486721U;
				if (this.3C2017D9)
				{
					return (int)(num ^ 2191916250U);
				}
			}
			return (int)(num ^ 2191916251U);
		}

		// Token: 0x040001CB RID: 459
		private bool 3C2017D9;
	}

	// Token: 0x02000058 RID: 88
	private sealed class 06B44EBD : 467F5DB3.37FA30B9
	{
		// Token: 0x060003B0 RID: 944 RVA: 0x0030DD28 File Offset: 0x0030B928
		public 06B44EBD(char 28C27488)
		{
			uint num;
			do
			{
				num = 1344809515U;
				base..ctor();
				if (num == 310800633U)
				{
					break;
				}
				num = 1706432698U % num;
				num *= 1755002253U;
				this.5A6E7DD7 = 28C27488;
			}
			while (1718038428U - num == 0U);
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x0030DD70 File Offset: 0x0030B970
		public override Type 303BF244()
		{
			return typeof(char);
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x0030DD88 File Offset: 0x0030B988
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 1140358860U;
			num |= 2016627940U;
			char 28C = this.5A6E7DD7;
			num = (2044076430U ^ num);
			return new 467F5DB3.06B44EBD(28C);
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x0030DDB8 File Offset: 0x0030B9B8
		public override object 6B58D7F4()
		{
			return this.5A6E7DD7;
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x0030DDD8 File Offset: 0x0030B9D8
		public override void 59A76885(object 7325432C)
		{
			uint num = 1834960196U;
			if (647061745 << (int)num != 0)
			{
				char c = Convert.ToChar(7325432C);
				num = 1885630356U - num;
				this.5A6E7DD7 = c;
			}
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x0030D9B4 File Offset: 0x0030B5B4
		public override 467F5DB3.371F2AF7 52809797()
		{
			uint num = 2063733702U;
			int 0A = this.D6BFBC24();
			num /= 1431928112U;
			return new 467F5DB3.1C0911B0(0A);
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x0030DE14 File Offset: 0x0030BA14
		public override sbyte 3D1BD445()
		{
			uint num = 784015179U;
			sbyte b = (sbyte)this.5A6E7DD7;
			num = 40437128U - num;
			return b;
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x0030DE38 File Offset: 0x0030BA38
		public override byte 76883720()
		{
			uint num = 719201818U;
			num = 943608927U % num;
			byte b = (byte)this.5A6E7DD7;
			num %= 584913374U;
			return b;
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x0030DE64 File Offset: 0x0030BA64
		public override short D204A80D()
		{
			return (short)this.5A6E7DD7;
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x0030DE80 File Offset: 0x0030BA80
		public override ushort E91B7AB7()
		{
			return (ushort)this.5A6E7DD7;
		}

		// Token: 0x060003BA RID: 954 RVA: 0x0030DE80 File Offset: 0x0030BA80
		public override int D6BFBC24()
		{
			return (int)this.5A6E7DD7;
		}

		// Token: 0x060003BB RID: 955 RVA: 0x0030DE80 File Offset: 0x0030BA80
		public override uint 437B0320()
		{
			return (uint)this.5A6E7DD7;
		}

		// Token: 0x040001CC RID: 460
		private char 5A6E7DD7;
	}

	// Token: 0x02000059 RID: 89
	private sealed class 1A802882 : 467F5DB3.37FA30B9
	{
		// Token: 0x060003BC RID: 956 RVA: 0x0030DE9C File Offset: 0x0030BA9C
		public 1A802882(byte 287768DC)
		{
			uint num = 448623997U;
			base..ctor();
			if ((1048328591U ^ num) != 0U)
			{
				this.498A419E = 287768DC;
			}
		}

		// Token: 0x060003BD RID: 957 RVA: 0x0030DEC8 File Offset: 0x0030BAC8
		public override Type 303BF244()
		{
			return typeof(byte);
		}

		// Token: 0x060003BE RID: 958 RVA: 0x0030DEE8 File Offset: 0x0030BAE8
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 2027899375U;
			num |= 582903308U;
			return new 467F5DB3.1A802882(this.498A419E);
		}

		// Token: 0x060003BF RID: 959 RVA: 0x0030DF10 File Offset: 0x0030BB10
		public override object 6B58D7F4()
		{
			return this.498A419E;
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x0030DF28 File Offset: 0x0030BB28
		public override void 59A76885(object 6C5543A0)
		{
			uint num = 31220230U;
			do
			{
				num = 807603746U >> (int)num;
				this.498A419E = Convert.ToByte(6C5543A0);
			}
			while (num >= 396119982U);
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x0030D9B4 File Offset: 0x0030B5B4
		public override 467F5DB3.371F2AF7 52809797()
		{
			uint num = 2063733702U;
			int 0A = this.D6BFBC24();
			num /= 1431928112U;
			return new 467F5DB3.1C0911B0(0A);
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x0030DF60 File Offset: 0x0030BB60
		public override sbyte 3D1BD445()
		{
			return (sbyte)this.498A419E;
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x0030DF7C File Offset: 0x0030BB7C
		public override byte 76883720()
		{
			return this.498A419E;
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0030DF7C File Offset: 0x0030BB7C
		public override short D204A80D()
		{
			return (short)this.498A419E;
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x0030DF7C File Offset: 0x0030BB7C
		public override ushort E91B7AB7()
		{
			return (ushort)this.498A419E;
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x0030DF7C File Offset: 0x0030BB7C
		public override int D6BFBC24()
		{
			return (int)this.498A419E;
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0030DF7C File Offset: 0x0030BB7C
		public override uint 437B0320()
		{
			return (uint)this.498A419E;
		}

		// Token: 0x040001CD RID: 461
		private byte 498A419E;
	}

	// Token: 0x0200005A RID: 90
	private sealed class 745721FC : 467F5DB3.37FA30B9
	{
		// Token: 0x060003C8 RID: 968 RVA: 0x0030DF90 File Offset: 0x0030BB90
		public 745721FC(sbyte 43912B72)
		{
			for (;;)
			{
				uint num = 353251247U;
				base..ctor();
				if (num <= 646651312U)
				{
					num ^= 1444431300U;
					num = (735522049U | num);
					this.12D87B85 = 43912B72;
					if (1005405205U != num)
					{
						break;
					}
				}
			}
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x0030DFD8 File Offset: 0x0030BBD8
		public override Type 303BF244()
		{
			uint num = 462441721U;
			RuntimeTypeHandle handle = typeof(sbyte).TypeHandle;
			num = 955464396U + num;
			return Type.GetTypeFromHandle(handle);
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0030E000 File Offset: 0x0030BC00
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 1144075723U;
			num %= 743786262U;
			sbyte 43912B = this.12D87B85;
			num >>= 19;
			return new 467F5DB3.745721FC(43912B);
		}

		// Token: 0x060003CB RID: 971 RVA: 0x0030E030 File Offset: 0x0030BC30
		public override object 6B58D7F4()
		{
			uint num = 37117493U;
			sbyte b = this.12D87B85;
			num = (696073413U ^ num);
			return b;
		}

		// Token: 0x060003CC RID: 972 RVA: 0x0030E058 File Offset: 0x0030BC58
		public override void 59A76885(object 695F7C99)
		{
			uint num = 1291788873U;
			if ((num & 608192851U) != 0U)
			{
				num /= 663376123U;
				this.12D87B85 = Convert.ToSByte(695F7C99);
			}
		}

		// Token: 0x060003CD RID: 973 RVA: 0x0030D9B4 File Offset: 0x0030B5B4
		public override 467F5DB3.371F2AF7 52809797()
		{
			uint num = 2063733702U;
			int 0A = this.D6BFBC24();
			num /= 1431928112U;
			return new 467F5DB3.1C0911B0(0A);
		}

		// Token: 0x060003CE RID: 974 RVA: 0x0030E08C File Offset: 0x0030BC8C
		public override sbyte 3D1BD445()
		{
			uint num = 1016471236U;
			num = 912998360U >> (int)num;
			return this.12D87B85;
		}

		// Token: 0x060003CF RID: 975 RVA: 0x0030E0B4 File Offset: 0x0030BCB4
		public override byte 76883720()
		{
			uint num = 196621079U;
			byte b = (byte)this.12D87B85;
			num = 948765627U * num;
			return b;
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x0030E08C File Offset: 0x0030BC8C
		public override short D204A80D()
		{
			uint num = 1016471236U;
			num = 912998360U >> (int)num;
			return (short)this.12D87B85;
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x0030E0D8 File Offset: 0x0030BCD8
		public override ushort E91B7AB7()
		{
			uint num = 603814899U;
			ushort num2 = (ushort)this.12D87B85;
			num /= 643330948U;
			return num2;
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x0030E08C File Offset: 0x0030BC8C
		public override int D6BFBC24()
		{
			uint num = 1016471236U;
			num = 912998360U >> (int)num;
			return (int)this.12D87B85;
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0030E08C File Offset: 0x0030BC8C
		public override uint 437B0320()
		{
			uint num = 1016471236U;
			num = 912998360U >> (int)num;
			return (uint)this.12D87B85;
		}

		// Token: 0x040001CE RID: 462
		private sbyte 12D87B85;
	}

	// Token: 0x0200005B RID: 91
	private sealed class 2DB44737 : 467F5DB3.37FA30B9
	{
		// Token: 0x060003D4 RID: 980 RVA: 0x0030E0FC File Offset: 0x0030BCFC
		public 2DB44737(uint 4C6E61B5)
		{
			uint num = 809652050U;
			do
			{
				base..ctor();
				num += 670512229U;
				num -= 1887845479U;
				this.3FCF13A5 = 4C6E61B5;
			}
			while (1937926972U + num == 0U);
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0030E138 File Offset: 0x0030BD38
		public override Type 303BF244()
		{
			return typeof(uint);
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0030E158 File Offset: 0x0030BD58
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			return new 467F5DB3.2DB44737(this.3FCF13A5);
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x0030E178 File Offset: 0x0030BD78
		public override object 6B58D7F4()
		{
			uint num = 688989957U;
			num = (985088165U ^ num);
			return this.3FCF13A5;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x0030E1A0 File Offset: 0x0030BDA0
		public override void 59A76885(object 24893FC7)
		{
			uint num = 319294241U;
			if (1896876914U + num != 0U)
			{
				do
				{
					num /= 230754336U;
					uint num2 = Convert.ToUInt32(24893FC7);
					num ^= 2054892385U;
					this.3FCF13A5 = num2;
				}
				while (1016626783U >> (int)num == 0U);
			}
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x0030D9B4 File Offset: 0x0030B5B4
		public override 467F5DB3.371F2AF7 52809797()
		{
			uint num = 2063733702U;
			int 0A = this.D6BFBC24();
			num /= 1431928112U;
			return new 467F5DB3.1C0911B0(0A);
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0030E1F0 File Offset: 0x0030BDF0
		public override sbyte 3D1BD445()
		{
			uint num = 848043627U;
			sbyte b = (sbyte)this.3FCF13A5;
			num %= 1260671342U;
			return b;
		}

		// Token: 0x060003DB RID: 987 RVA: 0x0030E214 File Offset: 0x0030BE14
		public override byte 76883720()
		{
			return (byte)this.3FCF13A5;
		}

		// Token: 0x060003DC RID: 988 RVA: 0x0030E230 File Offset: 0x0030BE30
		public override short D204A80D()
		{
			return (short)this.3FCF13A5;
		}

		// Token: 0x060003DD RID: 989 RVA: 0x0030E24C File Offset: 0x0030BE4C
		public override ushort E91B7AB7()
		{
			uint num = 643267642U;
			num %= 1516593278U;
			ushort num2 = (ushort)this.3FCF13A5;
			num = 1023894388U % num;
			return num2;
		}

		// Token: 0x060003DE RID: 990 RVA: 0x0030E278 File Offset: 0x0030BE78
		public override int D6BFBC24()
		{
			return (int)this.3FCF13A5;
		}

		// Token: 0x060003DF RID: 991 RVA: 0x0030E278 File Offset: 0x0030BE78
		public override uint 437B0320()
		{
			return this.3FCF13A5;
		}

		// Token: 0x040001CF RID: 463
		private uint 3FCF13A5;
	}

	// Token: 0x0200005C RID: 92
	private sealed class 00C71221 : 467F5DB3.37FA30B9
	{
		// Token: 0x060003E0 RID: 992 RVA: 0x0030E294 File Offset: 0x0030BE94
		public 00C71221(ulong 5BBF2E10)
		{
			uint num = 541097054U;
			base..ctor();
			num += 829177220U;
			do
			{
				num -= 619599876U;
				this.5A79405D = 5BBF2E10;
			}
			while (656681060U > num);
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x0030E2D0 File Offset: 0x0030BED0
		public override Type 303BF244()
		{
			return typeof(ulong);
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x0030E2E8 File Offset: 0x0030BEE8
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 1591901201U;
			ulong 5BBF2E = this.5A79405D;
			num = (1645937759U ^ num);
			return new 467F5DB3.00C71221(5BBF2E);
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x0030E310 File Offset: 0x0030BF10
		public override object 6B58D7F4()
		{
			uint num = 829699523U;
			num = 2121604666U - num;
			return this.5A79405D;
		}

		// Token: 0x060003E4 RID: 996 RVA: 0x0030E338 File Offset: 0x0030BF38
		public override void 59A76885(object 710D63F9)
		{
			this.5A79405D = Convert.ToUInt64(710D63F9);
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x0030E358 File Offset: 0x0030BF58
		public override 467F5DB3.371F2AF7 52809797()
		{
			uint num = 1436167592U;
			num |= 345202086U;
			return new 467F5DB3.06E010E5(this.E1698415());
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x0030E380 File Offset: 0x0030BF80
		public override sbyte 3D1BD445()
		{
			uint num = 2124635498U;
			num /= 147157511U;
			sbyte b = (sbyte)this.5A79405D;
			num = 1410077146U - num;
			return b;
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x0030E3AC File Offset: 0x0030BFAC
		public override byte 76883720()
		{
			uint num = 416754441U;
			byte b = (byte)this.5A79405D;
			num = 180892113U / num;
			return b;
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x0030E3D0 File Offset: 0x0030BFD0
		public override short D204A80D()
		{
			return (short)this.5A79405D;
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x0030E3EC File Offset: 0x0030BFEC
		public override ushort E91B7AB7()
		{
			uint num = 2124611590U;
			num = 384256694U >> (int)num;
			return (ushort)this.5A79405D;
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x0030E414 File Offset: 0x0030C014
		public override int D6BFBC24()
		{
			uint num = 265696012U;
			num = 810961384U << (int)num;
			return (int)this.5A79405D;
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x0030E43C File Offset: 0x0030C03C
		public override uint 437B0320()
		{
			return (uint)this.5A79405D;
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x0030E458 File Offset: 0x0030C058
		public override long E1698415()
		{
			return (long)this.5A79405D;
		}

		// Token: 0x060003ED RID: 1005 RVA: 0x0030E458 File Offset: 0x0030C058
		public override ulong 67922FD7()
		{
			return this.5A79405D;
		}

		// Token: 0x040001D0 RID: 464
		private ulong 5A79405D;
	}

	// Token: 0x0200005D RID: 93
	private sealed class 4CF55D0F : 467F5DB3.371F2AF7
	{
		// Token: 0x060003EE RID: 1006 RVA: 0x0030E46C File Offset: 0x0030C06C
		public 4CF55D0F(object 79093674)
		{
			uint num = 1617500030U;
			base..ctor();
			do
			{
				this.3DF714D1 = 79093674;
			}
			while (1176446887U + num == 0U);
		}

		// Token: 0x060003EF RID: 1007 RVA: 0x0030E498 File Offset: 0x0030C098
		public override Type 303BF244()
		{
			return typeof(object);
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x002FC330 File Offset: 0x002F9F30
		public override TypeCode 02557F0D()
		{
			uint num = 366420344U;
			return (TypeCode)(num ^ 366420345U);
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x0030E4B8 File Offset: 0x0030C0B8
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 752095873U;
			num /= 1349134068U;
			object <<EMPTY_NAME>> = this.3DF714D1;
			num = (124274952U | num);
			return new 467F5DB3.4CF55D0F(<<EMPTY_NAME>>);
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x0030E4E8 File Offset: 0x0030C0E8
		public override object 6B58D7F4()
		{
			return this.3DF714D1;
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x0030E504 File Offset: 0x0030C104
		public override void 59A76885(object 279A7FA7)
		{
			uint num = 1660162996U;
			if ((1121141187U & num) != 0U)
			{
				num = 54076842U << (int)num;
				this.3DF714D1 = 279A7FA7;
			}
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x0030E538 File Offset: 0x0030C138
		public override bool A8DF755E()
		{
			return this.3DF714D1 != null;
		}

		// Token: 0x040001D1 RID: 465
		private object 3DF714D1;
	}

	// Token: 0x0200005E RID: 94
	private sealed class 6B576539 : 467F5DB3.371F2AF7
	{
		// Token: 0x060003F5 RID: 1013 RVA: 0x0030E554 File Offset: 0x0030C154
		public 6B576539(object 36FA1F66, Type 53375D39)
		{
			uint num = 1369390591U;
			do
			{
				num |= 609425809U;
				num -= 1953369505U;
				this.00DC307B = 36FA1F66;
			}
			while (num >> 2 == 0U);
			num |= 246554001U;
			this.368A4746 = 53375D39;
			num = 147220047U % num;
			467F5DB3.37FA30B9 37FA30B = 467F5DB3.6B576539.13253AD6(36FA1F66);
			num = 198323349U - num;
			this.47451FE4 = 37FA30B;
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x0030E5BC File Offset: 0x0030C1BC
		private unsafe static 467F5DB3.37FA30B9 13253AD6(object 48C03BAF)
		{
			uint num = 1656372174U;
			for (;;)
			{
				num = (1581384778U & num);
				if (48C03BAF != null)
				{
					break;
				}
				if (1781495098U > num)
				{
					goto Block_1;
				}
			}
			IL_14:
			num <<= 14;
			void* value = Pointer.Unbox(48C03BAF);
			num &= 1698975867U;
			IntPtr intPtr = new IntPtr(value);
			goto IL_4C;
			Block_1:
			intPtr = IntPtr.Zero;
			num += 3187539894U;
			IL_4C:
			num <<= 22;
			IntPtr intPtr2 = intPtr;
			int size = IntPtr.Size;
			uint num2 = num ^ 4U;
			num = 301798236U * num;
			if (size != num2)
			{
				num -= 2027376464U;
				long 0E0B = intPtr2.ToInt64();
				num = 1520336268U * num;
				return new 467F5DB3.06E010E5(0E0B);
			}
			num ^= 2108565715U;
			if (1009127649U != num)
			{
				num ^= 1698503126U;
				int 0A = intPtr2.ToInt32();
				num /= 827276126U;
				return new 467F5DB3.1C0911B0(0A);
			}
			goto IL_14;
		}

		// Token: 0x060003F7 RID: 1015 RVA: 0x0030E498 File Offset: 0x0030C098
		public override Type 303BF244()
		{
			return typeof(object);
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x0030E684 File Offset: 0x0030C284
		public Type 62D13369()
		{
			return this.368A4746;
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x0030E6A0 File Offset: 0x0030C2A0
		public override TypeCode 02557F0D()
		{
			int size = IntPtr.Size;
			int num = 4;
			uint num2 = 2052612909U;
			if (size != num)
			{
				num2 |= 2132046324U;
				return (TypeCode)(num2 ^ 2136765425U);
			}
			num2 /= 2011773253U;
			return (TypeCode)(num2 - 4294967287U);
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x0030E6E0 File Offset: 0x0030C2E0
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 930677976U;
			object 36FA1F = this.00DC307B;
			num ^= 1871932456U;
			return new 467F5DB3.6B576539(36FA1F, this.368A4746);
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x0030E70C File Offset: 0x0030C30C
		public override object 6B58D7F4()
		{
			return this.00DC307B;
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x0030E728 File Offset: 0x0030C328
		public override void 59A76885(object 0BC8047E)
		{
			uint num = 1843200582U;
			do
			{
				this.00DC307B = 0BC8047E;
				num <<= 25;
			}
			while ((num ^ 1611598489U) == 0U);
			num -= 1202705U;
			this.47451FE4 = 467F5DB3.6B576539.13253AD6(0BC8047E);
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x0030E76C File Offset: 0x0030C36C
		public override bool A8DF755E()
		{
			return this.00DC307B != null;
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x0030E788 File Offset: 0x0030C388
		public override sbyte 3D1BD445()
		{
			return this.47451FE4.3D1BD445();
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x0030E7A8 File Offset: 0x0030C3A8
		public override short D204A80D()
		{
			uint num = 150549868U;
			num += 1785290904U;
			return this.47451FE4.D204A80D();
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x0030E7D0 File Offset: 0x0030C3D0
		public override int D6BFBC24()
		{
			return this.47451FE4.D6BFBC24();
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x0030E7F0 File Offset: 0x0030C3F0
		public override long E1698415()
		{
			return this.47451FE4.E1698415();
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x0030E810 File Offset: 0x0030C410
		public override byte 76883720()
		{
			return this.47451FE4.76883720();
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x0030E830 File Offset: 0x0030C430
		public override ushort E91B7AB7()
		{
			return this.47451FE4.E91B7AB7();
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x0030E850 File Offset: 0x0030C450
		public override uint 437B0320()
		{
			return this.47451FE4.437B0320();
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x0030E870 File Offset: 0x0030C470
		public override ulong 67922FD7()
		{
			return this.47451FE4.67922FD7();
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x0030E890 File Offset: 0x0030C490
		public override float 8E4073FD()
		{
			uint num = 1641246763U;
			467F5DB3.37FA30B9 37FA30B = this.47451FE4;
			num %= 2080339116U;
			return 37FA30B.8E4073FD();
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x0030E8B8 File Offset: 0x0030C4B8
		public override double B7D5DC99()
		{
			uint num = 1586970626U;
			num = 430464157U << (int)num;
			return this.47451FE4.B7D5DC99();
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x0030E8E4 File Offset: 0x0030C4E4
		public override IntPtr 8C5D656E()
		{
			return this.47451FE4.8C5D656E();
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x0030E904 File Offset: 0x0030C504
		public override UIntPtr 103B638B()
		{
			return this.47451FE4.103B638B();
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x0030E924 File Offset: 0x0030C524
		public override object F187362C(Type 744B1847, bool 0E960F91)
		{
			return this.47451FE4.F187362C(744B1847, 0E960F91);
		}

		// Token: 0x040001D2 RID: 466
		private object 00DC307B;

		// Token: 0x040001D3 RID: 467
		private Type 368A4746;

		// Token: 0x040001D4 RID: 468
		private 467F5DB3.37FA30B9 47451FE4;
	}

	// Token: 0x0200005F RID: 95
	private sealed class 7EA91122 : 467F5DB3.371F2AF7
	{
		// Token: 0x0600040B RID: 1035 RVA: 0x0030E944 File Offset: 0x0030C544
		public 7EA91122(object 534D4E3B)
		{
			uint num;
			do
			{
				num = 1801201890U;
				base..ctor();
				num |= 508842125U;
				for (;;)
				{
					if (534D4E3B != null)
					{
						num = (1668376439U ^ num);
						if (620395302U / num == 0U)
						{
							goto IL_55;
						}
						num ^= 1608140943U;
						bool flag = 534D4E3B is ValueType;
						num ^= 1017851896U;
						if (!flag)
						{
							break;
						}
					}
					num |= 1732272394U;
					num = 693390811U << (int)num;
					this.34550D6D = 534D4E3B;
					if (num < 1298994870U)
					{
						return;
					}
				}
			}
			while (num + 86002242U == 0U);
			IL_55:
			throw new ArgumentException();
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x0030E9D4 File Offset: 0x0030C5D4
		public override Type 303BF244()
		{
			return typeof(ValueType);
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x0030E9EC File Offset: 0x0030C5EC
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			return new 467F5DB3.7EA91122(this.34550D6D);
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x0030EA0C File Offset: 0x0030C60C
		public override object 6B58D7F4()
		{
			return this.34550D6D;
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x0030EA20 File Offset: 0x0030C620
		public override void 59A76885(object 4E9519C8)
		{
			uint num = 536552516U;
			for (;;)
			{
				num /= 1034319177U;
				if (4E9519C8 != null && 107827215U + num != 0U)
				{
					for (;;)
					{
						bool flag = 4E9519C8 is ValueType;
						num += 2023303719U;
						num ^= 2023303719U;
						if (flag)
						{
							break;
						}
						if (num < 1738872555U)
						{
							goto Block_3;
						}
					}
				}
				if (num <= 1735868191U)
				{
					goto Block_4;
				}
			}
			Block_3:
			throw new ArgumentException();
			Block_4:
			this.34550D6D = 4E9519C8;
		}

		// Token: 0x040001D5 RID: 469
		private object 34550D6D;
	}

	// Token: 0x02000060 RID: 96
	private sealed class 705703B5 : 467F5DB3.371F2AF7
	{
		// Token: 0x06000410 RID: 1040 RVA: 0x0030EA8C File Offset: 0x0030C68C
		public 705703B5(Array 413C5DF2)
		{
			uint num = 841762124U;
			if ((num ^ 1973095497U) != 0U)
			{
				num = 362042909U >> (int)num;
				base..ctor();
				if (num == 202846530U)
				{
					return;
				}
			}
			num >>= 16;
			num = (376844524U & num);
			this.53814D5B = 413C5DF2;
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x0030EAE4 File Offset: 0x0030C6E4
		public override Type 303BF244()
		{
			uint num = 1032147205U;
			RuntimeTypeHandle handle = typeof(Array).TypeHandle;
			num -= 1492525437U;
			return Type.GetTypeFromHandle(handle);
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x0030EB0C File Offset: 0x0030C70C
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			return new 467F5DB3.705703B5(this.53814D5B);
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x0030EB2C File Offset: 0x0030C72C
		public override object 6B58D7F4()
		{
			return this.53814D5B;
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x0030EB48 File Offset: 0x0030C748
		public override void 59A76885(object 135B6E2D)
		{
			uint num = 1729432929U;
			do
			{
				this.53814D5B = (Array)135B6E2D;
			}
			while (697194956U - num == 0U);
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x0030EB74 File Offset: 0x0030C774
		public override bool A8DF755E()
		{
			uint num = 438044614U;
			num *= 2008445076U;
			Array array = this.53814D5B;
			num = (585501295U & num);
			object obj = null;
			num += 311645994U;
			return array > obj;
		}

		// Token: 0x040001D6 RID: 470
		private Array 53814D5B;
	}

	// Token: 0x02000061 RID: 97
	private abstract class 00BC6875 : 467F5DB3.371F2AF7
	{
		// Token: 0x06000416 RID: 1046 RVA: 0x002FC330 File Offset: 0x002F9F30
		public override bool 535FA4FE()
		{
			uint num = 366420344U;
			return (num ^ 366420345U) != 0U;
		}
	}

	// Token: 0x02000062 RID: 98
	private sealed class 3DA7232B : 467F5DB3.00BC6875
	{
		// Token: 0x06000418 RID: 1048 RVA: 0x0030EBBC File Offset: 0x0030C7BC
		public 3DA7232B(467F5DB3.37FA30B9 64C32543)
		{
			for (;;)
			{
				base..ctor();
				uint num = 1681482338U;
				if (num != 465454116U)
				{
					this.51AA0273 = 64C32543;
					if (2096980440U - num != 0U)
					{
						break;
					}
				}
			}
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x0030EBF4 File Offset: 0x0030C7F4
		public override Type 303BF244()
		{
			uint num = 641164654U;
			467F5DB3.37FA30B9 37FA30B = this.51AA0273;
			num = (1244466327U & num);
			return 37FA30B.303BF244();
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x0030EC1C File Offset: 0x0030C81C
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 708209288U;
			num %= 1331310789U;
			467F5DB3.37FA30B9 64C = this.51AA0273;
			num -= 342058633U;
			return new 467F5DB3.3DA7232B(64C);
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x0030EC4C File Offset: 0x0030C84C
		public override object 6B58D7F4()
		{
			return this.51AA0273.6B58D7F4();
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x0030EC6C File Offset: 0x0030C86C
		public override void 59A76885(object 00DE4FE8)
		{
			uint num = 1260665603U;
			do
			{
				467F5DB3.37FA30B9 37FA30B = this.51AA0273;
				num /= 1549339140U;
				37FA30B.59A76885(00DE4FE8);
			}
			while ((num & 235291290U) != 0U);
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x0030ECA0 File Offset: 0x0030C8A0
		public override bool A8DF755E()
		{
			uint num = 529011464U;
			num = 317210321U - num;
			return this.51AA0273 != null;
		}

		// Token: 0x040001D7 RID: 471
		private 467F5DB3.37FA30B9 51AA0273;
	}

	// Token: 0x02000063 RID: 99
	private sealed class 05DF5272 : 467F5DB3.00BC6875
	{
		// Token: 0x0600041E RID: 1054 RVA: 0x0030ECC4 File Offset: 0x0030C8C4
		public 05DF5272(467F5DB3.37FA30B9 5FA538FB, 467F5DB3.37FA30B9 5D180793)
		{
			uint num = 1466833892U;
			base..ctor();
			num -= 1745422620U;
			if (1076320892U <= num)
			{
				do
				{
					num = (1123317634U & num);
					this.4A0917D6 = 5FA538FB;
					num = (537810963U | num);
					this.4A5076EC = 5D180793;
				}
				while ((127213691U ^ num) == 0U);
			}
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x0030ED1C File Offset: 0x0030C91C
		public override Type 303BF244()
		{
			uint num = 588063054U;
			467F5DB3.37FA30B9 37FA30B = this.4A0917D6;
			num = 1330714380U / num;
			return 37FA30B.303BF244();
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x0030ED44 File Offset: 0x0030C944
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 974998087U;
			num = 171792705U - num;
			467F5DB3.37FA30B9 5FA538FB = this.4A0917D6;
			num += 1441099689U;
			return new 467F5DB3.05DF5272(5FA538FB, this.4A5076EC);
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x0030ED78 File Offset: 0x0030C978
		public override object 6B58D7F4()
		{
			uint num = 839476818U;
			num = (661482108U | num);
			return this.4A0917D6.6B58D7F4();
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x0030EDA0 File Offset: 0x0030C9A0
		public override void 59A76885(object 0E234921)
		{
			uint num = 1741958216U;
			do
			{
				467F5DB3.37FA30B9 37FA30B = this.4A0917D6;
				num = (755320178U ^ num);
				num = 2100057033U >> (int)num;
				37FA30B.59A76885(0E234921);
				num += 988625111U;
			}
			while (1289508703 << (int)num == 0);
			do
			{
				467F5DB3.37FA30B9 37FA30B2 = this.4A5076EC;
				num %= 1447123085U;
				object 594737E = this.4A0917D6.6B58D7F4();
				num ^= 1420386266U;
				37FA30B2.59A76885(594737E);
			}
			while (num << 3 == 0U);
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x0030EE24 File Offset: 0x0030CA24
		public override bool A8DF755E()
		{
			uint num = 1639603239U;
			num = (1772697533U & num);
			object obj = this.4A0917D6;
			num = (1496075784U | num);
			return obj != null;
		}

		// Token: 0x040001D8 RID: 472
		private 467F5DB3.37FA30B9 4A0917D6;

		// Token: 0x040001D9 RID: 473
		private 467F5DB3.37FA30B9 4A5076EC;
	}

	// Token: 0x02000064 RID: 100
	private sealed class 1DEE779D : 467F5DB3.00BC6875
	{
		// Token: 0x06000424 RID: 1060 RVA: 0x0030EE50 File Offset: 0x0030CA50
		public 1DEE779D(FieldInfo 3EDF6AD8, object 259E2D6E)
		{
			uint num = 2044731114U;
			base..ctor();
			if (200288554U <= num)
			{
				this.2EB3528E = 3EDF6AD8;
				num *= 1714884778U;
				if (num > 108359601U)
				{
					do
					{
						num = 1878739029U >> (int)num;
						this.6ECC5F52 = 259E2D6E;
					}
					while (num == 1366240948U);
				}
			}
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x0030EEB0 File Offset: 0x0030CAB0
		public override Type 303BF244()
		{
			uint num = 212600662U;
			FieldInfo fieldInfo = this.2EB3528E;
			num = (365771765U | num);
			return fieldInfo.FieldType;
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0030EED8 File Offset: 0x0030CAD8
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 913316538U;
			num = 890449385U - num;
			FieldInfo 3EDF6AD = this.2EB3528E;
			num &= 230324614U;
			num = (13896255U & num);
			return new 467F5DB3.1DEE779D(3EDF6AD, this.6ECC5F52);
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x0030EF14 File Offset: 0x0030CB14
		public override object 6B58D7F4()
		{
			uint num = 437076412U;
			FieldInfo fieldInfo = this.2EB3528E;
			num = (1810652521U & num);
			num >>= 3;
			return fieldInfo.GetValue(this.6ECC5F52);
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x0030EF48 File Offset: 0x0030CB48
		public override void 59A76885(object 51084ACD)
		{
			uint num = 29497841U;
			if (num <= 1848906026U)
			{
				FieldInfo fieldInfo = this.2EB3528E;
				object obj = this.6ECC5F52;
				num = 1249334147U << (int)num;
				num = 578962034U << (int)num;
				fieldInfo.SetValue(obj, 51084ACD);
			}
		}

		// Token: 0x040001DA RID: 474
		private FieldInfo 2EB3528E;

		// Token: 0x040001DB RID: 475
		private object 6ECC5F52;
	}

	// Token: 0x02000065 RID: 101
	private sealed class 67EB01D1 : 467F5DB3.00BC6875
	{
		// Token: 0x06000429 RID: 1065 RVA: 0x0030EF94 File Offset: 0x0030CB94
		public 67EB01D1(Array 128018FF, int 20CE28B0)
		{
			uint num = 845360315U;
			if (num << 27 != 0U)
			{
				base..ctor();
				num = 516236436U * num;
				this.2C916E9C = 128018FF;
				num = (53964821U & num);
			}
			num >>= 15;
			this.7C652901 = 20CE28B0;
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0030EFE0 File Offset: 0x0030CBE0
		public override Type 303BF244()
		{
			uint num = 1443645074U;
			num &= 565707420U;
			return this.2C916E9C.GetType().GetElementType();
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x0030F00C File Offset: 0x0030CC0C
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 137253975U;
			Array 128018FF = this.2C916E9C;
			num = 448474669U / num;
			int 20CE28B = this.7C652901;
			num = (1305768636U ^ num);
			return new 467F5DB3.67EB01D1(128018FF, 20CE28B);
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0030F040 File Offset: 0x0030CC40
		public override object 6B58D7F4()
		{
			uint num = 241790497U;
			Array array = this.2C916E9C;
			num |= 1793857467U;
			return array.GetValue(this.7C652901);
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x0030F06C File Offset: 0x0030CC6C
		public override void 59A76885(object 1F890A30)
		{
			Array array = this.2C916E9C;
			uint num = 1683626509U;
			int index = this.7C652901;
			num /= 1986791011U;
			array.SetValue(1F890A30, index);
		}

		// Token: 0x040001DC RID: 476
		private Array 2C916E9C;

		// Token: 0x040001DD RID: 477
		private int 7C652901;
	}

	// Token: 0x02000066 RID: 102
	private sealed class 6C3B2692 : 467F5DB3.371F2AF7
	{
		// Token: 0x0600042E RID: 1070 RVA: 0x0030F09C File Offset: 0x0030CC9C
		public 6C3B2692(MethodBase 0DEB6D76)
		{
			uint num = 2045316083U;
			base..ctor();
			num *= 570644100U;
			this.77D31FF9 = 0DEB6D76;
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x0030F0C4 File Offset: 0x0030CCC4
		public override Type 303BF244()
		{
			uint num = 47457409U;
			RuntimeTypeHandle handle = typeof(MethodBase).TypeHandle;
			num |= 1594521140U;
			return Type.GetTypeFromHandle(handle);
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x0030F0EC File Offset: 0x0030CCEC
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 1978291773U;
			num = 714234491U >> (int)num;
			return new 467F5DB3.6C3B2692(this.77D31FF9);
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x0030F118 File Offset: 0x0030CD18
		public override object 6B58D7F4()
		{
			uint num = 2040228910U;
			num = (1091459731U ^ num);
			return this.77D31FF9;
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x0030F13C File Offset: 0x0030CD3C
		public override void 59A76885(object 44067EF0)
		{
			uint num = 1330066142U;
			num = (1978301000U ^ num);
			num = 1312561557U >> (int)num;
			MethodBase methodBase = (MethodBase)44067EF0;
			num = 1027743962U * num;
			this.77D31FF9 = methodBase;
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x0030F17C File Offset: 0x0030CD7C
		public override bool A8DF755E()
		{
			return this.77D31FF9 != null;
		}

		// Token: 0x06000434 RID: 1076 RVA: 0x0030F198 File Offset: 0x0030CD98
		public override IntPtr 8C5D656E()
		{
			uint num = 428561097U;
			RuntimeMethodHandle methodHandle = this.77D31FF9.MethodHandle;
			num = 2029322280U + num;
			RuntimeMethodHandle runtimeMethodHandle = methodHandle;
			num = (876178205U & num);
			return runtimeMethodHandle.GetFunctionPointer();
		}

		// Token: 0x040001DE RID: 478
		private MethodBase 77D31FF9;
	}

	// Token: 0x02000067 RID: 103
	private sealed class 00086387 : 467F5DB3.371F2AF7
	{
		// Token: 0x06000435 RID: 1077 RVA: 0x0030F1D0 File Offset: 0x0030CDD0
		public 00086387(IntPtr 6C1245F1)
		{
			uint num = 713129269U;
			num = (1616653032U & num);
			this.6C097A98 = 6C1245F1;
			num /= 985557692U;
			467F5DB3.37FA30B9 37FA30B = 467F5DB3.00086387.46786C0A(this.6C097A98);
			num = 1675573806U >> (int)num;
			this.236454C6 = 37FA30B;
		}

		// Token: 0x06000436 RID: 1078 RVA: 0x0030F220 File Offset: 0x0030CE20
		private static 467F5DB3.37FA30B9 46786C0A(IntPtr 65DD0B32)
		{
			uint num = 371687000U;
			if (IntPtr.Size == (int)(num - 371686996U) && num >= 326772521U)
			{
				num = 1735802232U % num;
				return new 467F5DB3.1C0911B0(65DD0B32.ToInt32());
			}
			num /= 986518325U;
			long 0E0B = 65DD0B32.ToInt64();
			num += 2032627700U;
			return new 467F5DB3.06E010E5(0E0B);
		}

		// Token: 0x06000437 RID: 1079 RVA: 0x0030F280 File Offset: 0x0030CE80
		public override Type 303BF244()
		{
			return typeof(IntPtr);
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x0030F2A0 File Offset: 0x0030CEA0
		public override TypeCode 02557F0D()
		{
			uint num = 1407920090U;
			467F5DB3.37FA30B9 37FA30B = this.236454C6;
			num = 2116296216U - num;
			return 37FA30B.02557F0D();
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x0030F2C8 File Offset: 0x0030CEC8
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			return new 467F5DB3.00086387(this.6C097A98);
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x0030F2E0 File Offset: 0x0030CEE0
		public override object 6B58D7F4()
		{
			return this.6C097A98;
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0030F300 File Offset: 0x0030CF00
		public override void 59A76885(object 22D94024)
		{
			uint num;
			do
			{
				num = 1860253723U;
				this.6C097A98 = (IntPtr)22D94024;
				num -= 541994188U;
				IntPtr 65DD0B = this.6C097A98;
				num = 131489887U - num;
				this.236454C6 = 467F5DB3.00086387.46786C0A(65DD0B);
			}
			while ((num & 1469347250U) == 0U);
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x0030F34C File Offset: 0x0030CF4C
		public override bool A8DF755E()
		{
			uint num = 1133148242U;
			IntPtr value = this.6C097A98;
			num = (792133718U ^ num);
			return value != IntPtr.Zero;
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x0030F378 File Offset: 0x0030CF78
		public override sbyte 3D1BD445()
		{
			return this.236454C6.3D1BD445();
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x0030F398 File Offset: 0x0030CF98
		public override short D204A80D()
		{
			uint num = 952322506U;
			num = 861305344U >> (int)num;
			467F5DB3.37FA30B9 37FA30B = this.236454C6;
			num = 517611390U - num;
			return 37FA30B.D204A80D();
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x0030F3CC File Offset: 0x0030CFCC
		public override int D6BFBC24()
		{
			uint num = 576793486U;
			467F5DB3.37FA30B9 37FA30B = this.236454C6;
			num = 791150738U >> (int)num;
			return 37FA30B.D6BFBC24();
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x0030F3F8 File Offset: 0x0030CFF8
		public override long E1698415()
		{
			return this.236454C6.E1698415();
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x0030F418 File Offset: 0x0030D018
		public override byte 76883720()
		{
			uint num = 308288824U;
			467F5DB3.37FA30B9 37FA30B = this.236454C6;
			num = 1691775711U % num;
			return 37FA30B.76883720();
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0030F440 File Offset: 0x0030D040
		public override ushort E91B7AB7()
		{
			uint num = 439485671U;
			num *= 2057717760U;
			467F5DB3.37FA30B9 37FA30B = this.236454C6;
			num -= 208608020U;
			return 37FA30B.E91B7AB7();
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x0030F470 File Offset: 0x0030D070
		public override uint 437B0320()
		{
			uint num = 90127877U;
			467F5DB3.37FA30B9 37FA30B = this.236454C6;
			num |= 476580389U;
			return 37FA30B.437B0320();
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x0030F498 File Offset: 0x0030D098
		public override ulong 67922FD7()
		{
			return this.236454C6.67922FD7();
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x0030F4B8 File Offset: 0x0030D0B8
		public override float 8E4073FD()
		{
			uint num = 875984544U;
			467F5DB3.37FA30B9 37FA30B = this.236454C6;
			num = 2071337512U - num;
			return 37FA30B.8E4073FD();
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x0030F4E0 File Offset: 0x0030D0E0
		public override double B7D5DC99()
		{
			return this.236454C6.B7D5DC99();
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x0030F500 File Offset: 0x0030D100
		public override IntPtr 8C5D656E()
		{
			return this.6C097A98;
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x0030F51C File Offset: 0x0030D11C
		public override UIntPtr 103B638B()
		{
			uint num = 1459161360U;
			467F5DB3.37FA30B9 37FA30B = this.236454C6;
			num = (679170045U ^ num);
			return 37FA30B.103B638B();
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x0030F544 File Offset: 0x0030D144
		public override object F187362C(Type 09EE1C38, bool 58534548)
		{
			uint num = 624777079U;
			467F5DB3.37FA30B9 37FA30B = this.236454C6;
			num >>= 15;
			return 37FA30B.F187362C(09EE1C38, 58534548);
		}

		// Token: 0x040001DF RID: 479
		private IntPtr 6C097A98;

		// Token: 0x040001E0 RID: 480
		private 467F5DB3.37FA30B9 236454C6;
	}

	// Token: 0x02000068 RID: 104
	private sealed class 01BD2A31 : 467F5DB3.371F2AF7
	{
		// Token: 0x0600044A RID: 1098 RVA: 0x0030F56C File Offset: 0x0030D16C
		public 01BD2A31(UIntPtr 10D22B3E)
		{
			uint num = 578908755U;
			base..ctor();
			num = 627733636U % num;
			this.73EC2553 = 10D22B3E;
			do
			{
				467F5DB3.37FA30B9 37FA30B = 467F5DB3.01BD2A31.0ABA63A2(this.73EC2553);
				num %= 1616137605U;
				this.2AA93CB3 = 37FA30B;
			}
			while (1278490796U == num);
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x0030F5B8 File Offset: 0x0030D1B8
		private static 467F5DB3.37FA30B9 0ABA63A2(UIntPtr 58F6700A)
		{
			if (IntPtr.Size == 4)
			{
				uint num = 107161842U;
				int 0A = (int)58F6700A.ToUInt32();
				num &= 536044872U;
				return new 467F5DB3.1C0911B0(0A);
			}
			return new 467F5DB3.06E010E5((long)58F6700A.ToUInt64());
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x0030F5F8 File Offset: 0x0030D1F8
		public override Type 303BF244()
		{
			return typeof(UIntPtr);
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x0030F618 File Offset: 0x0030D218
		public override TypeCode 02557F0D()
		{
			uint num = 2142588856U;
			467F5DB3.37FA30B9 37FA30B = this.2AA93CB3;
			num += 1327193679U;
			return 37FA30B.02557F0D();
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x0030F640 File Offset: 0x0030D240
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 1941992257U;
			num &= 1123498038U;
			UIntPtr 10D22B3E = this.73EC2553;
			num -= 408618454U;
			return new 467F5DB3.01BD2A31(10D22B3E);
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x0030F670 File Offset: 0x0030D270
		public override object 6B58D7F4()
		{
			return this.73EC2553;
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x0030F688 File Offset: 0x0030D288
		public override void 59A76885(object 44894A87)
		{
			uint num = 1031745360U;
			if (1302296080U > num)
			{
				do
				{
					num = (1574573399U ^ num);
					this.73EC2553 = (UIntPtr)44894A87;
				}
				while (num / 1204248192U == 0U);
			}
			do
			{
				this.2AA93CB3 = 467F5DB3.01BD2A31.0ABA63A2(this.73EC2553);
			}
			while (num == 983243216U);
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x0030F6E4 File Offset: 0x0030D2E4
		public override bool A8DF755E()
		{
			uint num = 1902726062U;
			num |= 1347363059U;
			UIntPtr value = this.73EC2553;
			UIntPtr zero = UIntPtr.Zero;
			num += 2100251291U;
			return value != zero;
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x0030F718 File Offset: 0x0030D318
		public override sbyte 3D1BD445()
		{
			return this.2AA93CB3.3D1BD445();
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x0030F738 File Offset: 0x0030D338
		public override short D204A80D()
		{
			return this.2AA93CB3.D204A80D();
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x0030F750 File Offset: 0x0030D350
		public override int D6BFBC24()
		{
			return this.2AA93CB3.D6BFBC24();
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0030F770 File Offset: 0x0030D370
		public override long E1698415()
		{
			return this.2AA93CB3.E1698415();
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0030F790 File Offset: 0x0030D390
		public override byte 76883720()
		{
			return this.2AA93CB3.76883720();
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0030F7B0 File Offset: 0x0030D3B0
		public override ushort E91B7AB7()
		{
			return this.2AA93CB3.E91B7AB7();
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0030F7D0 File Offset: 0x0030D3D0
		public override uint 437B0320()
		{
			return this.2AA93CB3.437B0320();
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0030F7F0 File Offset: 0x0030D3F0
		public override ulong 67922FD7()
		{
			return this.2AA93CB3.67922FD7();
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x0030F810 File Offset: 0x0030D410
		public override float 8E4073FD()
		{
			uint num = 119409138U;
			467F5DB3.37FA30B9 37FA30B = this.2AA93CB3;
			num /= 1657742750U;
			return 37FA30B.8E4073FD();
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x0030F838 File Offset: 0x0030D438
		public override double B7D5DC99()
		{
			uint num = 1580756914U;
			num <<= 31;
			467F5DB3.37FA30B9 37FA30B = this.2AA93CB3;
			num &= 1309870978U;
			return 37FA30B.B7D5DC99();
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x0030F868 File Offset: 0x0030D468
		public override IntPtr 8C5D656E()
		{
			return this.2AA93CB3.8C5D656E();
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x0030F888 File Offset: 0x0030D488
		public override UIntPtr 103B638B()
		{
			return this.73EC2553;
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x0030F89C File Offset: 0x0030D49C
		public override object F187362C(Type 7C0C732F, bool 282441D9)
		{
			return this.2AA93CB3.F187362C(7C0C732F, 282441D9);
		}

		// Token: 0x040001E1 RID: 481
		private UIntPtr 73EC2553;

		// Token: 0x040001E2 RID: 482
		private 467F5DB3.37FA30B9 2AA93CB3;
	}

	// Token: 0x02000069 RID: 105
	private sealed class 14624823 : 467F5DB3.371F2AF7
	{
		// Token: 0x0600045F RID: 1119 RVA: 0x0030F8BC File Offset: 0x0030D4BC
		public 14624823(Enum 1E3A6B48)
		{
			for (;;)
			{
				base..ctor();
				uint num = 1317433434U;
				while (1E3A6B48 == null)
				{
					if (152717627 << (int)num != 0)
					{
						goto Block_1;
					}
				}
				num -= 1980121769U;
				num = (418795341U & num);
				num += 99950988U;
				this.35CE49DD = 1E3A6B48;
				num /= 1269828571U;
				Enum 72AB5D8F = this.35CE49DD;
				num = 1632785544U << (int)num;
				467F5DB3.37FA30B9 37FA30B = 467F5DB3.14624823.0FE41542(72AB5D8F);
				num = 293554526U - num;
				this.0A22142B = 37FA30B;
				if (1340888520U + num != 0U)
				{
					return;
				}
			}
			Block_1:
			throw new ArgumentException();
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x0030F950 File Offset: 0x0030D550
		private static 467F5DB3.37FA30B9 0FE41542(Enum 72AB5D8F)
		{
			uint num;
			for (;;)
			{
				num = 248254698U;
				TypeCode typeCode = 72AB5D8F.GetTypeCode();
				num = (829496821U ^ num);
				TypeCode typeCode2 = typeCode;
				num = 1723668632U * num;
				if (num + 1852579076U != 0U)
				{
					for (;;)
					{
						switch (typeCode2 - ((int)num + (TypeCode)1688358301))
						{
						case 0:
						case 2:
						case 4:
							goto IL_8F;
						case 1:
						case 3:
						case 5:
							goto IL_68;
						case 6:
							goto IL_BF;
						case 7:
							goto IL_A3;
						default:
							if (num % 1200696772U == 0U)
							{
								goto IL_68;
							}
							num %= 1958828787U;
							if (852560088U + num != 0U)
							{
								goto Block_3;
							}
							break;
						}
					}
					IL_68:
					if (num >= 1314529089U)
					{
						break;
					}
				}
			}
			num = (1906642167U ^ num);
			int 0A = (int)Convert.ToUInt32(72AB5D8F);
			num += 1505241966U;
			return new 467F5DB3.1C0911B0(0A);
			IL_8F:
			int 0A2 = Convert.ToInt32(72AB5D8F);
			num = 1006966050U - num;
			return new 467F5DB3.1C0911B0(0A2);
			IL_A3:
			num ^= 1278491390U;
			long 0E0B = (long)Convert.ToUInt64(72AB5D8F);
			num = 1334251603U / num;
			return new 467F5DB3.06E010E5(0E0B);
			IL_BF:
			num = 1237337493U << (int)num;
			num = 2036925789U / num;
			return new 467F5DB3.06E010E5(Convert.ToInt64(72AB5D8F));
			Block_3:
			throw new InvalidOperationException();
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0030FA58 File Offset: 0x0030D658
		public override 467F5DB3.37FA30B9 374AB499()
		{
			return this.0A22142B.374AB499();
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x0030FA78 File Offset: 0x0030D678
		public override Type 303BF244()
		{
			uint num = 117770389U;
			object obj = this.35CE49DD;
			num -= 1815760488U;
			return obj.GetType();
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x0030FAA0 File Offset: 0x0030D6A0
		public override TypeCode 02557F0D()
		{
			return this.0A22142B.02557F0D();
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x0030FAB8 File Offset: 0x0030D6B8
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 1822634513U;
			Enum 1E3A6B = this.35CE49DD;
			num += 1903034459U;
			return new 467F5DB3.14624823(1E3A6B);
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x0030FAE0 File Offset: 0x0030D6E0
		public override object 6B58D7F4()
		{
			uint num = 2098016966U;
			num = 1909940809U + num;
			return this.35CE49DD;
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x0030FB04 File Offset: 0x0030D704
		public override void 59A76885(object 73A95F39)
		{
			uint num = 504370044U;
			if ((num ^ 1074610841U) == 0U)
			{
				goto IL_39;
			}
			IL_12:
			num = (996878344U | num);
			if (73A95F39 == null)
			{
				num = (1857104754U | num);
				if (1909793802U <= num)
				{
					throw new ArgumentException();
				}
				goto IL_69;
			}
			IL_39:
			num *= 1703544205U;
			if (2100589362U + num == 0U)
			{
				goto IL_12;
			}
			num = 909060558U + num;
			this.35CE49DD = (Enum)73A95F39;
			num %= 398659897U;
			IL_69:
			num = 1162627825U << (int)num;
			this.0A22142B = 467F5DB3.14624823.0FE41542(this.35CE49DD);
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x0030FB9C File Offset: 0x0030D79C
		public override byte 76883720()
		{
			uint num = 372455273U;
			467F5DB3.37FA30B9 37FA30B = this.0A22142B;
			num *= 864314161U;
			return 37FA30B.76883720();
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x0030FBC4 File Offset: 0x0030D7C4
		public override sbyte 3D1BD445()
		{
			return this.0A22142B.3D1BD445();
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x0030FBE4 File Offset: 0x0030D7E4
		public override short D204A80D()
		{
			return this.0A22142B.D204A80D();
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x0030FC04 File Offset: 0x0030D804
		public override ushort E91B7AB7()
		{
			return this.0A22142B.E91B7AB7();
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x0030FC24 File Offset: 0x0030D824
		public override int D6BFBC24()
		{
			uint num = 1662130311U;
			467F5DB3.37FA30B9 37FA30B = this.0A22142B;
			num = 1777163437U + num;
			return 37FA30B.D6BFBC24();
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x0030FC4C File Offset: 0x0030D84C
		public override uint 437B0320()
		{
			return this.0A22142B.437B0320();
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x0030FC6C File Offset: 0x0030D86C
		public override long E1698415()
		{
			return this.0A22142B.E1698415();
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x0030FC84 File Offset: 0x0030D884
		public override ulong 67922FD7()
		{
			return this.0A22142B.67922FD7();
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x0030FCA4 File Offset: 0x0030D8A4
		public override float 8E4073FD()
		{
			uint num = 12992467U;
			467F5DB3.37FA30B9 37FA30B = this.0A22142B;
			num %= 1146946328U;
			return 37FA30B.8E4073FD();
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x0030FCCC File Offset: 0x0030D8CC
		public override double B7D5DC99()
		{
			uint num = 211552650U;
			num |= 141895765U;
			return this.0A22142B.B7D5DC99();
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x0030FCF4 File Offset: 0x0030D8F4
		public override IntPtr 8C5D656E()
		{
			uint size = (uint)IntPtr.Size;
			uint num = 2100434130U;
			long value;
			if (size != num + 2194533170U)
			{
				num -= 1539184189U;
				num ^= 912458106U;
				value = this.E1698415();
			}
			else
			{
				num *= 582305507U;
				value = (long)this.D6BFBC24();
				num += 3313311161U;
			}
			return new IntPtr(value);
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x0030FD50 File Offset: 0x0030D950
		public override UIntPtr 103B638B()
		{
			int size = IntPtr.Size;
			uint num = 595474539U;
			uint num2 = num + 3699492761U;
			num = 1203257699U * num;
			ulong value;
			if (size != num2 && 236405439U > num)
			{
				num = 541987574U + num;
				value = this.67922FD7();
			}
			else
			{
				num = 1328246305U % num;
				value = (ulong)this.437B0320();
				num ^= 542149690U;
			}
			return new UIntPtr(value);
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x0030FDB8 File Offset: 0x0030D9B8
		public override object F187362C(Type 3C6608F8, bool 6BE84A53)
		{
			uint num = 657342576U;
			467F5DB3.37FA30B9 37FA30B = this.0A22142B;
			num = (91247092U & num);
			num ^= 777868459U;
			num &= 1963275603U;
			return 37FA30B.F187362C(3C6608F8, 6BE84A53);
		}

		// Token: 0x040001E3 RID: 483
		private Enum 35CE49DD;

		// Token: 0x040001E4 RID: 484
		private 467F5DB3.37FA30B9 0A22142B;
	}

	// Token: 0x0200006A RID: 106
	private sealed class 14F4779B : 467F5DB3.00BC6875
	{
		// Token: 0x06000474 RID: 1140 RVA: 0x0030FDF0 File Offset: 0x0030D9F0
		public 14F4779B(IntPtr 1B901B23, Type 2C8510BE)
		{
			uint num = 404317409U;
			if (num != 982851171U)
			{
				num = (803947926U ^ num);
				base..ctor();
				num = 494956274U >> (int)num;
				num = 2095739970U - num;
				num = (1156525492U & num);
				this.204D2D72 = 1B901B23;
			}
			num *= 1725174645U;
			this.26E2552A = 2C8510BE;
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x0030FE50 File Offset: 0x0030DA50
		public override Type 303BF244()
		{
			uint num = 2101369345U;
			RuntimeTypeHandle handle = typeof(Pointer).TypeHandle;
			num = (498470109U ^ num);
			return Type.GetTypeFromHandle(handle);
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x002FC34C File Offset: 0x002F9F4C
		public override TypeCode 02557F0D()
		{
			uint num = 893199558U;
			return (TypeCode)(num ^ 893199558U);
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x0030FE78 File Offset: 0x0030DA78
		public override 467F5DB3.37FA30B9 15FAD4A1()
		{
			uint num = 582889825U;
			IntPtr 1B901B = this.204D2D72;
			num >>= 27;
			num ^= 1709668252U;
			Type 2C8510BE = this.26E2552A;
			num |= 2120687762U;
			return new 467F5DB3.14F4779B(1B901B, 2C8510BE);
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x0030FEB4 File Offset: 0x0030DAB4
		public override object 6B58D7F4()
		{
			Type type = this.26E2552A;
			uint num = 1868827048U;
			if (!type.IsValueType || num == 2110260138U)
			{
				num >>= 15;
				if (1884253931U + num != 0U)
				{
					throw new InvalidOperationException();
				}
			}
			return Marshal.PtrToStructure(this.204D2D72, this.26E2552A);
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x0030FF10 File Offset: 0x0030DB10
		public override void 59A76885(object 00E3683B)
		{
			uint num = 2003650155U;
			if (num == 888495305U)
			{
				goto IL_29;
			}
			IL_11:
			while (00E3683B == null)
			{
				if (num + 2079354836U != 0U)
				{
					goto IL_23;
				}
			}
			for (;;)
			{
				IL_29:
				num = 2146304467U * num;
				if (this.26E2552A.IsValueType)
				{
					break;
				}
				if (638872617U - num != 0U)
				{
					Type type = 00E3683B.GetType();
					num = (1752259682U | num);
					TypeCode typeCode = Type.GetTypeCode(type);
					num = (191199022U | num);
					TypeCode typeCode2 = typeCode;
					num = (1226905236U ^ num);
					if (873951168U < num)
					{
						goto IL_11;
					}
					TypeCode typeCode3 = typeCode2;
					num -= 79775219U;
					uint num2 = num - 504570868U;
					num = 1306988429U >> (int)num;
					switch (typeCode3 - num2)
					{
					case 0:
						goto IL_1A3;
					case 1:
						goto IL_115;
					case 2:
						goto IL_165;
					case 3:
						goto IL_1D6;
					case 4:
						goto IL_1F0;
					case 5:
						goto IL_235;
					case 6:
						goto IL_26E;
					case 7:
						goto IL_290;
					case 8:
						goto IL_2C2;
					case 9:
						goto IL_2FA;
					case 10:
						if (num <= 675027241U)
						{
							goto Block_13;
						}
						break;
					default:
						if ((2131701458U ^ num) == 0U)
						{
							goto IL_23;
						}
						num = 225711992U >> (int)num;
						if (num != 1577809883U)
						{
							goto Block_15;
						}
						break;
					}
				}
			}
			num = 642451639U % num;
			if (2104443432U % num == 0U)
			{
				return;
			}
			IL_55:
			num = (1042023273U | num);
			IntPtr ptr = this.204D2D72;
			num -= 493496988U;
			Marshal.StructureToPtr(00E3683B, ptr, (num ^ 552919395U) != 0U);
			return;
			IL_115:
			IntPtr ptr2 = this.204D2D72;
			num = 1891059571U << (int)num;
			num = 1605305296U >> (int)num;
			byte b = (byte)Convert.ToSByte(00E3683B);
			num = 2015968412U << (int)num;
			byte val = b;
			num %= 825653540U;
			Marshal.WriteByte(ptr2, val);
			if (num != 2009793185U)
			{
				return;
			}
			goto IL_11;
			IL_165:
			num /= 1341152940U;
			num = 1273245146U - num;
			IntPtr ptr3 = this.204D2D72;
			num |= 1979197983U;
			byte val2 = Convert.ToByte(00E3683B);
			num *= 1006449289U;
			Marshal.WriteByte(ptr3, val2);
			if (num << 2 != 0U)
			{
				return;
			}
			goto IL_23;
			IL_1A3:
			if (1595305176U > num)
			{
				IntPtr ptr4 = this.204D2D72;
				num = 135025377U >> (int)num;
				char val3 = Convert.ToChar(00E3683B);
				num ^= 1958616860U;
				Marshal.WriteInt16(ptr4, val3);
				return;
			}
			goto IL_55;
			IL_1D6:
			num <<= 15;
			Marshal.WriteInt16(this.204D2D72, Convert.ToInt16(00E3683B));
			return;
			IL_1F0:
			if ((1784618112U & num) == 0U)
			{
				num = 1691229798U + num;
				IntPtr ptr5 = this.204D2D72;
				num = 1185447902U >> (int)num;
				short num3 = (short)Convert.ToUInt16(00E3683B);
				num = 1484727646U + num;
				short val4 = num3;
				num = (1146177413U ^ num);
				Marshal.WriteInt16(ptr5, val4);
				return;
			}
			goto IL_11;
			IL_235:
			if (90271451U == num)
			{
				goto IL_11;
			}
			num -= 2084441900U;
			IntPtr ptr6 = this.204D2D72;
			int val5 = Convert.ToInt32(00E3683B);
			num >>= 21;
			Marshal.WriteInt32(ptr6, val5);
			if (2076995867U + num != 0U)
			{
				return;
			}
			goto IL_11;
			IL_26E:
			num /= 1688207943U;
			IntPtr ptr7 = this.204D2D72;
			num = (1740526798U | num);
			Marshal.WriteInt32(ptr7, (int)Convert.ToUInt32(00E3683B));
			return;
			IL_290:
			num = 1553138334U - num;
			IntPtr ptr8 = this.204D2D72;
			num *= 1959074613U;
			num |= 1924806567U;
			long val6 = Convert.ToInt64(00E3683B);
			num >>= 14;
			Marshal.WriteInt64(ptr8, val6);
			return;
			IL_2C2:
			num = (1673268253U & num);
			num <<= 4;
			IntPtr ptr9 = this.204D2D72;
			num = 1481330187U << (int)num;
			long val7 = (long)Convert.ToUInt64(00E3683B);
			num = (695493250U & num);
			Marshal.WriteInt64(ptr9, val7);
			return;
			IL_2FA:
			num |= 2040410228U;
			IntPtr ptr10 = this.204D2D72;
			num >>= 23;
			byte[] bytes = BitConverter.GetBytes(Convert.ToSingle(00E3683B));
			num |= 2068258285U;
			int startIndex = (int)(num ^ 2068258303U);
			num >>= 22;
			int val8 = BitConverter.ToInt32(bytes, startIndex);
			num = (1387795067U & num);
			Marshal.WriteInt32(ptr10, val8);
			return;
			Block_13:
			num /= 1827219034U;
			IntPtr ptr11 = this.204D2D72;
			num = (1068443906U & num);
			byte[] bytes2 = BitConverter.GetBytes(Convert.ToDouble(00E3683B));
			num /= 267653114U;
			int startIndex2 = (int)(num ^ 0U);
			num %= 287996003U;
			long val9 = BitConverter.ToInt64(bytes2, startIndex2);
			num = (1139545823U | num);
			Marshal.WriteInt64(ptr11, val9);
			if (79195483 << (int)num != 0)
			{
				return;
			}
			goto IL_55;
			Block_15:
			throw new ArgumentException();
			IL_23:
			throw new ArgumentException();
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x003102E8 File Offset: 0x0030DEE8
		public override sbyte 3D1BD445()
		{
			uint num = 1856242019U;
			IntPtr ptr = this.204D2D72;
			num = 1368148330U << (int)num;
			sbyte b = (sbyte)Marshal.ReadByte(ptr);
			num = 1130371311U - num;
			return b;
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x00310320 File Offset: 0x0030DF20
		public override short D204A80D()
		{
			uint num = 1186949069U;
			num += 1544909999U;
			return Marshal.ReadInt16(this.204D2D72);
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x00310348 File Offset: 0x0030DF48
		public override int D6BFBC24()
		{
			uint num = 1800737531U;
			num = 443048235U + num;
			return Marshal.ReadInt32(this.204D2D72);
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x00310370 File Offset: 0x0030DF70
		public override long E1698415()
		{
			uint num = 993866387U;
			IntPtr ptr = this.204D2D72;
			num = 116293509U * num;
			return Marshal.ReadInt64(ptr);
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x00310398 File Offset: 0x0030DF98
		public override char C8DBDBAA()
		{
			uint num = 880088570U;
			num = 1702657094U >> (int)num;
			return (char)Marshal.ReadInt16(this.204D2D72);
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x003103C8 File Offset: 0x0030DFC8
		public override byte 76883720()
		{
			uint num = 393499571U;
			IntPtr ptr = this.204D2D72;
			num >>= 22;
			return Marshal.ReadByte(ptr);
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x00310398 File Offset: 0x0030DF98
		public override ushort E91B7AB7()
		{
			uint num = 880088570U;
			num = 1702657094U >> (int)num;
			return (ushort)Marshal.ReadInt16(this.204D2D72);
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x00310348 File Offset: 0x0030DF48
		public override uint 437B0320()
		{
			uint num = 1800737531U;
			num = 443048235U + num;
			return (uint)Marshal.ReadInt32(this.204D2D72);
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x00310370 File Offset: 0x0030DF70
		public override ulong 67922FD7()
		{
			uint num = 993866387U;
			IntPtr ptr = this.204D2D72;
			num = 116293509U * num;
			return (ulong)Marshal.ReadInt64(ptr);
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x003103F0 File Offset: 0x0030DFF0
		public override float 8E4073FD()
		{
			uint num = 1211195747U;
			IntPtr ptr = this.204D2D72;
			num = 2036271670U + num;
			return BitConverter.ToSingle(BitConverter.GetBytes(Marshal.ReadInt32(ptr)), (int)(num + 1047499879U));
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x00310428 File Offset: 0x0030E028
		public override double B7D5DC99()
		{
			uint num = 316959496U;
			num ^= 1665344957U;
			byte[] bytes = BitConverter.GetBytes(Marshal.ReadInt64(this.204D2D72));
			num <<= 27;
			int startIndex = (int)(num ^ 2818572288U);
			num = 1150429350U + num;
			return BitConverter.ToDouble(bytes, startIndex);
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x00310470 File Offset: 0x0030E070
		public override IntPtr 8C5D656E()
		{
			uint num = 1084381953U;
			long value;
			if (num - 1462394477U != 0U)
			{
				for (;;)
				{
					int size = IntPtr.Size;
					uint num2 = num ^ 1084381957U;
					num = 1996825705U / num;
					if (size != num2)
					{
						if (44776221U % num == 0U)
						{
							goto IL_37;
						}
					}
					else if (num <= 1910775391U)
					{
						break;
					}
				}
				num >>= 5;
				value = (long)Marshal.ReadInt32(this.204D2D72);
				num ^= 1U;
				goto IL_6E;
			}
			IL_37:
			value = Marshal.ReadInt64(this.204D2D72);
			IL_6E:
			return new IntPtr(value);
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x003104F0 File Offset: 0x0030E0F0
		public override UIntPtr 103B638B()
		{
			uint num = 1477444716U;
			if (num != 1673337596U)
			{
				while (IntPtr.Size != (int)(num - 1477444712U))
				{
					num ^= 546838731U;
					if (429855658U != num)
					{
						goto IL_35;
					}
				}
				goto IL_4D;
			}
			goto IL_4D;
			IL_35:
			num = 758122304U / num;
			ulong value = (ulong)Marshal.ReadInt64(this.204D2D72);
			goto IL_85;
			IL_4D:
			if ((400699318U & num) == 0U)
			{
				goto IL_35;
			}
			num >>= 6;
			IntPtr ptr = this.204D2D72;
			num /= 509307927U;
			ulong num2 = (ulong)Marshal.ReadInt32(ptr);
			num &= 1157911281U;
			value = num2;
			num += 0U;
			IL_85:
			num |= 1484403086U;
			return new UIntPtr(value);
		}

		// Token: 0x040001E5 RID: 485
		private IntPtr 204D2D72;

		// Token: 0x040001E6 RID: 486
		private Type 26E2552A;
	}

	// Token: 0x0200006B RID: 107
	private sealed class 42FB763B
	{
		// Token: 0x06000487 RID: 1159 RVA: 0x00310590 File Offset: 0x0030E190
		public 42FB763B(byte 7D8A45C0, int 72B3454B, int 429D2705)
		{
			uint num;
			do
			{
				num = 1947079265U;
				base..ctor();
			}
			while (804675118U + num == 0U);
			num = 1623226067U >> (int)num;
			this.71A2437E = 7D8A45C0;
			num = 1390021783U + num;
			num = 40642995U - num;
			this.2D42349B = 72B3454B;
			this.689066E0 = 429D2705;
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x003105E8 File Offset: 0x0030E1E8
		public byte 725458AE()
		{
			return this.71A2437E;
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x00310604 File Offset: 0x0030E204
		public int 012472E6()
		{
			return this.2D42349B;
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x00310620 File Offset: 0x0030E220
		public int 23206D20()
		{
			return this.689066E0;
		}

		// Token: 0x040001E7 RID: 487
		private byte 71A2437E;

		// Token: 0x040001E8 RID: 488
		private int 2D42349B;

		// Token: 0x040001E9 RID: 489
		private int 689066E0;
	}

	// Token: 0x0200006C RID: 108
	private sealed class 74D46A00
	{
		// Token: 0x0600048B RID: 1163 RVA: 0x0031063C File Offset: 0x0030E23C
		public 74D46A00(int 1AF5160A, int 2DB12037)
		{
			uint num = 2081227846U;
			if (num != 446909939U)
			{
				num >>= 3;
				this.0DA319D5 = new List<467F5DB3.42FB763B>();
				do
				{
					num >>= 4;
					base..ctor();
					this.31B85BA9 = 1AF5160A;
					num = 1918447378U - num;
					this.3FD93E70 = 2DB12037;
				}
				while (1037592783U >> (int)num == 0U);
			}
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x003106A4 File Offset: 0x0030E2A4
		public int 40532304()
		{
			return this.31B85BA9;
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x003106C0 File Offset: 0x0030E2C0
		public int 74685482()
		{
			return this.3FD93E70;
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x003106DC File Offset: 0x0030E2DC
		public int 355255BD(467F5DB3.74D46A00 5FA55207)
		{
			uint num;
			int num3;
			int num5;
			for (;;)
			{
				num = 1716521342U;
				if (5FA55207 == null)
				{
					break;
				}
				num *= 2134918842U;
				num <<= 2;
				num = 500240356U % num;
				int value = 5FA55207.40532304();
				num += 1192773968U;
				int num2 = this.31B85BA9.CompareTo(value);
				num -= 1667191784U;
				num3 = num2;
				if (num3 != 0)
				{
					return num3;
				}
				if (795285059U - num != 0U)
				{
					int num4 = 5FA55207.74685482();
					num |= 1682733980U;
					num5 = num4;
					if (num != 1006121753U)
					{
						goto Block_3;
					}
				}
			}
			num = 2101556064U % num;
			return (int)(num ^ 385034723U);
			Block_3:
			num = 1516310786U + num;
			num = 1263281988U >> (int)num;
			num3 = num5.CompareTo(this.3FD93E70);
			num ^= 25822541U;
			return num3;
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x00310798 File Offset: 0x0030E398
		public void 195657AE(byte 47D122D4, int 33135B31, int 623A7127)
		{
			uint num = 130558898U;
			List<467F5DB3.42FB763B> list = this.0DA319D5;
			num = 535180034U >> (int)num;
			num = 29509191U << (int)num;
			num &= 314526204U;
			467F5DB3.42FB763B item = new 467F5DB3.42FB763B(47D122D4, 33135B31, 623A7127);
			num /= 172242316U;
			list.Add(item);
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x003107EC File Offset: 0x0030E3EC
		public List<467F5DB3.42FB763B> 5A314F34()
		{
			return this.0DA319D5;
		}

		// Token: 0x040001EA RID: 490
		private int 31B85BA9;

		// Token: 0x040001EB RID: 491
		private int 3FD93E70;

		// Token: 0x040001EC RID: 492
		private List<467F5DB3.42FB763B> 0DA319D5;
	}

	// Token: 0x0200006D RID: 109
	// (Invoke) Token: 0x06000492 RID: 1170
	internal delegate void 37CE4668();
}
