﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

// Token: 0x0200003E RID: 62
internal struct 032546EE
{
	// Token: 0x060002CC RID: 716 RVA: 0x001C0972 File Offset: 0x001BE772
	[Conditional("DEBUG")]
	private void 04E76A2D(bool 028D2FF4)
	{
		int num = this.77F16D84;
	}

	// Token: 0x060002CD RID: 717 RVA: 0x001C097D File Offset: 0x001BE77D
	internal 032546EE(int 42E138E2)
	{
		this.77F16D84 = 0;
		this.45B43F98 = 0U;
		if (42E138E2 > 1)
		{
			this.03033C30 = new uint[42E138E2];
			this.024F2731 = true;
			return;
		}
		this.03033C30 = null;
		this.024F2731 = false;
	}

	// Token: 0x060002CE RID: 718 RVA: 0x001C09B4 File Offset: 0x001BE7B4
	internal 032546EE(20307533 09F57F2D, ref int 211D45AF)
	{
		this.024F2731 = false;
		this.03033C30 = 09F57F2D.102F2D90;
		int num = 09F57F2D.327A1157;
		int num2 = num >> 31;
		211D45AF = (211D45AF ^ num2) - num2;
		if (this.03033C30 == null)
		{
			this.77F16D84 = 0;
			this.45B43F98 = (uint)((num ^ num2) - num2);
			return;
		}
		this.77F16D84 = this.03033C30.Length - 1;
		this.45B43F98 = this.03033C30[0];
		while (this.77F16D84 > 0 && this.03033C30[this.77F16D84] == 0U)
		{
			this.77F16D84--;
		}
	}

	// Token: 0x060002CF RID: 719 RVA: 0x001C0A4C File Offset: 0x001BE84C
	internal 20307533 6B396A2D(int 4B456954)
	{
		uint[] 39CF5D;
		this.68F933CB(4B456954, out 4B456954, out 39CF5D);
		return new 20307533(4B456954, 39CF5D);
	}

	// Token: 0x060002D0 RID: 720 RVA: 0x001C0A6C File Offset: 0x001BE86C
	private void 68F933CB(int 28A36C6E, out int 71583166, out uint[] 05CA0825)
	{
		if (this.77F16D84 == 0)
		{
			if (this.45B43F98 <= 2147483647U)
			{
				71583166 = 28A36C6E * (int)this.45B43F98;
				05CA0825 = null;
				return;
			}
			if (this.03033C30 == null)
			{
				this.03033C30 = new uint[]
				{
					this.45B43F98
				};
			}
			else if (this.024F2731)
			{
				this.03033C30[0] = this.45B43F98;
			}
			else if (this.03033C30[0] != this.45B43F98)
			{
				this.03033C30 = new uint[]
				{
					this.45B43F98
				};
			}
		}
		71583166 = 28A36C6E;
		int num = this.03033C30.Length - this.77F16D84 - 1;
		if (num <= 1)
		{
			if (num == 0 || this.03033C30[this.77F16D84 + 1] == 0U)
			{
				this.024F2731 = false;
				05CA0825 = this.03033C30;
				return;
			}
			if (this.024F2731)
			{
				this.03033C30[this.77F16D84 + 1] = 0U;
				this.024F2731 = false;
				05CA0825 = this.03033C30;
				return;
			}
		}
		05CA0825 = this.03033C30;
		Array.Resize<uint>(ref 05CA0825, this.77F16D84 + 1);
		if (!this.024F2731)
		{
			this.03033C30 = 05CA0825;
		}
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x001C0B83 File Offset: 0x001BE983
	private void 0F23555E(uint 0AEE0BB5)
	{
		this.45B43F98 = 0AEE0BB5;
		this.77F16D84 = 0;
	}

	// Token: 0x060002D2 RID: 722 RVA: 0x001C0B94 File Offset: 0x001BE994
	private void 16D67F25(ulong 39E979E1)
	{
		uint num = 353B51DA.3B4D32F1(39E979E1);
		if (num == 0U)
		{
			this.45B43F98 = 353B51DA.1F176203(39E979E1);
			this.77F16D84 = 0;
			return;
		}
		this.5DDE6A84(2);
		this.03033C30[0] = (uint)39E979E1;
		this.03033C30[1] = num;
	}

	// Token: 0x1700005E RID: 94
	// (get) Token: 0x060002D3 RID: 723 RVA: 0x001C0BD9 File Offset: 0x001BE9D9
	internal int 2E3A65C2
	{
		get
		{
			return this.77F16D84 + 1;
		}
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x001C0BE4 File Offset: 0x001BE9E4
	private void 75BD5F8E()
	{
		if (this.77F16D84 > 0 && this.03033C30[this.77F16D84] == 0U)
		{
			this.45B43F98 = this.03033C30[0];
			int num;
			do
			{
				num = this.77F16D84 - 1;
				this.77F16D84 = num;
			}
			while (num > 0 && this.03033C30[this.77F16D84] == 0U);
		}
	}

	// Token: 0x1700005F RID: 95
	// (get) Token: 0x060002D5 RID: 725 RVA: 0x001C0C3C File Offset: 0x001BEA3C
	private int 103738E0
	{
		get
		{
			int num = 0;
			for (int i = this.77F16D84; i >= 0; i--)
			{
				if (this.03033C30[i] != 0U)
				{
					num++;
				}
			}
			return num;
		}
	}

	// Token: 0x060002D6 RID: 726 RVA: 0x001C0C6B File Offset: 0x001BEA6B
	private void 5DDE6A84(int 05AD3CE0)
	{
		if (05AD3CE0 <= 1)
		{
			this.77F16D84 = 0;
			return;
		}
		if (!this.024F2731 || this.03033C30.Length < 05AD3CE0)
		{
			this.03033C30 = new uint[05AD3CE0];
			this.024F2731 = true;
		}
		this.77F16D84 = 05AD3CE0 - 1;
	}

	// Token: 0x060002D7 RID: 727 RVA: 0x001C0CA8 File Offset: 0x001BEAA8
	private void 09806E77(int 0E775F4D)
	{
		if (0E775F4D <= 1)
		{
			this.77F16D84 = 0;
			this.45B43F98 = 0U;
			return;
		}
		if (!this.024F2731 || this.03033C30.Length < 0E775F4D)
		{
			this.03033C30 = new uint[0E775F4D];
			this.024F2731 = true;
		}
		else
		{
			Array.Clear(this.03033C30, 0, 0E775F4D);
		}
		this.77F16D84 = 0E775F4D - 1;
	}

	// Token: 0x060002D8 RID: 728 RVA: 0x001C0D08 File Offset: 0x001BEB08
	private void 07C07987(int 5A652501, int 43711783)
	{
		if (5A652501 <= 1)
		{
			if (this.77F16D84 > 0)
			{
				this.45B43F98 = this.03033C30[0];
			}
			this.77F16D84 = 0;
			return;
		}
		if (!this.024F2731 || this.03033C30.Length < 5A652501)
		{
			uint[] array = new uint[5A652501 + 43711783];
			if (this.77F16D84 == 0)
			{
				array[0] = this.45B43F98;
			}
			else
			{
				Array.Copy(this.03033C30, array, Math.Min(5A652501, this.77F16D84 + 1));
			}
			this.03033C30 = array;
			this.024F2731 = true;
		}
		else if (this.77F16D84 + 1 < 5A652501)
		{
			Array.Clear(this.03033C30, this.77F16D84 + 1, 5A652501 - this.77F16D84 - 1);
			if (this.77F16D84 == 0)
			{
				this.03033C30[0] = this.45B43F98;
			}
		}
		this.77F16D84 = 5A652501 - 1;
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x001C0DD8 File Offset: 0x001BEBD8
	private void 68BF151E([Optional] int 4E980B28)
	{
		if (this.024F2731)
		{
			return;
		}
		uint[] destinationArray = new uint[this.77F16D84 + 1 + 4E980B28];
		Array.Copy(this.03033C30, destinationArray, this.77F16D84 + 1);
		this.03033C30 = destinationArray;
		this.024F2731 = true;
	}

	// Token: 0x060002DA RID: 730 RVA: 0x001C0E20 File Offset: 0x001BEC20
	private void 0AE03E2C(ref 032546EE 7CFC0A22, int 6F3A3D09)
	{
		if (7CFC0A22.77F16D84 == 0)
		{
			this.45B43F98 = 7CFC0A22.45B43F98;
			this.77F16D84 = 0;
			return;
		}
		if (!this.024F2731 || this.03033C30.Length <= 7CFC0A22.77F16D84)
		{
			this.03033C30 = new uint[7CFC0A22.77F16D84 + 1 + 6F3A3D09];
			this.024F2731 = true;
		}
		this.77F16D84 = 7CFC0A22.77F16D84;
		Array.Copy(7CFC0A22.03033C30, this.03033C30, this.77F16D84 + 1);
	}

	// Token: 0x060002DB RID: 731 RVA: 0x001C0EA4 File Offset: 0x001BECA4
	private void 170462F7(uint 344C64A1)
	{
		if (344C64A1 == 0U)
		{
			this.0F23555E(0U);
			return;
		}
		if (344C64A1 == 1U)
		{
			return;
		}
		if (this.77F16D84 == 0)
		{
			this.16D67F25((ulong)this.45B43F98 * (ulong)344C64A1);
			return;
		}
		this.68BF151E(1);
		uint num = 0U;
		for (int i = 0; i <= this.77F16D84; i++)
		{
			num = 032546EE.0050634C(ref this.03033C30[i], 344C64A1, num);
		}
		if (num != 0U)
		{
			this.07C07987(this.77F16D84 + 2, 0);
			this.03033C30[this.77F16D84] = num;
		}
	}

	// Token: 0x060002DC RID: 732 RVA: 0x001C0F28 File Offset: 0x001BED28
	internal void 2F9B5C6D(ref 032546EE 28B556F1, ref 032546EE 2FC441E3)
	{
		if (28B556F1.77F16D84 == 0)
		{
			if (2FC441E3.77F16D84 == 0)
			{
				this.16D67F25((ulong)28B556F1.45B43F98 * (ulong)2FC441E3.45B43F98);
				return;
			}
			this.0AE03E2C(ref 2FC441E3, 1);
			this.170462F7(28B556F1.45B43F98);
			return;
		}
		else
		{
			if (2FC441E3.77F16D84 == 0)
			{
				this.0AE03E2C(ref 28B556F1, 1);
				this.170462F7(2FC441E3.45B43F98);
				return;
			}
			this.09806E77(28B556F1.77F16D84 + 2FC441E3.77F16D84 + 2);
			uint[] array;
			int num;
			uint[] array2;
			int num2;
			if (28B556F1.103738E0 <= 2FC441E3.103738E0)
			{
				array = 28B556F1.03033C30;
				num = 28B556F1.77F16D84 + 1;
				array2 = 2FC441E3.03033C30;
				num2 = 2FC441E3.77F16D84 + 1;
			}
			else
			{
				array = 2FC441E3.03033C30;
				num = 2FC441E3.77F16D84 + 1;
				array2 = 28B556F1.03033C30;
				num2 = 28B556F1.77F16D84 + 1;
			}
			for (int i = 0; i < num; i++)
			{
				uint num3 = array[i];
				if (num3 != 0U)
				{
					uint num4 = 0U;
					int num5 = i;
					int j = 0;
					while (j < num2)
					{
						num4 = 032546EE.3AAE54B4(ref this.03033C30[num5], num3, array2[j], num4);
						j++;
						num5++;
					}
					while (num4 != 0U)
					{
						num4 = 032546EE.05BB1B77(ref this.03033C30[num5++], 0U, num4);
					}
				}
			}
			this.75BD5F8E();
			return;
		}
	}

	// Token: 0x060002DD RID: 733 RVA: 0x001C1070 File Offset: 0x001BEE70
	private static uint 712C26FD(ref 032546EE 203047FF, uint 465F700B)
	{
		if (465F700B == 1U)
		{
			return 0U;
		}
		if (203047FF.77F16D84 == 0)
		{
			return 203047FF.45B43F98 % 465F700B;
		}
		ulong num = 0UL;
		for (int i = 203047FF.77F16D84; i >= 0; i--)
		{
			num = 353B51DA.1EA114CC((uint)num, 203047FF.03033C30[i]);
			num %= (ulong)465F700B;
		}
		return (uint)num;
	}

	// Token: 0x060002DE RID: 734 RVA: 0x001C10C0 File Offset: 0x001BEEC0
	internal void 184D7F43(ref 032546EE 32116690)
	{
		if (32116690.77F16D84 == 0)
		{
			this.0F23555E(032546EE.712C26FD(ref this, 32116690.45B43F98));
			return;
		}
		if (this.77F16D84 == 0)
		{
			return;
		}
		032546EE 032546EE = default(032546EE);
		032546EE.001E690B(ref this, ref 32116690, false, ref 032546EE);
	}

	// Token: 0x060002DF RID: 735 RVA: 0x001C1104 File Offset: 0x001BEF04
	private static void 001E690B(ref 032546EE 724E4891, ref 032546EE 39C028FB, bool 76E34E96, ref 032546EE 06AE567F)
	{
		06AE567F.0F23555E(0U);
		if (724E4891.77F16D84 < 39C028FB.77F16D84)
		{
			return;
		}
		int num = 39C028FB.77F16D84 + 1;
		int num2 = 724E4891.77F16D84 - 39C028FB.77F16D84;
		int num3 = num2;
		int i = 724E4891.77F16D84;
		while (i >= num2)
		{
			if (39C028FB.03033C30[i - num2] != 724E4891.03033C30[i])
			{
				if (39C028FB.03033C30[i - num2] < 724E4891.03033C30[i])
				{
					num3++;
				}
				IL_7C:
				if (num3 == 0)
				{
					return;
				}
				if (76E34E96)
				{
					06AE567F.5DDE6A84(num3);
				}
				uint num4 = 39C028FB.03033C30[num - 1];
				uint num5 = 39C028FB.03033C30[num - 2];
				int num6 = 353B51DA.27811C05(num4);
				int num7 = 32 - num6;
				if (num6 > 0)
				{
					num4 = (num4 << num6 | num5 >> num7);
					num5 <<= num6;
					if (num > 2)
					{
						num5 |= 39C028FB.03033C30[num - 3] >> num7;
					}
				}
				724E4891.68BF151E(0);
				int num8 = num3;
				while (--num8 >= 0)
				{
					uint num9 = (num8 + num <= 724E4891.77F16D84) ? 724E4891.03033C30[num8 + num] : 0U;
					ulong num10 = 353B51DA.1EA114CC(num9, 724E4891.03033C30[num8 + num - 1]);
					uint num11 = 724E4891.03033C30[num8 + num - 2];
					if (num6 > 0)
					{
						num10 = (num10 << num6 | (ulong)(num11 >> num7));
						num11 <<= num6;
						if (num8 + num >= 3)
						{
							num11 |= 724E4891.03033C30[num8 + num - 3] >> num7;
						}
					}
					ulong num12 = num10 / (ulong)num4;
					ulong num13 = (ulong)((uint)(num10 % (ulong)num4));
					if (num12 > (ulong)-1)
					{
						num13 += (ulong)num4 * (num12 - (ulong)-1);
						num12 = (ulong)-1;
					}
					while (num13 <= (ulong)-1 && num12 * (ulong)num5 > 353B51DA.1EA114CC((uint)num13, num11))
					{
						num12 -= 1UL;
						num13 += (ulong)num4;
					}
					if (num12 > 0UL)
					{
						ulong num14 = 0UL;
						for (int j = 0; j < num; j++)
						{
							num14 += (ulong)39C028FB.03033C30[j] * num12;
							uint num15 = (uint)num14;
							num14 >>= 32;
							if (724E4891.03033C30[num8 + j] < num15)
							{
								num14 += 1UL;
							}
							724E4891.03033C30[num8 + j] -= num15;
						}
						if ((ulong)num9 < num14)
						{
							uint 4EE5419A = 0U;
							for (int k = 0; k < num; k++)
							{
								4EE5419A = 032546EE.05BB1B77(ref 724E4891.03033C30[num8 + k], 39C028FB.03033C30[k], 4EE5419A);
							}
							num12 -= 1UL;
						}
						724E4891.77F16D84 = num8 + num - 1;
					}
					if (76E34E96)
					{
						if (num3 == 1)
						{
							06AE567F.45B43F98 = (uint)num12;
						}
						else
						{
							06AE567F.03033C30[num8] = (uint)num12;
						}
					}
				}
				724E4891.77F16D84 = num - 1;
				724E4891.75BD5F8E();
				return;
			}
			else
			{
				i--;
			}
		}
		num3++;
		goto IL_7C;
	}

	// Token: 0x060002E0 RID: 736 RVA: 0x001C13CC File Offset: 0x001BF1CC
	private static uint 05BB1B77(ref uint 1DAD0774, uint 22974479, uint 4EE5419A)
	{
		ulong num = (ulong)1DAD0774 + (ulong)22974479 + (ulong)4EE5419A;
		1DAD0774 = (uint)num;
		return (uint)(num >> 32);
	}

	// Token: 0x060002E1 RID: 737 RVA: 0x001C13EC File Offset: 0x001BF1EC
	private static uint 0050634C(ref uint 4D0473DA, uint 09083D97, uint 501322D9)
	{
		ulong num = (ulong)4D0473DA * (ulong)09083D97 + (ulong)501322D9;
		4D0473DA = (uint)num;
		return (uint)(num >> 32);
	}

	// Token: 0x060002E2 RID: 738 RVA: 0x001C140C File Offset: 0x001BF20C
	private static uint 3AAE54B4(ref uint 7BC66D74, uint 127A26E5, uint 4A1B3E47, uint 0ACA22DE)
	{
		ulong num = (ulong)127A26E5 * (ulong)4A1B3E47 + (ulong)7BC66D74 + (ulong)0ACA22DE;
		7BC66D74 = (uint)num;
		return (uint)(num >> 32);
	}

	// Token: 0x0400017D RID: 381
	private const int 37BC2005 = 32;

	// Token: 0x0400017E RID: 382
	private int 77F16D84;

	// Token: 0x0400017F RID: 383
	private uint 45B43F98;

	// Token: 0x04000180 RID: 384
	private uint[] 03033C30;

	// Token: 0x04000181 RID: 385
	private bool 024F2731;
}
