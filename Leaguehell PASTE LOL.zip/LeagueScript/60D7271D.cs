﻿using System;
using System.IO;

// Token: 0x02000045 RID: 69
public class 60D7271D
{
	// Token: 0x06000300 RID: 768 RVA: 0x0030B698 File Offset: 0x00309298
	public void 5ECD3A65(uint 23DB4A0E)
	{
		if (this.290C1959 != 23DB4A0E)
		{
			this.360D44A0 = new byte[23DB4A0E];
		}
		this.290C1959 = 23DB4A0E;
		this.2A2D7A66 = 0U;
		this.05283747 = 0U;
	}

	// Token: 0x06000301 RID: 769 RVA: 0x0030B6C8 File Offset: 0x003092C8
	public void 79167C46(Stream 7AFF7BBE, bool 04393A50)
	{
		this.59DA5CE6();
		this.7D3A1F9D = 7AFF7BBE;
		if (!04393A50)
		{
			this.05283747 = 0U;
			this.2A2D7A66 = 0U;
			this.21913397 = 0U;
		}
	}

	// Token: 0x06000302 RID: 770 RVA: 0x0030B6F4 File Offset: 0x003092F4
	public void 59DA5CE6()
	{
		this.4CDA6C69();
		this.7D3A1F9D = null;
	}

	// Token: 0x06000303 RID: 771 RVA: 0x0030B704 File Offset: 0x00309304
	public void 4CDA6C69()
	{
		uint num = this.2A2D7A66 - this.05283747;
		if (num == 0U)
		{
			return;
		}
		this.7D3A1F9D.Write(this.360D44A0, (int)this.05283747, (int)num);
		if (this.2A2D7A66 >= this.290C1959)
		{
			this.2A2D7A66 = 0U;
		}
		this.05283747 = this.2A2D7A66;
	}

	// Token: 0x06000304 RID: 772 RVA: 0x0030B764 File Offset: 0x00309364
	public void 6F6A718C(uint 1A656049, uint 54A37C34)
	{
		uint num = this.2A2D7A66 - 1A656049 - 1U;
		if (num >= this.290C1959)
		{
			num += this.290C1959;
		}
		while (54A37C34 > 0U)
		{
			if (num >= this.290C1959)
			{
				num = 0U;
			}
			byte[] array = this.360D44A0;
			uint num2 = this.2A2D7A66;
			this.2A2D7A66 = num2 + 1U;
			array[(int)num2] = this.360D44A0[(int)num++];
			if (this.2A2D7A66 >= this.290C1959)
			{
				this.4CDA6C69();
			}
			54A37C34 -= 1U;
		}
	}

	// Token: 0x06000305 RID: 773 RVA: 0x0030B7EC File Offset: 0x003093EC
	public void 79266A07(byte 33960F60)
	{
		byte[] array = this.360D44A0;
		uint num = this.2A2D7A66;
		this.2A2D7A66 = num + 1U;
		array[(int)num] = 33960F60;
		if (this.2A2D7A66 >= this.290C1959)
		{
			this.4CDA6C69();
		}
	}

	// Token: 0x06000306 RID: 774 RVA: 0x0030B82C File Offset: 0x0030942C
	public byte 2B4A6AFD(uint 11A237AB)
	{
		uint num = this.2A2D7A66 - 11A237AB - 1U;
		if (num >= this.290C1959)
		{
			num += this.290C1959;
		}
		return this.360D44A0[(int)num];
	}

	// Token: 0x040001B0 RID: 432
	private byte[] 360D44A0;

	// Token: 0x040001B1 RID: 433
	private uint 2A2D7A66;

	// Token: 0x040001B2 RID: 434
	private uint 290C1959;

	// Token: 0x040001B3 RID: 435
	private uint 05283747;

	// Token: 0x040001B4 RID: 436
	private Stream 7D3A1F9D;

	// Token: 0x040001B5 RID: 437
	private uint 002A5A15 = 1U;

	// Token: 0x040001B6 RID: 438
	public uint 21913397;
}
