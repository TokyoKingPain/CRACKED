﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;

namespace LHSharp
{
	// Token: 0x02000023 RID: 35
	internal class InfoManager
	{
		// Token: 0x060001D6 RID: 470 RVA: 0x0000AA61 File Offset: 0x00008E61
		public InfoManager()
		{
			this.lastGateway = this.GetGatewayMAC();
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0000AA75 File Offset: 0x00008E75
		public void StartListener()
		{
			this.timer = new Timer(new TimerCallback(this.<StartListener>b__3_0), null, 5000, -1);
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x0000AA98 File Offset: 0x00008E98
		private void OnCallBack()
		{
			this.timer.Dispose();
			if (!(this.GetGatewayMAC() == this.lastGateway))
			{
				Constants.Breached = true;
				MessageBox.Show("ARP Cache poisoning has been detected!", OnProgramStart.Name, MessageBoxButton.OK, MessageBoxImage.Hand);
				Process.GetCurrentProcess().Kill();
			}
			else
			{
				this.lastGateway = this.GetGatewayMAC();
			}
			this.timer = new Timer(new TimerCallback(this.<OnCallBack>b__4_0), null, 5000, -1);
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x0000AB14 File Offset: 0x00008F14
		public static IPAddress GetDefaultGateway()
		{
			return (from a in (from n in NetworkInterface.GetAllNetworkInterfaces()
			where n.OperationalStatus == OperationalStatus.Up
			where n.NetworkInterfaceType != NetworkInterfaceType.Loopback
			select n).SelectMany(delegate(NetworkInterface n)
			{
				IPInterfaceProperties ipproperties = n.GetIPProperties();
				if (ipproperties == null)
				{
					return null;
				}
				return ipproperties.GatewayAddresses;
			}).Select(delegate(GatewayIPAddressInformation g)
			{
				if (g == null)
				{
					return null;
				}
				return g.Address;
			})
			where a != null
			select a).FirstOrDefault<IPAddress>();
		}

		// Token: 0x060001DA RID: 474 RVA: 0x0000ABE0 File Offset: 0x00008FE0
		private string GetArpTable()
		{
			string pathRoot = Path.GetPathRoot(Environment.SystemDirectory);
			string result;
			using (Process process = Process.Start(new ProcessStartInfo
			{
				FileName = pathRoot + "Windows\\System32\\arp.exe",
				Arguments = "-a",
				UseShellExecute = false,
				RedirectStandardOutput = true,
				CreateNoWindow = true
			}))
			{
				using (StreamReader standardOutput = process.StandardOutput)
				{
					result = standardOutput.ReadToEnd();
				}
			}
			return result;
		}

		// Token: 0x060001DB RID: 475 RVA: 0x0000AC78 File Offset: 0x00009078
		private string GetGatewayMAC()
		{
			string arg = InfoManager.GetDefaultGateway().ToString();
			return new Regex(string.Format("({0} [\\W]*) ([a-z0-9-]*)", arg)).Match(this.GetArpTable()).Groups[2].ToString();
		}

		// Token: 0x060001DC RID: 476 RVA: 0x0000ACBB File Offset: 0x000090BB
		private void <StartListener>b__3_0(object _)
		{
			this.OnCallBack();
		}

		// Token: 0x060001DD RID: 477 RVA: 0x0000ACC3 File Offset: 0x000090C3
		private void <OnCallBack>b__4_0(object _)
		{
			this.OnCallBack();
		}

		// Token: 0x04000113 RID: 275
		private Timer timer;

		// Token: 0x04000114 RID: 276
		private string lastGateway;
	}
}
