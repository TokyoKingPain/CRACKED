﻿using System;
using System.Runtime.CompilerServices;

namespace LHSharp
{
	// Token: 0x0200001E RID: 30
	internal class ApplicationSettings
	{
		// Token: 0x1700004D RID: 77
		// (get) Token: 0x060001A9 RID: 425 RVA: 0x00008BEF File Offset: 0x00006FEF
		// (set) Token: 0x060001AA RID: 426 RVA: 0x00008BF6 File Offset: 0x00006FF6
		public static bool Status { get; set; }

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x060001AB RID: 427 RVA: 0x00008BFE File Offset: 0x00006FFE
		// (set) Token: 0x060001AC RID: 428 RVA: 0x00008C05 File Offset: 0x00007005
		public static bool DeveloperMode { get; set; }

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x060001AD RID: 429 RVA: 0x00008C0D File Offset: 0x0000700D
		// (set) Token: 0x060001AE RID: 430 RVA: 0x00008C14 File Offset: 0x00007014
		public static string Hash { get; set; }

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x060001AF RID: 431 RVA: 0x00008C1C File Offset: 0x0000701C
		// (set) Token: 0x060001B0 RID: 432 RVA: 0x00008C23 File Offset: 0x00007023
		public static string Version { get; set; }

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060001B1 RID: 433 RVA: 0x00008C2B File Offset: 0x0000702B
		// (set) Token: 0x060001B2 RID: 434 RVA: 0x00008C32 File Offset: 0x00007032
		public static string Update_Link { get; set; }

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060001B3 RID: 435 RVA: 0x00008C3A File Offset: 0x0000703A
		// (set) Token: 0x060001B4 RID: 436 RVA: 0x00008C41 File Offset: 0x00007041
		public static bool Freemode { get; set; }

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x060001B5 RID: 437 RVA: 0x00008C49 File Offset: 0x00007049
		// (set) Token: 0x060001B6 RID: 438 RVA: 0x00008C50 File Offset: 0x00007050
		public static bool Login { get; set; }

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x060001B7 RID: 439 RVA: 0x00008C58 File Offset: 0x00007058
		// (set) Token: 0x060001B8 RID: 440 RVA: 0x00008C5F File Offset: 0x0000705F
		public static string Name { get; set; }

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x00008C67 File Offset: 0x00007067
		// (set) Token: 0x060001BA RID: 442 RVA: 0x00008C6E File Offset: 0x0000706E
		public static bool Register
		{
			[CompilerGenerated]
			get
			{
				return ApplicationSettings.<Register>k__BackingField;
			}
			set
			{
				ApplicationSettings.<Register>k__BackingField = value;
			}
		}
	}
}
