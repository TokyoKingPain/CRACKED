﻿using System;
using System.Collections.Generic;

namespace LHSharp
{
	// Token: 0x0200001B RID: 27
	internal class App
	{
		// Token: 0x06000183 RID: 387 RVA: 0x00008A04 File Offset: 0x00006E04
		public static string GrabVariable(string name)
		{
			string result;
			try
			{
				if (User.ID != null || User.HWID != null || User.IP != null || !Constants.Breached)
				{
					result = App.Variables[name];
				}
				else
				{
					Constants.Breached = true;
					result = "User is not logged in, possible breach detected!";
				}
			}
			catch
			{
				result = "N/A";
			}
			return result;
		}

		// Token: 0x040000EC RID: 236
		public static string Error = null;

		// Token: 0x040000ED RID: 237
		public static Dictionary<string, string> Variables = new Dictionary<string, string>();
	}
}
