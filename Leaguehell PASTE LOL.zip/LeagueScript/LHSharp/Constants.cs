﻿using System;
using System.Linq;
using System.Security.Principal;

namespace LHSharp
{
	// Token: 0x0200001C RID: 28
	internal class Constants
	{
		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000186 RID: 390 RVA: 0x00008A7E File Offset: 0x00006E7E
		// (set) Token: 0x06000187 RID: 391 RVA: 0x00008A85 File Offset: 0x00006E85
		public static string Token { get; set; }

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000188 RID: 392 RVA: 0x00008A8D File Offset: 0x00006E8D
		// (set) Token: 0x06000189 RID: 393 RVA: 0x00008A94 File Offset: 0x00006E94
		public static string Date { get; set; }

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600018A RID: 394 RVA: 0x00008A9C File Offset: 0x00006E9C
		// (set) Token: 0x0600018B RID: 395 RVA: 0x00008AA3 File Offset: 0x00006EA3
		public static string APIENCRYPTKEY { get; set; }

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600018C RID: 396 RVA: 0x00008AAB File Offset: 0x00006EAB
		// (set) Token: 0x0600018D RID: 397 RVA: 0x00008AB2 File Offset: 0x00006EB2
		public static string APIENCRYPTSALT { get; set; }

		// Token: 0x0600018E RID: 398 RVA: 0x00008ABA File Offset: 0x00006EBA
		public static string RandomString(int length)
		{
			return new string((from s in Enumerable.Repeat<string>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", length)
			select s[Constants.random.Next(s.Length)]).ToArray<char>());
		}

		// Token: 0x0600018F RID: 399 RVA: 0x00008AF5 File Offset: 0x00006EF5
		public static string HWID()
		{
			return WindowsIdentity.GetCurrent().User.Value;
		}

		// Token: 0x040000F2 RID: 242
		public static bool Breached = false;

		// Token: 0x040000F3 RID: 243
		public static bool Started = false;

		// Token: 0x040000F4 RID: 244
		public static string IV = null;

		// Token: 0x040000F5 RID: 245
		public static string Key = null;

		// Token: 0x040000F6 RID: 246
		public static string ApiUrl = "https://api.auth.gg/csharp/";

		// Token: 0x040000F7 RID: 247
		public static bool Initialized = false;

		// Token: 0x040000F8 RID: 248
		public static Random random = new Random();
	}
}
