﻿using System;

namespace LHSharp
{
	// Token: 0x0200001D RID: 29
	internal class User
	{
		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000192 RID: 402 RVA: 0x00008B42 File Offset: 0x00006F42
		// (set) Token: 0x06000193 RID: 403 RVA: 0x00008B49 File Offset: 0x00006F49
		public static string ID { get; set; }

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000194 RID: 404 RVA: 0x00008B51 File Offset: 0x00006F51
		// (set) Token: 0x06000195 RID: 405 RVA: 0x00008B58 File Offset: 0x00006F58
		public static string Username { get; set; }

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000196 RID: 406 RVA: 0x00008B60 File Offset: 0x00006F60
		// (set) Token: 0x06000197 RID: 407 RVA: 0x00008B67 File Offset: 0x00006F67
		public static string Password { get; set; }

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000198 RID: 408 RVA: 0x00008B6F File Offset: 0x00006F6F
		// (set) Token: 0x06000199 RID: 409 RVA: 0x00008B76 File Offset: 0x00006F76
		public static string Email { get; set; }

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x0600019A RID: 410 RVA: 0x00008B7E File Offset: 0x00006F7E
		// (set) Token: 0x0600019B RID: 411 RVA: 0x00008B85 File Offset: 0x00006F85
		public static string HWID { get; set; }

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x0600019C RID: 412 RVA: 0x00008B8D File Offset: 0x00006F8D
		// (set) Token: 0x0600019D RID: 413 RVA: 0x00008B94 File Offset: 0x00006F94
		public static string IP { get; set; }

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x0600019E RID: 414 RVA: 0x00008B9C File Offset: 0x00006F9C
		// (set) Token: 0x0600019F RID: 415 RVA: 0x00008BA3 File Offset: 0x00006FA3
		public static string UserVariable { get; set; }

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x00008BAB File Offset: 0x00006FAB
		// (set) Token: 0x060001A1 RID: 417 RVA: 0x00008BB2 File Offset: 0x00006FB2
		public static string Rank { get; set; }

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x060001A2 RID: 418 RVA: 0x00008BBA File Offset: 0x00006FBA
		// (set) Token: 0x060001A3 RID: 419 RVA: 0x00008BC1 File Offset: 0x00006FC1
		public static string Expiry { get; set; }

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x060001A4 RID: 420 RVA: 0x00008BC9 File Offset: 0x00006FC9
		// (set) Token: 0x060001A5 RID: 421 RVA: 0x00008BD0 File Offset: 0x00006FD0
		public static string LastLogin { get; set; }

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x060001A6 RID: 422 RVA: 0x00008BD8 File Offset: 0x00006FD8
		// (set) Token: 0x060001A7 RID: 423 RVA: 0x00008BDF File Offset: 0x00006FDF
		public static string RegisterDate { get; set; }
	}
}
