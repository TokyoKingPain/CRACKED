﻿using System;
using System.Windows.Forms;
using ValoBot;

namespace LHSharp
{
	// Token: 0x02000024 RID: 36
	internal static class Program
	{
		// Token: 0x060001DE RID: 478 RVA: 0x0000ACCB File Offset: 0x000090CB
		private static void Main()
		{
			OnProgramStart.Initialize("LHSharp", "361361", "Lxg4Mzv5gCv76LyI22uEUxnpHJiPptpbMfn", "1.0");
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form2());
		}
	}
}
