﻿namespace AmongUs
{
	// Token: 0x02000018 RID: 24
	public partial class Form3 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000171 RID: 369 RVA: 0x000070E4 File Offset: 0x000054E4
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000172 RID: 370 RVA: 0x00007104 File Offset: 0x00005504
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::AmongUs.Form3));
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.eliteButton6 = new global::eliteButton();
			this.eliteButton4 = new global::eliteButton();
			this.eliteGroupBox1 = new global::eliteGroupBox();
			this.eliteLabel3 = new global::eliteLabel();
			this.eliteButton7 = new global::eliteButton();
			this.eliteButton8 = new global::eliteButton();
			this.eliteButton9 = new global::eliteButton();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(12, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(129, 109);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			this.eliteButton6.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton6.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton6.Image = null;
			this.eliteButton6.Location = new global::System.Drawing.Point(23, 354);
			this.eliteButton6.Name = "eliteButton6";
			this.eliteButton6.NoRounding = false;
			this.eliteButton6.Size = new global::System.Drawing.Size(107, 38);
			this.eliteButton6.TabIndex = 40;
			this.eliteButton6.Text = "Exit";
			this.eliteButton6.Transparent = false;
			this.eliteButton6.Click += new global::System.EventHandler(this.eliteButton6_Click);
			this.eliteButton4.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton4.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton4.Image = null;
			this.eliteButton4.Location = new global::System.Drawing.Point(23, 310);
			this.eliteButton4.Name = "eliteButton4";
			this.eliteButton4.NoRounding = false;
			this.eliteButton4.Size = new global::System.Drawing.Size(107, 38);
			this.eliteButton4.TabIndex = 31;
			this.eliteButton4.Text = "UNLOAD";
			this.eliteButton4.Transparent = false;
			this.eliteButton4.Click += new global::System.EventHandler(this.eliteButton4_Click);
			this.eliteGroupBox1.Location = new global::System.Drawing.Point(12, 163);
			this.eliteGroupBox1.Name = "eliteGroupBox1";
			this.eliteGroupBox1.Size = new global::System.Drawing.Size(129, 238);
			this.eliteGroupBox1.TabIndex = 18;
			this.eliteLabel3.Customization = "/v7+/yoqKv8=";
			this.eliteLabel3.Font = new global::System.Drawing.Font("ZeF RAVE", 13f, global::System.Drawing.FontStyle.Italic);
			this.eliteLabel3.Image = null;
			this.eliteLabel3.Location = new global::System.Drawing.Point(12, 127);
			this.eliteLabel3.Name = "eliteLabel3";
			this.eliteLabel3.NoRounding = false;
			this.eliteLabel3.Size = new global::System.Drawing.Size(129, 30);
			this.eliteLabel3.TabIndex = 17;
			this.eliteLabel3.Text = "LeagueScript";
			this.eliteLabel3.Transparent = false;
			this.eliteButton7.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton7.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton7.Image = null;
			this.eliteButton7.Location = new global::System.Drawing.Point(23, 222);
			this.eliteButton7.Name = "eliteButton7";
			this.eliteButton7.NoRounding = false;
			this.eliteButton7.Size = new global::System.Drawing.Size(107, 38);
			this.eliteButton7.TabIndex = 88;
			this.eliteButton7.Text = "#2";
			this.eliteButton7.Transparent = false;
			this.eliteButton7.Click += new global::System.EventHandler(this.eliteButton7_Click);
			this.eliteButton8.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton8.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton8.Image = null;
			this.eliteButton8.Location = new global::System.Drawing.Point(23, 266);
			this.eliteButton8.Name = "eliteButton8";
			this.eliteButton8.NoRounding = false;
			this.eliteButton8.Size = new global::System.Drawing.Size(107, 38);
			this.eliteButton8.TabIndex = 89;
			this.eliteButton8.Text = "START";
			this.eliteButton8.Transparent = false;
			this.eliteButton8.Click += new global::System.EventHandler(this.eliteButton8_Click);
			this.eliteButton9.Customization = "Kioq/zIyMv8yMjL/Kioq/y8vL/8nJyf//v7+/yMjI/8qKir/";
			this.eliteButton9.Font = new global::System.Drawing.Font("Verdana", 8f);
			this.eliteButton9.Image = null;
			this.eliteButton9.Location = new global::System.Drawing.Point(23, 178);
			this.eliteButton9.Name = "eliteButton9";
			this.eliteButton9.NoRounding = false;
			this.eliteButton9.Size = new global::System.Drawing.Size(107, 38);
			this.eliteButton9.TabIndex = 90;
			this.eliteButton9.Text = "#1";
			this.eliteButton9.Transparent = false;
			this.eliteButton9.Click += new global::System.EventHandler(this.eliteButton9_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(42, 42, 42);
			base.ClientSize = new global::System.Drawing.Size(154, 410);
			base.Controls.Add(this.eliteButton9);
			base.Controls.Add(this.eliteButton8);
			base.Controls.Add(this.eliteButton7);
			base.Controls.Add(this.eliteButton6);
			base.Controls.Add(this.eliteButton4);
			base.Controls.Add(this.eliteGroupBox1);
			base.Controls.Add(this.eliteLabel3);
			base.Controls.Add(this.pictureBox1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "Form3";
			this.Text = "Main Area";
			base.TransparencyKey = global::System.Drawing.Color.Purple;
			base.Load += new global::System.EventHandler(this.Form3_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040000CB RID: 203
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040000CC RID: 204
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x040000CD RID: 205
		private global::eliteLabel eliteLabel3;

		// Token: 0x040000CE RID: 206
		private global::eliteGroupBox eliteGroupBox1;

		// Token: 0x040000CF RID: 207
		private global::eliteButton eliteButton4;

		// Token: 0x040000D0 RID: 208
		private global::eliteButton eliteButton6;

		// Token: 0x040000D1 RID: 209
		private global::eliteButton eliteButton7;

		// Token: 0x040000D2 RID: 210
		private global::eliteButton eliteButton8;

		// Token: 0x040000D3 RID: 211
		private global::eliteButton eliteButton9;
	}
}
