﻿using System;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x002FC004 File Offset: 0x002F9C04
	static <Module>()
	{
		new 467F5DB3().37F432DB(null, 1976960);
	}
}
