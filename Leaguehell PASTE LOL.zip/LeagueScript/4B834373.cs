﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000046 RID: 70
internal sealed class 4B834373
{
	// Token: 0x040001B7 RID: 439 RVA: 0x001D0D20 File Offset: 0x001CEB20
	internal static readonly 4B834373.207D0DA3 5F77771E;

	// Token: 0x040001B8 RID: 440 RVA: 0x001D0D40 File Offset: 0x001CEB40
	internal static readonly 4B834373.3CD06598 477E4113;

	// Token: 0x02000078 RID: 120
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 26)]
	private struct 207D0DA3
	{
	}

	// Token: 0x02000079 RID: 121
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 30)]
	private struct 3CD06598
	{
	}
}
