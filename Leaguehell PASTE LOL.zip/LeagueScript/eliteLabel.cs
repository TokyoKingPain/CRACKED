﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x0200000A RID: 10
internal class eliteLabel : ThemeControl154
{
	// Token: 0x0600011C RID: 284 RVA: 0x00005612 File Offset: 0x00003A12
	public eliteLabel()
	{
		base.SetColor("Text", 254, 254, 254);
		base.SetColor("Background", 42, 42, 42);
	}

	// Token: 0x0600011D RID: 285 RVA: 0x00005645 File Offset: 0x00003A45
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("Background");
		this.B1 = new SolidBrush(base.GetColor("Text"));
	}

	// Token: 0x0600011E RID: 286 RVA: 0x0000566E File Offset: 0x00003A6E
	protected override void PaintHook()
	{
		this.G.Clear(this.C1);
		base.DrawText(this.B1, HorizontalAlignment.Center, 0, 0);
	}

	// Token: 0x04000079 RID: 121
	private Color C1;

	// Token: 0x0400007A RID: 122
	private SolidBrush B1;
}
