﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// Token: 0x02000034 RID: 52
public class 6AD532EC
{
	// Token: 0x0600020C RID: 524 RVA: 0x002FC330 File Offset: 0x002F9F30
	public static bool 275F6092()
	{
		uint num = 366420344U;
		return (num ^ 366420345U) != 0U;
	}

	// Token: 0x0600020D RID: 525 RVA: 0x001E1270 File Offset: 0x001DF070
	public static bool 3B4B7A55(bool 62BE3862)
	{
		object[] 560004FE = new object[]
		{
			62BE3862
		};
		return (bool)new 467F5DB3().37F432DB(560004FE, 52246);
	}

	// Token: 0x0600020E RID: 526 RVA: 0x002FC34C File Offset: 0x002F9F4C
	public static bool 69000D55()
	{
		uint num = 893199558U;
		return (num ^ 893199558U) != 0U;
	}

	// Token: 0x0600020F RID: 527 RVA: 0x001E12A8 File Offset: 0x001DF0A8
	public static bool 344A14C2()
	{
		uint num = 1832873163U;
		IL_07:
		while (!5AA813B9.650334E1())
		{
			bool result;
			for (;;)
			{
				IL_1A:
				Type typeFromHandle = typeof(6AD532EC);
				num ^= 1331168893U;
				Module module = typeFromHandle.Module;
				num = 659253692U - num;
				IntPtr hinstance = Marshal.GetHINSTANCE(module);
				num = (1265392920U | num);
				IntPtr intPtr = hinstance;
				if (109272730U <= num)
				{
					goto IL_5A;
				}
				IL_A3:
				long num2 = (long)((ulong)1967408);
				num |= 848055960U;
				long num3 = num2;
				bool flag = (num ^ 933126075U) != 0U;
				num ^= 1096833015U;
				result = flag;
				byte[] array = new byte[num ^ 1996359745U];
				num = 308114909U - num;
				if (num * 1026110951U == 0U)
				{
					goto IL_07;
				}
				01557696 <<EMPTY_NAME>> = new 01557696();
				num = 272184082U * num;
				01557696 2 = <<EMPTY_NAME>>;
				num += 525954591U;
				if (1304259508U > num)
				{
					goto IL_07;
				}
				long num5;
				ulong num4 = num5;
				num = 36714909U >> (int)num;
				long value = num4 + (ulong)1966342;
				num = 1617787039U * num;
				int num6 = Marshal.ReadInt32(new IntPtr(value));
				num %= 945773956U;
				01557696 3 = 2;
				num = (442645422U | num);
				long num7 = num5;
				long num8 = num3;
				num = (1630493080U & num);
				long value2 = num7 + num8;
				num = (329332921U & num);
				uint num10;
				uint num9 = 3.4521524A(new IntPtr(value2), num10);
				num |= 485652002U;
				if (num6 != num9)
				{
					num = 2120819014U % num;
					result = (num - 178202270U != 0U);
					num ^= 376264756U;
				}
				51E33AD3 51E33AD = new 51E33AD3();
				num = (173479464U & num);
				51E33AD3 51E33AD2 = 51E33AD;
				int num11 = (int)(num + 4155369944U);
				num = 347960239U >> (int)num;
				int num12 = num11;
				for (;;)
				{
					num /= 531850041U;
					long num13 = num12;
					num = 1645219954U >> (int)num;
					long num14 = num13;
					num += 1923357734U;
					ulong num15 = (ulong)num10;
					num &= 1261462102U;
					if (num14 >= num15)
					{
						break;
					}
					long num16 = num5;
					num = 1996698325U;
					long num17 = num3;
					num = 406483106U / num;
					long num18 = num16 + num17;
					long num19 = (long)num12;
					num = 2122203031U >> (int)num;
					long num20 = num19;
					num = 1192691123U % num;
					long value3 = num18 + num20;
					num -= 228000334U;
					IntPtr source = new IntPtr(value3);
					byte[] destination = array;
					num = 596195246U + num;
					int startIndex = (int)(num ^ 1560886035U);
					num = (1105160127U & num);
					byte[] array2 = array;
					num = (665857889U & num);
					int length = array2.Length;
					num >>= 15;
					Marshal.Copy(source, destination, startIndex, length);
					51E33AD3 51E33AD3 = 51E33AD2;
					num = (487336897U & num);
					byte[] value4 = array;
					int startIndex2 = (int)(num - 512U);
					num <<= 31;
					uint 5A5C = BitConverter.ToUInt32(value4, startIndex2);
					num >>= 8;
					uint num21 = 51E33AD3.73DC7C62(5A5C);
					if ((num ^ 375799101U) == 0U)
					{
						goto IL_11;
					}
					51E33AD3 51E33AD4 = 51E33AD2;
					byte[] value5 = array;
					num |= 880700878U;
					int startIndex3 = (int)(num + 3414266422U);
					num = 1539510102U << (int)num;
					uint num22 = 51E33AD4.73DC7C62(BitConverter.ToUInt32(value5, startIndex3));
					num ^= 1825143592U;
					uint num23 = num22;
					num = (1060178528U ^ num);
					51E33AD3 51E33AD5 = 51E33AD2;
					num |= 965312273U;
					byte[] value6 = array;
					num ^= 1008215774U;
					int startIndex4 = (int)(num + 2051679873U);
					num = 164444029U + num;
					uint 5A5C2 = BitConverter.ToUInt32(value6, startIndex4);
					num %= 1924812602U;
					uint num24 = 51E33AD5.73DC7C62(5A5C2);
					01557696 4 = 2;
					num *= 292691697U;
					long value7 = num5 + (long)((ulong)num21);
					num /= 736378850U;
					IntPtr 75644D = new IntPtr(value7);
					uint 5D4E101F = num23;
					num -= 1500264365U;
					uint num25 = 4.4521524A(75644D, 5D4E101F);
					num = 724461525U % num;
					uint num26 = num24;
					num <<= 0;
					if (num25 != num26)
					{
						num = 1137974384U % num;
						result = ((num ^ 413512859U) != 0U);
						num += 310948666U;
					}
					int num27 = num12;
					int num28 = array.Length;
					num += 1850110360U;
					num12 = num27 + num28;
					num += 1721754630U;
				}
				long num29 = num5;
				long num30 = (long)((ulong)5AA813B9.4B57470D());
				num = (2083205013U | num);
				uint num31 = (uint)Marshal.ReadInt32(new IntPtr(num29 + num30));
				num = 1055152056U + num;
				num10 = num31;
				num |= 1078866831U;
				if (1594367803U % num == 0U)
				{
					goto IL_07;
				}
				ulong num32 = (ulong)5AA813B9.1DC70CA4();
				num += 1180328355U;
				num3 = (long)num32;
				if (num == 1101090198U)
				{
					goto IL_07;
				}
				long num33 = num5;
				ulong num34 = (ulong)5AA813B9.5F6B1B00();
				num &= 1586393338U;
				uint num35 = (uint)Marshal.ReadInt32(new IntPtr(num33 + (long)num34));
				01557696 5 = 2;
				num = 661285666U >> (int)num;
				long value8 = num5 + num3;
				num &= 481709540U;
				IntPtr 75644D2 = new IntPtr(value8);
				uint 5D4E101F2 = num10;
				num -= 1240024704U;
				if (num35 != 5.4521524A(75644D2, 5D4E101F2))
				{
					result = (num + 1240022208U != 0U);
					num ^= 0U;
				}
				num /= 934887389U;
				if (176164067U / num != 0U)
				{
					51E33AD3 51E33AD6 = new 51E33AD3();
					num |= 252529098U;
					51E33AD3 51E33AD7 = 51E33AD6;
					int num36 = (int)(num ^ 252529099U);
					while (num <= 2010450747U)
					{
						long num37 = num36;
						num = 932138665U % num;
						long num38 = num37;
						ulong num39 = (ulong)num10;
						num *= 503013095U;
						if (num38 >= num39)
						{
							goto Block_18;
						}
						num = 712516668U;
						long num40 = num5;
						num = 1114573520U + num;
						long num41 = num3;
						num |= 1989096656U;
						long num42 = num40 + num41;
						long num43 = (long)num36;
						num /= 317853476U;
						long value9 = num42 + num43;
						num = (797068978U | num);
						IntPtr source2 = new IntPtr(value9);
						num = 1863545952U + num;
						byte[] destination2 = array;
						int startIndex5 = (int)(num ^ 2660614934U);
						byte[] array3 = array;
						num ^= 1523350906U;
						int num44 = array3.Length;
						num ^= 1508463532U;
						Marshal.Copy(source2, destination2, startIndex5, num44);
						51E33AD3 51E33AD8 = 51E33AD7;
						byte[] value10 = array;
						int startIndex6 = (int)(num ^ 2645618112U);
						num -= 1695620369U;
						uint num45 = 51E33AD8.73DC7C62(BitConverter.ToUInt32(value10, startIndex6));
						num = 1343165553U * num;
						uint num46 = num45;
						if (1513629920U > num)
						{
							goto IL_5A;
						}
						51E33AD3 51E33AD9 = 51E33AD7;
						num = 1878269546U * num;
						uint 5A5C3 = BitConverter.ToUInt32(array, (int)(num ^ 55490066U));
						num = 999237467U << (int)num;
						uint num47 = 51E33AD9.73DC7C62(5A5C3);
						num %= 1534139950U;
						uint num48 = num47;
						num = 1887437552U / num;
						if (num == 1726041520U)
						{
							break;
						}
						51E33AD3 51E33AD10 = 51E33AD7;
						byte[] value11 = array;
						int startIndex7 = (int)(num ^ 11U);
						num |= 959543667U;
						uint num49 = 51E33AD10.73DC7C62(BitConverter.ToUInt32(value11, startIndex7));
						num %= 820451406U;
						uint num50 = num49;
						num = 586108794U + num;
						if (682718332U == num)
						{
							goto IL_1A;
						}
						01557696 6 = 2;
						num ^= 1238897493U;
						ulong num51 = num5;
						num = 422792595U / num;
						long value12 = num51 + (ulong)num46;
						num *= 1516645457U;
						IntPtr 75644D3 = new IntPtr(value12);
						uint 5D4E101F3 = num48;
						num = (1581663168U & num);
						uint num52 = 6.4521524A(75644D3, 5D4E101F3);
						num = (2048263341U | num);
						uint num53 = num50;
						num = 730743960U % num;
						if (num52 != num53)
						{
							num /= 1226198214U;
							bool flag2 = num - 0U != 0U;
							num <<= 30;
							result = flag2;
							num ^= 730743960U;
						}
						num = 1041129001U + num;
						if (56131102U >= num)
						{
							goto IL_5A;
						}
						int num54 = num36;
						byte[] array4 = array;
						num = 1131036210U / num;
						int num55 = array4.Length;
						num ^= 66716227U;
						num36 = num54 + num55;
						num ^= 217533320U;
					}
					goto IL_07;
				}
				goto IL_07;
				IL_5A:
				num5 = intPtr.ToInt64();
				if ((num ^ 45876534U) != 0U)
				{
					long num56 = num5;
					ulong num57 = 1966190UL;
					num ^= 634659417U;
					long value13 = num56 + (long)num57;
					num = 980105032U - num;
					num10 = (uint)Marshal.ReadInt32(new IntPtr(value13));
					num = 127015330U % num;
					goto IL_A3;
				}
				goto IL_07;
			}
			Block_18:
			num = 1180072157U + num;
			return result;
		}
		IL_11:
		return num - 1832873163U != 0U;
	}

	// Token: 0x06000210 RID: 528 RVA: 0x001E19B8 File Offset: 0x001DF7B8
	public static string 263E11FB()
	{
		return new 467F5DB3().37F432DB(null, 53789);
	}

	// Token: 0x06000211 RID: 529 RVA: 0x001E19D8 File Offset: 0x001DF7D8
	public static bool 79153687(ref string 754E6A32)
	{
		object[] array = new object[]
		{
			754E6A32
		};
		bool result;
		try
		{
			result = (bool)new 467F5DB3().37F432DB(array, 53010);
		}
		finally
		{
			754E6A32 = array[0];
		}
		return result;
	}

	// Token: 0x17000056 RID: 86
	// (get) Token: 0x06000212 RID: 530 RVA: 0x001BA82D File Offset: 0x001B862D
	// (set) Token: 0x06000213 RID: 531 RVA: 0x001BA835 File Offset: 0x001B8635
	public 75596968 1DCF52AC
	{
		[CompilerGenerated]
		get
		{
			return this.490438EE;
		}
		[CompilerGenerated]
		private set
		{
			this.490438EE = value;
		}
	}

	// Token: 0x17000057 RID: 87
	// (get) Token: 0x06000214 RID: 532 RVA: 0x001BA83E File Offset: 0x001B863E
	// (set) Token: 0x06000215 RID: 533 RVA: 0x001BA846 File Offset: 0x001B8646
	public 6A0710EF 63170D7F
	{
		[CompilerGenerated]
		get
		{
			return this.1ACA4098;
		}
		[CompilerGenerated]
		private set
		{
			this.1ACA4098 = value;
		}
	}

	// Token: 0x17000058 RID: 88
	// (get) Token: 0x06000216 RID: 534 RVA: 0x001BA84F File Offset: 0x001B864F
	// (set) Token: 0x06000217 RID: 535 RVA: 0x001BA857 File Offset: 0x001B8657
	public 1DB13DC8 013D7B51
	{
		[CompilerGenerated]
		get
		{
			return this.0C7C529B;
		}
		private set
		{
			this.0C7C529B = value;
		}
	}

	// Token: 0x06000218 RID: 536 RVA: 0x001E1A34 File Offset: 0x001DF834
	private static string 02357498(uint 0A90690C)
	{
		object[] 560004FE = new object[]
		{
			0A90690C
		};
		return new 467F5DB3().37F432DB(560004FE, 51561);
	}

	// Token: 0x06000219 RID: 537 RVA: 0x001BA872 File Offset: 0x001B8672
	public static void 0FBD5111(string 490D2360)
	{
		MessageBox.Show(490D2360, Assembly.GetExecutingAssembly().GetName().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
	}

	// Token: 0x0600021A RID: 538 RVA: 0x001E1A68 File Offset: 0x001DF868
	private static void 57BB1B01(object 1F555CDB)
	{
		object[] 560004FE = new object[]
		{
			1F555CDB
		};
		new 467F5DB3().37F432DB(560004FE, 46493);
	}

	// Token: 0x0600021B RID: 539 RVA: 0x001E1A98 File Offset: 0x001DF898
	public bool 65D33820(long 598D2757)
	{
		object[] 560004FE = new object[]
		{
			this,
			598D2757
		};
		return (bool)new 467F5DB3().37F432DB(560004FE, 54902);
	}

	// Token: 0x04000146 RID: 326
	public static readonly 6AD532EC 07480CBB = new 6AD532EC();

	// Token: 0x04000147 RID: 327
	private 75596968 490438EE;

	// Token: 0x04000148 RID: 328
	private 6A0710EF 1ACA4098;

	// Token: 0x04000149 RID: 329
	private 1DB13DC8 0C7C529B;
}
