﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000012 RID: 18
internal class eliteSeparatorHorizontal : ThemeControl154
{
	// Token: 0x06000138 RID: 312 RVA: 0x00006694 File Offset: 0x00004A94
	public eliteSeparatorHorizontal()
	{
		base.SetColor("DownGradient1", 42, 42, 42);
		base.SetColor("DownGradient2", 42, 42, 42);
		base.SetColor("Border1", 35, 35, 35);
		base.SetColor("Border2", 42, 42, 42);
	}

	// Token: 0x06000139 RID: 313 RVA: 0x000066EC File Offset: 0x00004AEC
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("DownGradient1");
		this.C2 = base.GetColor("DownGradient2");
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x0600013A RID: 314 RVA: 0x00006748 File Offset: 0x00004B48
	protected override void PaintHook()
	{
		base.DrawGradient(this.C1, this.C2, base.ClientRectangle, 90f);
		base.DrawBorders(this.P1, 1);
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x0600013B RID: 315 RVA: 0x00006797 File Offset: 0x00004B97
	protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
	{
		if ((specified & BoundsSpecified.Height) == BoundsSpecified.None || height == 4)
		{
			base.SetBoundsCore(x, y, width, 4, specified);
			return;
		}
	}

	// Token: 0x040000B8 RID: 184
	private Color C1;

	// Token: 0x040000B9 RID: 185
	private Color C2;

	// Token: 0x040000BA RID: 186
	private Pen P1;

	// Token: 0x040000BB RID: 187
	private Pen P2;
}
