﻿using System;
using System.Collections.Generic;

// Token: 0x02000004 RID: 4
internal static class ThemeShare
{
	// Token: 0x06000103 RID: 259 RVA: 0x00004EAC File Offset: 0x000032AC
	private static void HandleCallbacks(IntPtr state, bool reserve)
	{
		ThemeShare.Invalidate = (ThemeShare.Frames >= 50);
		if (ThemeShare.Invalidate)
		{
			ThemeShare.Frames = 0;
		}
		List<ThemeShare.AnimationDelegate> callbacks = ThemeShare.Callbacks;
		lock (callbacks)
		{
			for (int i = 0; i <= ThemeShare.Callbacks.Count - 1; i++)
			{
				ThemeShare.Callbacks[i](ThemeShare.Invalidate);
			}
		}
		ThemeShare.Frames += 10;
	}

	// Token: 0x06000104 RID: 260 RVA: 0x00004F3C File Offset: 0x0000333C
	private static void InvalidateThemeTimer()
	{
		if (ThemeShare.Callbacks.Count == 0)
		{
			ThemeShare.ThemeTimer.Delete();
			return;
		}
		ThemeShare.ThemeTimer.Create(0U, 10U, new PrecisionTimer.TimerDelegate(ThemeShare.HandleCallbacks));
	}

	// Token: 0x06000105 RID: 261 RVA: 0x00004F70 File Offset: 0x00003370
	public static void AddAnimationCallback(ThemeShare.AnimationDelegate callback)
	{
		List<ThemeShare.AnimationDelegate> callbacks = ThemeShare.Callbacks;
		lock (callbacks)
		{
			if (!ThemeShare.Callbacks.Contains(callback))
			{
				ThemeShare.Callbacks.Add(callback);
				ThemeShare.InvalidateThemeTimer();
			}
		}
	}

	// Token: 0x06000106 RID: 262 RVA: 0x00004FC8 File Offset: 0x000033C8
	public static void RemoveAnimationCallback(ThemeShare.AnimationDelegate callback)
	{
		List<ThemeShare.AnimationDelegate> callbacks = ThemeShare.Callbacks;
		lock (callbacks)
		{
			if (ThemeShare.Callbacks.Contains(callback))
			{
				ThemeShare.Callbacks.Remove(callback);
				ThemeShare.InvalidateThemeTimer();
			}
		}
	}

	// Token: 0x04000058 RID: 88
	private static int Frames;

	// Token: 0x04000059 RID: 89
	private static bool Invalidate;

	// Token: 0x0400005A RID: 90
	public static PrecisionTimer ThemeTimer = new PrecisionTimer();

	// Token: 0x0400005B RID: 91
	private const int FPS = 50;

	// Token: 0x0400005C RID: 92
	private const int Rate = 10;

	// Token: 0x0400005D RID: 93
	private static List<ThemeShare.AnimationDelegate> Callbacks = new List<ThemeShare.AnimationDelegate>();

	// Token: 0x02000025 RID: 37
	// (Invoke) Token: 0x060001E0 RID: 480
	public delegate void AnimationDelegate(bool invalidate);
}
