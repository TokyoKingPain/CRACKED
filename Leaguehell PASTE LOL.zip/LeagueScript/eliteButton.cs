﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000009 RID: 9
internal class eliteButton : ThemeControl154
{
	// Token: 0x06000119 RID: 281 RVA: 0x000053F4 File Offset: 0x000037F4
	public eliteButton()
	{
		base.SetColor("DownGradient1", 42, 42, 42);
		base.SetColor("DownGradient2", 50, 50, 50);
		base.SetColor("NoneGradient1", 50, 50, 50);
		base.SetColor("NoneGradient2", 42, 42, 42);
		base.SetColor("ClickedGradient1", 47, 47, 47);
		base.SetColor("ClickedGradient2", 39, 39, 39);
		base.SetColor("Text", 254, 254, 254);
		base.SetColor("Border1", 35, 35, 35);
		base.SetColor("Border2", 42, 42, 42);
	}

	// Token: 0x0600011A RID: 282 RVA: 0x000054AC File Offset: 0x000038AC
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("DownGradient1");
		this.C2 = base.GetColor("DownGradient2");
		this.C3 = base.GetColor("NoneGradient1");
		this.C4 = base.GetColor("NoneGradient2");
		this.C5 = base.GetColor("ClickedGradient1");
		this.C6 = base.GetColor("ClickedGradient2");
		this.B1 = new SolidBrush(base.GetColor("Text"));
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x0600011B RID: 283 RVA: 0x00005564 File Offset: 0x00003964
	protected override void PaintHook()
	{
		if (this.State == MouseState.Over)
		{
			base.DrawGradient(this.C1, this.C2, base.ClientRectangle, 90f);
		}
		else if (this.State == MouseState.Down)
		{
			base.DrawGradient(this.C6, this.C5, base.ClientRectangle, 90f);
		}
		else
		{
			base.DrawGradient(this.C3, this.C4, base.ClientRectangle, 90f);
		}
		base.DrawText(this.B1, HorizontalAlignment.Center, 0, 0);
		base.DrawBorders(this.P1, 1);
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x04000070 RID: 112
	private Color C1;

	// Token: 0x04000071 RID: 113
	private Color C2;

	// Token: 0x04000072 RID: 114
	private Color C3;

	// Token: 0x04000073 RID: 115
	private Color C4;

	// Token: 0x04000074 RID: 116
	private Color C5;

	// Token: 0x04000075 RID: 117
	private Color C6;

	// Token: 0x04000076 RID: 118
	private SolidBrush B1;

	// Token: 0x04000077 RID: 119
	private Pen P1;

	// Token: 0x04000078 RID: 120
	private Pen P2;
}
