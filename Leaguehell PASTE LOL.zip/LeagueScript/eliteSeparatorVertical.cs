﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000013 RID: 19
internal class eliteSeparatorVertical : ThemeControl154
{
	// Token: 0x0600013C RID: 316 RVA: 0x000067B4 File Offset: 0x00004BB4
	public eliteSeparatorVertical()
	{
		base.SetColor("DownGradient1", 42, 42, 42);
		base.SetColor("DownGradient2", 42, 42, 42);
		base.SetColor("Border1", 35, 35, 35);
		base.SetColor("Border2", 42, 42, 42);
	}

	// Token: 0x0600013D RID: 317 RVA: 0x0000680C File Offset: 0x00004C0C
	protected override void ColorHook()
	{
		this.C1 = base.GetColor("DownGradient1");
		this.C2 = base.GetColor("DownGradient2");
		this.P1 = new Pen(base.GetColor("Border1"));
		this.P2 = new Pen(base.GetColor("Border2"));
	}

	// Token: 0x0600013E RID: 318 RVA: 0x00006868 File Offset: 0x00004C68
	protected override void PaintHook()
	{
		base.DrawGradient(this.C1, this.C2, base.ClientRectangle, 90f);
		base.DrawBorders(this.P1, 1);
		base.DrawBorders(this.P2);
		base.DrawCorners(this.BackColor);
	}

	// Token: 0x0600013F RID: 319 RVA: 0x000068B7 File Offset: 0x00004CB7
	protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
	{
		if ((specified & BoundsSpecified.Width) == BoundsSpecified.None || width == 4)
		{
			base.SetBoundsCore(x, y, 4, height, specified);
			return;
		}
	}

	// Token: 0x040000BC RID: 188
	private Color C1;

	// Token: 0x040000BD RID: 189
	private Color C2;

	// Token: 0x040000BE RID: 190
	private Pen P1;

	// Token: 0x040000BF RID: 191
	private Pen P2;
}
