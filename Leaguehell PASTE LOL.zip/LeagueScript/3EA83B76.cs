﻿using System;
using System.IO;

// Token: 0x02000042 RID: 66
internal class 3EA83B76
{
	// Token: 0x060002F5 RID: 757 RVA: 0x0030B370 File Offset: 0x00308F70
	public void 4DB9499E(Stream 2DA3599B)
	{
		this.0FD9684F = 2DA3599B;
		this.77710334 = 0U;
		this.4550755C = uint.MaxValue;
		for (int i = 0; i < 5; i++)
		{
			this.77710334 = (this.77710334 << 8 | (uint)((byte)this.0FD9684F.ReadByte()));
		}
	}

	// Token: 0x060002F6 RID: 758 RVA: 0x0030B3C0 File Offset: 0x00308FC0
	public void 17D619A9()
	{
		this.0FD9684F = null;
	}

	// Token: 0x060002F7 RID: 759 RVA: 0x0030B3CC File Offset: 0x00308FCC
	public uint 782E7457(int 6A8E63D3)
	{
		uint num = this.4550755C;
		uint num2 = this.77710334;
		uint num3 = 0U;
		for (int i = 6A8E63D3; i > 0; i--)
		{
			num >>= 1;
			uint num4 = num2 - num >> 31;
			num2 -= (num & num4 - 1U);
			num3 = (num3 << 1 | 1U - num4);
			if (num < 16777216U)
			{
				num2 = (num2 << 8 | (uint)((byte)this.0FD9684F.ReadByte()));
				num <<= 8;
			}
		}
		this.4550755C = num;
		this.77710334 = num2;
		return num3;
	}

	// Token: 0x040001A5 RID: 421
	private uint 739811C1 = 1U;

	// Token: 0x040001A6 RID: 422
	public const uint 4E4B154E = 16777216U;

	// Token: 0x040001A7 RID: 423
	public uint 4550755C;

	// Token: 0x040001A8 RID: 424
	public uint 77710334;

	// Token: 0x040001A9 RID: 425
	public Stream 0FD9684F;
}
