﻿using System;

// Token: 0x02000030 RID: 48
public class 00542DE3
{
	// Token: 0x06000207 RID: 519 RVA: 0x002FC2A4 File Offset: 0x002F9EA4
	public static uint 5403126C(uint 05A63C64, int 519910D7)
	{
		uint num = 05A63C64 << 519910D7;
		uint num2 = 05A63C64 >> 32 - 519910D7;
		return num | num2;
	}

	// Token: 0x06000208 RID: 520 RVA: 0x002FC2C4 File Offset: 0x002F9EC4
	public static uint 4D4A6110(uint 14F747BC, int 23F25BF1)
	{
		uint num = 14F747BC >> 23F25BF1;
		uint num2 = 14F747BC << 32 - 23F25BF1;
		return num | num2;
	}

	// Token: 0x06000209 RID: 521 RVA: 0x002FC2E4 File Offset: 0x002F9EE4
	public static uint 248839F4(uint 0F7F5DE4)
	{
		uint num = 0F7F5DE4 & 16711935U;
		uint num2 = 0F7F5DE4 & 4278255360U;
		return (num >> 8 | num << 24) + (num2 << 8 | num2 >> 24);
	}

	// Token: 0x0400012A RID: 298
	public const int 047834A0 = 32;
}
