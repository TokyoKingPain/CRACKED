﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000015 RID: 21
public class eliteGroupBox : UserControl
{
	// Token: 0x0600014A RID: 330 RVA: 0x00006B8D File Offset: 0x00004F8D
	public eliteGroupBox()
	{
		this.InitializeComponent();
	}

	// Token: 0x0600014B RID: 331 RVA: 0x00006B9C File Offset: 0x00004F9C
	private void InitializeComponent()
	{
		this.panelMain = new GroupBox();
		base.SuspendLayout();
		Color backColor = Color.FromArgb(42, 42, 42);
		this.panelMain.BackColor = backColor;
		this.panelMain.Dock = DockStyle.Fill;
		this.panelMain.Location = new Point(0, 0);
		this.panelMain.Name = "eliteGroupBoxMain";
		this.panelMain.Size = new Size(140, 140);
		this.panelMain.TabIndex = 0;
		base.Controls.Add(this.panelMain);
		base.Name = "eliteGroupBox";
		base.ResumeLayout(false);
	}

	// Token: 0x040000C7 RID: 199
	private GroupBox panelMain;
}
