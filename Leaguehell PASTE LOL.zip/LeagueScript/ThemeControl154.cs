﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

// Token: 0x02000003 RID: 3
internal abstract class ThemeControl154 : Control
{
	// Token: 0x06000092 RID: 146 RVA: 0x00003C28 File Offset: 0x00002028
	public ThemeControl154()
	{
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		this._ImageSize = Size.Empty;
		this.Font = new Font("Verdana", 8f);
		this.MeasureBitmap = new Bitmap(1, 1);
		this.MeasureGraphics = Graphics.FromImage(this.MeasureBitmap);
		this.DrawRadialPath = new GraphicsPath();
		this.InvalidateCustimization();
	}

	// Token: 0x06000093 RID: 147 RVA: 0x00003CA4 File Offset: 0x000020A4
	protected sealed override void OnHandleCreated(EventArgs e)
	{
		this.InvalidateCustimization();
		this.ColorHook();
		if (this._LockWidth != 0)
		{
			base.Width = this._LockWidth;
		}
		if (this._LockHeight != 0)
		{
			base.Height = this._LockHeight;
		}
		this.Transparent = this._Transparent;
		if (this._Transparent && this._BackColor)
		{
			this.BackColor = Color.Transparent;
		}
		base.OnHandleCreated(e);
	}

	// Token: 0x06000094 RID: 148 RVA: 0x00003D13 File Offset: 0x00002113
	protected sealed override void OnParentChanged(EventArgs e)
	{
		if (base.Parent != null)
		{
			this.OnCreation();
			this.DoneCreation = true;
			this.InvalidateTimer();
		}
		base.OnParentChanged(e);
	}

	// Token: 0x06000095 RID: 149 RVA: 0x00003D37 File Offset: 0x00002137
	private void DoAnimation(bool i)
	{
		this.OnAnimation();
		if (i)
		{
			base.Invalidate();
		}
	}

	// Token: 0x06000096 RID: 150 RVA: 0x00003D48 File Offset: 0x00002148
	protected sealed override void OnPaint(PaintEventArgs e)
	{
		if (base.Width == 0 || base.Height == 0)
		{
			return;
		}
		if (this._Transparent)
		{
			this.PaintHook();
			e.Graphics.DrawImage(this.B, 0, 0);
			return;
		}
		this.G = e.Graphics;
		this.PaintHook();
	}

	// Token: 0x06000097 RID: 151 RVA: 0x00003D9A File Offset: 0x0000219A
	protected override void OnHandleDestroyed(EventArgs e)
	{
		ThemeShare.RemoveAnimationCallback(new ThemeShare.AnimationDelegate(this.DoAnimation));
		base.OnHandleDestroyed(e);
	}

	// Token: 0x06000098 RID: 152 RVA: 0x00003DB4 File Offset: 0x000021B4
	protected sealed override void OnSizeChanged(EventArgs e)
	{
		if (this._Transparent)
		{
			this.InvalidateBitmap();
		}
		base.Invalidate();
		base.OnSizeChanged(e);
	}

	// Token: 0x06000099 RID: 153 RVA: 0x00003DD1 File Offset: 0x000021D1
	protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
	{
		if (this._LockWidth != 0)
		{
			width = this._LockWidth;
		}
		if (this._LockHeight != 0)
		{
			height = this._LockHeight;
		}
		base.SetBoundsCore(x, y, width, height, specified);
	}

	// Token: 0x0600009A RID: 154 RVA: 0x00003E00 File Offset: 0x00002200
	protected override void OnMouseEnter(EventArgs e)
	{
		this.InPosition = true;
		this.SetState(MouseState.Over);
		base.OnMouseEnter(e);
	}

	// Token: 0x0600009B RID: 155 RVA: 0x00003E17 File Offset: 0x00002217
	protected override void OnMouseUp(MouseEventArgs e)
	{
		if (this.InPosition)
		{
			this.SetState(MouseState.Over);
		}
		base.OnMouseUp(e);
	}

	// Token: 0x0600009C RID: 156 RVA: 0x00003E2F File Offset: 0x0000222F
	protected override void OnMouseDown(MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.SetState(MouseState.Down);
		}
		base.OnMouseDown(e);
	}

	// Token: 0x0600009D RID: 157 RVA: 0x00003E4C File Offset: 0x0000224C
	protected override void OnMouseLeave(EventArgs e)
	{
		this.InPosition = false;
		this.SetState(MouseState.None);
		base.OnMouseLeave(e);
	}

	// Token: 0x0600009E RID: 158 RVA: 0x00003E63 File Offset: 0x00002263
	protected override void OnEnabledChanged(EventArgs e)
	{
		if (base.Enabled)
		{
			this.SetState(MouseState.None);
		}
		else
		{
			this.SetState(MouseState.Block);
		}
		base.OnEnabledChanged(e);
	}

	// Token: 0x0600009F RID: 159 RVA: 0x00003E84 File Offset: 0x00002284
	private void SetState(MouseState current)
	{
		this.State = current;
		base.Invalidate();
	}

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x060000A0 RID: 160 RVA: 0x00003E93 File Offset: 0x00002293
	// (set) Token: 0x060000A1 RID: 161 RVA: 0x00003E9A File Offset: 0x0000229A
	[Browsable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public override Color ForeColor
	{
		get
		{
			return Color.Empty;
		}
		set
		{
		}
	}

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x060000A2 RID: 162 RVA: 0x00003E9C File Offset: 0x0000229C
	// (set) Token: 0x060000A3 RID: 163 RVA: 0x00003E9F File Offset: 0x0000229F
	[Browsable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public override Image BackgroundImage
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x060000A4 RID: 164 RVA: 0x00003EA1 File Offset: 0x000022A1
	// (set) Token: 0x060000A5 RID: 165 RVA: 0x00003EA4 File Offset: 0x000022A4
	[Browsable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public override ImageLayout BackgroundImageLayout
	{
		get
		{
			return ImageLayout.None;
		}
		set
		{
		}
	}

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x060000A6 RID: 166 RVA: 0x00003EA6 File Offset: 0x000022A6
	// (set) Token: 0x060000A7 RID: 167 RVA: 0x00003EAE File Offset: 0x000022AE
	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x060000A8 RID: 168 RVA: 0x00003EBD File Offset: 0x000022BD
	// (set) Token: 0x060000A9 RID: 169 RVA: 0x00003EC5 File Offset: 0x000022C5
	public override Font Font
	{
		get
		{
			return base.Font;
		}
		set
		{
			base.Font = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x060000AA RID: 170 RVA: 0x00003ED4 File Offset: 0x000022D4
	// (set) Token: 0x060000AB RID: 171 RVA: 0x00003EDC File Offset: 0x000022DC
	[Category("Misc")]
	public override Color BackColor
	{
		get
		{
			return base.BackColor;
		}
		set
		{
			if (!base.IsHandleCreated && value == Color.Transparent)
			{
				this._BackColor = true;
				return;
			}
			base.BackColor = value;
			if (base.Parent != null)
			{
				this.ColorHook();
			}
		}
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x060000AC RID: 172 RVA: 0x00003F10 File Offset: 0x00002310
	// (set) Token: 0x060000AD RID: 173 RVA: 0x00003F18 File Offset: 0x00002318
	public bool NoRounding
	{
		get
		{
			return this._NoRounding;
		}
		set
		{
			this._NoRounding = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x060000AE RID: 174 RVA: 0x00003F27 File Offset: 0x00002327
	// (set) Token: 0x060000AF RID: 175 RVA: 0x00003F2F File Offset: 0x0000232F
	public Image Image
	{
		get
		{
			return this._Image;
		}
		set
		{
			if (value == null)
			{
				this._ImageSize = Size.Empty;
			}
			else
			{
				this._ImageSize = value.Size;
			}
			this._Image = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x060000B0 RID: 176 RVA: 0x00003F5A File Offset: 0x0000235A
	// (set) Token: 0x060000B1 RID: 177 RVA: 0x00003F64 File Offset: 0x00002364
	public bool Transparent
	{
		get
		{
			return this._Transparent;
		}
		set
		{
			this._Transparent = value;
			if (!base.IsHandleCreated)
			{
				return;
			}
			if (!value && this.BackColor.A != 255)
			{
				throw new Exception("Unable to change value to false while a transparent BackColor is in use.");
			}
			base.SetStyle(ControlStyles.Opaque, !value);
			base.SetStyle(ControlStyles.SupportsTransparentBackColor, value);
			if (value)
			{
				this.InvalidateBitmap();
			}
			else
			{
				this.B = null;
			}
			base.Invalidate();
		}
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x060000B2 RID: 178 RVA: 0x00003FD4 File Offset: 0x000023D4
	// (set) Token: 0x060000B3 RID: 179 RVA: 0x00004030 File Offset: 0x00002430
	public Bloom[] Colors
	{
		get
		{
			List<Bloom> list = new List<Bloom>();
			Dictionary<string, Color>.Enumerator enumerator = this.Items.GetEnumerator();
			while (enumerator.MoveNext())
			{
				List<Bloom> list2 = list;
				KeyValuePair<string, Color> keyValuePair = enumerator.Current;
				string key = keyValuePair.Key;
				keyValuePair = enumerator.Current;
				list2.Add(new Bloom(key, keyValuePair.Value));
			}
			return list.ToArray();
		}
		set
		{
			for (int i = 0; i < value.Length; i++)
			{
				Bloom bloom = value[i];
				if (this.Items.ContainsKey(bloom.Name))
				{
					this.Items[bloom.Name] = bloom.Value;
				}
			}
			this.InvalidateCustimization();
			this.ColorHook();
			base.Invalidate();
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x060000B4 RID: 180 RVA: 0x00004094 File Offset: 0x00002494
	// (set) Token: 0x060000B5 RID: 181 RVA: 0x0000409C File Offset: 0x0000249C
	public string Customization
	{
		get
		{
			return this._Customization;
		}
		set
		{
			if (value == this._Customization)
			{
				return;
			}
			Bloom[] colors = this.Colors;
			try
			{
				byte[] value2 = Convert.FromBase64String(value);
				for (int i = 0; i <= colors.Length - 1; i++)
				{
					colors[i].Value = Color.FromArgb(BitConverter.ToInt32(value2, i * 4));
				}
			}
			catch
			{
				return;
			}
			this._Customization = value;
			this.Colors = colors;
			this.ColorHook();
			base.Invalidate();
		}
	}

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x060000B6 RID: 182 RVA: 0x00004124 File Offset: 0x00002524
	protected Size ImageSize
	{
		get
		{
			return this._ImageSize;
		}
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x060000B7 RID: 183 RVA: 0x0000412C File Offset: 0x0000252C
	// (set) Token: 0x060000B8 RID: 184 RVA: 0x00004134 File Offset: 0x00002534
	protected int LockWidth
	{
		get
		{
			return this._LockWidth;
		}
		set
		{
			this._LockWidth = value;
			if (this.LockWidth != 0 && base.IsHandleCreated)
			{
				base.Width = this.LockWidth;
			}
		}
	}

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x060000B9 RID: 185 RVA: 0x00004159 File Offset: 0x00002559
	// (set) Token: 0x060000BA RID: 186 RVA: 0x00004161 File Offset: 0x00002561
	protected int LockHeight
	{
		get
		{
			return this._LockHeight;
		}
		set
		{
			this._LockHeight = value;
			if (this.LockHeight != 0 && base.IsHandleCreated)
			{
				base.Height = this.LockHeight;
			}
		}
	}

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x060000BB RID: 187 RVA: 0x00004186 File Offset: 0x00002586
	// (set) Token: 0x060000BC RID: 188 RVA: 0x0000418E File Offset: 0x0000258E
	protected bool IsAnimated
	{
		get
		{
			return this._IsAnimated;
		}
		set
		{
			this._IsAnimated = value;
			this.InvalidateTimer();
		}
	}

	// Token: 0x060000BD RID: 189 RVA: 0x0000419D File Offset: 0x0000259D
	protected Pen GetPen(string name)
	{
		return new Pen(this.Items[name]);
	}

	// Token: 0x060000BE RID: 190 RVA: 0x000041B0 File Offset: 0x000025B0
	protected Pen GetPen(string name, float width)
	{
		return new Pen(this.Items[name], width);
	}

	// Token: 0x060000BF RID: 191 RVA: 0x000041C4 File Offset: 0x000025C4
	protected SolidBrush GetBrush(string name)
	{
		return new SolidBrush(this.Items[name]);
	}

	// Token: 0x060000C0 RID: 192 RVA: 0x000041D7 File Offset: 0x000025D7
	protected Color GetColor(string name)
	{
		return this.Items[name];
	}

	// Token: 0x060000C1 RID: 193 RVA: 0x000041E5 File Offset: 0x000025E5
	protected void SetColor(string name, Color value)
	{
		if (this.Items.ContainsKey(name))
		{
			this.Items[name] = value;
			return;
		}
		this.Items.Add(name, value);
	}

	// Token: 0x060000C2 RID: 194 RVA: 0x00004210 File Offset: 0x00002610
	protected void SetColor(string name, byte r, byte g, byte b)
	{
		this.SetColor(name, Color.FromArgb((int)r, (int)g, (int)b));
	}

	// Token: 0x060000C3 RID: 195 RVA: 0x00004222 File Offset: 0x00002622
	protected void SetColor(string name, byte a, byte r, byte g, byte b)
	{
		this.SetColor(name, Color.FromArgb((int)a, (int)r, (int)g, (int)b));
	}

	// Token: 0x060000C4 RID: 196 RVA: 0x00004236 File Offset: 0x00002636
	protected void SetColor(string name, byte a, Color value)
	{
		this.SetColor(name, Color.FromArgb((int)a, value));
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x00004246 File Offset: 0x00002646
	private void InvalidateBitmap()
	{
		if (base.Width == 0 || base.Height == 0)
		{
			return;
		}
		this.B = new Bitmap(base.Width, base.Height, PixelFormat.Format32bppPArgb);
		this.G = Graphics.FromImage(this.B);
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x00004288 File Offset: 0x00002688
	private void InvalidateCustimization()
	{
		MemoryStream memoryStream = new MemoryStream(this.Items.Count * 4);
		foreach (Bloom bloom in this.Colors)
		{
			memoryStream.Write(BitConverter.GetBytes(bloom.Value.ToArgb()), 0, 4);
		}
		memoryStream.Close();
		this._Customization = Convert.ToBase64String(memoryStream.ToArray());
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x000042F9 File Offset: 0x000026F9
	private void InvalidateTimer()
	{
		if (base.DesignMode || !this.DoneCreation)
		{
			return;
		}
		if (this._IsAnimated)
		{
			ThemeShare.AddAnimationCallback(new ThemeShare.AnimationDelegate(this.DoAnimation));
			return;
		}
		ThemeShare.RemoveAnimationCallback(new ThemeShare.AnimationDelegate(this.DoAnimation));
	}

	// Token: 0x060000C8 RID: 200
	protected abstract void ColorHook();

	// Token: 0x060000C9 RID: 201
	protected abstract void PaintHook();

	// Token: 0x060000CA RID: 202 RVA: 0x00004337 File Offset: 0x00002737
	protected virtual void OnCreation()
	{
	}

	// Token: 0x060000CB RID: 203 RVA: 0x00004339 File Offset: 0x00002739
	protected virtual void OnAnimation()
	{
	}

	// Token: 0x060000CC RID: 204 RVA: 0x0000433B File Offset: 0x0000273B
	protected Rectangle Offset(Rectangle r, int amount)
	{
		this.OffsetReturnRectangle = new Rectangle(r.X + amount, r.Y + amount, r.Width - amount * 2, r.Height - amount * 2);
		return this.OffsetReturnRectangle;
	}

	// Token: 0x060000CD RID: 205 RVA: 0x00004376 File Offset: 0x00002776
	protected Size Offset(Size s, int amount)
	{
		this.OffsetReturnSize = new Size(s.Width + amount, s.Height + amount);
		return this.OffsetReturnSize;
	}

	// Token: 0x060000CE RID: 206 RVA: 0x0000439B File Offset: 0x0000279B
	protected Point Offset(Point p, int amount)
	{
		this.OffsetReturnPoint = new Point(p.X + amount, p.Y + amount);
		return this.OffsetReturnPoint;
	}

	// Token: 0x060000CF RID: 207 RVA: 0x000043C0 File Offset: 0x000027C0
	protected Point Center(Rectangle p, Rectangle c)
	{
		this.CenterReturn = new Point(p.Width / 2 - c.Width / 2 + p.X + c.X, p.Height / 2 - c.Height / 2 + p.Y + c.Y);
		return this.CenterReturn;
	}

	// Token: 0x060000D0 RID: 208 RVA: 0x00004424 File Offset: 0x00002824
	protected Point Center(Rectangle p, Size c)
	{
		this.CenterReturn = new Point(p.Width / 2 - c.Width / 2 + p.X, p.Height / 2 - c.Height / 2 + p.Y);
		return this.CenterReturn;
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x00004478 File Offset: 0x00002878
	protected Point Center(Rectangle child)
	{
		return this.Center(base.Width, base.Height, child.Width, child.Height);
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x0000449A File Offset: 0x0000289A
	protected Point Center(Size child)
	{
		return this.Center(base.Width, base.Height, child.Width, child.Height);
	}

	// Token: 0x060000D3 RID: 211 RVA: 0x000044BC File Offset: 0x000028BC
	protected Point Center(int childWidth, int childHeight)
	{
		return this.Center(base.Width, base.Height, childWidth, childHeight);
	}

	// Token: 0x060000D4 RID: 212 RVA: 0x000044D2 File Offset: 0x000028D2
	protected Point Center(Size p, Size c)
	{
		return this.Center(p.Width, p.Height, c.Width, c.Height);
	}

	// Token: 0x060000D5 RID: 213 RVA: 0x000044F6 File Offset: 0x000028F6
	protected Point Center(int pWidth, int pHeight, int cWidth, int cHeight)
	{
		this.CenterReturn = new Point(pWidth / 2 - cWidth / 2, pHeight / 2 - cHeight / 2);
		return this.CenterReturn;
	}

	// Token: 0x060000D6 RID: 214 RVA: 0x00004518 File Offset: 0x00002918
	protected Size Measure()
	{
		return this.MeasureGraphics.MeasureString(this.Text, this.Font, base.Width).ToSize();
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x0000454C File Offset: 0x0000294C
	protected Size Measure(string text)
	{
		return this.MeasureGraphics.MeasureString(text, this.Font, base.Width).ToSize();
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x00004579 File Offset: 0x00002979
	protected void DrawPixel(Color c1, int x, int y)
	{
		if (this._Transparent)
		{
			this.B.SetPixel(x, y, c1);
			return;
		}
		this.DrawPixelBrush = new SolidBrush(c1);
		this.G.FillRectangle(this.DrawPixelBrush, x, y, 1, 1);
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x000045B3 File Offset: 0x000029B3
	protected void DrawCorners(Color c1, int offset)
	{
		this.DrawCorners(c1, 0, 0, base.Width, base.Height, offset);
	}

	// Token: 0x060000DA RID: 218 RVA: 0x000045CB File Offset: 0x000029CB
	protected void DrawCorners(Color c1, Rectangle r1, int offset)
	{
		this.DrawCorners(c1, r1.X, r1.Y, r1.Width, r1.Height, offset);
	}

	// Token: 0x060000DB RID: 219 RVA: 0x000045F1 File Offset: 0x000029F1
	protected void DrawCorners(Color c1, int x, int y, int width, int height, int offset)
	{
		this.DrawCorners(c1, x + offset, y + offset, width - offset * 2, height - offset * 2);
	}

	// Token: 0x060000DC RID: 220 RVA: 0x00004610 File Offset: 0x00002A10
	protected void DrawCorners(Color c1)
	{
		this.DrawCorners(c1, 0, 0, base.Width, base.Height);
	}

	// Token: 0x060000DD RID: 221 RVA: 0x00004627 File Offset: 0x00002A27
	protected void DrawCorners(Color c1, Rectangle r1)
	{
		this.DrawCorners(c1, r1.X, r1.Y, r1.Width, r1.Height);
	}

	// Token: 0x060000DE RID: 222 RVA: 0x0000464C File Offset: 0x00002A4C
	protected void DrawCorners(Color c1, int x, int y, int width, int height)
	{
		if (this._NoRounding)
		{
			return;
		}
		if (this._Transparent)
		{
			this.B.SetPixel(x, y, c1);
			this.B.SetPixel(x + (width - 1), y, c1);
			this.B.SetPixel(x, y + (height - 1), c1);
			this.B.SetPixel(x + (width - 1), y + (height - 1), c1);
			return;
		}
		this.DrawCornersBrush = new SolidBrush(c1);
		this.G.FillRectangle(this.DrawCornersBrush, x, y, 1, 1);
		this.G.FillRectangle(this.DrawCornersBrush, x + (width - 1), y, 1, 1);
		this.G.FillRectangle(this.DrawCornersBrush, x, y + (height - 1), 1, 1);
		this.G.FillRectangle(this.DrawCornersBrush, x + (width - 1), y + (height - 1), 1, 1);
	}

	// Token: 0x060000DF RID: 223 RVA: 0x0000472B File Offset: 0x00002B2B
	protected void DrawBorders(Pen p1, int offset)
	{
		this.DrawBorders(p1, 0, 0, base.Width, base.Height, offset);
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x00004743 File Offset: 0x00002B43
	protected void DrawBorders(Pen p1, Rectangle r, int offset)
	{
		this.DrawBorders(p1, r.X, r.Y, r.Width, r.Height, offset);
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x00004769 File Offset: 0x00002B69
	protected void DrawBorders(Pen p1, int x, int y, int width, int height, int offset)
	{
		this.DrawBorders(p1, x + offset, y + offset, width - offset * 2, height - offset * 2);
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x00004788 File Offset: 0x00002B88
	protected void DrawBorders(Pen p1)
	{
		this.DrawBorders(p1, 0, 0, base.Width, base.Height);
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x0000479F File Offset: 0x00002B9F
	protected void DrawBorders(Pen p1, Rectangle r)
	{
		this.DrawBorders(p1, r.X, r.Y, r.Width, r.Height);
	}

	// Token: 0x060000E4 RID: 228 RVA: 0x000047C4 File Offset: 0x00002BC4
	protected void DrawBorders(Pen p1, int x, int y, int width, int height)
	{
		this.G.DrawRectangle(p1, x, y, width - 1, height - 1);
	}

	// Token: 0x060000E5 RID: 229 RVA: 0x000047DC File Offset: 0x00002BDC
	protected void DrawText(Brush b1, HorizontalAlignment a, int x, int y)
	{
		this.DrawText(b1, this.Text, a, x, y);
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x000047F0 File Offset: 0x00002BF0
	protected void DrawText(Brush b1, string text, HorizontalAlignment a, int x, int y)
	{
		if (text.Length == 0)
		{
			return;
		}
		this.DrawTextSize = this.Measure(text);
		this.DrawTextPoint = this.Center(this.DrawTextSize);
		switch (a)
		{
		case HorizontalAlignment.Left:
			this.G.DrawString(text, this.Font, b1, (float)x, (float)(this.DrawTextPoint.Y + y));
			return;
		case HorizontalAlignment.Right:
			this.G.DrawString(text, this.Font, b1, (float)(base.Width - this.DrawTextSize.Width - x), (float)(this.DrawTextPoint.Y + y));
			return;
		case HorizontalAlignment.Center:
			this.G.DrawString(text, this.Font, b1, (float)(this.DrawTextPoint.X + x), (float)(this.DrawTextPoint.Y + y));
			return;
		default:
			return;
		}
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x000048C8 File Offset: 0x00002CC8
	protected void DrawText(Brush b1, Point p1)
	{
		if (this.Text.Length == 0)
		{
			return;
		}
		this.G.DrawString(this.Text, this.Font, b1, p1);
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x000048F6 File Offset: 0x00002CF6
	protected void DrawText(Brush b1, int x, int y)
	{
		if (this.Text.Length == 0)
		{
			return;
		}
		this.G.DrawString(this.Text, this.Font, b1, (float)x, (float)y);
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x00004922 File Offset: 0x00002D22
	protected void DrawImage(HorizontalAlignment a, int x, int y)
	{
		this.DrawImage(this._Image, a, x, y);
	}

	// Token: 0x060000EA RID: 234 RVA: 0x00004934 File Offset: 0x00002D34
	protected void DrawImage(Image image, HorizontalAlignment a, int x, int y)
	{
		if (image == null)
		{
			return;
		}
		this.DrawImagePoint = this.Center(image.Size);
		switch (a)
		{
		case HorizontalAlignment.Left:
			this.G.DrawImage(image, x, this.DrawImagePoint.Y + y, image.Width, image.Height);
			return;
		case HorizontalAlignment.Right:
			this.G.DrawImage(image, base.Width - image.Width - x, this.DrawImagePoint.Y + y, image.Width, image.Height);
			return;
		case HorizontalAlignment.Center:
			this.G.DrawImage(image, this.DrawImagePoint.X + x, this.DrawImagePoint.Y + y, image.Width, image.Height);
			return;
		default:
			return;
		}
	}

	// Token: 0x060000EB RID: 235 RVA: 0x000049FB File Offset: 0x00002DFB
	protected void DrawImage(Point p1)
	{
		this.DrawImage(this._Image, p1.X, p1.Y);
	}

	// Token: 0x060000EC RID: 236 RVA: 0x00004A17 File Offset: 0x00002E17
	protected void DrawImage(int x, int y)
	{
		this.DrawImage(this._Image, x, y);
	}

	// Token: 0x060000ED RID: 237 RVA: 0x00004A27 File Offset: 0x00002E27
	protected void DrawImage(Image image, Point p1)
	{
		this.DrawImage(image, p1.X, p1.Y);
	}

	// Token: 0x060000EE RID: 238 RVA: 0x00004A3E File Offset: 0x00002E3E
	protected void DrawImage(Image image, int x, int y)
	{
		if (image == null)
		{
			return;
		}
		this.G.DrawImage(image, x, y, image.Width, image.Height);
	}

	// Token: 0x060000EF RID: 239 RVA: 0x00004A5E File Offset: 0x00002E5E
	protected void DrawGradient(ColorBlend blend, int x, int y, int width, int height)
	{
		this.DrawGradientRectangle = new Rectangle(x, y, width, height);
		this.DrawGradient(blend, this.DrawGradientRectangle);
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x00004A7E File Offset: 0x00002E7E
	protected void DrawGradient(ColorBlend blend, int x, int y, int width, int height, float angle)
	{
		this.DrawGradientRectangle = new Rectangle(x, y, width, height);
		this.DrawGradient(blend, this.DrawGradientRectangle, angle);
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x00004AA0 File Offset: 0x00002EA0
	protected void DrawGradient(ColorBlend blend, Rectangle r)
	{
		this.DrawGradientBrush = new LinearGradientBrush(r, Color.Empty, Color.Empty, 90f);
		this.DrawGradientBrush.InterpolationColors = blend;
		this.G.FillRectangle(this.DrawGradientBrush, r);
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x00004ADB File Offset: 0x00002EDB
	protected void DrawGradient(ColorBlend blend, Rectangle r, float angle)
	{
		this.DrawGradientBrush = new LinearGradientBrush(r, Color.Empty, Color.Empty, angle);
		this.DrawGradientBrush.InterpolationColors = blend;
		this.G.FillRectangle(this.DrawGradientBrush, r);
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x00004B12 File Offset: 0x00002F12
	protected void DrawGradient(Color c1, Color c2, int x, int y, int width, int height)
	{
		this.DrawGradientRectangle = new Rectangle(x, y, width, height);
		this.DrawGradient(c1, c2, this.DrawGradientRectangle);
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x00004B34 File Offset: 0x00002F34
	protected void DrawGradient(Color c1, Color c2, int x, int y, int width, int height, float angle)
	{
		this.DrawGradientRectangle = new Rectangle(x, y, width, height);
		this.DrawGradient(c1, c2, this.DrawGradientRectangle, angle);
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x00004B58 File Offset: 0x00002F58
	protected void DrawGradient(Color c1, Color c2, Rectangle r)
	{
		this.DrawGradientBrush = new LinearGradientBrush(r, c1, c2, 90f);
		this.G.FillRectangle(this.DrawGradientBrush, r);
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x00004B7F File Offset: 0x00002F7F
	protected void DrawGradient(Color c1, Color c2, Rectangle r, float angle)
	{
		this.DrawGradientBrush = new LinearGradientBrush(r, c1, c2, angle);
		this.G.FillRectangle(this.DrawGradientBrush, r);
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x00004BA3 File Offset: 0x00002FA3
	public void DrawRadial(ColorBlend blend, int x, int y, int width, int height)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(blend, this.DrawRadialRectangle, width / 2, height / 2);
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x00004BCB File Offset: 0x00002FCB
	public void DrawRadial(ColorBlend blend, int x, int y, int width, int height, Point center)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(blend, this.DrawRadialRectangle, center.X, center.Y);
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x00004BF9 File Offset: 0x00002FF9
	public void DrawRadial(ColorBlend blend, int x, int y, int width, int height, int cx, int cy)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(blend, this.DrawRadialRectangle, cx, cy);
	}

	// Token: 0x060000FA RID: 250 RVA: 0x00004C1D File Offset: 0x0000301D
	public void DrawRadial(ColorBlend blend, Rectangle r)
	{
		this.DrawRadial(blend, r, r.Width / 2, r.Height / 2);
	}

	// Token: 0x060000FB RID: 251 RVA: 0x00004C39 File Offset: 0x00003039
	public void DrawRadial(ColorBlend blend, Rectangle r, Point center)
	{
		this.DrawRadial(blend, r, center.X, center.Y);
	}

	// Token: 0x060000FC RID: 252 RVA: 0x00004C54 File Offset: 0x00003054
	public void DrawRadial(ColorBlend blend, Rectangle r, int cx, int cy)
	{
		this.DrawRadialPath.Reset();
		this.DrawRadialPath.AddEllipse(r.X, r.Y, r.Width - 1, r.Height - 1);
		this.DrawRadialBrush1 = new PathGradientBrush(this.DrawRadialPath);
		this.DrawRadialBrush1.CenterPoint = new Point(r.X + cx, r.Y + cy);
		this.DrawRadialBrush1.InterpolationColors = blend;
		if (this.G.SmoothingMode == SmoothingMode.AntiAlias)
		{
			this.G.FillEllipse(this.DrawRadialBrush1, r.X + 1, r.Y + 1, r.Width - 3, r.Height - 3);
			return;
		}
		this.G.FillEllipse(this.DrawRadialBrush1, r);
	}

	// Token: 0x060000FD RID: 253 RVA: 0x00004D32 File Offset: 0x00003132
	protected void DrawRadial(Color c1, Color c2, int x, int y, int width, int height)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(c1, c2, this.DrawRadialRectangle);
	}

	// Token: 0x060000FE RID: 254 RVA: 0x00004D54 File Offset: 0x00003154
	protected void DrawRadial(Color c1, Color c2, int x, int y, int width, int height, float angle)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(c1, c2, this.DrawRadialRectangle, angle);
	}

	// Token: 0x060000FF RID: 255 RVA: 0x00004D78 File Offset: 0x00003178
	protected void DrawRadial(Color c1, Color c2, Rectangle r)
	{
		this.DrawRadialBrush2 = new LinearGradientBrush(r, c1, c2, 90f);
		this.G.FillEllipse(this.DrawRadialBrush2, r);
	}

	// Token: 0x06000100 RID: 256 RVA: 0x00004D9F File Offset: 0x0000319F
	protected void DrawRadial(Color c1, Color c2, Rectangle r, float angle)
	{
		this.DrawRadialBrush2 = new LinearGradientBrush(r, c1, c2, angle);
		this.G.FillEllipse(this.DrawRadialBrush2, r);
	}

	// Token: 0x06000101 RID: 257 RVA: 0x00004DC3 File Offset: 0x000031C3
	public GraphicsPath CreateRound(int x, int y, int width, int height, int slope)
	{
		this.CreateRoundRectangle = new Rectangle(x, y, width, height);
		return this.CreateRound(this.CreateRoundRectangle, slope);
	}

	// Token: 0x06000102 RID: 258 RVA: 0x00004DE4 File Offset: 0x000031E4
	public GraphicsPath CreateRound(Rectangle r, int slope)
	{
		this.CreateRoundPath = new GraphicsPath(FillMode.Winding);
		this.CreateRoundPath.AddArc(r.X, r.Y, slope, slope, 180f, 90f);
		this.CreateRoundPath.AddArc(r.Right - slope, r.Y, slope, slope, 270f, 90f);
		this.CreateRoundPath.AddArc(r.Right - slope, r.Bottom - slope, slope, slope, 0f, 90f);
		this.CreateRoundPath.AddArc(r.X, r.Bottom - slope, slope, slope, 90f, 90f);
		this.CreateRoundPath.CloseFigure();
		return this.CreateRoundPath;
	}

	// Token: 0x04000036 RID: 54
	protected Graphics G;

	// Token: 0x04000037 RID: 55
	protected Bitmap B;

	// Token: 0x04000038 RID: 56
	private bool DoneCreation;

	// Token: 0x04000039 RID: 57
	private bool InPosition;

	// Token: 0x0400003A RID: 58
	protected MouseState State;

	// Token: 0x0400003B RID: 59
	private bool _BackColor;

	// Token: 0x0400003C RID: 60
	private bool _NoRounding;

	// Token: 0x0400003D RID: 61
	private Image _Image;

	// Token: 0x0400003E RID: 62
	private bool _Transparent;

	// Token: 0x0400003F RID: 63
	private Dictionary<string, Color> Items = new Dictionary<string, Color>();

	// Token: 0x04000040 RID: 64
	private string _Customization;

	// Token: 0x04000041 RID: 65
	private Size _ImageSize;

	// Token: 0x04000042 RID: 66
	private int _LockWidth;

	// Token: 0x04000043 RID: 67
	private int _LockHeight;

	// Token: 0x04000044 RID: 68
	private bool _IsAnimated;

	// Token: 0x04000045 RID: 69
	private Rectangle OffsetReturnRectangle;

	// Token: 0x04000046 RID: 70
	private Size OffsetReturnSize;

	// Token: 0x04000047 RID: 71
	private Point OffsetReturnPoint;

	// Token: 0x04000048 RID: 72
	private Point CenterReturn;

	// Token: 0x04000049 RID: 73
	private Bitmap MeasureBitmap;

	// Token: 0x0400004A RID: 74
	private Graphics MeasureGraphics;

	// Token: 0x0400004B RID: 75
	private SolidBrush DrawPixelBrush;

	// Token: 0x0400004C RID: 76
	private SolidBrush DrawCornersBrush;

	// Token: 0x0400004D RID: 77
	private Point DrawTextPoint;

	// Token: 0x0400004E RID: 78
	private Size DrawTextSize;

	// Token: 0x0400004F RID: 79
	private Point DrawImagePoint;

	// Token: 0x04000050 RID: 80
	private LinearGradientBrush DrawGradientBrush;

	// Token: 0x04000051 RID: 81
	private Rectangle DrawGradientRectangle;

	// Token: 0x04000052 RID: 82
	private GraphicsPath DrawRadialPath;

	// Token: 0x04000053 RID: 83
	private PathGradientBrush DrawRadialBrush1;

	// Token: 0x04000054 RID: 84
	private LinearGradientBrush DrawRadialBrush2;

	// Token: 0x04000055 RID: 85
	private Rectangle DrawRadialRectangle;

	// Token: 0x04000056 RID: 86
	private GraphicsPath CreateRoundPath;

	// Token: 0x04000057 RID: 87
	private Rectangle CreateRoundRectangle;
}
