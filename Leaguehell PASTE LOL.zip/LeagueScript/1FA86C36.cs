﻿using System;

// Token: 0x02000033 RID: 51
public enum 1FA86C36
{
	// Token: 0x0400013C RID: 316
	Ok,
	// Token: 0x0400013D RID: 317
	NoConnection,
	// Token: 0x0400013E RID: 318
	BadReply,
	// Token: 0x0400013F RID: 319
	Banned,
	// Token: 0x04000140 RID: 320
	Corrupted,
	// Token: 0x04000141 RID: 321
	BadCode,
	// Token: 0x04000142 RID: 322
	AlreadyUsed,
	// Token: 0x04000143 RID: 323
	SerialUnknown,
	// Token: 0x04000144 RID: 324
	Expired,
	// Token: 0x04000145 RID: 325
	NotAvailable
}
