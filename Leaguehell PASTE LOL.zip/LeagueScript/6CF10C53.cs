﻿using System;

// Token: 0x02000031 RID: 49
public enum 6CF10C53
{
	// Token: 0x0400012C RID: 300
	Success,
	// Token: 0x0400012D RID: 301
	Corrupted,
	// Token: 0x0400012E RID: 302
	Invalid,
	// Token: 0x0400012F RID: 303
	Blacklisted = 4,
	// Token: 0x04000130 RID: 304
	DateExpired = 8,
	// Token: 0x04000131 RID: 305
	RunningTimeOver = 16,
	// Token: 0x04000132 RID: 306
	BadHwid = 32,
	// Token: 0x04000133 RID: 307
	MaxBuildExpired = 64
}
