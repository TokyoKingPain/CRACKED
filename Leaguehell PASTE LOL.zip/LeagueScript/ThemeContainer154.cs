﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

// Token: 0x02000002 RID: 2
internal abstract class ThemeContainer154 : ContainerControl
{
	// Token: 0x06000002 RID: 2 RVA: 0x00002050 File Offset: 0x00000450
	public ThemeContainer154()
	{
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		this._ImageSize = Size.Empty;
		this.Font = new Font("Verdana", 8f);
		this.MeasureBitmap = new Bitmap(1, 1);
		this.MeasureGraphics = Graphics.FromImage(this.MeasureBitmap);
		this.DrawRadialPath = new GraphicsPath();
		this.InvalidateCustimization();
	}

	// Token: 0x06000003 RID: 3 RVA: 0x000020F4 File Offset: 0x000004F4
	protected sealed override void OnHandleCreated(EventArgs e)
	{
		if (this.DoneCreation)
		{
			this.InitializeMessages();
		}
		this.InvalidateCustimization();
		this.ColorHook();
		if (this._LockWidth != 0)
		{
			base.Width = this._LockWidth;
		}
		if (this._LockHeight != 0)
		{
			base.Height = this._LockHeight;
		}
		if (!this._ControlMode)
		{
			base.Dock = DockStyle.Fill;
		}
		this.Transparent = this._Transparent;
		if (this._Transparent && this._BackColor)
		{
			this.BackColor = Color.Transparent;
		}
		base.OnHandleCreated(e);
	}

	// Token: 0x06000004 RID: 4 RVA: 0x00002180 File Offset: 0x00000580
	protected sealed override void OnParentChanged(EventArgs e)
	{
		base.OnParentChanged(e);
		if (base.Parent == null)
		{
			return;
		}
		this._IsParentForm = (base.Parent is Form);
		if (!this._ControlMode)
		{
			this.InitializeMessages();
			if (this._IsParentForm)
			{
				base.ParentForm.FormBorderStyle = this._BorderStyle;
				base.ParentForm.TransparencyKey = this._TransparencyKey;
				if (!base.DesignMode)
				{
					base.ParentForm.Shown += this.FormShown;
				}
			}
			base.Parent.BackColor = this.BackColor;
		}
		this.OnCreation();
		this.DoneCreation = true;
		this.InvalidateTimer();
	}

	// Token: 0x06000005 RID: 5 RVA: 0x0000222C File Offset: 0x0000062C
	private void DoAnimation(bool i)
	{
		this.OnAnimation();
		if (i)
		{
			base.Invalidate();
		}
	}

	// Token: 0x06000006 RID: 6 RVA: 0x00002240 File Offset: 0x00000640
	protected sealed override void OnPaint(PaintEventArgs e)
	{
		if (base.Width == 0 || base.Height == 0)
		{
			return;
		}
		if (this._Transparent && this._ControlMode)
		{
			this.PaintHook();
			e.Graphics.DrawImage(this.B, 0, 0);
			return;
		}
		this.G = e.Graphics;
		this.PaintHook();
	}

	// Token: 0x06000007 RID: 7 RVA: 0x0000229A File Offset: 0x0000069A
	protected override void OnHandleDestroyed(EventArgs e)
	{
		ThemeShare.RemoveAnimationCallback(new ThemeShare.AnimationDelegate(this.DoAnimation));
		base.OnHandleDestroyed(e);
	}

	// Token: 0x06000008 RID: 8 RVA: 0x000022B4 File Offset: 0x000006B4
	private void FormShown(object sender, EventArgs e)
	{
		if (this._ControlMode || this.HasShown)
		{
			return;
		}
		if (this._StartPosition == FormStartPosition.CenterParent || this._StartPosition == FormStartPosition.CenterScreen)
		{
			Rectangle bounds = Screen.PrimaryScreen.Bounds;
			Rectangle bounds2 = base.ParentForm.Bounds;
			base.ParentForm.Location = new Point(bounds.Width / 2 - bounds2.Width / 2, bounds.Height / 2 - bounds2.Width / 2);
		}
		this.HasShown = true;
	}

	// Token: 0x06000009 RID: 9 RVA: 0x00002338 File Offset: 0x00000738
	protected sealed override void OnSizeChanged(EventArgs e)
	{
		if (this._Movable && !this._ControlMode)
		{
			this.Frame = new Rectangle(7, 7, base.Width - 14, this._Header - 7);
		}
		this.InvalidateBitmap();
		base.Invalidate();
		base.OnSizeChanged(e);
	}

	// Token: 0x0600000A RID: 10 RVA: 0x00002386 File Offset: 0x00000786
	protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
	{
		if (this._LockWidth != 0)
		{
			width = this._LockWidth;
		}
		if (this._LockHeight != 0)
		{
			height = this._LockHeight;
		}
		base.SetBoundsCore(x, y, width, height, specified);
	}

	// Token: 0x0600000B RID: 11 RVA: 0x000023B5 File Offset: 0x000007B5
	private void SetState(MouseState current)
	{
		this.State = current;
		base.Invalidate();
	}

	// Token: 0x0600000C RID: 12 RVA: 0x000023C4 File Offset: 0x000007C4
	protected override void OnMouseMove(MouseEventArgs e)
	{
		if ((!this._IsParentForm || base.ParentForm.WindowState != FormWindowState.Maximized) && this._Sizable && !this._ControlMode)
		{
			this.InvalidateMouse();
		}
		base.OnMouseMove(e);
	}

	// Token: 0x0600000D RID: 13 RVA: 0x000023F9 File Offset: 0x000007F9
	protected override void OnEnabledChanged(EventArgs e)
	{
		if (base.Enabled)
		{
			this.SetState(MouseState.None);
		}
		else
		{
			this.SetState(MouseState.Block);
		}
		base.OnEnabledChanged(e);
	}

	// Token: 0x0600000E RID: 14 RVA: 0x0000241A File Offset: 0x0000081A
	protected override void OnMouseEnter(EventArgs e)
	{
		this.SetState(MouseState.Over);
		base.OnMouseEnter(e);
	}

	// Token: 0x0600000F RID: 15 RVA: 0x0000242A File Offset: 0x0000082A
	protected override void OnMouseUp(MouseEventArgs e)
	{
		this.SetState(MouseState.Over);
		base.OnMouseUp(e);
	}

	// Token: 0x06000010 RID: 16 RVA: 0x0000243C File Offset: 0x0000083C
	protected override void OnMouseLeave(EventArgs e)
	{
		this.SetState(MouseState.None);
		if (base.GetChildAtPoint(base.PointToClient(Control.MousePosition)) != null && this._Sizable && !this._ControlMode)
		{
			this.Cursor = Cursors.Default;
			this.Previous = 0;
		}
		base.OnMouseLeave(e);
	}

	// Token: 0x06000011 RID: 17 RVA: 0x0000248C File Offset: 0x0000088C
	protected override void OnMouseDown(MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			this.SetState(MouseState.Down);
		}
		if ((!this._IsParentForm || base.ParentForm.WindowState != FormWindowState.Maximized) && !this._ControlMode)
		{
			if (this._Movable && this.Frame.Contains(e.Location))
			{
				base.Capture = false;
				this.WM_LMBUTTONDOWN = true;
				this.DefWndProc(ref this.Messages[0]);
			}
			else if (this._Sizable && this.Previous != 0)
			{
				base.Capture = false;
				this.WM_LMBUTTONDOWN = true;
				this.DefWndProc(ref this.Messages[this.Previous]);
			}
		}
		base.OnMouseDown(e);
	}

	// Token: 0x06000012 RID: 18 RVA: 0x00002544 File Offset: 0x00000944
	protected override void WndProc(ref Message m)
	{
		base.WndProc(ref m);
		if (this.WM_LMBUTTONDOWN && m.Msg == 513)
		{
			this.WM_LMBUTTONDOWN = false;
			this.SetState(MouseState.Over);
			if (!this._SmartBounds)
			{
				return;
			}
			if (this.IsParentMdi)
			{
				this.CorrectBounds(new Rectangle(Point.Empty, base.Parent.Parent.Size));
				return;
			}
			this.CorrectBounds(Screen.FromControl(base.Parent).WorkingArea);
		}
	}

	// Token: 0x06000013 RID: 19 RVA: 0x000025C4 File Offset: 0x000009C4
	private int GetIndex()
	{
		this.GetIndexPoint = base.PointToClient(Control.MousePosition);
		this.B1 = (this.GetIndexPoint.X < 7);
		this.B2 = (this.GetIndexPoint.X > base.Width - 7);
		this.B3 = (this.GetIndexPoint.Y < 7);
		this.B4 = (this.GetIndexPoint.Y > base.Height - 7);
		if (this.B1 && this.B3)
		{
			return 4;
		}
		if (this.B1 && this.B4)
		{
			return 7;
		}
		if (this.B2 && this.B3)
		{
			return 5;
		}
		if (this.B2 && this.B4)
		{
			return 8;
		}
		if (this.B1)
		{
			return 1;
		}
		if (this.B2)
		{
			return 2;
		}
		if (this.B3)
		{
			return 3;
		}
		if (this.B4)
		{
			return 6;
		}
		return 0;
	}

	// Token: 0x06000014 RID: 20 RVA: 0x000026B4 File Offset: 0x00000AB4
	private void InvalidateMouse()
	{
		this.Current = this.GetIndex();
		if (this.Current == this.Previous)
		{
			return;
		}
		this.Previous = this.Current;
		switch (this.Previous)
		{
		case 0:
			this.Cursor = Cursors.Default;
			return;
		case 1:
		case 2:
			this.Cursor = Cursors.SizeWE;
			return;
		case 3:
		case 6:
			this.Cursor = Cursors.SizeNS;
			return;
		case 4:
		case 8:
			this.Cursor = Cursors.SizeNWSE;
			return;
		case 5:
		case 7:
			this.Cursor = Cursors.SizeNESW;
			return;
		default:
			return;
		}
	}

	// Token: 0x06000015 RID: 21 RVA: 0x00002758 File Offset: 0x00000B58
	private void InitializeMessages()
	{
		this.Messages[0] = Message.Create(base.Parent.Handle, 161, new IntPtr(2), IntPtr.Zero);
		for (int i = 1; i <= 8; i++)
		{
			this.Messages[i] = Message.Create(base.Parent.Handle, 161, new IntPtr(i + 9), IntPtr.Zero);
		}
	}

	// Token: 0x06000016 RID: 22 RVA: 0x000027CC File Offset: 0x00000BCC
	private void CorrectBounds(Rectangle bounds)
	{
		if (base.Parent.Width > bounds.Width)
		{
			base.Parent.Width = bounds.Width;
		}
		if (base.Parent.Height > bounds.Height)
		{
			base.Parent.Height = bounds.Height;
		}
		int num = base.Parent.Location.X;
		int num2 = base.Parent.Location.Y;
		if (num < bounds.X)
		{
			num = bounds.X;
		}
		if (num2 < bounds.Y)
		{
			num2 = bounds.Y;
		}
		int num3 = bounds.X + bounds.Width;
		int num4 = bounds.Y + bounds.Height;
		if (num + base.Parent.Width > num3)
		{
			num = num3 - base.Parent.Width;
		}
		if (num2 + base.Parent.Height > num4)
		{
			num2 = num4 - base.Parent.Height;
		}
		base.Parent.Location = new Point(num, num2);
	}

	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000017 RID: 23 RVA: 0x000028E1 File Offset: 0x00000CE1
	// (set) Token: 0x06000018 RID: 24 RVA: 0x000028E9 File Offset: 0x00000CE9
	public override DockStyle Dock
	{
		get
		{
			return base.Dock;
		}
		set
		{
			if (!this._ControlMode)
			{
				return;
			}
			base.Dock = value;
		}
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000019 RID: 25 RVA: 0x000028FB File Offset: 0x00000CFB
	// (set) Token: 0x0600001A RID: 26 RVA: 0x00002904 File Offset: 0x00000D04
	[Category("Misc")]
	public override Color BackColor
	{
		get
		{
			return base.BackColor;
		}
		set
		{
			if (value == base.BackColor)
			{
				return;
			}
			if (!base.IsHandleCreated && this._ControlMode && value == Color.Transparent)
			{
				this._BackColor = true;
				return;
			}
			base.BackColor = value;
			if (base.Parent != null)
			{
				if (!this._ControlMode)
				{
					base.Parent.BackColor = value;
				}
				this.ColorHook();
			}
		}
	}

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x0600001B RID: 27 RVA: 0x0000296E File Offset: 0x00000D6E
	// (set) Token: 0x0600001C RID: 28 RVA: 0x00002976 File Offset: 0x00000D76
	public override Size MinimumSize
	{
		get
		{
			return base.MinimumSize;
		}
		set
		{
			base.MinimumSize = value;
			if (base.Parent != null)
			{
				base.Parent.MinimumSize = value;
			}
		}
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x0600001D RID: 29 RVA: 0x00002993 File Offset: 0x00000D93
	// (set) Token: 0x0600001E RID: 30 RVA: 0x0000299B File Offset: 0x00000D9B
	public override Size MaximumSize
	{
		get
		{
			return base.MaximumSize;
		}
		set
		{
			base.MaximumSize = value;
			if (base.Parent != null)
			{
				base.Parent.MaximumSize = value;
			}
		}
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x0600001F RID: 31 RVA: 0x000029B8 File Offset: 0x00000DB8
	// (set) Token: 0x06000020 RID: 32 RVA: 0x000029C0 File Offset: 0x00000DC0
	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x06000021 RID: 33 RVA: 0x000029CF File Offset: 0x00000DCF
	// (set) Token: 0x06000022 RID: 34 RVA: 0x000029D7 File Offset: 0x00000DD7
	public override Font Font
	{
		get
		{
			return base.Font;
		}
		set
		{
			base.Font = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x06000023 RID: 35 RVA: 0x000029E6 File Offset: 0x00000DE6
	// (set) Token: 0x06000024 RID: 36 RVA: 0x000029ED File Offset: 0x00000DED
	[Browsable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public override Color ForeColor
	{
		get
		{
			return Color.Empty;
		}
		set
		{
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x06000025 RID: 37 RVA: 0x000029EF File Offset: 0x00000DEF
	// (set) Token: 0x06000026 RID: 38 RVA: 0x000029F2 File Offset: 0x00000DF2
	[Browsable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public override Image BackgroundImage
	{
		get
		{
			return null;
		}
		set
		{
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000027 RID: 39 RVA: 0x000029F4 File Offset: 0x00000DF4
	// (set) Token: 0x06000028 RID: 40 RVA: 0x000029F7 File Offset: 0x00000DF7
	[Browsable(false)]
	[EditorBrowsable(EditorBrowsableState.Never)]
	[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
	public override ImageLayout BackgroundImageLayout
	{
		get
		{
			return ImageLayout.None;
		}
		set
		{
		}
	}

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x06000029 RID: 41 RVA: 0x000029F9 File Offset: 0x00000DF9
	// (set) Token: 0x0600002A RID: 42 RVA: 0x00002A01 File Offset: 0x00000E01
	public bool SmartBounds
	{
		get
		{
			return this._SmartBounds;
		}
		set
		{
			this._SmartBounds = value;
		}
	}

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x0600002B RID: 43 RVA: 0x00002A0A File Offset: 0x00000E0A
	// (set) Token: 0x0600002C RID: 44 RVA: 0x00002A12 File Offset: 0x00000E12
	public bool Movable
	{
		get
		{
			return this._Movable;
		}
		set
		{
			this._Movable = value;
		}
	}

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x0600002D RID: 45 RVA: 0x00002A1B File Offset: 0x00000E1B
	// (set) Token: 0x0600002E RID: 46 RVA: 0x00002A23 File Offset: 0x00000E23
	public bool Sizable
	{
		get
		{
			return this._Sizable;
		}
		set
		{
			this._Sizable = value;
		}
	}

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x0600002F RID: 47 RVA: 0x00002A2C File Offset: 0x00000E2C
	// (set) Token: 0x06000030 RID: 48 RVA: 0x00002A50 File Offset: 0x00000E50
	public Color TransparencyKey
	{
		get
		{
			if (this._IsParentForm && !this._ControlMode)
			{
				return base.ParentForm.TransparencyKey;
			}
			return this._TransparencyKey;
		}
		set
		{
			if (value == this._TransparencyKey)
			{
				return;
			}
			this._TransparencyKey = value;
			if (this._IsParentForm && !this._ControlMode)
			{
				base.ParentForm.TransparencyKey = value;
				this.ColorHook();
			}
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x06000031 RID: 49 RVA: 0x00002A8A File Offset: 0x00000E8A
	// (set) Token: 0x06000032 RID: 50 RVA: 0x00002AAE File Offset: 0x00000EAE
	public FormBorderStyle BorderStyle
	{
		get
		{
			if (this._IsParentForm && !this._ControlMode)
			{
				return base.ParentForm.FormBorderStyle;
			}
			return this._BorderStyle;
		}
		set
		{
			this._BorderStyle = value;
			if (this._IsParentForm && !this._ControlMode)
			{
				base.ParentForm.FormBorderStyle = value;
				if (value != FormBorderStyle.None)
				{
					this.Movable = false;
					this.Sizable = false;
				}
			}
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x06000033 RID: 51 RVA: 0x00002AE4 File Offset: 0x00000EE4
	// (set) Token: 0x06000034 RID: 52 RVA: 0x00002B08 File Offset: 0x00000F08
	public FormStartPosition StartPosition
	{
		get
		{
			if (this._IsParentForm && !this._ControlMode)
			{
				return base.ParentForm.StartPosition;
			}
			return this._StartPosition;
		}
		set
		{
			this._StartPosition = value;
			if (this._IsParentForm && !this._ControlMode)
			{
				base.ParentForm.StartPosition = value;
			}
		}
	}

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x06000035 RID: 53 RVA: 0x00002B2D File Offset: 0x00000F2D
	// (set) Token: 0x06000036 RID: 54 RVA: 0x00002B35 File Offset: 0x00000F35
	public bool NoRounding
	{
		get
		{
			return this._NoRounding;
		}
		set
		{
			this._NoRounding = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000037 RID: 55 RVA: 0x00002B44 File Offset: 0x00000F44
	// (set) Token: 0x06000038 RID: 56 RVA: 0x00002B4C File Offset: 0x00000F4C
	public Image Image
	{
		get
		{
			return this._Image;
		}
		set
		{
			if (value == null)
			{
				this._ImageSize = Size.Empty;
			}
			else
			{
				this._ImageSize = value.Size;
			}
			this._Image = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x06000039 RID: 57 RVA: 0x00002B78 File Offset: 0x00000F78
	// (set) Token: 0x0600003A RID: 58 RVA: 0x00002BD4 File Offset: 0x00000FD4
	public Bloom[] Colors
	{
		get
		{
			List<Bloom> list = new List<Bloom>();
			Dictionary<string, Color>.Enumerator enumerator = this.Items.GetEnumerator();
			while (enumerator.MoveNext())
			{
				List<Bloom> list2 = list;
				KeyValuePair<string, Color> keyValuePair = enumerator.Current;
				string key = keyValuePair.Key;
				keyValuePair = enumerator.Current;
				list2.Add(new Bloom(key, keyValuePair.Value));
			}
			return list.ToArray();
		}
		set
		{
			for (int i = 0; i < value.Length; i++)
			{
				Bloom bloom = value[i];
				if (this.Items.ContainsKey(bloom.Name))
				{
					this.Items[bloom.Name] = bloom.Value;
				}
			}
			this.InvalidateCustimization();
			this.ColorHook();
			base.Invalidate();
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x0600003B RID: 59 RVA: 0x00002C38 File Offset: 0x00001038
	// (set) Token: 0x0600003C RID: 60 RVA: 0x00002C40 File Offset: 0x00001040
	public string Customization
	{
		get
		{
			return this._Customization;
		}
		set
		{
			if (value == this._Customization)
			{
				return;
			}
			Bloom[] colors = this.Colors;
			try
			{
				byte[] value2 = Convert.FromBase64String(value);
				for (int i = 0; i <= colors.Length - 1; i++)
				{
					colors[i].Value = Color.FromArgb(BitConverter.ToInt32(value2, i * 4));
				}
			}
			catch
			{
				return;
			}
			this._Customization = value;
			this.Colors = colors;
			this.ColorHook();
			base.Invalidate();
		}
	}

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x0600003D RID: 61 RVA: 0x00002CC8 File Offset: 0x000010C8
	// (set) Token: 0x0600003E RID: 62 RVA: 0x00002CD0 File Offset: 0x000010D0
	public bool Transparent
	{
		get
		{
			return this._Transparent;
		}
		set
		{
			this._Transparent = value;
			if (!base.IsHandleCreated && !this._ControlMode)
			{
				return;
			}
			if (!value && this.BackColor.A != 255)
			{
				throw new Exception("Unable to change value to false while a transparent BackColor is in use.");
			}
			base.SetStyle(ControlStyles.Opaque, !value);
			base.SetStyle(ControlStyles.SupportsTransparentBackColor, value);
			this.InvalidateBitmap();
			base.Invalidate();
		}
	}

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x0600003F RID: 63 RVA: 0x00002D3B File Offset: 0x0000113B
	protected Size ImageSize
	{
		get
		{
			return this._ImageSize;
		}
	}

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000040 RID: 64 RVA: 0x00002D43 File Offset: 0x00001143
	protected bool IsParentForm
	{
		get
		{
			return this._IsParentForm;
		}
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000041 RID: 65 RVA: 0x00002D4B File Offset: 0x0000114B
	protected bool IsParentMdi
	{
		get
		{
			return base.Parent != null && base.Parent.Parent != null;
		}
	}

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x06000042 RID: 66 RVA: 0x00002D65 File Offset: 0x00001165
	// (set) Token: 0x06000043 RID: 67 RVA: 0x00002D6D File Offset: 0x0000116D
	protected int LockWidth
	{
		get
		{
			return this._LockWidth;
		}
		set
		{
			this._LockWidth = value;
			if (this.LockWidth != 0 && base.IsHandleCreated)
			{
				base.Width = this.LockWidth;
			}
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x06000044 RID: 68 RVA: 0x00002D92 File Offset: 0x00001192
	// (set) Token: 0x06000045 RID: 69 RVA: 0x00002D9A File Offset: 0x0000119A
	protected int LockHeight
	{
		get
		{
			return this._LockHeight;
		}
		set
		{
			this._LockHeight = value;
			if (this.LockHeight != 0 && base.IsHandleCreated)
			{
				base.Height = this.LockHeight;
			}
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x06000046 RID: 70 RVA: 0x00002DBF File Offset: 0x000011BF
	// (set) Token: 0x06000047 RID: 71 RVA: 0x00002DC7 File Offset: 0x000011C7
	protected int Header
	{
		get
		{
			return this._Header;
		}
		set
		{
			this._Header = value;
			if (!this._ControlMode)
			{
				this.Frame = new Rectangle(7, 7, base.Width - 14, value - 7);
				base.Invalidate();
			}
		}
	}

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000048 RID: 72 RVA: 0x00002DF7 File Offset: 0x000011F7
	// (set) Token: 0x06000049 RID: 73 RVA: 0x00002DFF File Offset: 0x000011FF
	protected bool ControlMode
	{
		get
		{
			return this._ControlMode;
		}
		set
		{
			this._ControlMode = value;
			this.Transparent = this._Transparent;
			if (this._Transparent && this._BackColor)
			{
				this.BackColor = Color.Transparent;
			}
			this.InvalidateBitmap();
			base.Invalidate();
		}
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x0600004A RID: 74 RVA: 0x00002E3B File Offset: 0x0000123B
	// (set) Token: 0x0600004B RID: 75 RVA: 0x00002E43 File Offset: 0x00001243
	protected bool IsAnimated
	{
		get
		{
			return this._IsAnimated;
		}
		set
		{
			this._IsAnimated = value;
			this.InvalidateTimer();
		}
	}

	// Token: 0x0600004C RID: 76 RVA: 0x00002E52 File Offset: 0x00001252
	protected Pen GetPen(string name)
	{
		return new Pen(this.Items[name]);
	}

	// Token: 0x0600004D RID: 77 RVA: 0x00002E65 File Offset: 0x00001265
	protected Pen GetPen(string name, float width)
	{
		return new Pen(this.Items[name], width);
	}

	// Token: 0x0600004E RID: 78 RVA: 0x00002E79 File Offset: 0x00001279
	protected SolidBrush GetBrush(string name)
	{
		return new SolidBrush(this.Items[name]);
	}

	// Token: 0x0600004F RID: 79 RVA: 0x00002E8C File Offset: 0x0000128C
	protected Color GetColor(string name)
	{
		return this.Items[name];
	}

	// Token: 0x06000050 RID: 80 RVA: 0x00002E9A File Offset: 0x0000129A
	protected void SetColor(string name, Color value)
	{
		if (this.Items.ContainsKey(name))
		{
			this.Items[name] = value;
			return;
		}
		this.Items.Add(name, value);
	}

	// Token: 0x06000051 RID: 81 RVA: 0x00002EC5 File Offset: 0x000012C5
	protected void SetColor(string name, byte r, byte g, byte b)
	{
		this.SetColor(name, Color.FromArgb((int)r, (int)g, (int)b));
	}

	// Token: 0x06000052 RID: 82 RVA: 0x00002ED7 File Offset: 0x000012D7
	protected void SetColor(string name, byte a, byte r, byte g, byte b)
	{
		this.SetColor(name, Color.FromArgb((int)a, (int)r, (int)g, (int)b));
	}

	// Token: 0x06000053 RID: 83 RVA: 0x00002EEB File Offset: 0x000012EB
	protected void SetColor(string name, byte a, Color value)
	{
		this.SetColor(name, Color.FromArgb((int)a, value));
	}

	// Token: 0x06000054 RID: 84 RVA: 0x00002EFC File Offset: 0x000012FC
	private void InvalidateBitmap()
	{
		if (!this._Transparent || !this._ControlMode)
		{
			this.G = null;
			this.B = null;
			return;
		}
		if (base.Width == 0 || base.Height == 0)
		{
			return;
		}
		this.B = new Bitmap(base.Width, base.Height, PixelFormat.Format32bppPArgb);
		this.G = Graphics.FromImage(this.B);
	}

	// Token: 0x06000055 RID: 85 RVA: 0x00002F68 File Offset: 0x00001368
	private void InvalidateCustimization()
	{
		MemoryStream memoryStream = new MemoryStream(this.Items.Count * 4);
		foreach (Bloom bloom in this.Colors)
		{
			memoryStream.Write(BitConverter.GetBytes(bloom.Value.ToArgb()), 0, 4);
		}
		memoryStream.Close();
		this._Customization = Convert.ToBase64String(memoryStream.ToArray());
	}

	// Token: 0x06000056 RID: 86 RVA: 0x00002FD9 File Offset: 0x000013D9
	private void InvalidateTimer()
	{
		if (base.DesignMode || !this.DoneCreation)
		{
			return;
		}
		if (this._IsAnimated)
		{
			ThemeShare.AddAnimationCallback(new ThemeShare.AnimationDelegate(this.DoAnimation));
			return;
		}
		ThemeShare.RemoveAnimationCallback(new ThemeShare.AnimationDelegate(this.DoAnimation));
	}

	// Token: 0x06000057 RID: 87
	protected abstract void ColorHook();

	// Token: 0x06000058 RID: 88
	protected abstract void PaintHook();

	// Token: 0x06000059 RID: 89 RVA: 0x00003017 File Offset: 0x00001417
	protected virtual void OnCreation()
	{
	}

	// Token: 0x0600005A RID: 90 RVA: 0x00003019 File Offset: 0x00001419
	protected virtual void OnAnimation()
	{
	}

	// Token: 0x0600005B RID: 91 RVA: 0x0000301B File Offset: 0x0000141B
	protected Rectangle Offset(Rectangle r, int amount)
	{
		this.OffsetReturnRectangle = new Rectangle(r.X + amount, r.Y + amount, r.Width - amount * 2, r.Height - amount * 2);
		return this.OffsetReturnRectangle;
	}

	// Token: 0x0600005C RID: 92 RVA: 0x00003056 File Offset: 0x00001456
	protected Size Offset(Size s, int amount)
	{
		this.OffsetReturnSize = new Size(s.Width + amount, s.Height + amount);
		return this.OffsetReturnSize;
	}

	// Token: 0x0600005D RID: 93 RVA: 0x0000307B File Offset: 0x0000147B
	protected Point Offset(Point p, int amount)
	{
		this.OffsetReturnPoint = new Point(p.X + amount, p.Y + amount);
		return this.OffsetReturnPoint;
	}

	// Token: 0x0600005E RID: 94 RVA: 0x000030A0 File Offset: 0x000014A0
	protected Point Center(Rectangle p, Rectangle c)
	{
		this.CenterReturn = new Point(p.Width / 2 - c.Width / 2 + p.X + c.X, p.Height / 2 - c.Height / 2 + p.Y + c.Y);
		return this.CenterReturn;
	}

	// Token: 0x0600005F RID: 95 RVA: 0x00003104 File Offset: 0x00001504
	protected Point Center(Rectangle p, Size c)
	{
		this.CenterReturn = new Point(p.Width / 2 - c.Width / 2 + p.X, p.Height / 2 - c.Height / 2 + p.Y);
		return this.CenterReturn;
	}

	// Token: 0x06000060 RID: 96 RVA: 0x00003158 File Offset: 0x00001558
	protected Point Center(Rectangle child)
	{
		return this.Center(base.Width, base.Height, child.Width, child.Height);
	}

	// Token: 0x06000061 RID: 97 RVA: 0x0000317A File Offset: 0x0000157A
	protected Point Center(Size child)
	{
		return this.Center(base.Width, base.Height, child.Width, child.Height);
	}

	// Token: 0x06000062 RID: 98 RVA: 0x0000319C File Offset: 0x0000159C
	protected Point Center(int childWidth, int childHeight)
	{
		return this.Center(base.Width, base.Height, childWidth, childHeight);
	}

	// Token: 0x06000063 RID: 99 RVA: 0x000031B2 File Offset: 0x000015B2
	protected Point Center(Size p, Size c)
	{
		return this.Center(p.Width, p.Height, c.Width, c.Height);
	}

	// Token: 0x06000064 RID: 100 RVA: 0x000031D6 File Offset: 0x000015D6
	protected Point Center(int pWidth, int pHeight, int cWidth, int cHeight)
	{
		this.CenterReturn = new Point(pWidth / 2 - cWidth / 2, pHeight / 2 - cHeight / 2);
		return this.CenterReturn;
	}

	// Token: 0x06000065 RID: 101 RVA: 0x000031F8 File Offset: 0x000015F8
	protected Size Measure()
	{
		Graphics measureGraphics = this.MeasureGraphics;
		Size result;
		lock (measureGraphics)
		{
			result = this.MeasureGraphics.MeasureString(this.Text, this.Font, base.Width).ToSize();
		}
		return result;
	}

	// Token: 0x06000066 RID: 102 RVA: 0x0000325C File Offset: 0x0000165C
	protected Size Measure(string text)
	{
		Graphics measureGraphics = this.MeasureGraphics;
		Size result;
		lock (measureGraphics)
		{
			result = this.MeasureGraphics.MeasureString(text, this.Font, base.Width).ToSize();
		}
		return result;
	}

	// Token: 0x06000067 RID: 103 RVA: 0x000032B8 File Offset: 0x000016B8
	protected void DrawPixel(Color c1, int x, int y)
	{
		if (this._Transparent)
		{
			this.B.SetPixel(x, y, c1);
			return;
		}
		this.DrawPixelBrush = new SolidBrush(c1);
		this.G.FillRectangle(this.DrawPixelBrush, x, y, 1, 1);
	}

	// Token: 0x06000068 RID: 104 RVA: 0x000032F2 File Offset: 0x000016F2
	protected void DrawCorners(Color c1, int offset)
	{
		this.DrawCorners(c1, 0, 0, base.Width, base.Height, offset);
	}

	// Token: 0x06000069 RID: 105 RVA: 0x0000330A File Offset: 0x0000170A
	protected void DrawCorners(Color c1, Rectangle r1, int offset)
	{
		this.DrawCorners(c1, r1.X, r1.Y, r1.Width, r1.Height, offset);
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00003330 File Offset: 0x00001730
	protected void DrawCorners(Color c1, int x, int y, int width, int height, int offset)
	{
		this.DrawCorners(c1, x + offset, y + offset, width - offset * 2, height - offset * 2);
	}

	// Token: 0x0600006B RID: 107 RVA: 0x0000334F File Offset: 0x0000174F
	protected void DrawCorners(Color c1)
	{
		this.DrawCorners(c1, 0, 0, base.Width, base.Height);
	}

	// Token: 0x0600006C RID: 108 RVA: 0x00003366 File Offset: 0x00001766
	protected void DrawCorners(Color c1, Rectangle r1)
	{
		this.DrawCorners(c1, r1.X, r1.Y, r1.Width, r1.Height);
	}

	// Token: 0x0600006D RID: 109 RVA: 0x0000338C File Offset: 0x0000178C
	protected void DrawCorners(Color c1, int x, int y, int width, int height)
	{
		if (this._NoRounding)
		{
			return;
		}
		if (this._Transparent)
		{
			this.B.SetPixel(x, y, c1);
			this.B.SetPixel(x + (width - 1), y, c1);
			this.B.SetPixel(x, y + (height - 1), c1);
			this.B.SetPixel(x + (width - 1), y + (height - 1), c1);
			return;
		}
		this.DrawCornersBrush = new SolidBrush(c1);
		this.G.FillRectangle(this.DrawCornersBrush, x, y, 1, 1);
		this.G.FillRectangle(this.DrawCornersBrush, x + (width - 1), y, 1, 1);
		this.G.FillRectangle(this.DrawCornersBrush, x, y + (height - 1), 1, 1);
		this.G.FillRectangle(this.DrawCornersBrush, x + (width - 1), y + (height - 1), 1, 1);
	}

	// Token: 0x0600006E RID: 110 RVA: 0x0000346B File Offset: 0x0000186B
	protected void DrawBorders(Pen p1, int offset)
	{
		this.DrawBorders(p1, 0, 0, base.Width, base.Height, offset);
	}

	// Token: 0x0600006F RID: 111 RVA: 0x00003483 File Offset: 0x00001883
	protected void DrawBorders(Pen p1, Rectangle r, int offset)
	{
		this.DrawBorders(p1, r.X, r.Y, r.Width, r.Height, offset);
	}

	// Token: 0x06000070 RID: 112 RVA: 0x000034A9 File Offset: 0x000018A9
	protected void DrawBorders(Pen p1, int x, int y, int width, int height, int offset)
	{
		this.DrawBorders(p1, x + offset, y + offset, width - offset * 2, height - offset * 2);
	}

	// Token: 0x06000071 RID: 113 RVA: 0x000034C8 File Offset: 0x000018C8
	protected void DrawBorders(Pen p1)
	{
		this.DrawBorders(p1, 0, 0, base.Width, base.Height);
	}

	// Token: 0x06000072 RID: 114 RVA: 0x000034DF File Offset: 0x000018DF
	protected void DrawBorders(Pen p1, Rectangle r)
	{
		this.DrawBorders(p1, r.X, r.Y, r.Width, r.Height);
	}

	// Token: 0x06000073 RID: 115 RVA: 0x00003504 File Offset: 0x00001904
	protected void DrawBorders(Pen p1, int x, int y, int width, int height)
	{
		this.G.DrawRectangle(p1, x, y, width - 1, height - 1);
	}

	// Token: 0x06000074 RID: 116 RVA: 0x0000351C File Offset: 0x0000191C
	protected void DrawText(Brush b1, HorizontalAlignment a, int x, int y)
	{
		this.DrawText(b1, this.Text, a, x, y);
	}

	// Token: 0x06000075 RID: 117 RVA: 0x00003530 File Offset: 0x00001930
	protected void DrawText(Brush b1, string text, HorizontalAlignment a, int x, int y)
	{
		if (text.Length == 0)
		{
			return;
		}
		this.DrawTextSize = this.Measure(text);
		this.DrawTextPoint = new Point(base.Width / 2 - this.DrawTextSize.Width / 2, this.Header / 2 - this.DrawTextSize.Height / 2);
		switch (a)
		{
		case HorizontalAlignment.Left:
			this.G.DrawString(text, this.Font, b1, (float)x, (float)(this.DrawTextPoint.Y + y));
			return;
		case HorizontalAlignment.Right:
			this.G.DrawString(text, this.Font, b1, (float)(base.Width - this.DrawTextSize.Width - x), (float)(this.DrawTextPoint.Y + y));
			return;
		case HorizontalAlignment.Center:
			this.G.DrawString(text, this.Font, b1, (float)(this.DrawTextPoint.X + x), (float)(this.DrawTextPoint.Y + y));
			return;
		default:
			return;
		}
	}

	// Token: 0x06000076 RID: 118 RVA: 0x0000362D File Offset: 0x00001A2D
	protected void DrawText(Brush b1, Point p1)
	{
		if (this.Text.Length == 0)
		{
			return;
		}
		this.G.DrawString(this.Text, this.Font, b1, p1);
	}

	// Token: 0x06000077 RID: 119 RVA: 0x0000365B File Offset: 0x00001A5B
	protected void DrawText(Brush b1, int x, int y)
	{
		if (this.Text.Length == 0)
		{
			return;
		}
		this.G.DrawString(this.Text, this.Font, b1, (float)x, (float)y);
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00003687 File Offset: 0x00001A87
	protected void DrawImage(HorizontalAlignment a, int x, int y)
	{
		this.DrawImage(this._Image, a, x, y);
	}

	// Token: 0x06000079 RID: 121 RVA: 0x00003698 File Offset: 0x00001A98
	protected void DrawImage(Image image, HorizontalAlignment a, int x, int y)
	{
		if (image == null)
		{
			return;
		}
		this.DrawImagePoint = new Point(base.Width / 2 - image.Width / 2, this.Header / 2 - image.Height / 2);
		switch (a)
		{
		case HorizontalAlignment.Left:
			this.G.DrawImage(image, x, this.DrawImagePoint.Y + y, image.Width, image.Height);
			return;
		case HorizontalAlignment.Right:
			this.G.DrawImage(image, base.Width - image.Width - x, this.DrawImagePoint.Y + y, image.Width, image.Height);
			return;
		case HorizontalAlignment.Center:
			this.G.DrawImage(image, this.DrawImagePoint.X + x, this.DrawImagePoint.Y + y, image.Width, image.Height);
			return;
		default:
			return;
		}
	}

	// Token: 0x0600007A RID: 122 RVA: 0x0000377A File Offset: 0x00001B7A
	protected void DrawImage(Point p1)
	{
		this.DrawImage(this._Image, p1.X, p1.Y);
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00003796 File Offset: 0x00001B96
	protected void DrawImage(int x, int y)
	{
		this.DrawImage(this._Image, x, y);
	}

	// Token: 0x0600007C RID: 124 RVA: 0x000037A6 File Offset: 0x00001BA6
	protected void DrawImage(Image image, Point p1)
	{
		this.DrawImage(image, p1.X, p1.Y);
	}

	// Token: 0x0600007D RID: 125 RVA: 0x000037BD File Offset: 0x00001BBD
	protected void DrawImage(Image image, int x, int y)
	{
		if (image == null)
		{
			return;
		}
		this.G.DrawImage(image, x, y, image.Width, image.Height);
	}

	// Token: 0x0600007E RID: 126 RVA: 0x000037DD File Offset: 0x00001BDD
	protected void DrawGradient(ColorBlend blend, int x, int y, int width, int height)
	{
		this.DrawGradientRectangle = new Rectangle(x, y, width, height);
		this.DrawGradient(blend, this.DrawGradientRectangle);
	}

	// Token: 0x0600007F RID: 127 RVA: 0x000037FD File Offset: 0x00001BFD
	protected void DrawGradient(ColorBlend blend, int x, int y, int width, int height, float angle)
	{
		this.DrawGradientRectangle = new Rectangle(x, y, width, height);
		this.DrawGradient(blend, this.DrawGradientRectangle, angle);
	}

	// Token: 0x06000080 RID: 128 RVA: 0x0000381F File Offset: 0x00001C1F
	protected void DrawGradient(ColorBlend blend, Rectangle r)
	{
		this.DrawGradientBrush = new LinearGradientBrush(r, Color.Empty, Color.Empty, 90f);
		this.DrawGradientBrush.InterpolationColors = blend;
		this.G.FillRectangle(this.DrawGradientBrush, r);
	}

	// Token: 0x06000081 RID: 129 RVA: 0x0000385A File Offset: 0x00001C5A
	protected void DrawGradient(ColorBlend blend, Rectangle r, float angle)
	{
		this.DrawGradientBrush = new LinearGradientBrush(r, Color.Empty, Color.Empty, angle);
		this.DrawGradientBrush.InterpolationColors = blend;
		this.G.FillRectangle(this.DrawGradientBrush, r);
	}

	// Token: 0x06000082 RID: 130 RVA: 0x00003891 File Offset: 0x00001C91
	protected void DrawGradient(Color c1, Color c2, int x, int y, int width, int height)
	{
		this.DrawGradientRectangle = new Rectangle(x, y, width, height);
		this.DrawGradient(c1, c2, this.DrawGradientRectangle);
	}

	// Token: 0x06000083 RID: 131 RVA: 0x000038B3 File Offset: 0x00001CB3
	protected void DrawGradient(Color c1, Color c2, int x, int y, int width, int height, float angle)
	{
		this.DrawGradientRectangle = new Rectangle(x, y, width, height);
		this.DrawGradient(c1, c2, this.DrawGradientRectangle, angle);
	}

	// Token: 0x06000084 RID: 132 RVA: 0x000038D7 File Offset: 0x00001CD7
	protected void DrawGradient(Color c1, Color c2, Rectangle r)
	{
		this.DrawGradientBrush = new LinearGradientBrush(r, c1, c2, 90f);
		this.G.FillRectangle(this.DrawGradientBrush, r);
	}

	// Token: 0x06000085 RID: 133 RVA: 0x000038FE File Offset: 0x00001CFE
	protected void DrawGradient(Color c1, Color c2, Rectangle r, float angle)
	{
		this.DrawGradientBrush = new LinearGradientBrush(r, c1, c2, angle);
		this.G.FillRectangle(this.DrawGradientBrush, r);
	}

	// Token: 0x06000086 RID: 134 RVA: 0x00003922 File Offset: 0x00001D22
	public void DrawRadial(ColorBlend blend, int x, int y, int width, int height)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(blend, this.DrawRadialRectangle, width / 2, height / 2);
	}

	// Token: 0x06000087 RID: 135 RVA: 0x0000394A File Offset: 0x00001D4A
	public void DrawRadial(ColorBlend blend, int x, int y, int width, int height, Point center)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(blend, this.DrawRadialRectangle, center.X, center.Y);
	}

	// Token: 0x06000088 RID: 136 RVA: 0x00003978 File Offset: 0x00001D78
	public void DrawRadial(ColorBlend blend, int x, int y, int width, int height, int cx, int cy)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(blend, this.DrawRadialRectangle, cx, cy);
	}

	// Token: 0x06000089 RID: 137 RVA: 0x0000399C File Offset: 0x00001D9C
	public void DrawRadial(ColorBlend blend, Rectangle r)
	{
		this.DrawRadial(blend, r, r.Width / 2, r.Height / 2);
	}

	// Token: 0x0600008A RID: 138 RVA: 0x000039B8 File Offset: 0x00001DB8
	public void DrawRadial(ColorBlend blend, Rectangle r, Point center)
	{
		this.DrawRadial(blend, r, center.X, center.Y);
	}

	// Token: 0x0600008B RID: 139 RVA: 0x000039D0 File Offset: 0x00001DD0
	public void DrawRadial(ColorBlend blend, Rectangle r, int cx, int cy)
	{
		this.DrawRadialPath.Reset();
		this.DrawRadialPath.AddEllipse(r.X, r.Y, r.Width - 1, r.Height - 1);
		this.DrawRadialBrush1 = new PathGradientBrush(this.DrawRadialPath);
		this.DrawRadialBrush1.CenterPoint = new Point(r.X + cx, r.Y + cy);
		this.DrawRadialBrush1.InterpolationColors = blend;
		if (this.G.SmoothingMode == SmoothingMode.AntiAlias)
		{
			this.G.FillEllipse(this.DrawRadialBrush1, r.X + 1, r.Y + 1, r.Width - 3, r.Height - 3);
			return;
		}
		this.G.FillEllipse(this.DrawRadialBrush1, r);
	}

	// Token: 0x0600008C RID: 140 RVA: 0x00003AAE File Offset: 0x00001EAE
	protected void DrawRadial(Color c1, Color c2, int x, int y, int width, int height)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(c1, c2, this.DrawGradientRectangle);
	}

	// Token: 0x0600008D RID: 141 RVA: 0x00003AD0 File Offset: 0x00001ED0
	protected void DrawRadial(Color c1, Color c2, int x, int y, int width, int height, float angle)
	{
		this.DrawRadialRectangle = new Rectangle(x, y, width, height);
		this.DrawRadial(c1, c2, this.DrawGradientRectangle, angle);
	}

	// Token: 0x0600008E RID: 142 RVA: 0x00003AF4 File Offset: 0x00001EF4
	protected void DrawRadial(Color c1, Color c2, Rectangle r)
	{
		this.DrawRadialBrush2 = new LinearGradientBrush(r, c1, c2, 90f);
		this.G.FillRectangle(this.DrawGradientBrush, r);
	}

	// Token: 0x0600008F RID: 143 RVA: 0x00003B1B File Offset: 0x00001F1B
	protected void DrawRadial(Color c1, Color c2, Rectangle r, float angle)
	{
		this.DrawRadialBrush2 = new LinearGradientBrush(r, c1, c2, angle);
		this.G.FillEllipse(this.DrawGradientBrush, r);
	}

	// Token: 0x06000090 RID: 144 RVA: 0x00003B3F File Offset: 0x00001F3F
	public GraphicsPath CreateRound(int x, int y, int width, int height, int slope)
	{
		this.CreateRoundRectangle = new Rectangle(x, y, width, height);
		return this.CreateRound(this.CreateRoundRectangle, slope);
	}

	// Token: 0x06000091 RID: 145 RVA: 0x00003B60 File Offset: 0x00001F60
	public GraphicsPath CreateRound(Rectangle r, int slope)
	{
		this.CreateRoundPath = new GraphicsPath(FillMode.Winding);
		this.CreateRoundPath.AddArc(r.X, r.Y, slope, slope, 180f, 90f);
		this.CreateRoundPath.AddArc(r.Right - slope, r.Y, slope, slope, 270f, 90f);
		this.CreateRoundPath.AddArc(r.Right - slope, r.Bottom - slope, slope, slope, 0f, 90f);
		this.CreateRoundPath.AddArc(r.X, r.Bottom - slope, slope, slope, 90f, 90f);
		this.CreateRoundPath.CloseFigure();
		return this.CreateRoundPath;
	}

	// Token: 0x04000001 RID: 1
	protected Graphics G;

	// Token: 0x04000002 RID: 2
	protected Bitmap B;

	// Token: 0x04000003 RID: 3
	private bool DoneCreation;

	// Token: 0x04000004 RID: 4
	private bool HasShown;

	// Token: 0x04000005 RID: 5
	private Rectangle Frame;

	// Token: 0x04000006 RID: 6
	protected MouseState State;

	// Token: 0x04000007 RID: 7
	private bool WM_LMBUTTONDOWN;

	// Token: 0x04000008 RID: 8
	private Point GetIndexPoint;

	// Token: 0x04000009 RID: 9
	private bool B1;

	// Token: 0x0400000A RID: 10
	private bool B2;

	// Token: 0x0400000B RID: 11
	private bool B3;

	// Token: 0x0400000C RID: 12
	private bool B4;

	// Token: 0x0400000D RID: 13
	private int Current;

	// Token: 0x0400000E RID: 14
	private int Previous;

	// Token: 0x0400000F RID: 15
	private Message[] Messages = new Message[9];

	// Token: 0x04000010 RID: 16
	private bool _BackColor;

	// Token: 0x04000011 RID: 17
	private bool _SmartBounds = true;

	// Token: 0x04000012 RID: 18
	private bool _Movable = true;

	// Token: 0x04000013 RID: 19
	private bool _Sizable = true;

	// Token: 0x04000014 RID: 20
	private Color _TransparencyKey;

	// Token: 0x04000015 RID: 21
	private FormBorderStyle _BorderStyle;

	// Token: 0x04000016 RID: 22
	private FormStartPosition _StartPosition;

	// Token: 0x04000017 RID: 23
	private bool _NoRounding;

	// Token: 0x04000018 RID: 24
	private Image _Image;

	// Token: 0x04000019 RID: 25
	private Dictionary<string, Color> Items = new Dictionary<string, Color>();

	// Token: 0x0400001A RID: 26
	private string _Customization;

	// Token: 0x0400001B RID: 27
	private bool _Transparent;

	// Token: 0x0400001C RID: 28
	private Size _ImageSize;

	// Token: 0x0400001D RID: 29
	private bool _IsParentForm;

	// Token: 0x0400001E RID: 30
	private int _LockWidth;

	// Token: 0x0400001F RID: 31
	private int _LockHeight;

	// Token: 0x04000020 RID: 32
	private int _Header = 24;

	// Token: 0x04000021 RID: 33
	private bool _ControlMode;

	// Token: 0x04000022 RID: 34
	private bool _IsAnimated;

	// Token: 0x04000023 RID: 35
	private Rectangle OffsetReturnRectangle;

	// Token: 0x04000024 RID: 36
	private Size OffsetReturnSize;

	// Token: 0x04000025 RID: 37
	private Point OffsetReturnPoint;

	// Token: 0x04000026 RID: 38
	private Point CenterReturn;

	// Token: 0x04000027 RID: 39
	private Bitmap MeasureBitmap;

	// Token: 0x04000028 RID: 40
	private Graphics MeasureGraphics;

	// Token: 0x04000029 RID: 41
	private SolidBrush DrawPixelBrush;

	// Token: 0x0400002A RID: 42
	private SolidBrush DrawCornersBrush;

	// Token: 0x0400002B RID: 43
	private Point DrawTextPoint;

	// Token: 0x0400002C RID: 44
	private Size DrawTextSize;

	// Token: 0x0400002D RID: 45
	private Point DrawImagePoint;

	// Token: 0x0400002E RID: 46
	private LinearGradientBrush DrawGradientBrush;

	// Token: 0x0400002F RID: 47
	private Rectangle DrawGradientRectangle;

	// Token: 0x04000030 RID: 48
	private GraphicsPath DrawRadialPath;

	// Token: 0x04000031 RID: 49
	private PathGradientBrush DrawRadialBrush1;

	// Token: 0x04000032 RID: 50
	private LinearGradientBrush DrawRadialBrush2;

	// Token: 0x04000033 RID: 51
	private Rectangle DrawRadialRectangle;

	// Token: 0x04000034 RID: 52
	private GraphicsPath CreateRoundPath;

	// Token: 0x04000035 RID: 53
	private Rectangle CreateRoundRectangle;
}
